suppressPackageStartupMessages({library(dplyr);library(tidyr)})
table_dir <- out_dir
class_table_dir <- out_dir
position_class_input <- input_path("position_classes")

# Adapted from Fig5_secretion_mechanism/03_code/microneme_spatial_restriction/ICATkd_MIC2_width_ratio.R, lines 38-42.
position_class_columns <- c(
  "condition", "cell_id", "source_label", "MIC2_width", "Tubulin_width",
  "confinement_index", "source_image", "class_I", "class_II", "class_III",
  "notes"
)

# Adapted from Fig5_secretion_mechanism/03_code/microneme_spatial_restriction/ICATkd_MIC2_width_ratio.R, lines 44-55.
read_mci_from_width_file <- function(file_name, condition) {
  path <- input_path(if(condition=="iKD-vehicle") "vehicle_widths" else "iaa_widths")
  df <- read.csv(
    path,
    header = FALSE,
    col.names = c("source_label", "MIC2_width", "Tubulin_width", "raw_ratio"),
    check.names = FALSE
  )
  df$condition <- condition
  df$source_file <- file_name
  df
}

# Adapted from Fig5_secretion_mechanism/03_code/microneme_spatial_restriction/ICATkd_MIC2_width_ratio.R, lines 57-67.
read_mci_from_width_files <- function() {
  bind_rows(
    read_mci_from_width_file("iKD_vehicle.csv", "iKD-vehicle"),
    read_mci_from_width_file("iKD_IAA.csv", "iKD-IAA")
  ) %>%
    mutate(
      condition = factor(condition, levels = c("iKD-vehicle", "iKD-IAA")),
      cell_id = ave(raw_ratio, condition, FUN = seq_along),
      confinement_index = raw_ratio
    )
}

# Adapted from Fig5_secretion_mechanism/03_code/microneme_spatial_restriction/ICATkd_MIC2_width_ratio.R, lines 86-89.
class_pattern <- function(i, ii, iii) {
  classes <- c("I", "II", "III")[c(i, ii, iii)]
  if (length(classes) == 0) "none" else paste(classes, collapse = "+")
}

# Adapted from Fig5_secretion_mechanism/03_code/microneme_spatial_restriction/ICATkd_MIC2_width_ratio.R, lines 91-97.
dominant_class <- function(i, ii, iii) {
  counts <- c(I = i, II = ii, III = iii)
  if (all(is.na(counts)) || sum(counts, na.rm = TRUE) == 0) {
    return("none")
  }
  paste(names(counts)[counts == max(counts, na.rm = TRUE)], collapse = "+")
}

# Adapted from Fig5_secretion_mechanism/03_code/microneme_spatial_restriction/ICATkd_MIC2_width_ratio.R, lines 99-105.
validate_binary_class <- function(values, column) {
  filled <- values[!is.na(values)]
  invalid <- setdiff(unique(filled), c(0L, 1L))
  if (length(invalid)) {
    stop(column, " must contain only 0, 1, or blank values.")
  }
}

# Adapted from Fig5_secretion_mechanism/03_code/microneme_spatial_restriction/ICATkd_MIC2_width_ratio.R, lines 135-177.
read_position_classes <- function(path, fallback_mci_df) {

  raw <- read_input_table("position_classes")
  for(n in c("source_label","source_image","notes")) if(!n %in% names(raw)) raw[[n]] <- NA_character_
  assert_columns(raw,position_class_columns,"position_classes")
  if(length(cfg$condition_map)) {
    mapped <- unlist(cfg$condition_map)[as.character(raw$condition)]
    if(anyNA(mapped)) stop("Unknown treatment in configured condition_map.")
    raw$condition <- unname(mapped)
  }
  for(n in c("class_I","class_II","class_III")) validate_binary_class(as.numeric(raw[[n]]),n)
  raw <- raw[, position_class_columns]
  if (nrow(raw) == 0) {
    return(raw)
  }
  raw <- raw %>%
    mutate(
      condition = factor(condition, levels = c("iKD-vehicle", "iKD-IAA")),
      cell_id = as.integer(cell_id),
      MIC2_width = as.numeric(MIC2_width),
      Tubulin_width = as.numeric(Tubulin_width),
      confinement_index = as.numeric(confinement_index),
      # Compute missing MCI from the supplied MIC2 and Tubulin widths.
      confinement_index = ifelse(
        is.na(confinement_index) & !is.na(MIC2_width) & !is.na(Tubulin_width) & Tubulin_width > 0,
        MIC2_width / Tubulin_width,
        confinement_index
      ),
      class_I = as.integer(class_I),
      class_II = as.integer(class_II),
      class_III = as.integer(class_III)
    )
  validate_binary_class(raw$class_I, "class_I")
  validate_binary_class(raw$class_II, "class_II")
  validate_binary_class(raw$class_III, "class_III")
  if (any(is.na(raw$condition))) {
    stop("condition must be iKD-vehicle or iKD-IAA.")
  }
  duplicated_cells <- raw %>%
    count(condition, cell_id, name = "n_rows") %>%
    filter(n_rows > 1)
  if (nrow(duplicated_cells) > 0) {
    stop("Duplicate condition/cell_id rows found in position-class table.")
  }
  raw
}

mci_from_width_files <- if(all(c("vehicle_widths","iaa_widths") %in% names(cfg$inputs))) read_mci_from_width_files() else data.frame()
position_classes <- read_position_classes(position_class_input,mci_from_width_files)

# Adapted from Fig5_secretion_mechanism/03_code/microneme_spatial_restriction/ICATkd_MIC2_width_ratio.R, lines 184-195.
mci_from_position_classes <- position_classes %>%
  filter(!is.na(confinement_index)) %>%
  transmute(
    source_label = source_label,
    MIC2_width = MIC2_width,
    Tubulin_width = Tubulin_width,
    raw_ratio = confinement_index,
    condition = condition,
    source_file = basename(position_class_input),
    cell_id = cell_id,
    confinement_index = confinement_index
  )

# Adapted from Fig5_secretion_mechanism/03_code/microneme_spatial_restriction/ICATkd_MIC2_width_ratio.R, lines 197-197.
uses_position_class_mci <- nrow(mci_from_position_classes) > 0

# Adapted from Fig5_secretion_mechanism/03_code/microneme_spatial_restriction/ICATkd_MIC2_width_ratio.R, lines 198-202.
df <- if (uses_position_class_mci) {
  mci_from_position_classes
} else {
  mci_from_width_files
}

# Adapted from Fig5_secretion_mechanism/03_code/microneme_spatial_restriction/ICATkd_MIC2_width_ratio.R, lines 204-208.
mci_source_note <- if (uses_position_class_mci) {
  sprintf("MCI values were read directly from `%s`.", basename(position_class_input))
} else {
  "MCI values were read from the legacy width-ratio raw CSV files because the position-class table contained no MCI values."
}

# Adapted from Fig5_secretion_mechanism/03_code/microneme_spatial_restriction/ICATkd_MIC2_width_ratio.R, lines 210-210.
if(!nrow(df)) stop("No observed MCI values; provide a scored position table or both legacy width files.")
vehicle <- df$confinement_index[df$condition == "iKD-vehicle"]

# Adapted from Fig5_secretion_mechanism/03_code/microneme_spatial_restriction/ICATkd_MIC2_width_ratio.R, lines 211-211.
iaa <- df$confinement_index[df$condition == "iKD-IAA"]

# Adapted from Fig5_secretion_mechanism/03_code/microneme_spatial_restriction/ICATkd_MIC2_width_ratio.R, lines 213-215.
cliffs_delta <- function(x, y) {
  mean(sign(outer(x, y, "-")))
}

# Adapted from Fig5_secretion_mechanism/03_code/microneme_spatial_restriction/ICATkd_MIC2_width_ratio.R, lines 217-225.
bootstrap_mean_difference <- function(mutant, control, iterations = 20000, seed = 20260706) {
  set.seed(seed)
  diffs <- replicate(
    iterations,
    mean(sample(mutant, length(mutant), replace = TRUE)) -
      mean(sample(control, length(control), replace = TRUE))
  )
  as.numeric(quantile(diffs, probs = c(0.025, 0.975), names = FALSE))
}

# Adapted from Fig5_secretion_mechanism/03_code/microneme_spatial_restriction/ICATkd_MIC2_width_ratio.R, lines 227-240.
summary_table <- df %>%
  group_by(condition) %>%
  summarise(
    n_cells = n(),
    mean = mean(confinement_index),
    median = median(confinement_index),
    sd = sd(confinement_index),
    q1 = quantile(confinement_index, 0.25),
    q3 = quantile(confinement_index, 0.75),
    min = min(confinement_index),
    max = max(confinement_index),
    replicate_metadata_present = "no",
    .groups = "drop"
  )

# Adapted from Fig5_secretion_mechanism/03_code/microneme_spatial_restriction/ICATkd_MIC2_width_ratio.R, lines 242-242.
mean_diff <- mean(iaa) - mean(vehicle)

# Adapted from Fig5_secretion_mechanism/03_code/microneme_spatial_restriction/ICATkd_MIC2_width_ratio.R, lines 243-243.
median_diff <- median(iaa) - median(vehicle)

# Adapted from Fig5_secretion_mechanism/03_code/microneme_spatial_restriction/ICATkd_MIC2_width_ratio.R, lines 244-244.
fold_change <- mean(iaa) / mean(vehicle)

# Adapted from Fig5_secretion_mechanism/03_code/microneme_spatial_restriction/ICATkd_MIC2_width_ratio.R, lines 245-245.
delta <- cliffs_delta(iaa, vehicle)

# Adapted from Fig5_secretion_mechanism/03_code/microneme_spatial_restriction/ICATkd_MIC2_width_ratio.R, lines 246-246.
ci <- bootstrap_mean_difference(iaa, vehicle)

# Adapted from Fig5_secretion_mechanism/03_code/microneme_spatial_restriction/ICATkd_MIC2_width_ratio.R, lines 247-247.
vehicle_q95 <- as.numeric(quantile(vehicle, 0.95, names = FALSE))

# Adapted from Fig5_secretion_mechanism/03_code/microneme_spatial_restriction/ICATkd_MIC2_width_ratio.R, lines 248-248.
iaa_above_vehicle_q95 <- mean(iaa > vehicle_q95)

# Adapted from Fig5_secretion_mechanism/03_code/microneme_spatial_restriction/ICATkd_MIC2_width_ratio.R, lines 250-271.
effects_table <- tibble::tibble(
  metric = c(
    "mean_difference_iKD_IAA_minus_iKD_vehicle",
    "cell_level_bootstrap_95CI_low",
    "cell_level_bootstrap_95CI_high",
    "median_difference_iKD_IAA_minus_iKD_vehicle",
    "mean_fold_change_iKD_IAA_over_iKD_vehicle",
    "cliffs_delta_iKD_IAA_vs_iKD_vehicle",
    "iKD_vehicle_95th_percentile",
    "fraction_iKD_IAA_above_iKD_vehicle_95th_percentile"
  ),
  value = c(
    mean_diff,
    ci[[1]],
    ci[[2]],
    median_diff,
    fold_change,
    delta,
    vehicle_q95,
    iaa_above_vehicle_q95
  )
)

# Adapted from Fig5_secretion_mechanism/03_code/microneme_spatial_restriction/ICATkd_MIC2_width_ratio.R, lines 273-273.
write.csv(df, file.path(table_dir, "ICATkd_MCI_long.csv"), row.names = FALSE)

# Adapted from Fig5_secretion_mechanism/03_code/microneme_spatial_restriction/ICATkd_MIC2_width_ratio.R, lines 274-274.
write.csv(summary_table, file.path(table_dir, "ICATkd_MCI_summary.csv"), row.names = FALSE)

# Adapted from Fig5_secretion_mechanism/03_code/microneme_spatial_restriction/ICATkd_MIC2_width_ratio.R, lines 275-275.
write.csv(effects_table, file.path(table_dir, "ICATkd_MCI_effects.csv"), row.names = FALSE)

# Adapted from Fig5_secretion_mechanism/03_code/microneme_spatial_restriction/ICATkd_MIC2_width_ratio.R, lines 277-278.
has_position_class_data <- nrow(position_classes) > 0 &&
  any(!is.na(position_classes$class_I) | !is.na(position_classes$class_II) | !is.na(position_classes$class_III))

# Adapted from Fig5_secretion_mechanism/03_code/microneme_spatial_restriction/ICATkd_MIC2_width_ratio.R, lines 280-372.
if (has_position_class_data) {
  position_classes <- position_classes %>%
    mutate(
      has_class_I = class_I == 1L,
      has_class_II = class_II == 1L,
      has_class_III = class_III == 1L,
      class_richness = has_class_I + has_class_II + has_class_III,
      class_pattern = mapply(class_pattern, has_class_I, has_class_II, has_class_III),
      dominant_class = mapply(dominant_class, class_I, class_II, class_III)
    )

  scored_position_classes <- position_classes %>%
    filter(!is.na(class_I) | !is.na(class_II) | !is.na(class_III))

  mci_key <- df %>%
    distinct(condition, cell_id)

  unmatched_position_classes <- scored_position_classes %>%
    anti_join(mci_key, by = c("condition", "cell_id"))

  mci_with_classes <- df %>%
    select(condition, cell_id, source_file, raw_ratio, confinement_index) %>%
    left_join(
      position_classes %>%
        select(
          condition, cell_id, source_image, class_I, class_II, class_III,
          has_class_I, has_class_II, has_class_III, class_richness,
          class_pattern, dominant_class, notes
        ),
      by = c("condition", "cell_id")
    )

  matched_position_classes <- mci_with_classes %>%
    filter(!is.na(class_I) | !is.na(class_II) | !is.na(class_III))

  class_positive_summary <- scored_position_classes %>%
    group_by(condition) %>%
    summarise(
      n_cells_with_position_data = n(),
      fraction_has_class_I = mean(has_class_I),
      fraction_has_class_II = mean(has_class_II),
      fraction_has_class_III = mean(has_class_III),
      mean_class_richness = mean(class_richness),
      .groups = "drop"
    )

  mci_by_class_pattern <- matched_position_classes %>%
    filter(!is.na(class_pattern)) %>%
    group_by(condition, class_pattern, class_richness, dominant_class) %>%
    summarise(
      n_cells = n(),
      mean_confinement_index = mean(confinement_index),
      median_confinement_index = median(confinement_index),
      sd_confinement_index = ifelse(n() > 1, sd(confinement_index), NA_real_),
      .groups = "drop"
    )

  mci_classIII_quadrant <- matched_position_classes %>%
    mutate(
      class_III_state = factor(ifelse(has_class_III, "III+", "III-"), levels = c("III-", "III+")),
      class_III_y = ifelse(has_class_III, 1, 0),
      mci_state = factor(
        ifelse(confinement_index > vehicle_q95, "High MCI", "Low MCI"),
        levels = c("Low MCI", "High MCI")
      ),
      quadrant = factor(
        paste(mci_state, class_III_state, sep = " / "),
        levels = c("Low MCI / III+", "High MCI / III-", "Low MCI / III-", "High MCI / III+")
      )
    )

  mci_classIII_quadrant_summary <- mci_classIII_quadrant %>%
    count(condition, mci_state, class_III_state, quadrant, name = "n_cells") %>%
    group_by(condition) %>%
    mutate(fraction_within_condition = n_cells / sum(n_cells)) %>%
    ungroup()

  write.csv(position_classes, file.path(class_table_dir, "microneme_position_class_long.csv"), row.names = FALSE)
  write.csv(scored_position_classes, file.path(class_table_dir, "microneme_position_class_scored.csv"), row.names = FALSE)
  write.csv(matched_position_classes, file.path(class_table_dir, "microneme_position_class_MCI_matched.csv"), row.names = FALSE)
  write.csv(class_positive_summary, file.path(class_table_dir, "microneme_position_class_positive_summary.csv"), row.names = FALSE)
  write.csv(mci_by_class_pattern, file.path(class_table_dir, "MCI_by_position_class_pattern.csv"), row.names = FALSE)
  write.csv(mci_classIII_quadrant_summary, file.path(class_table_dir, "MCI_ClassIII_quadrant_summary.csv"), row.names = FALSE)
  write.csv(unmatched_position_classes, file.path(class_table_dir, "microneme_position_class_unmatched_to_MCI.csv"), row.names = FALSE)
} else {
  position_classes <- NULL
  scored_position_classes <- NULL
  mci_with_classes <- NULL
  matched_position_classes <- NULL
  unmatched_position_classes <- NULL
  mci_classIII_quadrant <- NULL
  mci_classIII_quadrant_summary <- NULL
}

# Adapted from Fig5_secretion_mechanism/03_code/microneme_spatial_restriction/ICATkd_MIC2_width_ratio.R, lines 427-445.
make_smoothed_cdf <- function(condition_df, x_limits = c(0, 1), n = 512) {
  values <- condition_df$confinement_index
  density_fit <- density(
    values,
    from = x_limits[[1]],
    to = x_limits[[2]],
    n = n,
    adjust = 1.05,
    na.rm = TRUE
  )
  dx <- c(0, diff(density_fit$x))
  cumulative <- cumsum(density_fit$y * dx)
  cumulative <- cumulative / max(cumulative, na.rm = TRUE)
  data.frame(
    condition = condition_df$condition[[1]],
    confinement_index = density_fit$x,
    cumulative_fraction = cumulative
  )
}

# Adapted from Fig5_secretion_mechanism/03_code/microneme_spatial_restriction/ICATkd_MIC2_width_ratio.R, lines 447-451.
ecdf_smooth_df <- df %>%
  split(.$condition) %>%
  lapply(make_smoothed_cdf, x_limits = c(0, 1)) %>%
  bind_rows() %>%
  mutate(condition = factor(condition, levels = c("iKD-vehicle", "iKD-IAA")))

write_table(ecdf_smooth_df,"MCI_smoothed_cumulative_distribution.csv")

if(has_position_class_data) {

# Adapted from Fig5_secretion_mechanism/03_code/microneme_spatial_restriction/ICATkd_MIC2_width_ratio.R, lines 786-904.
  classIII_probability_cells <- mci_classIII_quadrant %>%
    mutate(has_class_III = class_III_state == "III+")

  mci_bin_breaks <- quantile(
    classIII_probability_cells$confinement_index,
    probs = c(0, 1 / 3, 2 / 3, 1),
    na.rm = TRUE,
    names = FALSE
  )
  mci_bin_breaks[[1]] <- mci_bin_breaks[[1]] - .Machine$double.eps
  mci_bin_labels <- c("Low", "Mid", "High")

  exact_binom_ci <- function(success, total, index) {
    if (is.na(total) || total == 0) {
      return(NA_real_)
    }
    binom.test(success, total)$conf.int[[index]]
  }

  classIII_fraction_by_mci_bin <- classIII_probability_cells %>%
    mutate(
      mci_bin = cut(
        confinement_index,
        breaks = mci_bin_breaks,
        labels = mci_bin_labels,
        include.lowest = TRUE,
        ordered_result = TRUE
      )
    ) %>%
    group_by(mci_bin) %>%
    summarise(
      mci_min = min(confinement_index),
      mci_max = max(confinement_index),
      mci_median = median(confinement_index),
      n_cells = n(),
      n_class_III = sum(has_class_III),
      fraction_class_III = mean(has_class_III),
      .groups = "drop"
    ) %>%
    mutate(
      ci_low = mapply(exact_binom_ci, n_class_III, n_cells, MoreArgs = list(index = 1)),
      ci_high = mapply(exact_binom_ci, n_class_III, n_cells, MoreArgs = list(index = 2))
    )

  classIII_fraction_by_mci_bin_condition <- classIII_probability_cells %>%
    mutate(
      mci_bin = cut(
        confinement_index,
        breaks = mci_bin_breaks,
        labels = mci_bin_labels,
        include.lowest = TRUE,
        ordered_result = TRUE
      )
    ) %>%
    group_by(condition, mci_bin) %>%
    summarise(
      n_cells = n(),
      n_class_III = sum(has_class_III),
      fraction_class_III = mean(has_class_III),
      .groups = "drop"
    ) %>%
    mutate(
      ci_low = mapply(exact_binom_ci, n_class_III, n_cells, MoreArgs = list(index = 1)),
      ci_high = mapply(exact_binom_ci, n_class_III, n_cells, MoreArgs = list(index = 2))
    )

  classIII_probability_fit <- glm(
    has_class_III ~ confinement_index,
    family = binomial(),
    data = classIII_probability_cells
  )
  # Obtain fitted Class III probabilities for each matched cell.
  classIII_probability_cells_fitted <- classIII_probability_cells %>%
    mutate(
      predicted_probability = predict(
        classIII_probability_fit,
        newdata = classIII_probability_cells,
        type = "response"
      )
    )
  probability_curve_df <- data.frame(
    confinement_index = seq(
      min(classIII_probability_cells$confinement_index, na.rm = TRUE),
      max(classIII_probability_cells$confinement_index, na.rm = TRUE),
      length.out = 180
    )
  )
  probability_curve_prediction <- predict(
    classIII_probability_fit,
    newdata = probability_curve_df,
    type = "link",
    se.fit = TRUE
  )
  probability_curve_df <- probability_curve_df %>%
    mutate(
      probability = plogis(probability_curve_prediction$fit),
      ci_low = plogis(probability_curve_prediction$fit - 1.96 * probability_curve_prediction$se.fit),
      ci_high = plogis(probability_curve_prediction$fit + 1.96 * probability_curve_prediction$se.fit)
    )

  classIII_probability_coef <- summary(classIII_probability_fit)$coefficients
  classIII_probability_trend <- data.frame(
    model = "Class III positivity ~ MCI",
    term = "MCI, per 0.1 unit increase",
    log_odds = classIII_probability_coef["confinement_index", "Estimate"] * 0.1,
    se = classIII_probability_coef["confinement_index", "Std. Error"] * 0.1,
    odds_ratio = exp(classIII_probability_coef["confinement_index", "Estimate"] * 0.1),
    ci_low = exp((classIII_probability_coef["confinement_index", "Estimate"] - 1.96 * classIII_probability_coef["confinement_index", "Std. Error"]) * 0.1),
    ci_high = exp((classIII_probability_coef["confinement_index", "Estimate"] + 1.96 * classIII_probability_coef["confinement_index", "Std. Error"]) * 0.1),
    exploratory_p_value = classIII_probability_coef["confinement_index", "Pr(>|z|)"],
    n_cells = nrow(classIII_probability_cells)
  )

  write.csv(classIII_fraction_by_mci_bin, file.path(class_table_dir, "MCI_ClassIII_fraction_by_MCI_bin.csv"), row.names = FALSE)
  write.csv(classIII_fraction_by_mci_bin_condition, file.path(class_table_dir, "MCI_ClassIII_fraction_by_MCI_bin_by_condition.csv"), row.names = FALSE)
  write.csv(classIII_probability_trend, file.path(class_table_dir, "MCI_ClassIII_probability_trend.csv"), row.names = FALSE)

write_table(probability_curve_df,"MCI_ClassIII_model_predictions.csv")
}
