# Validation

Validation date: 2026-11-04. Performed locally using R 4.5.0 and the recorded package versions.

This module completed 2 positive task/configuration runs from an external working directory. It has 9 retained numerical comparison/consistency checks.

| Check | Result | Rows or matched cells |
|---|---|---:|
|MCI: ICATkd_MCI_long.csv|matched|153|
|MCI: ICATkd_MCI_summary.csv|matched|2|
|MCI: ICATkd_MCI_effects.csv|matched|8|
|MCI classes: microneme_position_class_MCI_matched.csv|matched|153|
|MCI classes: MCI_ClassIII_fraction_by_MCI_bin.csv|matched|3|
|MCI classes: MCI_ClassIII_fraction_by_MCI_bin_by_condition.csv|matched|6|
|MCI classes: MCI_ClassIII_probability_trend.csv|matched|1|
|MCI CDF retains both cumulative values, 512 points/group and endpoints|passed|1024|
|current MCI source data vs older inputs|matched|153|

Comparisons use the same external inputs as the original numerical exports. Shared numerical fields are compared with relative tolerance 1e-9 and absolute tolerance 1e-12; missing patterns, keys and categorical fields are checked separately. PCoA geometry is checked independently of axis signs/rotation. Input snapshots, expected result tables, negative-test fixtures and generated results are not included in this package.

All five package entry points, missing-file handling, unknown-task handling and refusal to write inside the code package were checked. Domain checks cover missing fields and duplicate identifiers for every module, plus nonbinary class/presence values and the full-length-to-N-terminal handoff. All checks passed.

349 original external input files retained their pre-run SHA-256 hashes. Package syntax and runtime dependencies were checked. A fresh network/environment installation was not performed; validation reused the installed matching R environment. These tests do not establish availability or redistribution rights for the external datasets.

The current author source-data workbook and older scored CSV matched all 153 cells within the stated numerical tolerance. Both source formats were exercised without changing either input.
