# Runtime environment

R 4.5.0. Direct packages: jsonlite.

The lockfile retains their original recorded versions and runtime dependency closure, without plotting packages. Restore with `renv::restore(lockfile="renv.lock", prompt=FALSE)` after installing renv. The original copyright notice is preserved in LICENSE.
