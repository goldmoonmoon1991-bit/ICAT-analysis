# Validation

Validation date: 2026-11-04. Performed locally using R 4.5.0 and the recorded package versions.

This module completed 8 positive task/configuration runs from an external working directory. It has 44 retained numerical comparison/consistency checks.

| Check | Result | Rows or matched cells |
|---|---|---:|
|profiles WT-MIC2: peak_measurements_per_cell.csv|matched|54|
|profiles WT-MIC2: peak_position_summary.csv|matched|2|
|profiles WT-MIC2: measurement_summary.csv|matched|7|
|profiles WT-MIC2: asymmetry_tests.csv|matched|4|
|profiles WT-MIC2: aligned_profiles_normalized.csv|matched|64908|
|profiles WT-MIC2: mean_profile_normalized.csv|matched|1202|
|profiles ARO: peak_measurements_per_cell.csv|matched|23|
|profiles ARO: peak_position_summary.csv|matched|2|
|profiles ARO: measurement_summary.csv|matched|7|
|profiles ARO: asymmetry_tests.csv|matched|4|
|profiles ARO: aligned_profiles_normalized.csv|matched|27646|
|profiles ARO: mean_profile_normalized.csv|matched|1202|
|profiles ICMAP1-MIC2: peak_measurements_per_cell.csv|matched|30|
|profiles ICMAP1-MIC2: peak_position_summary.csv|matched|2|
|profiles ICMAP1-MIC2: measurement_summary.csv|matched|7|
|profiles ICMAP1-MIC2: asymmetry_tests.csv|matched|4|
|profiles ICMAP1-MIC2: aligned_profiles_normalized.csv|matched|36060|
|profiles ICMAP1-MIC2: mean_profile_normalized.csv|matched|1202|
|profiles ICMAP2-MIC2: peak_measurements_per_cell.csv|matched|17|
|profiles ICMAP2-MIC2: peak_position_summary.csv|matched|2|
|profiles ICMAP2-MIC2: measurement_summary.csv|matched|7|
|profiles ICMAP2-MIC2: asymmetry_tests.csv|matched|4|
|profiles ICMAP2-MIC2: aligned_profiles_normalized.csv|matched|20434|
|profiles ICMAP2-MIC2: mean_profile_normalized.csv|matched|1202|
|profiles ARO-MIC2: peak_measurements_per_cell.csv|matched|20|
|profiles ARO-MIC2: peak_position_summary.csv|matched|2|
|profiles ARO-MIC2: measurement_summary.csv|matched|7|
|profiles ARO-MIC2: asymmetry_tests.csv|matched|4|
|profiles ARO-MIC2: aligned_profiles_normalized.csv|matched|24040|
|profiles ARO-MIC2: mean_profile_normalized.csv|matched|1202|
|ICAT profiles: peak_measurements_per_cell.csv|matched|43|
|ICAT profiles: measurement_summary.csv|matched|7|
|ICAT aligned profiles|matched|51686|
|distances: surface_distances_per_cell.csv|matched|206|
|distances: surface_distance_summary.csv|matched|56|
|distances: microneme_FWHM_width_summary.csv|matched|4|
|distances: microneme_width_thresholds_per_cell.csv|matched|484|
|distances: microneme_B2_width_threshold_comparison.csv|matched|4|
|distances: FWHM_QC_summary.csv|matched|7|
|distances: asymmetry_tests.csv|matched|3|
|distances: zone_separation_tests.csv|matched|2|
|focused ICAT: purple_signal_to_B2_distance_per_cell.csv|matched|43|
|focused ICAT: purple_signal_to_B2_distance_summary.csv|matched|6|
|focused ICAT: purple_signal_to_B2_FWHM_QC.csv|matched|1|

Comparisons use the same external inputs as the original numerical exports. Shared numerical fields are compared with relative tolerance 1e-9 and absolute tolerance 1e-12; missing patterns, keys and categorical fields are checked separately. PCoA geometry is checked independently of axis signs/rotation. Input snapshots, expected result tables, negative-test fixtures and generated results are not included in this package.

All five package entry points, missing-file handling, unknown-task handling and refusal to write inside the code package were checked. Domain checks cover missing fields and duplicate identifiers for every module, plus nonbinary class/presence values and the full-length-to-N-terminal handoff. All checks passed.

349 original external input files retained their pre-run SHA-256 hashes. Package syntax and runtime dependencies were checked. A fresh network/environment installation was not performed; validation reused the installed matching R environment. These tests do not establish availability or redistribution rights for the external datasets.
