variant <- if(is.null(cfg$variant)) "fig1" else cfg$variant
if(!variant %in% c("fig1","fig2")) stop("variant must be fig1 or fig2")
results_root <- input_path("measurements_root",directory=TRUE)
corrected_root <- input_path("normalized_profiles_root",directory=TRUE)
focused_purple_b2 <- !is.null(cfg$focused_group)
focused_group <- if(focused_purple_b2) cfg$focused_group else NA_character_
focused_expansion_factor <- if(is.null(cfg$expansion_factor)) 4.5 else cfg$expansion_factor
focused_height_fraction <- if(is.null(cfg$height_fraction)) 0.5 else cfg$height_fraction
if(!is.finite(focused_expansion_factor)||focused_expansion_factor<=0||!is.finite(focused_height_fraction)||focused_height_fraction<=0||focused_height_fraction>=1) stop("Invalid expansion factor or height fraction.")
table_dir <- out_dir
sys.source(file.path(module_dir,"R",paste0("distances_",variant,".R")),envir=environment())
