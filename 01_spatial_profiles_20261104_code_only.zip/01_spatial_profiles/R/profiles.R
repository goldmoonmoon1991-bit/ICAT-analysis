variant <- if(is.null(cfg$variant)) "fig1" else cfg$variant
if(!variant %in% c("fig1","fig2")) stop("variant must be fig1 or fig2")
group_name <- cfg$group
if(is.null(group_name)||length(group_name)!=1||!nzchar(group_name)||basename(group_name)!=group_name||group_name %in% c(".","..")) stop("Configure one valid group name.")
group_input_dir <- input_path("profile_directory",directory=TRUE)
table_dir <- file.path(out_dir,"tables",group_name)
corrected_data_dir <- file.path(out_dir,"profiles",group_name)
dir.create(table_dir,recursive=TRUE,showWarnings=FALSE);dir.create(corrected_data_dir,recursive=TRUE,showWarnings=FALSE)
sys.source(file.path(module_dir,"R",paste0("profiles_",variant,".R")),envir=environment())
