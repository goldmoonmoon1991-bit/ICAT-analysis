
# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 61-91.
params <- list(
  green_column = 2L,
  purple_column = 3L,
  background_fraction = 0.10,
  # Preserve the reproducible ICMT shoulder seen between the two conoid
  # boundaries. Higher values (for example 0.48) merge this shoulder in many
  # profiles and should not be used for these data.
  smoothing_spar = 0.30,
  min_peak_separation_nm = 110,
  prominence_window_nm = 450,
  min_prominence = 0.035,
  min_purple_peak_height = 0.45,
  # Hard floor for green peak candidates. Peaks below 35% of the normalized
  # green-channel maximum are excluded before boundary/ICMT assignment.
  min_peak_height = 0.35,
  # Preserve broad or smooth high peaks even when their local prominence is
  # reduced by an adjacent shoulder.
  strong_peak_height = 0.75,
  peak_height_weight = 2.0,
  peak_selection_priority = "height_then_prominence",
  icmt_left_proximity_weight = 0.5,
  min_conoid_width_nm = 500,
  max_conoid_width_nm = 2000,
  interpolation_step_nm = 10,
  normalized_step = 0.005,
  preserve_original_direction = TRUE,
  extra_peak_rule = "boundary_pair_by_width_then_internal_icmt",
  two_peak_rule = "left_boundary_plus_group_median_fraction",
  right_half_icmt_rule = "replace_icmt_gt_0.5_with_group_median_fraction",
  imputed_icmt_fraction = 0.30
)

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 93-97.
if(length(cfg$parameters)) {
  bad <- setdiff(names(cfg$parameters),names(params));if(length(bad)) stop("Unknown parameters: ",paste(bad,collapse=", "))
  params[names(cfg$parameters)] <- cfg$parameters
}
input_files <- sort(list.files(
  group_input_dir,
  pattern = "Profile Data.*\\.csv$",
  full.names = TRUE
))

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 99-101.
if (!length(input_files)) {
  stop("No ZEN Profile Data CSV files found in: ", group_input_dir)
}

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 103-119.
read_zen_profile <- function(path) {
  dat <- read.csv(
    path,
    skip = 2,
    header = FALSE,
    col.names = c("distance_nm", "green_raw", "purple_raw"),
    check.names = FALSE
  )
  dat <- dat[complete.cases(dat), , drop = FALSE]
  dat$distance_nm <- as.numeric(dat$distance_nm)
  dat$green_raw <- as.numeric(dat$green_raw)
  dat$purple_raw <- as.numeric(dat$purple_raw)
  dat <- dat[order(dat$distance_nm), , drop = FALSE]
  dat$group <- group_name
  dat$cell_id <- sub("\\.csv$", "", basename(path))
  dat
}

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 121-133.
linear_background <- function(x, y, fraction) {
  n_edge <- max(3L, round(length(y) * fraction))
  left_idx <- seq_len(n_edge)
  right_idx <- seq.int(length(y) - n_edge + 1L, length(y))
  left_x <- median(x[left_idx])
  right_x <- median(x[right_idx])
  left_y <- median(y[left_idx])
  right_y <- median(y[right_idx])
  if (right_x == left_x) {
    return(rep(mean(c(left_y, right_y)), length(x)))
  }
  left_y + (right_y - left_y) * (x - left_x) / (right_x - left_x)
}

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 135-141.
smooth_profile <- function(x, y, spar) {
  if (length(unique(x)) < 5L || max(y, na.rm = TRUE) <= 0) {
    return(y)
  }
  fit <- smooth.spline(x, y, spar = spar)
  pmax(0, predict(fit, x)$y)
}

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 143-148.
normalize_profile <- function(y) {
  y <- pmax(0, y)
  peak <- max(y, na.rm = TRUE)
  if (!is.finite(peak) || peak <= 0) return(rep(0, length(y)))
  y / peak
}

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 150-154.
local_maxima <- function(x, y) {
  if (length(y) < 3L) return(integer())
  which(y[2:(length(y) - 1L)] >= y[1:(length(y) - 2L)] &
          y[2:(length(y) - 1L)] > y[3:length(y)]) + 1L
}

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 156-161.
peak_prominence <- function(i, x, y, window_nm) {
  left <- which(x >= x[i] - window_nm & x <= x[i])
  right <- which(x >= x[i] & x <= x[i] + window_nm)
  if (length(left) < 2L || length(right) < 2L) return(0)
  y[i] - max(min(y[left]), min(y[right]))
}

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 163-202.
detect_green_candidates <- function(x, y, params) {
  idx <- local_maxima(x, y)
  if (!length(idx)) return(data.frame())
  candidates <- data.frame(
    index = idx,
    x_nm = x[idx],
    height = y[idx],
    prominence = vapply(
      idx,
      peak_prominence,
      numeric(1),
      x = x,
      y = y,
      window_nm = params$prominence_window_nm
    )
  )
  candidates <- candidates[
    candidates$height >= params$min_peak_height &
      (candidates$prominence >= params$min_prominence |
         candidates$height >= params$strong_peak_height),
    ,
    drop = FALSE
  ]
  if (!nrow(candidates)) return(candidates)

  # Keep stronger candidates when neighboring maxima are closer than the
  # microscope-scale minimum separation.
  candidates <- candidates[order(-candidates$height, -candidates$prominence), ]
  keep <- logical(nrow(candidates))
  accepted_x <- numeric()
  for (j in seq_len(nrow(candidates))) {
    if (!length(accepted_x) ||
        all(abs(candidates$x_nm[j] - accepted_x) >= params$min_peak_separation_nm)) {
      keep[j] <- TRUE
      accepted_x <- c(accepted_x, candidates$x_nm[j])
    }
  }
  candidates <- candidates[keep, , drop = FALSE]
  candidates[order(candidates$x_nm), , drop = FALSE]
}

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 204-210.
detect_purple_peak <- function(x, y, params) {
  idx <- local_maxima(x, y)
  if (!length(idx)) return(integer())
  idx <- idx[y[idx] >= params$min_purple_peak_height]
  if (!length(idx)) return(integer())
  idx[which.max(y[idx])]
}

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 212-252.
choose_green_triplet <- function(candidates, params) {
  if (nrow(candidates) < 3L) return(NULL)
  candidates <- candidates[order(candidates$x_nm), , drop = FALSE]

  # Select the two conoid boundaries first. A valid boundary pair must span at
  # least one internal candidate and fall inside the configured B-to-B range.
  boundary_pairs <- list()
  boundary_scores <- numeric()
  for (left_index in seq_len(nrow(candidates) - 2L)) {
    for (right_index in seq.int(left_index + 2L, nrow(candidates))) {
      width <- candidates$x_nm[right_index] - candidates$x_nm[left_index]
      if (width < params$min_conoid_width_nm ||
          width > params$max_conoid_width_nm) next

      boundary_pairs[[length(boundary_pairs) + 1L]] <- c(left_index, right_index)
      boundary_scores <- c(
        boundary_scores,
        params$peak_height_weight *
          (candidates$height[left_index] + candidates$height[right_index]) +
          candidates$prominence[left_index] + candidates$prominence[right_index]
      )
    }
  }
  if (!length(boundary_pairs)) return(NULL)

  selected_pair <- boundary_pairs[[which.max(boundary_scores)]]
  boundary_1_index <- selected_pair[1]
  boundary_2_index <- selected_pair[2]
  width <- candidates$x_nm[boundary_2_index] - candidates$x_nm[boundary_1_index]

  # After the boundaries are fixed, select ICMTs only from peaks between them.
  internal_indices <- seq.int(boundary_1_index + 1L, boundary_2_index - 1L)
  internal_fraction <-
    (candidates$x_nm[internal_indices] - candidates$x_nm[boundary_1_index]) / width
  icmt_scores <- params$peak_height_weight * candidates$height[internal_indices] +
    candidates$prominence[internal_indices] +
    params$icmt_left_proximity_weight * (1 - internal_fraction)
  icmt_index <- internal_indices[which.max(icmt_scores)]

  candidates[c(boundary_1_index, icmt_index, boundary_2_index), , drop = FALSE]
}

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 254-256.
interpolate_no_extrapolation <- function(x, y, xout) {
  approx(x, y, xout = xout, rule = 1, ties = mean)$y
}

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 258-280.
mean_and_ci <- function(dat, x_col, y_col, group_col, min_n = 3L) {
  split_key <- interaction(dat[[group_col]], dat[[x_col]], drop = TRUE)
  pieces <- split(dat, split_key)
  out <- lapply(pieces, function(z) {
    values <- z[[y_col]][is.finite(z[[y_col]])]
    n <- length(values)
    data.frame(
      channel = z[[group_col]][1],
      position = z[[x_col]][1],
      n = n,
      mean = if (n) mean(values) else NA_real_,
      sd = if (n > 1L) sd(values) else NA_real_,
      sem = if (n > 1L) sd(values) / sqrt(n) else NA_real_
    )
  })
  out <- do.call(rbind, out)
  critical_value <- rep(NA_real_, nrow(out))
  valid_ci <- out$n > 1L
  critical_value[valid_ci] <- qt(0.975, df = out$n[valid_ci] - 1L)
  out$ci95_low <- out$mean - critical_value * out$sem
  out$ci95_high <- out$mean + critical_value * out$sem
  out[out$n >= min_n, , drop = FALSE]
}

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 282-282.
profiles <- lapply(input_files, read_zen_profile)

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 283-283.
processed <- list()

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 284-284.
measurements <- list()

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 285-285.
peak_annotations <- list()

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 287-490.
for (i in seq_along(profiles)) {
  dat <- profiles[[i]]
  x <- dat$distance_nm
  green_bg <- linear_background(x, dat$green_raw, params$background_fraction)
  purple_bg <- linear_background(x, dat$purple_raw, params$background_fraction)
  green_corrected <- pmax(0, dat$green_raw - green_bg)
  purple_corrected <- pmax(0, dat$purple_raw - purple_bg)
  green_smooth <- smooth_profile(x, green_corrected, params$smoothing_spar)
  purple_smooth <- smooth_profile(x, purple_corrected, params$smoothing_spar)
  green_norm <- normalize_profile(green_smooth)
  purple_norm <- normalize_profile(purple_smooth)

  purple_index <- detect_purple_peak(x, purple_norm, params)
  purple_peak_found <- length(purple_index) == 1L
  purple_x <- if (purple_peak_found) x[purple_index] else NA_real_
  purple_peak_height <- if (purple_peak_found) purple_norm[purple_index] else NA_real_
  candidates <- detect_green_candidates(x, green_norm, params)
  # Assign the three green peaks without consulting the purple channel. This
  # keeps the later green-versus-purple asymmetry comparison independent.
  triplet <- choose_green_triplet(candidates, params)
  detected_icmt_before_imputation_nm <- if (is.null(triplet)) {
    NA_real_
  } else {
    triplet$x_nm[2]
  }
  icmt_imputed <- FALSE
  icmt_imputation_reason <- ""
  triplet_selection_rule <- if (is.null(triplet)) {
    "no_valid_triplet"
  } else if (nrow(candidates) > 3L) {
    params$extra_peak_rule
  } else {
    "all_three_candidates"
  }

  # When only two reliable green peaks remain, treat them as the conoid
  # boundaries and estimate an unresolved ICMT overlapping the left boundary.
  # The 0.30 fraction is the median normalized ICMT position in direct PASS
  # WT-MIC2 profiles and is recorded explicitly as an imputed measurement.
  if (is.null(triplet) && nrow(candidates) == 2L) {
    candidate_width <- candidates$x_nm[2] - candidates$x_nm[1]
    if (candidate_width >= params$min_conoid_width_nm &&
        candidate_width <= params$max_conoid_width_nm) {
      imputed_icmt <- candidates$x_nm[1] +
        params$imputed_icmt_fraction * candidate_width
      triplet <- data.frame(
        x_nm = c(candidates$x_nm[1], imputed_icmt, candidates$x_nm[2])
      )
      icmt_imputed <- TRUE
      icmt_imputation_reason <- "two_green_candidates_boundary_overlap"
      triplet_selection_rule <- params$two_peak_rule
    }
  }

  qc <- if (purple_peak_found) character() else "PURPLE_PEAK_BELOW_THRESHOLD"
  if (is.null(triplet)) {
    qc <- c(qc, "AUTO_PEAK_FAILURE")
    # Preserve the profile in overview output, but exclude it from alignment.
    processed[[i]] <- transform(
      dat,
      green_corrected = green_corrected,
      purple_corrected = purple_corrected,
      green_norm = green_norm,
      purple_norm = purple_norm,
      position_normalized = NA_real_,
      position_center_um = NA_real_,
      icmt_imputed = FALSE,
      eligible = FALSE
    )
    measurements[[i]] <- data.frame(
      group = group_name,
      cell_id = dat$cell_id[1],
      n_points = nrow(dat),
      sampling_nm = median(diff(x)),
      conoid_boundary_1_nm = NA_real_,
      icmt_peak_nm = NA_real_,
      conoid_boundary_2_nm = NA_real_,
      purple_peak_nm = purple_x,
      purple_peak_height = purple_peak_height,
      purple_peak_found = purple_peak_found,
      conoid_width_nm = NA_real_,
      icmt_position_normalized = NA_real_,
      purple_position_normalized = NA_real_,
      icmt_offset_from_center_normalized = NA_real_,
      purple_offset_from_center_normalized = NA_real_,
      purple_minus_icmt_normalized = NA_real_,
      purple_minus_icmt_um = NA_real_,
      icmt_offset_from_center_um = NA_real_,
      purple_offset_from_center_um = NA_real_,
      green_candidate_count = nrow(candidates),
      green_candidate_positions_nm = paste(round(candidates$x_nm, 3), collapse = ";"),
      triplet_selection_rule = triplet_selection_rule,
      icmt_imputed = FALSE,
      icmt_detected_before_imputation_nm = NA_real_,
      icmt_imputation_reason = "",
      orientation_reversed = FALSE,
      included_in_average = FALSE,
      qc_flag = paste(qc, collapse = ";")
    )
    next
  }

  boundary_1 <- triplet$x_nm[1]
  icmt <- triplet$x_nm[2]
  boundary_2 <- triplet$x_nm[3]
  width <- boundary_2 - boundary_1
  center <- (boundary_1 + boundary_2) / 2

  detected_icmt_normalized <- (icmt - boundary_1) / width
  if (!icmt_imputed && detected_icmt_normalized > 0.5) {
    icmt <- boundary_1 + params$imputed_icmt_fraction * width
    icmt_imputed <- TRUE
    icmt_imputation_reason <- "detected_icmt_position_normalized_gt_0.5"
    triplet_selection_rule <- params$right_half_icmt_rule
  }

  # Preserve the original ZEN line direction for every measurement. The first
  # detected conoid boundary is always 0 and the second is always 1.
  position_normalized <- (x - boundary_1) / width
  position_center_um <- (x - center) / 1000
  purple_normalized <- if (purple_peak_found) {
    (purple_x - boundary_1) / width
  } else {
    NA_real_
  }
  icmt_normalized <- (icmt - boundary_1) / width

  if (purple_peak_found &&
      (purple_normalized < -0.15 || purple_normalized > 1.15)) {
    qc <- c(qc, "PURPLE_OUTSIDE_CONOID")
  }
  if (nrow(candidates) > 3L) {
    qc <- c(qc, "EXTRA_GREEN_CANDIDATES_REVIEW")
  }
  if (purple_peak_found &&
      (icmt_normalized - 0.5) * (purple_normalized - 0.5) >= 0) {
    qc <- c(qc, "PURPLE_NOT_OPPOSITE_ICMT")
  }
  if (!length(qc)) {
    qc <- if (icmt_imputed) "PASS_IMPUTED_ICMT_OVERLAP" else "PASS"
  }

  processed[[i]] <- transform(
    dat,
    green_corrected = green_corrected,
    purple_corrected = purple_corrected,
    green_norm = green_norm,
    purple_norm = purple_norm,
    position_normalized = position_normalized,
    position_center_um = position_center_um,
    icmt_imputed = icmt_imputed,
    eligible = purple_peak_found
  )

  icmt_center_um <- (icmt - center) / 1000
  purple_center_um <- (purple_x - center) / 1000

  measurements[[i]] <- data.frame(
    group = group_name,
    cell_id = dat$cell_id[1],
    n_points = nrow(dat),
    sampling_nm = median(diff(x)),
    conoid_boundary_1_nm = boundary_1,
    icmt_peak_nm = icmt,
    conoid_boundary_2_nm = boundary_2,
    purple_peak_nm = purple_x,
    purple_peak_height = purple_peak_height,
    purple_peak_found = purple_peak_found,
    conoid_width_nm = width,
    icmt_position_normalized = icmt_normalized,
    purple_position_normalized = purple_normalized,
    icmt_offset_from_center_normalized = icmt_normalized - 0.5,
    purple_offset_from_center_normalized = purple_normalized - 0.5,
    purple_minus_icmt_normalized = purple_normalized - icmt_normalized,
    purple_minus_icmt_um = purple_center_um - icmt_center_um,
    icmt_offset_from_center_um = icmt_center_um,
    purple_offset_from_center_um = purple_center_um,
    green_candidate_count = nrow(candidates),
    green_candidate_positions_nm = paste(round(candidates$x_nm, 3), collapse = ";"),
    triplet_selection_rule = triplet_selection_rule,
    icmt_imputed = icmt_imputed,
    icmt_detected_before_imputation_nm = detected_icmt_before_imputation_nm,
    icmt_imputation_reason = icmt_imputation_reason,
    orientation_reversed = FALSE,
    included_in_average = purple_peak_found,
    qc_flag = paste(qc, collapse = ";")
  )

  annotation_x <- c(boundary_1, icmt, boundary_2)
  annotation_channel <- c("Green", "Green", "Green")
  annotation_label <- c("B", if (icmt_imputed) "ICMT*" else "ICMT", "B")
  if (purple_peak_found) {
    annotation_x <- c(annotation_x, purple_x)
    annotation_channel <- c(annotation_channel, "Purple")
    annotation_label <- c(annotation_label, "Purple")
  }
  peak_annotations[[i]] <- data.frame(
    group = group_name,
    cell_id = dat$cell_id[1],
    x_nm = annotation_x,
    channel = annotation_channel,
    label = annotation_label
  )
}

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 492-492.
processed_all <- do.call(rbind, processed)

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 493-493.
measurements_all <- do.call(rbind, measurements)

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 494-494.
annotations_all <- if (length(peak_annotations)) do.call(rbind, peak_annotations) else data.frame()

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 496-496.
eligible <- processed_all[processed_all$eligible, , drop = FALSE]

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 497-497.
if (!nrow(eligible)) stop("No profiles passed automatic peak detection.")

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 578-578.
abs_limit <- max(abs(eligible$position_center_um), na.rm = TRUE)

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 579-579.
abs_grid <- seq(-abs_limit, abs_limit, by = params$interpolation_step_nm / 1000)

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 580-580.
norm_min <- max(-1, min(eligible$position_normalized, na.rm = TRUE))

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 581-581.
norm_max <- min(2, max(eligible$position_normalized, na.rm = TRUE))

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 582-582.
norm_grid <- seq(norm_min, norm_max, by = params$normalized_step)

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 584-584.
abs_profiles <- list()

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 585-585.
norm_profiles <- list()

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 586-586.
cell_ids <- unique(eligible$cell_id)

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 587-603.
for (cell in cell_ids) {
  z <- eligible[eligible$cell_id == cell, , drop = FALSE]
  ord_abs <- order(z$position_center_um)
  ord_norm <- order(z$position_normalized)
  abs_profiles[[length(abs_profiles) + 1L]] <- rbind(
    data.frame(group = group_name, cell_id = cell, icmt_imputed = z$icmt_imputed[1], position_center_um = abs_grid, channel = "Green",
               intensity = interpolate_no_extrapolation(z$position_center_um[ord_abs], z$green_norm[ord_abs], abs_grid)),
    data.frame(group = group_name, cell_id = cell, icmt_imputed = z$icmt_imputed[1], position_center_um = abs_grid, channel = "Purple",
               intensity = interpolate_no_extrapolation(z$position_center_um[ord_abs], z$purple_norm[ord_abs], abs_grid))
  )
  norm_profiles[[length(norm_profiles) + 1L]] <- rbind(
    data.frame(group = group_name, cell_id = cell, icmt_imputed = z$icmt_imputed[1], position_normalized = norm_grid, channel = "Green",
               intensity = interpolate_no_extrapolation(z$position_normalized[ord_norm], z$green_norm[ord_norm], norm_grid)),
    data.frame(group = group_name, cell_id = cell, icmt_imputed = z$icmt_imputed[1], position_normalized = norm_grid, channel = "Purple",
               intensity = interpolate_no_extrapolation(z$position_normalized[ord_norm], z$purple_norm[ord_norm], norm_grid))
  )
}

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 605-605.
abs_profiles_all <- do.call(rbind, abs_profiles)

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 606-606.
norm_profiles_all <- do.call(rbind, norm_profiles)

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 607-607.
abs_mean <- mean_and_ci(abs_profiles_all, "position_center_um", "intensity", "channel")

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 608-608.
norm_mean <- mean_and_ci(norm_profiles_all, "position_normalized", "intensity", "channel")

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 609-609.
names(abs_mean)[names(abs_mean) == "position"] <- "position_center_um"

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 610-610.
names(norm_mean)[names(norm_mean) == "position"] <- "position_normalized"

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 611-611.
abs_mean$group <- group_name

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 612-612.
norm_mean$group <- group_name

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 688-693.
position_points <- rbind(
  data.frame(group = group_name, cell_id = measurements_all$cell_id, structure = "ICMT",
             position = measurements_all$icmt_position_normalized),
  data.frame(group = group_name, cell_id = measurements_all$cell_id, structure = "Purple",
             position = measurements_all$purple_position_normalized)
)

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 694-694.
position_points <- position_points[is.finite(position_points$position), , drop = FALSE]

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 695-695.
position_points$structure[position_points$structure == "ICMT"] <- "ICMTs"

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 696-710.
position_summary <- do.call(rbind, lapply(split(position_points, position_points$structure), function(z) {
  n <- nrow(z)
  sem <- sd(z$position) / sqrt(n)
  critical_value <- qt(0.975, df = n - 1L)
  data.frame(
    group = group_name,
    structure = z$structure[1],
    n = n,
    mean_position = mean(z$position),
    sd = sd(z$position),
    sem = sem,
    ci95_low = mean(z$position) - critical_value * sem,
    ci95_high = mean(z$position) + critical_value * sem
  )
}))

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 712-729.
summarize_metric <- function(values, metric, unit) {
  values <- values[is.finite(values)]
  n <- length(values)
  sem <- if (n > 1L) sd(values) / sqrt(n) else NA_real_
  critical_value <- if (n > 1L) qt(0.975, df = n - 1L) else NA_real_
  data.frame(
    group = group_name,
    metric = metric,
    unit = unit,
    n = n,
    mean = if (n) mean(values) else NA_real_,
    median = if (n) median(values) else NA_real_,
    sd = if (n > 1L) sd(values) else NA_real_,
    sem = sem,
    ci95_low = if (n > 1L) mean(values) - critical_value * sem else NA_real_,
    ci95_high = if (n > 1L) mean(values) + critical_value * sem else NA_real_
  )
}

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 731-739.
measurement_summary <- rbind(
  summarize_metric(measurements_all$conoid_width_nm, "conoid_width", "nm"),
  summarize_metric(measurements_all$icmt_position_normalized, "icmt_peak_position", "conoid_width"),
  summarize_metric(measurements_all$purple_position_normalized, "purple_peak_position", "conoid_width"),
  summarize_metric(measurements_all$icmt_offset_from_center_um, "icmt_offset_from_midpoint", "um"),
  summarize_metric(measurements_all$purple_offset_from_center_um, "purple_offset_from_midpoint", "um"),
  summarize_metric(measurements_all$purple_minus_icmt_normalized, "purple_minus_icmt_distance", "conoid_width"),
  summarize_metric(measurements_all$purple_minus_icmt_um, "purple_minus_icmt_distance", "um")
)

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 741-758.
one_sample_test <- function(values, comparison, reference, unit) {
  values <- values[is.finite(values)]
  tt <- t.test(values, mu = reference)
  wt <- suppressWarnings(wilcox.test(values, mu = reference, exact = FALSE))
  data.frame(
    group = group_name,
    comparison = comparison,
    unit = unit,
    n = length(values),
    reference = reference,
    mean_difference = mean(values) - reference,
    t_statistic = unname(tt$statistic),
    t_df = unname(tt$parameter),
    t_p_value_two_sided = tt$p.value,
    wilcoxon_statistic = unname(wt$statistic),
    wilcoxon_p_value_two_sided = wt$p.value
  )
}

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 760-785.
asymmetry_tests <- rbind(
  one_sample_test(
    measurements_all$icmt_position_normalized,
    "ICMT peak versus conoid midpoint",
    0.5,
    "conoid_width"
  ),
  one_sample_test(
    measurements_all$purple_position_normalized,
    "Purple peak versus conoid midpoint",
    0.5,
    "conoid_width"
  ),
  one_sample_test(
    measurements_all$purple_minus_icmt_normalized,
    "Purple minus ICMT peak separation versus zero",
    0,
    "conoid_width"
  ),
  one_sample_test(
    measurements_all$purple_minus_icmt_um,
    "Purple minus ICMT peak separation versus zero",
    0,
    "um"
  )
)

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 821-821.
write.csv(measurements_all, file.path(table_dir, "peak_measurements_per_cell.csv"), row.names = FALSE)

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 822-822.
accepted_qc <- c("PASS", "PASS_IMPUTED_ICMT_OVERLAP")

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 823-827.
write.csv(
  measurements_all[!measurements_all$qc_flag %in% accepted_qc, , drop = FALSE],
  file.path(table_dir, "qc_review_queue.csv"),
  row.names = FALSE
)

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 828-828.
write.csv(abs_profiles_all, file.path(corrected_data_dir, "aligned_profiles_absolute.csv"), row.names = FALSE)

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 829-829.
write.csv(norm_profiles_all, file.path(corrected_data_dir, "aligned_profiles_normalized.csv"), row.names = FALSE)

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 830-830.
write.csv(abs_mean, file.path(corrected_data_dir, "mean_profile_absolute.csv"), row.names = FALSE)

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 831-831.
write.csv(norm_mean, file.path(corrected_data_dir, "mean_profile_normalized.csv"), row.names = FALSE)

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 832-832.
write.csv(position_summary, file.path(table_dir, "peak_position_summary.csv"), row.names = FALSE)

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 833-833.
write.csv(measurement_summary, file.path(table_dir, "measurement_summary.csv"), row.names = FALSE)

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 834-834.
write.csv(asymmetry_tests, file.path(table_dir, "asymmetry_tests.csv"), row.names = FALSE)

# Adapted from Fig1_intro_spatial/03_code/peak_profiles/analyze_peak_profiles.R, lines 835-843.
write.csv(
  data.frame(
    parameter = c("group", names(params)),
    value = c(group_name, unlist(params)),
    row.names = NULL
  ),
  file.path(table_dir, "analysis_parameters.csv"),
  row.names = FALSE
)
