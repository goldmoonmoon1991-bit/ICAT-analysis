
# Adapted from Fig2_ICAT_identification/03_code/peak_profiles/symmetry_distance.R, lines 94-111.
primary_groups <- if (focused_purple_b2) character() else c("ARO", "WT-MIC2")
microneme_groups <- if (focused_purple_b2) {
  focused_group
} else {
  c("WT-MIC2", "ICMAP1-MIC2", "ICMAP2-MIC2", "ARO-MIC2")
}
required_groups <- unique(c(primary_groups, microneme_groups))

group_labels <- c(
  "ARO" = "ARO (rhoptry)",
  "WT-MIC2" = "WT",
  "ICMAP1-MIC2" = "ICMAP1 KO",
  "ICMAP2-MIC2" = "ICMAP2 KO",
  "ARO-MIC2" = "ARO KO"
)
if (focused_purple_b2) {
  group_labels <- setNames("ICAT B2 asymmetry", focused_group)
}

# Adapted from Fig2_ICAT_identification/03_code/peak_profiles/symmetry_distance.R, lines 140-145.
required_measurement_columns <- c(
  "group", "cell_id", "conoid_boundary_1_nm", "icmt_peak_nm",
  "conoid_boundary_2_nm", "purple_peak_nm", "conoid_width_nm",
  "icmt_position_normalized", "purple_position_normalized",
  "icmt_imputed", "orientation_reversed", "included_in_average", "qc_flag"
)

# Adapted from Fig2_ICAT_identification/03_code/peak_profiles/symmetry_distance.R, lines 146-148.
required_profile_columns <- c(
  "group", "cell_id", "position_normalized", "channel", "intensity"
)

# Adapted from Fig2_ICAT_identification/03_code/peak_profiles/symmetry_distance.R, lines 150-196.
read_group_inputs <- function(group_name) {
  measurement_path <- file.path(
    results_root, group_name, "peak_measurements_per_cell.csv"
  )
  profile_path <- file.path(
    corrected_root, group_name, "aligned_profiles_normalized.csv"
  )
  if (!file.exists(measurement_path)) stop("Missing measurement table: ", measurement_path)
  if (!file.exists(profile_path)) stop("Missing normalized profiles: ", profile_path)

  measurements <- read.csv(
    measurement_path, check.names = FALSE, stringsAsFactors = FALSE
  )
  profiles <- read.csv(profile_path, check.names = FALSE, stringsAsFactors = FALSE)

  assert_unique(measurements,c("group","cell_id"),measurement_path)
  assert_unique(profiles,c("group","cell_id","channel","position_normalized"),profile_path)
  missing_measurements <- setdiff(required_measurement_columns, names(measurements))
  missing_profiles <- setdiff(required_profile_columns, names(profiles))
  if (length(missing_measurements)) {
    stop(group_name, " measurement table is missing: ",
         paste(missing_measurements, collapse = ", "))
  }
  if (length(missing_profiles)) {
    stop(group_name, " profile table is missing: ",
         paste(missing_profiles, collapse = ", "))
  }
  if (any(measurements$orientation_reversed %in% TRUE, na.rm = TRUE)) {
    stop(group_name, " contains orientation-reversed measurements.")
  }

  measurements <- measurements[
    measurements$included_in_average %in% TRUE &
      is.finite(measurements$conoid_width_nm) &
      measurements$conoid_width_nm > 0,
    ,
    drop = FALSE
  ]
  profiles <- profiles[
    profiles$cell_id %in% measurements$cell_id &
      profiles$channel %in% c("Green", "Purple"),
    ,
    drop = FALSE
  ]
  if (!nrow(measurements) || !nrow(profiles)) {
    stop("No eligible measurements or profiles for ", group_name)
  }
  list(measurements = measurements, profiles = profiles)
}

# Adapted from Fig2_ICAT_identification/03_code/peak_profiles/symmetry_distance.R, lines 198-198.
inputs <- setNames(lapply(required_groups, read_group_inputs), required_groups)

# Adapted from Fig2_ICAT_identification/03_code/peak_profiles/symmetry_distance.R, lines 200-205.
linear_crossing <- function(x1, y1, x2, y2, level) {
  if (!all(is.finite(c(x1, y1, x2, y2, level))) || y2 == y1) {
    return(mean(c(x1, x2)))
  }
  x1 + (level - y1) * (x2 - x1) / (y2 - y1)
}

# Adapted from Fig2_ICAT_identification/03_code/peak_profiles/symmetry_distance.R, lines 207-224.
empty_fwhm <- function(expected_center, status, height_fraction = 0.5) {
  list(
    expected_center = expected_center,
    height_fraction = height_fraction,
    peak_center = NA_real_,
    peak_height = NA_real_,
    local_baseline = NA_real_,
    half_height = NA_real_,
    left = NA_real_,
    right = NA_real_,
    width = NA_real_,
    left_found = FALSE,
    right_found = FALSE,
    left_method = "unresolved",
    right_method = "unresolved",
    status = status
  )
}

# Adapted from Fig2_ICAT_identification/03_code/peak_profiles/symmetry_distance.R, lines 226-361.
local_fwhm <- function(curve, expected_center, domain_left, domain_right,
                       search_radius = 0.08,
                       mirror_missing_edge = FALSE,
                       height_fraction = 0.5) {
  if (!is.finite(height_fraction) || height_fraction <= 0 || height_fraction >= 1) {
    stop("height_fraction must be between 0 and 1.")
  }
  curve <- curve[
    is.finite(curve$position_normalized) & is.finite(curve$intensity),
    c("position_normalized", "intensity"),
    drop = FALSE
  ]
  curve <- curve[order(curve$position_normalized), , drop = FALSE]
  curve <- curve[
    curve$position_normalized >= domain_left &
      curve$position_normalized <= domain_right,
    ,
    drop = FALSE
  ]
  if (nrow(curve) < 5L || !is.finite(expected_center)) {
    return(empty_fwhm(expected_center, "INSUFFICIENT_PROFILE", height_fraction))
  }

  search <- which(
    curve$position_normalized >= expected_center - search_radius &
      curve$position_normalized <= expected_center + search_radius
  )
  if (!length(search)) {
    return(empty_fwhm(expected_center, "PEAK_SEARCH_EMPTY", height_fraction))
  }
  peak_index <- search[which.max(curve$intensity[search])]
  peak_height <- curve$intensity[peak_index]
  if (!is.finite(peak_height) || peak_height <= 0) {
    return(empty_fwhm(expected_center, "INVALID_PEAK_HEIGHT", height_fraction))
  }

  # Use the local prominence baseline so partially overlapping peaks retain
  # interpretable half-height crossings. This is equivalent to a local,
  # background-corrected FWHM rather than an absolute 0.5 intensity cutoff.
  left_baseline <- min(curve$intensity[seq_len(peak_index)], na.rm = TRUE)
  right_baseline <- min(
    curve$intensity[seq.int(peak_index, nrow(curve))], na.rm = TRUE
  )
  local_baseline <- max(left_baseline, right_baseline)
  if (!is.finite(local_baseline) || peak_height <= local_baseline) {
    return(empty_fwhm(expected_center, "INVALID_LOCAL_PROMINENCE", height_fraction))
  }
  half_height <- local_baseline + height_fraction * (peak_height - local_baseline)

  left <- NA_real_
  if (peak_index > 1L) {
    for (j in seq.int(peak_index - 1L, 1L)) {
      if (curve$intensity[j] <= half_height &&
          curve$intensity[j + 1L] > half_height) {
        left <- linear_crossing(
          curve$position_normalized[j], curve$intensity[j],
          curve$position_normalized[j + 1L], curve$intensity[j + 1L],
          half_height
        )
        break
      }
    }
  }

  right <- NA_real_
  if (peak_index < nrow(curve)) {
    for (j in seq.int(peak_index, nrow(curve) - 1L)) {
      if (curve$intensity[j] > half_height &&
          curve$intensity[j + 1L] <= half_height) {
        right <- linear_crossing(
          curve$position_normalized[j], curve$intensity[j],
          curve$position_normalized[j + 1L], curve$intensity[j + 1L],
          half_height
        )
        break
      }
    }
  }

  left_method <- if (is.finite(left)) "observed" else "unresolved"
  right_method <- if (is.finite(right)) "observed" else "unresolved"

  # Adjacent green peaks often merge above half maximum. In that case the
  # inward-facing crossing is optically hidden, while the outward half-width
  # remains measurable. Mirror that observed half-width around the local peak
  # center and retain the method in the QC columns.
  peak_center <- curve$position_normalized[peak_index]
  curve_left <- min(curve$position_normalized)
  curve_right <- max(curve$position_normalized)
  if (mirror_missing_edge && !is.finite(left) && is.finite(right)) {
    candidate <- peak_center - (right - peak_center)
    if (is.finite(candidate) && candidate >= curve_left && candidate < peak_center) {
      left <- candidate
      left_method <- "mirrored_from_right"
    }
  }
  if (mirror_missing_edge && is.finite(left) && !is.finite(right)) {
    candidate <- peak_center + (peak_center - left)
    if (is.finite(candidate) && candidate <= curve_right && candidate > peak_center) {
      right <- candidate
      right_method <- "mirrored_from_left"
    }
  }

  left_found <- is.finite(left)
  right_found <- is.finite(right)
  status <- if (left_found && right_found &&
                left_method == "observed" && right_method == "observed") {
    "PASS"
  } else if (left_found && right_found) {
    "PASS_ONE_EDGE_MIRRORED"
  } else if (!left_found && !right_found) {
    "BOTH_HALFMAX_EDGES_UNRESOLVED"
  } else if (!left_found) {
    "LEFT_HALFMAX_EDGE_UNRESOLVED"
  } else {
    "RIGHT_HALFMAX_EDGE_UNRESOLVED"
  }

  list(
    expected_center = expected_center,
    height_fraction = height_fraction,
    peak_center = peak_center,
    peak_height = peak_height,
    local_baseline = local_baseline,
    half_height = half_height,
    left = left,
    right = right,
    width = if (left_found && right_found) right - left else NA_real_,
    left_found = left_found,
    right_found = right_found,
    left_method = left_method,
    right_method = right_method,
    status = status
  )
}

# Adapted from Fig2_ICAT_identification/03_code/peak_profiles/symmetry_distance.R, lines 363-378.
surface_gap <- function(left_fwhm, right_fwhm) {
  if (is.finite(left_fwhm$right) && is.finite(right_fwhm$left)) {
    raw_gap <- right_fwhm$left - left_fwhm$right
    return(list(
      gap = max(0, raw_gap),
      raw_gap = raw_gap,
      overlap = raw_gap <= 0,
      overlap_zero_assigned = FALSE,
      status = if (raw_gap <= 0) "FWHM_INTERVALS_OVERLAP" else "PASS"
    ))
  }
  list(
    gap = NA_real_, raw_gap = NA_real_, overlap = NA,
    overlap_zero_assigned = FALSE, status = "FWHM_FACING_EDGE_UNRESOLVED"
  )
}

# Adapted from Fig2_ICAT_identification/03_code/peak_profiles/symmetry_distance.R, lines 380-398.
fwhm_columns <- function(prefix, fwhm) {
  out <- data.frame(
    expected_center = fwhm$expected_center,
    height_fraction = fwhm$height_fraction,
    peak_center = fwhm$peak_center,
    peak_height = fwhm$peak_height,
    local_baseline = fwhm$local_baseline,
    half_height = fwhm$half_height,
    fwhm_left = fwhm$left,
    fwhm_right = fwhm$right,
    fwhm_width = fwhm$width,
    fwhm_left_method = fwhm$left_method,
    fwhm_right_method = fwhm$right_method,
    fwhm_status = fwhm$status,
    stringsAsFactors = FALSE
  )
  names(out) <- paste0(prefix, "_", names(out))
  out
}

# Adapted from Fig2_ICAT_identification/03_code/peak_profiles/symmetry_distance.R, lines 400-450.
make_relation_row <- function(group_name, measurement, relation,
                              structure, boundary, boundary_center,
                              structure_center, boundary_fwhm,
                              structure_fwhm, left_structure) {
  if (left_structure == "boundary") {
    gap <- surface_gap(boundary_fwhm, structure_fwhm)
    center_distance <- structure_center - boundary_center
    boundary_surface <- boundary_fwhm$right
    structure_surface <- structure_fwhm$left
  } else {
    gap <- surface_gap(structure_fwhm, boundary_fwhm)
    center_distance <- boundary_center - structure_center
    boundary_surface <- boundary_fwhm$left
    structure_surface <- structure_fwhm$right
  }

  width_nm <- measurement$conoid_width_nm
  ordering_valid <- is.finite(center_distance) && center_distance >= 0
  included_surface <- ordering_valid && is.finite(gap$gap)

  cbind(
    data.frame(
      group = group_name,
      group_label = unname(group_labels[group_name]),
      cell_id = measurement$cell_id,
      relation = relation,
      structure = structure,
      boundary = boundary,
      conoid_width_nm = width_nm,
      center_distance_normalized = center_distance,
      center_distance_nm = center_distance * width_nm,
      boundary_facing_surface_normalized = boundary_surface,
      structure_facing_surface_normalized = structure_surface,
      surface_gap_normalized = gap$gap,
      surface_gap_nm = gap$gap * width_nm,
      boundary_fwhm_width_nm = boundary_fwhm$width * width_nm,
      structure_fwhm_width_nm = structure_fwhm$width * width_nm,
      raw_surface_gap_normalized = gap$raw_gap,
      fwhm_intervals_overlap = gap$overlap,
      overlap_zero_assigned = gap$overlap_zero_assigned,
      surface_gap_status = gap$status,
      center_ordering_valid = ordering_valid,
      included_surface_analysis = included_surface,
      icmt_imputed = measurement$icmt_imputed %in% TRUE,
      source_qc_flag = measurement$qc_flag,
      stringsAsFactors = FALSE
    ),
    fwhm_columns("boundary", boundary_fwhm),
    fwhm_columns("structure", structure_fwhm)
  )
}

# Adapted from Fig2_ICAT_identification/03_code/peak_profiles/symmetry_distance.R, lines 452-452.
relation_rows <- list()

# Adapted from Fig2_ICAT_identification/03_code/peak_profiles/symmetry_distance.R, lines 454-537.
for (group_name in required_groups) {
  measurements <- inputs[[group_name]]$measurements
  profiles <- inputs[[group_name]]$profiles
  profile_split <- split(profiles, profiles$cell_id)

  for (i in seq_len(nrow(measurements))) {
    measurement <- measurements[i, , drop = FALSE]
    cell_id <- measurement$cell_id
    cell_profile <- profile_split[[cell_id]]
    if (is.null(cell_profile) || !nrow(cell_profile)) next

    green <- cell_profile[cell_profile$channel == "Green", , drop = FALSE]
    purple <- cell_profile[cell_profile$channel == "Purple", , drop = FALSE]
    icmt_center <- measurement$icmt_position_normalized
    purple_center <- measurement$purple_position_normalized
    if (!is.finite(icmt_center) || !is.finite(purple_center)) next

    green_min <- min(green$position_normalized, na.rm = TRUE)
    green_max <- max(green$position_normalized, na.rm = TRUE)
    purple_min <- min(purple$position_normalized, na.rm = TRUE)
    purple_max <- max(purple$position_normalized, na.rm = TRUE)
    midpoint_b1_icmt <- 0.5 * icmt_center
    midpoint_icmt_b2 <- 0.5 * (icmt_center + 1)
    green_radius <- max(0.025, min(0.08, 0.35 * min(
      abs(icmt_center), abs(1 - icmt_center)
    )))

    b1_fwhm <- local_fwhm(
      green, 0, green_min, midpoint_b1_icmt,
      search_radius = green_radius,
      mirror_missing_edge = TRUE
    )
    icmt_fwhm <- local_fwhm(
      green, icmt_center, midpoint_b1_icmt, midpoint_icmt_b2,
      search_radius = green_radius,
      mirror_missing_edge = TRUE
    )
    b2_fwhm <- local_fwhm(
      green, 1, midpoint_icmt_b2, green_max,
      search_radius = green_radius,
      mirror_missing_edge = TRUE,
      height_fraction = if (focused_purple_b2) focused_height_fraction else 0.5
    )
    purple_fwhm <- local_fwhm(
      purple, purple_center,
      max(purple_min, purple_center - 0.45),
      min(purple_max, purple_center + 0.45),
      search_radius = 0.10,
      height_fraction = if (focused_purple_b2) focused_height_fraction else 0.5
    )

    if (group_name %in% primary_groups && !(measurement$icmt_imputed %in% TRUE)) {
      relation_rows[[length(relation_rows) + 1L]] <- make_relation_row(
        group_name, measurement,
        relation = "ICMTs to B1", structure = "ICMTs", boundary = "B1",
        boundary_center = 0, structure_center = icmt_center,
        boundary_fwhm = b1_fwhm, structure_fwhm = icmt_fwhm,
        left_structure = "boundary"
      )
    }

    if (group_name == "ARO") {
      relation_rows[[length(relation_rows) + 1L]] <- make_relation_row(
        group_name, measurement,
        relation = "Rhoptry to B1", structure = "Rhoptry", boundary = "B1",
        boundary_center = 0, structure_center = purple_center,
        boundary_fwhm = b1_fwhm, structure_fwhm = purple_fwhm,
        left_structure = "boundary"
      )
    }

    if (group_name %in% microneme_groups) {
      relation_rows[[length(relation_rows) + 1L]] <- make_relation_row(
        group_name, measurement,
        relation = if (focused_purple_b2) "Purple signal to B2" else "Microneme to B2",
        structure = if (focused_purple_b2) "Purple signal" else "Microneme",
        boundary = "B2",
        boundary_center = 1, structure_center = purple_center,
        boundary_fwhm = b2_fwhm, structure_fwhm = purple_fwhm,
        left_structure = "structure"
      )
    }
  }
}

# Adapted from Fig2_ICAT_identification/03_code/peak_profiles/symmetry_distance.R, lines 539-539.
distance_data <- do.call(rbind, relation_rows)

# Adapted from Fig2_ICAT_identification/03_code/peak_profiles/symmetry_distance.R, lines 540-540.
rownames(distance_data) <- NULL

# Adapted from Fig2_ICAT_identification/03_code/peak_profiles/symmetry_distance.R, lines 541-541.
if (!nrow(distance_data)) stop("No distance rows were generated.")

# Adapted from Fig2_ICAT_identification/03_code/peak_profiles/symmetry_distance.R, lines 543-549.
distance_data$relation <- factor(
  distance_data$relation,
  levels = c(
    "ICMTs to B1", "Rhoptry to B1", "Microneme to B2",
    "Purple signal to B2"
  )
)

# Adapted from Fig2_ICAT_identification/03_code/peak_profiles/symmetry_distance.R, lines 551-567.
summarize_values <- function(values) {
  values <- values[is.finite(values)]
  n <- length(values)
  se <- if (n > 1L) sd(values) / sqrt(n) else NA_real_
  critical <- if (n > 1L) qt(0.975, n - 1L) else NA_real_
  data.frame(
    n = n,
    mean = if (n) mean(values) else NA_real_,
    median = if (n) median(values) else NA_real_,
    sd = if (n > 1L) sd(values) else NA_real_,
    sem = se,
    q1 = if (n) unname(quantile(values, 0.25)) else NA_real_,
    q3 = if (n) unname(quantile(values, 0.75)) else NA_real_,
    ci95_low = if (n > 1L) mean(values) - critical * se else NA_real_,
    ci95_high = if (n > 1L) mean(values) + critical * se else NA_real_
  )
}

if (focused_purple_b2) {
  distance_data$expansion_factor <- focused_expansion_factor
  distance_data$height_fraction <- focused_height_fraction
  distance_data$center_distance_biological_nm <-
    distance_data$center_distance_nm / focused_expansion_factor
  distance_data$surface_gap_biological_nm <-
    distance_data$surface_gap_nm / focused_expansion_factor

  focused_metrics <- c(
    "center_distance_normalized", "center_distance_nm",
    "center_distance_biological_nm", "surface_gap_normalized",
    "surface_gap_nm", "surface_gap_biological_nm"
  )
  focused_summary <- do.call(rbind, lapply(focused_metrics, function(metric) {
    cbind(
      data.frame(
        group = focused_group,
        relation = "Purple signal to B2",
        metric = metric,
        expansion_factor = focused_expansion_factor,
        height_fraction = focused_height_fraction,
        stringsAsFactors = FALSE
      ),
      summarize_values(distance_data[[metric]])
    )
  }))
  rownames(focused_summary) <- NULL

  focused_qc <- data.frame(
    group = focused_group,
    n_total = nrow(distance_data),
    n_center_order_valid = sum(distance_data$center_ordering_valid),
    n_surface_gap_available = sum(distance_data$included_surface_analysis),
    n_fwhm_overlap = sum(distance_data$fwhm_intervals_overlap %in% TRUE, na.rm = TRUE),
    n_surface_unresolved = sum(!is.finite(distance_data$surface_gap_normalized)),
    surface_success_rate = mean(distance_data$included_surface_analysis),
    expansion_factor = focused_expansion_factor,
    height_fraction = focused_height_fraction,
    stringsAsFactors = FALSE
  )


  write_table(distance_data,"purple_signal_to_B2_distance_per_cell.csv")
  write_table(focused_summary,"purple_signal_to_B2_distance_summary.csv")
  write_table(focused_qc,"purple_signal_to_B2_FWHM_QC.csv")
} else {

# Adapted from Fig2_ICAT_identification/03_code/peak_profiles/symmetry_distance.R, lines 836-1258.
uexm_expansion_factor <- 4.5
microneme_width_target_nm <- c(50, 80)
microneme_width_target_midpoint_nm <- mean(microneme_width_target_nm)
b2_width_target_nm <- c(20, 30)
b2_width_target_midpoint_nm <- mean(b2_width_target_nm)
candidate_height_fractions <- c(0.25, 0.50, 2 / 3, 0.75)
candidate_height_fraction_labels <- c("1/4", "1/2", "2/3", "3/4")
height_fraction_label <- function(value) {
  candidate_height_fraction_labels[
    which.min(abs(candidate_height_fractions - value))
  ]
}
threshold_rows <- list()

for (group_name in microneme_groups) {
  measurements <- inputs[[group_name]]$measurements
  profiles <- inputs[[group_name]]$profiles
  profile_split <- split(profiles, profiles$cell_id)

  for (i in seq_len(nrow(measurements))) {
    measurement <- measurements[i, , drop = FALSE]
    cell_profile <- profile_split[[measurement$cell_id]]
    if (is.null(cell_profile) || !nrow(cell_profile)) next

    green <- cell_profile[cell_profile$channel == "Green", , drop = FALSE]
    purple <- cell_profile[cell_profile$channel == "Purple", , drop = FALSE]
    icmt_center <- measurement$icmt_position_normalized
    purple_center <- measurement$purple_position_normalized
    if (!is.finite(icmt_center) || !is.finite(purple_center)) next

    green_max <- max(green$position_normalized, na.rm = TRUE)
    purple_min <- min(purple$position_normalized, na.rm = TRUE)
    purple_max <- max(purple$position_normalized, na.rm = TRUE)
    midpoint_icmt_b2 <- 0.5 * (icmt_center + 1)
    green_radius <- max(0.025, min(0.08, 0.35 * min(
      abs(icmt_center), abs(1 - icmt_center)
    )))

    for (height_fraction in candidate_height_fractions) {
      b2_width <- local_fwhm(
        green, 1, midpoint_icmt_b2, green_max,
        search_radius = green_radius,
        mirror_missing_edge = TRUE,
        height_fraction = height_fraction
      )
      microneme_width <- local_fwhm(
        purple, purple_center,
        max(purple_min, purple_center - 0.45),
        min(purple_max, purple_center + 0.45),
        search_radius = 0.10,
        height_fraction = height_fraction
      )
      gap <- surface_gap(microneme_width, b2_width)
      width_nm <- measurement$conoid_width_nm
      center_distance_normalized <- 1 - purple_center

      threshold_rows[[length(threshold_rows) + 1L]] <- data.frame(
        group = group_name,
        group_label = unname(group_labels[group_name]),
        cell_id = measurement$cell_id,
        height_fraction = height_fraction,
        height_fraction_label = height_fraction_label(height_fraction),
        uexm_expansion_factor = uexm_expansion_factor,
        conoid_width_expanded_nm = width_nm,
        center_distance_normalized = center_distance_normalized,
        center_distance_expanded_nm = center_distance_normalized * width_nm,
        center_distance_biological_nm = center_distance_normalized * width_nm /
          uexm_expansion_factor,
        microneme_width_normalized = microneme_width$width,
        microneme_width_expanded_nm = microneme_width$width * width_nm,
        microneme_width_biological_nm = microneme_width$width * width_nm /
          uexm_expansion_factor,
        microneme_left_normalized = microneme_width$left,
        microneme_right_normalized = microneme_width$right,
        microneme_width_status = microneme_width$status,
        b2_width_normalized = b2_width$width,
        b2_width_expanded_nm = b2_width$width * width_nm,
        b2_width_biological_nm = b2_width$width * width_nm /
          uexm_expansion_factor,
        b2_left_normalized = b2_width$left,
        b2_right_normalized = b2_width$right,
        b2_width_status = b2_width$status,
        raw_surface_gap_normalized = gap$raw_gap,
        surface_gap_normalized = gap$gap,
        surface_gap_expanded_nm = gap$gap * width_nm,
        surface_gap_biological_nm = gap$gap * width_nm /
          uexm_expansion_factor,
        intervals_overlap = gap$overlap,
        surface_gap_status = gap$status,
        included_surface_analysis = is.finite(center_distance_normalized) &&
          center_distance_normalized >= 0 && is.finite(gap$gap),
        stringsAsFactors = FALSE
      )
    }
  }
}

microneme_threshold_data <- do.call(rbind, threshold_rows)
rownames(microneme_threshold_data) <- NULL

threshold_comparison <- do.call(rbind, lapply(
  candidate_height_fractions,
  function(height_fraction) {
    z <- microneme_threshold_data[
      microneme_threshold_data$group == "WT-MIC2" &
        abs(microneme_threshold_data$height_fraction - height_fraction) < 1e-8,
      , drop = FALSE
    ]
    stats <- summarize_values(z$microneme_width_biological_nm)
    b2_stats <- summarize_values(z$b2_width_biological_nm)
    microneme_midpoint_error_scaled <- abs(
      stats$median - microneme_width_target_midpoint_nm
    ) / diff(microneme_width_target_nm) * 2
    b2_midpoint_error_scaled <- abs(
      b2_stats$median - b2_width_target_midpoint_nm
    ) / diff(b2_width_target_nm) * 2
    data.frame(
      height_fraction = height_fraction,
      height_fraction_label = height_fraction_label(height_fraction),
      n = stats$n,
      mean_width_expanded_nm = mean(z$microneme_width_expanded_nm, na.rm = TRUE),
      median_width_expanded_nm = median(z$microneme_width_expanded_nm, na.rm = TRUE),
      mean_width_biological_nm = stats$mean,
      median_width_biological_nm = stats$median,
      sd_width_biological_nm = stats$sd,
      q1_width_biological_nm = stats$q1,
      q3_width_biological_nm = stats$q3,
      percent_cells_in_50_80_nm = 100 * mean(
        z$microneme_width_biological_nm >= microneme_width_target_nm[1] &
          z$microneme_width_biological_nm <= microneme_width_target_nm[2],
        na.rm = TRUE
      ),
      mean_b2_width_biological_nm = b2_stats$mean,
      median_b2_width_biological_nm = b2_stats$median,
      percent_b2_in_20_30_nm = 100 * mean(
        z$b2_width_biological_nm >= b2_width_target_nm[1] &
          z$b2_width_biological_nm <= b2_width_target_nm[2],
        na.rm = TRUE
      ),
      microneme_midpoint_error_scaled = microneme_midpoint_error_scaled,
      b2_midpoint_error_scaled = b2_midpoint_error_scaled,
      joint_selection_score = microneme_midpoint_error_scaled +
        b2_midpoint_error_scaled,
      stringsAsFactors = FALSE
    )
  }
))
selected_height_fraction <- threshold_comparison$height_fraction[
  which.min(threshold_comparison$joint_selection_score)
]
threshold_comparison$selected <- abs(
  threshold_comparison$height_fraction - selected_height_fraction
) < 1e-8

height_fraction_file_tag <- function(value) {
  label <- height_fraction_label(value)
  if (label == "2/3") return("2over3")
  if (label == "3/4") return("3over4")
  gsub("[^0-9A-Za-z]+", "_", label)
}
threshold_result_fractions <- c(2 / 3, 0.75)

microneme_distance_data_for_fraction <- function(height_fraction) {
  z <- microneme_threshold_data[
    abs(microneme_threshold_data$height_fraction - height_fraction) < 1e-8,
    , drop = FALSE
  ]
  z$group_label <- factor(
    z$group_label,
    levels = unname(group_labels[microneme_groups])
  )
  z
}

summarize_microneme_distance_data <- function(dat, fraction_column_name) {
  out <- do.call(rbind, lapply(split(
    dat,
    paste(dat$height_fraction_label, dat$group, sep = "___")
  ), function(z) {
    width_stats <- summarize_values(z$microneme_width_biological_nm)
    gap_stats <- summarize_values(z$surface_gap_biological_nm)
    finite_gaps <- is.finite(z$surface_gap_biological_nm)
    data.frame(
      group = z$group[1],
      group_label = as.character(z$group_label[1]),
      height_fraction = z$height_fraction[1],
      height_fraction_label = z$height_fraction_label[1],
      n_width = width_stats$n,
      mean_microneme_width_biological_nm = width_stats$mean,
      median_microneme_width_biological_nm = width_stats$median,
      n_surface_gap = gap_stats$n,
      mean_surface_gap_biological_nm = gap_stats$mean,
      median_surface_gap_biological_nm = gap_stats$median,
      q1_surface_gap_biological_nm = gap_stats$q1,
      q3_surface_gap_biological_nm = gap_stats$q3,
      n_surface_gap_zero = sum(finite_gaps & z$surface_gap_biological_nm == 0),
      percent_surface_gap_zero = 100 * mean(
        z$surface_gap_biological_nm[finite_gaps] == 0
      ),
      stringsAsFactors = FALSE
    )
  }))
  names(out)[names(out) == "height_fraction"] <- fraction_column_name
  rownames(out) <- NULL
  out
}

microneme_selected_distance_data <- microneme_distance_data_for_fraction(
  selected_height_fraction
)
microneme_selected_distance_summary <- summarize_microneme_distance_data(
  microneme_selected_distance_data,
  "selected_height_fraction"
)
rownames(microneme_selected_distance_summary) <- NULL

microneme_threshold_result_data <- do.call(rbind, lapply(
  threshold_result_fractions,
  microneme_distance_data_for_fraction
))
rownames(microneme_threshold_result_data) <- NULL
microneme_threshold_result_summary <- summarize_microneme_distance_data(
  microneme_threshold_result_data,
  "height_fraction"
)

summary_rows <- list()
summary_metrics <- c(
  "center_distance_normalized", "center_distance_nm",
  "surface_gap_normalized", "surface_gap_nm",
  "structure_fwhm_width", "boundary_fwhm_width",
  "structure_fwhm_width_nm", "boundary_fwhm_width_nm"
)
for (relation_name in levels(distance_data$relation)) {
  for (group_name in unique(as.character(
    distance_data$group[distance_data$relation == relation_name]
  ))) {
    z <- distance_data[
      distance_data$relation == relation_name & distance_data$group == group_name,
      ,
      drop = FALSE
    ]
    for (metric in summary_metrics) {
      stats <- summarize_values(z[[metric]])
      summary_rows[[length(summary_rows) + 1L]] <- cbind(
        data.frame(
          relation = relation_name, group = group_name,
          group_label = unname(group_labels[group_name]), metric = metric,
          stringsAsFactors = FALSE
        ),
        stats
      )
    }
  }
}
distance_summary <- do.call(rbind, summary_rows)
rownames(distance_summary) <- NULL

microneme_width_summary <- do.call(rbind, lapply(split(
  distance_data[distance_data$relation == "Microneme to B2", , drop = FALSE],
  distance_data$group[distance_data$relation == "Microneme to B2"]
), function(z) {
  width_stats <- summarize_values(z$structure_fwhm_width_nm)
  finite_gaps <- is.finite(z$surface_gap_nm)
  zero_gaps <- finite_gaps & z$surface_gap_nm == 0
  data.frame(
    group = z$group[1],
    group_label = z$group_label[1],
    n_fwhm_width = width_stats$n,
    mean_fwhm_width_nm = width_stats$mean,
    median_fwhm_width_nm = width_stats$median,
    sd_fwhm_width_nm = width_stats$sd,
    q1_fwhm_width_nm = width_stats$q1,
    q3_fwhm_width_nm = width_stats$q3,
    ci95_low_fwhm_width_nm = width_stats$ci95_low,
    ci95_high_fwhm_width_nm = width_stats$ci95_high,
    mean_fwhm_width_normalized = mean(z$structure_fwhm_width, na.rm = TRUE),
    n_surface_gap_available = sum(finite_gaps),
    n_surface_gap_zero = sum(zero_gaps),
    percent_surface_gap_zero = if (any(finite_gaps)) {
      100 * sum(zero_gaps) / sum(finite_gaps)
    } else {
      NA_real_
    },
    stringsAsFactors = FALSE
  )
}))
rownames(microneme_width_summary) <- NULL

qc_summary <- do.call(rbind, lapply(split(
  distance_data,
  interaction(distance_data$relation, distance_data$group, drop = TRUE)
), function(z) {
  data.frame(
    relation = as.character(z$relation[1]),
    group = z$group[1],
    n_total = nrow(z),
    n_center_order_valid = sum(z$center_ordering_valid),
    n_surface_gap_available = sum(z$included_surface_analysis),
    n_fwhm_overlap = sum(z$fwhm_intervals_overlap %in% TRUE, na.rm = TRUE),
    n_overlap_zero_assigned = sum(z$overlap_zero_assigned),
    n_surface_unresolved = sum(!is.finite(z$surface_gap_normalized)),
    surface_success_rate = mean(z$included_surface_analysis),
    stringsAsFactors = FALSE
  )
}))
rownames(qc_summary) <- NULL

primary_data <- rbind(
  distance_data[
    distance_data$relation == "ICMTs to B1" &
      distance_data$group %in% primary_groups,
    ,
    drop = FALSE
  ],
  distance_data[
    distance_data$relation == "Rhoptry to B1" & distance_data$group == "ARO",
    ,
    drop = FALSE
  ],
  distance_data[
    distance_data$relation == "Microneme to B2" &
      distance_data$group == "WT-MIC2",
    ,
    drop = FALSE
  ]
)

primary_data$display_relation <- ifelse(
  primary_data$relation == "ICMTs to B1",
  "ICMTs - B1\n(ARO + WT)",
  ifelse(
    primary_data$relation == "Rhoptry to B1",
    "Rhoptry - B1\n(ARO)",
    "Microneme - B2\n(WT)"
  )
)
primary_relation_levels <- c(
  "ICMTs - B1\n(ARO + WT)",
  "Rhoptry - B1\n(ARO)",
  "Microneme - B2\n(WT)"
)
primary_data$display_relation <- factor(
  primary_data$display_relation, levels = primary_relation_levels
)

asymmetry_test <- function(values, alternative, structure, source) {
  values <- values[is.finite(values)]
  tt <- t.test(values, mu = 0.5, alternative = alternative)
  wt <- suppressWarnings(wilcox.test(
    values, mu = 0.5, alternative = alternative, exact = FALSE
  ))
  data.frame(
    structure = structure,
    source = source,
    n = length(values),
    mean_peak_position = mean(values),
    expected_boundary = if (alternative == "less") "B1" else "B2",
    alternative = if (alternative == "less") "position < 0.5" else "position > 0.5",
    t_statistic = unname(tt$statistic),
    t_df = unname(tt$parameter),
    t_p_value_one_sided = tt$p.value,
    wilcoxon_statistic = unname(wt$statistic),
    wilcoxon_p_value_one_sided = wt$p.value,
    stringsAsFactors = FALSE
  )
}

asymmetry_tests <- rbind(
  asymmetry_test(
    primary_data$structure_expected_center[primary_data$structure == "ICMTs"],
    "less", "ICMTs", "ARO + WT-MIC2"
  ),
  asymmetry_test(
    primary_data$structure_expected_center[primary_data$structure == "Rhoptry"],
    "less", "Rhoptry", "ARO"
  ),
  asymmetry_test(
    primary_data$structure_expected_center[primary_data$structure == "Microneme"],
    "greater", "Microneme", "WT-MIC2"
  )
)

zone_separation_test <- function(left_values, right_values, comparison) {
  left_values <- left_values[is.finite(left_values)]
  right_values <- right_values[is.finite(right_values)]
  tt <- t.test(right_values, left_values, alternative = "two.sided")
  wt <- suppressWarnings(wilcox.test(
    right_values, left_values, alternative = "two.sided", exact = FALSE
  ))
  data.frame(
    comparison = comparison,
    n_left = length(left_values),
    n_right = length(right_values),
    mean_left_position = mean(left_values),
    mean_right_position = mean(right_values),
    mean_separation_normalized = mean(right_values) - mean(left_values),
    separation_ci95_low = unname(tt$conf.int[1]),
    separation_ci95_high = unname(tt$conf.int[2]),
    welch_t_statistic = unname(tt$statistic),
    welch_df = unname(tt$parameter),
    welch_p_value = tt$p.value,
    wilcoxon_statistic = unname(wt$statistic),
    wilcoxon_p_value = wt$p.value,
    stringsAsFactors = FALSE
  )
}

primary_microneme_positions <- primary_data$structure_expected_center[
  primary_data$structure == "Microneme"
]
zone_separation_tests <- rbind(
  zone_separation_test(
    primary_data$structure_expected_center[primary_data$structure == "Rhoptry"],
    primary_microneme_positions,
    "Rhoptry (ARO) vs Microneme (WT)"
  ),
  zone_separation_test(
    primary_data$structure_expected_center[primary_data$structure == "ICMTs"],
    primary_microneme_positions,
    "ICMTs (ARO + WT) vs Microneme (WT)"
  )
)

for(n in c("distance_data","distance_summary","microneme_width_summary","microneme_threshold_data","threshold_comparison","microneme_selected_distance_data","microneme_selected_distance_summary","microneme_threshold_result_data","microneme_threshold_result_summary","qc_summary","asymmetry_tests","zone_separation_tests")) {
 names_out <- c(distance_data="surface_distances_per_cell.csv",distance_summary="surface_distance_summary.csv",microneme_width_summary="microneme_FWHM_width_summary.csv",microneme_threshold_data="microneme_width_thresholds_per_cell.csv",threshold_comparison="microneme_B2_width_threshold_comparison.csv",microneme_selected_distance_data="microneme_B2_selected_surface_distances_per_cell.csv",microneme_selected_distance_summary="microneme_B2_selected_surface_distance_summary.csv",microneme_threshold_result_data="microneme_B2_surface_distance_threshold_sensitivity_per_cell.csv",microneme_threshold_result_summary="microneme_B2_surface_distance_threshold_sensitivity_summary.csv",qc_summary="FWHM_QC_summary.csv",asymmetry_tests="asymmetry_tests.csv",zone_separation_tests="zone_separation_tests.csv")
 write_table(get(n),names_out[[n]])
}
}
