# DDA LFQ paired-analysis pipeline

This reusable pipeline implements:

`RAW → ThermoRawFileParser mzML → FragPipe/MSFragger/IonQuant → paired LFQ statistics → Excel + figures`

It is designed for paired DDA LFQ experiments such as `control` versus `rapa` in matched biological blocks.

## Required inputs

`sample_map.csv` columns:

- `sample_id`: stable sample number.
- `raw_file`: RAW filename or full RAW path.
- `condition`: exactly one control and one treatment per `pair_id`.
- `pair_id`: matched biological pair/block.
- `sample_label`: FragPipe/IonQuant sample label, e.g. `control_1`, `rapa_1`.

`config.yaml` records HPC paths, FragPipe settings, contrast names, and thresholds.

## HPC usage

Generate HPC input files locally:

```bash
python shared/dda_lfq_pipeline/bin/prepare_hpc_inputs.py \
  --config Fig6_ICAT_interactome/02_analysis/dda_lfq_pipeline/config.yaml \
  --sample-map Fig6_ICAT_interactome/02_analysis/dda_lfq_pipeline/sample_map.csv \
  --outdir Fig6_ICAT_interactome/02_analysis/dda_lfq_pipeline/hpc_inputs
```

Copy generated files to the HPC project `inputs/` directory together with the FragPipe workflow, then run:

```bash
bash /home/pg/ICAT_DiQ/inputs/run_hpc_pipeline.sh
```

The pipeline converts RAW to uncompressed indexed `.mzML`, checks that every mzML exists, and only then starts FragPipe.

## Local report usage

After FragPipe finishes, copy `combined_protein.tsv`, optional `combined_peptide.tsv`, and `*-metadata.txt` files back to the local project. Then run:

```bash
/Users/penggeqian/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 \
  shared/dda_lfq_pipeline/bin/analyze_fragpipe_lfq.py \
  --config Fig6_ICAT_interactome/02_analysis/dda_lfq_pipeline/config.yaml \
  --sample-map Fig6_ICAT_interactome/02_analysis/dda_lfq_pipeline/sample_map.csv \
  --protein path/to/combined_protein.tsv \
  --peptide path/to/combined_peptide.tsv \
  --raw-qc-dir path/to/raw_metadata \
  --outdir Fig6_ICAT_interactome/04_results/dda_lfq_report
```

Outputs:

- `DDA_LFQ_paired_report.xlsx`
- CSV tables under `tables/`
- figures under `figures/`

## Statistics

Always computed:

- paired log2FC per `pair_id`
- paired t-test
- Benjamini-Hochberg FDR
- Significance B-style local background correction

Optional:

- limma paired model, if the R `limma` package is installed.

Default candidate rule:

- mean log2FC ≥ 1
- positive pair fraction ≥ 0.70
- peptide support ≥ 2
- Significance B BH FDR ≤ 0.05

The pipeline never deletes or moves RAW files.

