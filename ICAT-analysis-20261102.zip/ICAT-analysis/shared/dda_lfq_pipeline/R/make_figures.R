#!/usr/bin/env Rscript

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 2) {
  stop("Usage: make_figures.R tables_dir figures_dir")
}

tables_dir <- args[[1]]
figures_dir <- args[[2]]
dir.create(figures_dir, recursive = TRUE, showWarnings = FALSE)

suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
  library(tidyr)
  library(ggplot2)
})

protein_stats <- readr::read_csv(file.path(tables_dir, "Protein_statistics.csv"), show_col_types = FALSE)
protein_intensity <- readr::read_csv(file.path(tables_dir, "Protein_intensity.csv"), show_col_types = FALSE)
paired <- readr::read_csv(file.path(tables_dir, "Paired_log2FC.csv"), show_col_types = FALSE)

fdr_col <- if ("significance_b_mean_fdr_bh" %in% names(protein_stats)) "significance_b_mean_fdr_bh" else "paired_t_fdr_bh"

volcano <- protein_stats %>%
  mutate(
    neg_log10_fdr = -log10(pmax(.data[[fdr_col]], 1e-300)),
    candidate_pass = as.logical(candidate_pass)
  ) %>%
  ggplot(aes(mean_log2FC, neg_log10_fdr, colour = candidate_pass)) +
  geom_point(alpha = 0.75, size = 1.2) +
  scale_colour_manual(values = c("FALSE" = "grey70", "TRUE" = "#D55E00"), na.value = "grey70") +
  theme_classic(base_size = 10) +
  labs(x = "Mean paired log2FC", y = paste0("-log10(", fdr_col, ")"), colour = "Candidate")
ggsave(file.path(figures_dir, "volcano.pdf"), volcano, width = 5.2, height = 4.2)
ggsave(file.path(figures_dir, "volcano.png"), volcano, width = 5.2, height = 4.2, dpi = 300)

mat <- protein_intensity %>%
  select(-protein_id) %>%
  mutate(across(everything(), ~ log2(.x + min(.x[.x > 0], na.rm = TRUE) / 2))) %>%
  as.data.frame()
rownames(mat) <- protein_intensity$protein_id
mat <- mat[rowSums(is.finite(as.matrix(mat))) == ncol(mat), , drop = FALSE]

if (ncol(mat) >= 2 && nrow(mat) >= 2) {
  pca <- prcomp(t(mat), center = TRUE, scale. = TRUE)
  pca_df <- as.data.frame(pca$x[, 1:min(2, ncol(pca$x)), drop = FALSE])
  pca_df$sample_label <- rownames(pca_df)
  if (!"PC2" %in% names(pca_df)) pca_df$PC2 <- 0
  var_exp <- round(100 * (pca$sdev^2 / sum(pca$sdev^2))[1:2], 1)
  p_pca <- ggplot(pca_df, aes(PC1, PC2, label = sample_label)) +
    geom_point(size = 2.5, colour = "#0072B2") +
    geom_text(vjust = -0.8, size = 3) +
    theme_classic(base_size = 10) +
    labs(x = paste0("PC1 (", var_exp[[1]], "%)"), y = paste0("PC2 (", var_exp[[2]], "%)"))
  ggsave(file.path(figures_dir, "pca.pdf"), p_pca, width = 5, height = 4)
  ggsave(file.path(figures_dir, "pca.png"), p_pca, width = 5, height = 4, dpi = 300)

  cor_df <- as.data.frame(as.table(cor(mat, use = "pairwise.complete.obs")))
  names(cor_df) <- c("sample_1", "sample_2", "correlation")
  p_cor <- ggplot(cor_df, aes(sample_1, sample_2, fill = correlation)) +
    geom_tile() +
    geom_text(aes(label = sprintf("%.2f", correlation)), size = 2.8) +
    scale_fill_gradient2(low = "#2166AC", mid = "white", high = "#B2182B", midpoint = 0.8, limits = c(0, 1)) +
    theme_classic(base_size = 9) +
    theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
    labs(x = NULL, y = NULL, fill = "Pearson r")
  ggsave(file.path(figures_dir, "sample_correlation_heatmap.pdf"), p_cor, width = 5, height = 4.5)
  ggsave(file.path(figures_dir, "sample_correlation_heatmap.png"), p_cor, width = 5, height = 4.5, dpi = 300)
}

pair_cols <- grep("^pair_.*_log2FC_", names(paired), value = TRUE)
if (length(pair_cols) >= 2) {
  rep_plot <- paired %>%
    select(protein_id, all_of(pair_cols[1:2])) %>%
    left_join(protein_stats %>% select(protein_id, candidate_pass), by = "protein_id") %>%
    ggplot(aes(.data[[pair_cols[[1]]]], .data[[pair_cols[[2]]]], colour = as.logical(candidate_pass))) +
    geom_hline(yintercept = 0, colour = "grey85") +
    geom_vline(xintercept = 0, colour = "grey85") +
    geom_point(alpha = 0.75, size = 1.2) +
    scale_colour_manual(values = c("FALSE" = "grey70", "TRUE" = "#D55E00"), na.value = "grey70") +
    theme_classic(base_size = 10) +
    labs(x = pair_cols[[1]], y = pair_cols[[2]], colour = "Candidate")
  ggsave(file.path(figures_dir, "paired_log2fc_reproducibility.pdf"), rep_plot, width = 5, height = 4.5)
  ggsave(file.path(figures_dir, "paired_log2fc_reproducibility.png"), rep_plot, width = 5, height = 4.5, dpi = 300)
}

candidate_ids <- protein_stats %>%
  filter(as.logical(candidate_pass)) %>%
  arrange(significance_b_mean_fdr_bh, desc(mean_log2FC)) %>%
  slice_head(n = 50) %>%
  pull(protein_id)
if (length(candidate_ids) >= 2 && exists("mat")) {
  heat <- mat[rownames(mat) %in% candidate_ids, , drop = FALSE]
  heat_z <- t(scale(t(heat)))
  heat_df <- as.data.frame(heat_z)
  heat_df$protein_id <- rownames(heat_z)
  heat_long <- heat_df %>%
    pivot_longer(-protein_id, names_to = "sample_label", values_to = "z")
  p_heat <- ggplot(heat_long, aes(sample_label, protein_id, fill = z)) +
    geom_tile() +
    scale_fill_gradient2(low = "#2166AC", mid = "white", high = "#B2182B", midpoint = 0) +
    theme_classic(base_size = 8) +
    theme(axis.text.x = element_text(angle = 45, hjust = 1), axis.text.y = element_text(size = 5)) +
    labs(x = NULL, y = NULL, fill = "row z")
  ggsave(file.path(figures_dir, "candidate_heatmap.pdf"), p_heat, width = 5, height = max(4, length(candidate_ids) * 0.12))
  ggsave(file.path(figures_dir, "candidate_heatmap.png"), p_heat, width = 5, height = max(4, length(candidate_ids) * 0.12), dpi = 300)
}

