#!/usr/bin/env Rscript

args <- commandArgs(trailingOnly = TRUE)
if (length(args) < 3 || length(args) > 5) {
  stop("Usage: limma_paired.R expr.csv sample_map.csv out.csv [control] [treatment]")
}

expr_path <- args[[1]]
sample_path <- args[[2]]
out_path <- args[[3]]
control_name <- if (length(args) >= 4) args[[4]] else "control"
treatment_name <- if (length(args) >= 5) args[[5]] else setdiff(unique(read.csv(sample_path, check.names = FALSE)$condition), control_name)[[1]]

if (!requireNamespace("limma", quietly = TRUE)) {
  stop("R package 'limma' is not installed.")
}

expr <- read.csv(expr_path, check.names = FALSE)
sample_map <- read.csv(sample_path, check.names = FALSE)
rownames(expr) <- expr$protein_id
mat <- as.matrix(expr[, setdiff(colnames(expr), "protein_id"), drop = FALSE])
sample_map <- sample_map[match(colnames(mat), sample_map$sample_label), ]

condition <- factor(sample_map$condition)
pair_id <- factor(sample_map$pair_id)
design <- model.matrix(~ 0 + condition + pair_id)
colnames(design) <- make.names(colnames(design))
fit <- limma::lmFit(mat, design)
contrast_name <- paste0("condition", treatment_name, "-condition", control_name)
contrast <- limma::makeContrasts(contrasts = contrast_name, levels = design)
fit2 <- limma::contrasts.fit(fit, contrast)
fit2 <- limma::eBayes(fit2)
tab <- limma::topTable(fit2, number = Inf, sort.by = "none")
out <- data.frame(
  protein_id = rownames(tab),
  limma_log2FC = tab$logFC,
  limma_t = tab$t,
  limma_pvalue = tab$P.Value,
  limma_fdr_bh = tab$adj.P.Val,
  check.names = FALSE
)
write.csv(out, out_path, row.names = FALSE)
