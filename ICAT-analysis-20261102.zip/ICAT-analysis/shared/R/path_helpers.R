icat_script_path <- function(fallback) {
  file_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
  if (length(file_arg)) {
    return(normalizePath(sub("^--file=", "", file_arg[[1]]), mustWork = TRUE))
  }
  if (interactive() && requireNamespace("rstudioapi", quietly = TRUE)) {
    active <- rstudioapi::getActiveDocumentContext()$path
    if (nzchar(active)) return(normalizePath(active, mustWork = TRUE))
  }
  normalizePath(fallback, mustWork = TRUE)
}
