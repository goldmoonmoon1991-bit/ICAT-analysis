# Shared publication style for all ICAT R-generated figures.
# ggplot2 text sizes are in pt inside themes but in mm for geom_text/annotate.

ICAT_FONT_SMALL_PT <- 7
ICAT_FONT_BODY_PT <- 8
ICAT_FONT_TITLE_PT <- 9
ICAT_LINE_PT <- 0.5
ICAT_GGPLOT_PT_PER_MM <- 2.845276
ICAT_R_DEVICE_PT_PER_LWD <- 0.75

ICAT_TEXT_SMALL_MM <- ICAT_FONT_SMALL_PT / ICAT_GGPLOT_PT_PER_MM
ICAT_TEXT_BODY_MM <- ICAT_FONT_BODY_PT / ICAT_GGPLOT_PT_PER_MM
ICAT_TEXT_TITLE_MM <- ICAT_FONT_TITLE_PT / ICAT_GGPLOT_PT_PER_MM
# ggplot2 converts mm to grid lwd; PDF devices render one lwd unit as 0.75 pt.
# Include both conversions so the final PDF stroke is physically 0.5 pt.
ICAT_LINE_MM <- ICAT_LINE_PT / (ICAT_R_DEVICE_PT_PER_LWD * ICAT_GGPLOT_PT_PER_MM)

icat_axis_theme <- function() {
  ggplot2::theme(
    axis.line = ggplot2::element_line(linewidth = ICAT_LINE_MM, colour = "black"),
    axis.ticks = ggplot2::element_line(linewidth = ICAT_LINE_MM, colour = "black"),
    axis.title = ggplot2::element_text(size = ICAT_FONT_BODY_PT),
    axis.text = ggplot2::element_text(size = ICAT_FONT_BODY_PT, colour = "black"),
    legend.title = ggplot2::element_text(size = ICAT_FONT_BODY_PT),
    legend.text = ggplot2::element_text(size = ICAT_FONT_BODY_PT),
    strip.text = ggplot2::element_text(size = ICAT_FONT_BODY_PT),
    plot.title = ggplot2::element_text(size = ICAT_FONT_TITLE_PT, face = "bold"),
    plot.subtitle = ggplot2::element_text(size = ICAT_FONT_SMALL_PT)
  )
}

icat_theme_classic <- function(base_family = "Arial") {
  ggplot2::theme_classic(
    base_size = ICAT_FONT_BODY_PT,
    base_family = base_family,
    base_line_size = ICAT_LINE_MM
  ) + icat_axis_theme()
}

icat_theme_bw <- function(base_family = "Arial") {
  ggplot2::theme_bw(
    base_size = ICAT_FONT_BODY_PT,
    base_family = base_family,
    base_line_size = ICAT_LINE_MM
  ) + icat_axis_theme()
}
