icat_project_library <- function(project_root) {
  library_root <- file.path(project_root, "renv", "library")
  r_minor <- paste(R.version$major, strsplit(R.version$minor, ".", fixed = TRUE)[[1]][1], sep = ".")
  platform_library <- file.path(library_root, "macos", paste0("R-", r_minor), R.version$platform)
  if (dir.exists(file.path(platform_library, "renv"))) {
    return(normalizePath(platform_library, mustWork = TRUE))
  }

  renv_packages <- list.files(
    library_root,
    pattern = "^renv$",
    recursive = TRUE,
    full.names = TRUE,
    include.dirs = TRUE
  )
  renv_packages <- renv_packages[dir.exists(renv_packages)]
  if (!length(renv_packages)) {
    stop("The project renv library is missing. Run renv::restore() first.")
  }
  libraries <- unique(dirname(renv_packages))
  package_counts <- vapply(libraries, function(path) {
    sum(dir.exists(list.dirs(path, recursive = FALSE, full.names = TRUE)))
  }, integer(1))
  normalizePath(libraries[[which.max(package_counts)]], mustWork = TRUE)
}

icat_activate_project_library <- function(project_root) {
  library <- icat_project_library(project_root)
  .libPaths(c(library, .libPaths()))
  Sys.setenv(R_LIBS = library)
  invisible(library)
}
