#!/usr/bin/env Rscript

# Compare MIC2 peak position in WT and ICMAP1, ICMAP2, and ARO knockouts.
# The script is self-contained and reads the per-cell outputs produced by
# analyze_peak_profiles.R. Original ZEN line direction is never reversed here.

runtime_cache <- file.path(tempdir(), "microneme-asymmetry-cache")
dir.create(runtime_cache, recursive = TRUE, showWarnings = FALSE)
Sys.setenv(XDG_CACHE_HOME = runtime_cache)

suppressPackageStartupMessages({
  library(ggplot2)
})

script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
script_path <- if (length(script_arg)) {
  normalizePath(sub("^--file=", "", script_arg[[1]]), mustWork = TRUE)
} else {
  normalizePath("microneme_asymmetry_analysis.R", mustWork = TRUE)
}

code_dir <- dirname(script_path)
fig_dir <- normalizePath(file.path(code_dir, "..", ".."), mustWork = TRUE)
project_root <- normalizePath(file.path(fig_dir, ".."), mustWork = TRUE)
source(file.path(project_root, "shared", "R", "plot_style.R"))
single_group_results_dir <- file.path(fig_dir, "04_results", "tables", "peak_profiles")
corrected_profile_dir <- file.path(fig_dir, "02_processed_data", "peak_profiles")
analysis_dir <- file.path(fig_dir, "04_results", "reports", "peak_profiles", "microneme_asymmetry_analysis")
figure_dir <- file.path(fig_dir, "04_results", "figures", "peak_profiles", "microneme_asymmetry_analysis")
table_dir <- file.path(fig_dir, "04_results", "tables", "peak_profiles", "microneme_asymmetry_analysis")
legend_dir <- file.path(fig_dir, "04_results", "legends")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(analysis_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(legend_dir, recursive = TRUE, showWarnings = FALSE)

# This is a practical-equivalence margin, not a fitted value. A margin of 0.15
# means that mean shifts smaller than 15% of the B1-B2 width are treated as not
# biologically important. Change this only with a documented biological reason.
equivalence_margin <- 0.15
alpha <- 0.05

group_levels <- c("WT-MIC2", "ICMAP1-MIC2", "ICMAP2-MIC2", "ARO-MIC2")
group_labels <- c(
  "WT-MIC2" = "WT",
  "ICMAP1-MIC2" = "ICMAP1 KO",
  "ICMAP2-MIC2" = "ICMAP2 KO",
  "ARO-MIC2" = "ARO KO"
)
group_colors <- c(
  "WT-MIC2" = "#30343B",
  "ICMAP1-MIC2" = "#178A5B",
  "ICMAP2-MIC2" = "#2878B5",
  "ARO-MIC2" = "#D14A3A"
)

required_columns <- c(
  "group", "cell_id", "purple_peak_height", "icmt_imputed",
  "included_in_average", "qc_flag", "orientation_reversed",
  "icmt_position_normalized", "purple_position_normalized",
  "purple_minus_icmt_normalized"
)

extract_acquisition_date <- function(cell_id) {
  has_date <- grepl("[0-9]{8}$", cell_id, perl = TRUE)
  out <- rep(NA_character_, length(cell_id))
  out[has_date] <- sub(".*([0-9]{8})$", "\\1", cell_id[has_date], perl = TRUE)
  out
}

read_group_measurements <- function(group_name) {
  path <- file.path(
    single_group_results_dir, group_name,
    "peak_measurements_per_cell.csv"
  )
  if (!file.exists(path)) stop("Missing per-cell result for ", group_name, ": ", path)

  dat <- read.csv(path, check.names = FALSE, stringsAsFactors = FALSE)
  missing_columns <- setdiff(required_columns, names(dat))
  if (length(missing_columns)) {
    stop(group_name, " is missing columns: ", paste(missing_columns, collapse = ", "))
  }

  # All groups must be analyzed without direction reversal for this comparison.
  if (any(dat$orientation_reversed %in% TRUE, na.rm = TRUE)) {
    stop(group_name, " contains orientation-reversed measurements.")
  }

  keep <- dat$included_in_average %in% TRUE &
    is.finite(dat$purple_position_normalized) &
    is.finite(dat$icmt_position_normalized) &
    is.finite(dat$purple_minus_icmt_normalized)
  dat <- dat[keep, , drop = FALSE]
  if (!nrow(dat)) stop("No included finite measurements for ", group_name)

  data.frame(
    group = group_name,
    group_label = unname(group_labels[group_name]),
    cell_id = dat$cell_id,
    acquisition_date = extract_acquisition_date(dat$cell_id),
    mic2_position_B1_B2 = dat$purple_position_normalized,
    icmt_position_B1_B2 = dat$icmt_position_normalized,
    mic2_minus_icmt = dat$purple_minus_icmt_normalized,
    mic2_distance_from_midpoint = abs(dat$purple_position_normalized - 0.5),
    purple_peak_height = dat$purple_peak_height,
    icmt_imputed = dat$icmt_imputed %in% TRUE,
    qc_flag = dat$qc_flag,
    source_file = path,
    stringsAsFactors = FALSE
  )
}

analysis_data <- do.call(rbind, lapply(group_levels, read_group_measurements))
analysis_data$group <- factor(analysis_data$group, levels = group_levels)
analysis_data$group_label <- factor(
  analysis_data$group_label,
  levels = unname(group_labels[group_levels])
)

metric_config <- data.frame(
  metric = c("mic2_position_B1_B2", "mic2_minus_icmt"),
  metric_label = c(
    "MIC2 position relative to B1-B2",
    "MIC2 position minus ICMT position"
  ),
  stringsAsFactors = FALSE
)

long_data <- do.call(rbind, lapply(seq_len(nrow(metric_config)), function(i) {
  data.frame(
    analysis_data[c("group", "group_label", "cell_id", "acquisition_date",
                    "icmt_imputed", "qc_flag")],
    metric = metric_config$metric[i],
    metric_label = metric_config$metric_label[i],
    value = analysis_data[[metric_config$metric[i]]],
    stringsAsFactors = FALSE
  )
}))
long_data$metric_label <- factor(
  long_data$metric_label,
  levels = metric_config$metric_label
)

summarize_values <- function(x) {
  x <- x[is.finite(x)]
  n <- length(x)
  se <- if (n > 1L) sd(x) / sqrt(n) else NA_real_
  critical <- if (n > 1L) qt(0.975, n - 1L) else NA_real_
  data.frame(
    n = n,
    mean = mean(x),
    sd = if (n > 1L) sd(x) else NA_real_,
    sem = se,
    median = median(x),
    q1 = unname(quantile(x, 0.25)),
    q3 = unname(quantile(x, 0.75)),
    ci95_low = mean(x) - critical * se,
    ci95_high = mean(x) + critical * se
  )
}

summary_rows <- lapply(split(
  long_data,
  interaction(long_data$metric, long_data$group, drop = TRUE)
), function(z) {
  cbind(
    data.frame(
      group = as.character(z$group[1]),
      group_label = as.character(z$group_label[1]),
      metric = z$metric[1],
      metric_label = as.character(z$metric_label[1]),
      stringsAsFactors = FALSE
    ),
    summarize_values(z$value)
  )
})
group_summary <- do.call(rbind, summary_rows)
rownames(group_summary) <- NULL

hedges_g <- function(x, y) {
  nx <- length(x)
  ny <- length(y)
  pooled_sd <- sqrt(((nx - 1) * var(x) + (ny - 1) * var(y)) / (nx + ny - 2))
  if (!is.finite(pooled_sd) || pooled_sd == 0) return(NA_real_)
  correction <- 1 - 3 / (4 * (nx + ny) - 9)
  correction * (mean(x) - mean(y)) / pooled_sd
}

compare_with_wt <- function(metric, mutant_group, data = analysis_data) {
  x <- data[data$group == mutant_group, metric]
  y <- data[data$group == "WT-MIC2", metric]
  x <- x[is.finite(x)]
  y <- y[is.finite(y)]
  if (length(x) < 2L || length(y) < 2L) return(NULL)

  difference <- mean(x) - mean(y)
  se <- sqrt(var(x) / length(x) + var(y) / length(y))
  df <- (var(x) / length(x) + var(y) / length(y))^2 /
    ((var(x) / length(x))^2 / (length(x) - 1) +
       (var(y) / length(y))^2 / (length(y) - 1))
  tt <- t.test(x, y, var.equal = FALSE)
  wt <- suppressWarnings(wilcox.test(x, y, exact = FALSE))
  ks <- suppressWarnings(ks.test(x, y, exact = FALSE))

  # TOST for H0: difference <= -margin or difference >= +margin.
  tost_lower_p <- 1 - pt((difference + equivalence_margin) / se, df = df)
  tost_upper_p <- pt((difference - equivalence_margin) / se, df = df)
  tost_p <- max(tost_lower_p, tost_upper_p)
  ci90_low <- difference - qt(0.95, df = df) * se
  ci90_high <- difference + qt(0.95, df = df) * se

  data.frame(
    metric = metric,
    mutant_group = mutant_group,
    mutant_label = unname(group_labels[mutant_group]),
    reference_group = "WT-MIC2",
    n_mutant = length(x),
    n_wt = length(y),
    mean_mutant = mean(x),
    mean_wt = mean(y),
    mean_difference_mutant_minus_wt = difference,
    difference_ci95_low = tt$conf.int[1],
    difference_ci95_high = tt$conf.int[2],
    welch_t_p_value = tt$p.value,
    wilcoxon_p_value = wt$p.value,
    ks_distribution_p_value = ks$p.value,
    hedges_g = hedges_g(x, y),
    equivalence_margin = equivalence_margin,
    difference_ci90_low = ci90_low,
    difference_ci90_high = ci90_high,
    tost_lower_p_value = tost_lower_p,
    tost_upper_p_value = tost_upper_p,
    tost_p_value = tost_p,
    equivalent_at_alpha = tost_p < alpha,
    stringsAsFactors = FALSE
  )
}

comparison_rows <- list()
for (metric in metric_config$metric) {
  for (mutant_group in group_levels[-1]) {
    comparison_rows[[length(comparison_rows) + 1L]] <-
      compare_with_wt(metric, mutant_group)
  }
}
comparisons <- do.call(rbind, comparison_rows)
comparisons$welch_t_p_holm <- ave(
  comparisons$welch_t_p_value, comparisons$metric,
  FUN = function(x) p.adjust(x, method = "holm")
)
comparisons$wilcoxon_p_holm <- ave(
  comparisons$wilcoxon_p_value, comparisons$metric,
  FUN = function(x) p.adjust(x, method = "holm")
)
comparisons$ks_distribution_p_holm <- ave(
  comparisons$ks_distribution_p_value, comparisons$metric,
  FUN = function(x) p.adjust(x, method = "holm")
)
comparisons$distribution_difference_detected <-
  comparisons$ks_distribution_p_holm < alpha
comparisons$conclusion <- ifelse(
  comparisons$equivalent_at_alpha & !comparisons$distribution_difference_detected,
  "No large mean shift and no distributional difference detected",
  ifelse(
    comparisons$equivalent_at_alpha & comparisons$distribution_difference_detected,
    "No large mean shift, but a distributional difference was detected",
    "Practical equivalence was not established"
  )
)

global_rows <- lapply(metric_config$metric, function(metric) {
  form <- as.formula(paste(metric, "~ group"))
  welch <- oneway.test(form, data = analysis_data, var.equal = FALSE)
  kw <- kruskal.test(form, data = analysis_data)
  data.frame(
    metric = metric,
    test = c("Welch one-way ANOVA", "Kruskal-Wallis"),
    statistic = c(unname(welch$statistic), unname(kw$statistic)),
    df_numerator = c(unname(welch$parameter[1]), unname(kw$parameter)),
    df_denominator = c(unname(welch$parameter[2]), NA_real_),
    p_value = c(welch$p.value, kw$p.value),
    stringsAsFactors = FALSE
  )
})
global_tests <- do.call(rbind, global_rows)

# Sensitivity analysis excludes measurements whose ICMT position was imputed.
direct_data <- analysis_data[!analysis_data$icmt_imputed, , drop = FALSE]
direct_rows <- list()
for (metric in metric_config$metric) {
  for (mutant_group in group_levels[-1]) {
    row <- compare_with_wt(metric, mutant_group, data = direct_data)
    if (!is.null(row)) direct_rows[[length(direct_rows) + 1L]] <- row
  }
}
direct_comparisons <- do.call(rbind, direct_rows)

batch_summary <- do.call(rbind, lapply(split(
  analysis_data,
  interaction(analysis_data$group, analysis_data$acquisition_date, drop = TRUE)
), function(z) {
  data.frame(
    group = as.character(z$group[1]),
    acquisition_date = z$acquisition_date[1],
    n = nrow(z),
    mean_mic2_position_B1_B2 = mean(z$mic2_position_B1_B2),
    sd_mic2_position_B1_B2 = if (nrow(z) > 1L) sd(z$mic2_position_B1_B2) else NA_real_,
    mean_mic2_minus_icmt = mean(z$mic2_minus_icmt),
    sd_mic2_minus_icmt = if (nrow(z) > 1L) sd(z$mic2_minus_icmt) else NA_real_,
    stringsAsFactors = FALSE
  )
}))
rownames(batch_summary) <- NULL

# Same-date comparisons reduce acquisition-batch confounding when a mutant and
# WT were both measured on the same date. Require at least three observations
# in each group; smaller same-date subsets are listed in batch_summary only.
same_date_rows <- list()
for (mutant_group in group_levels[-1]) {
  common_dates <- intersect(
    unique(analysis_data$acquisition_date[analysis_data$group == mutant_group]),
    unique(analysis_data$acquisition_date[analysis_data$group == "WT-MIC2"])
  )
  common_dates <- common_dates[!is.na(common_dates)]
  for (acquisition_date in common_dates) {
    date_data <- analysis_data[
      analysis_data$acquisition_date == acquisition_date,
      ,
      drop = FALSE
    ]
    n_mutant <- sum(date_data$group == mutant_group)
    n_wt <- sum(date_data$group == "WT-MIC2")
    if (n_mutant < 3L || n_wt < 3L) next
    for (metric in metric_config$metric) {
      row <- compare_with_wt(metric, mutant_group, data = date_data)
      if (!is.null(row)) {
        row$acquisition_date <- acquisition_date
        same_date_rows[[length(same_date_rows) + 1L]] <- row
      }
    }
  }
}
same_date_comparisons <- if (length(same_date_rows)) {
  do.call(rbind, same_date_rows)
} else {
  data.frame(note = "No same-date mutant/WT comparison had at least n=3 per group")
}

theme_analysis <- icat_theme_classic() +
  theme(
    plot.title = element_text(face = "bold", size = ICAT_FONT_TITLE_PT),
    plot.subtitle = element_text(color = "#444444"),
    axis.text.y = element_text(face = "bold"),
    legend.position = "none",
    plot.margin = margin(10, 14, 10, 10)
  )

position_data <- analysis_data
set.seed(20260630)
p_position <- ggplot(
  position_data,
  aes(x = mic2_position_B1_B2, y = group_label, color = group, fill = group)
) +
  geom_vline(xintercept = c(0, 1), color = "#333333", linewidth = 0.55) +
  geom_vline(xintercept = 0.5, color = "#777777", linetype = "dashed", linewidth = 0.45) +
  geom_violin(scale = "width", trim = FALSE, width = 0.78, alpha = 0.14, color = NA) +
  geom_boxplot(width = 0.17, outlier.shape = NA, alpha = 0.35, linewidth = 0.55) +
  geom_jitter(height = 0.09, width = 0, alpha = 0.52, size = 1.7) +
  stat_summary(fun = mean, geom = "point", shape = 18, size = 4, color = "black") +
  scale_color_manual(values = group_colors) +
  scale_fill_manual(values = group_colors) +
  scale_x_continuous(
    breaks = seq(0, 1, 0.25),
    labels = sprintf("%.2f", seq(0, 1, 0.25)), expand = expansion(mult = 0)
  ) +
  coord_cartesian(xlim = c(0, 1)) +
  labs(
    title = "MIC2 peak position relative to conoid boundaries",
    subtitle = "Black diamonds show group means; dashed line marks the B1-B2 midpoint",
    x = "Normalized position across B1-B2",
    y = NULL
  ) +
  theme_analysis

p_offset <- ggplot(
  analysis_data,
  aes(x = mic2_minus_icmt, y = group_label, color = group, fill = group)
) +
  geom_vline(xintercept = 0, color = "#777777", linetype = "dashed", linewidth = 0.45) +
  geom_violin(scale = "width", trim = FALSE, width = 0.78, alpha = 0.14, color = NA) +
  geom_boxplot(width = 0.17, outlier.shape = NA, alpha = 0.35, linewidth = 0.55) +
  geom_jitter(height = 0.09, width = 0, alpha = 0.52, size = 1.7) +
  stat_summary(fun = mean, geom = "point", shape = 18, size = 4, color = "black") +
  scale_color_manual(values = group_colors) +
  scale_fill_manual(values = group_colors) +
  scale_x_continuous(breaks = seq(0, 0.8, 0.1)) +
  labs(
    title = "MIC2 position relative to ICMTs",
    subtitle = "Positive values place MIC2 to the right of ICMTs in the original ZEN direction",
    x = "MIC2 position - ICMT position (normalized B1-B2 units)",
    y = NULL
  ) +
  theme_analysis

comparisons$metric_label <- metric_config$metric_label[
  match(comparisons$metric, metric_config$metric)
]
comparisons$mutant_label <- factor(
  comparisons$mutant_label,
  levels = rev(unname(group_labels[group_levels[-1]]))
)

wt_sd_reference <- group_summary[
  group_summary$group == "WT-MIC2" &
    group_summary$metric %in% metric_config$metric,
  c("metric", "metric_label", "sd"),
  drop = FALSE
]
wt_sd_reference$metric_label <- factor(
  wt_sd_reference$metric_label,
  levels = metric_config$metric_label
)
wt_sd_bands <- do.call(rbind, lapply(seq_len(nrow(wt_sd_reference)), function(i) {
  row <- wt_sd_reference[i, , drop = FALSE]
  rbind(
    data.frame(
      metric_label = row$metric_label,
      sd_band = "WT +/- 2 SD",
      xmin = -2 * row$sd,
      xmax = 2 * row$sd,
      stringsAsFactors = FALSE
    ),
    data.frame(
      metric_label = row$metric_label,
      sd_band = "WT +/- 1 SD",
      xmin = -row$sd,
      xmax = row$sd,
      stringsAsFactors = FALSE
    )
  )
}))
wt_sd_bands$metric_label <- factor(wt_sd_bands$metric_label, levels = metric_config$metric_label)
wt_sd_bands$sd_band <- factor(wt_sd_bands$sd_band, levels = c("WT +/- 2 SD", "WT +/- 1 SD"))

comparisons_effect_plot <- merge(
  comparisons,
  wt_sd_reference[c("metric", "sd")],
  by = "metric",
  all.x = TRUE,
  sort = FALSE
)
comparisons_effect_plot$metric_label <- metric_config$metric_label[
  match(comparisons_effect_plot$metric, metric_config$metric)
]
comparisons_effect_plot$metric_label <- factor(
  comparisons_effect_plot$metric_label,
  levels = metric_config$metric_label
)
comparisons_effect_plot$mutant_label <- factor(
  comparisons_effect_plot$mutant_label,
  levels = rev(unname(group_labels[group_levels[-1]]))
)
comparisons_effect_plot$mean_difference_wt_sd <- comparisons_effect_plot$mean_difference_mutant_minus_wt /
  comparisons_effect_plot$sd
comparisons_effect_plot$difference_ci90_low_wt_sd <- comparisons_effect_plot$difference_ci90_low /
  comparisons_effect_plot$sd
comparisons_effect_plot$difference_ci90_high_wt_sd <- comparisons_effect_plot$difference_ci90_high /
  comparisons_effect_plot$sd
comparisons_effect_plot$equivalence_margin_wt_sd <- equivalence_margin /
  comparisons_effect_plot$sd

wt_sd_bands_axis <- do.call(rbind, lapply(seq_len(nrow(wt_sd_reference)), function(i) {
  row <- wt_sd_reference[i, , drop = FALSE]
  rbind(
    data.frame(
      metric_label = row$metric_label,
      sd_band = "WT +/- 2 SD",
      xmin = -2,
      xmax = 2,
      stringsAsFactors = FALSE
    ),
    data.frame(
      metric_label = row$metric_label,
      sd_band = "WT +/- 1 SD",
      xmin = -1,
      xmax = 1,
      stringsAsFactors = FALSE
    )
  )
}))
wt_sd_bands_axis$metric_label <- factor(wt_sd_bands_axis$metric_label, levels = metric_config$metric_label)
wt_sd_bands_axis$sd_band <- factor(wt_sd_bands_axis$sd_band, levels = c("WT +/- 2 SD", "WT +/- 1 SD"))

equivalence_margin_lines <- rbind(
  data.frame(
    metric_label = comparisons_effect_plot$metric_label,
    xintercept = -comparisons_effect_plot$equivalence_margin_wt_sd,
    stringsAsFactors = FALSE
  ),
  data.frame(
    metric_label = comparisons_effect_plot$metric_label,
    xintercept = comparisons_effect_plot$equivalence_margin_wt_sd,
    stringsAsFactors = FALSE
  )
)
equivalence_margin_lines <- unique(equivalence_margin_lines)
equivalence_margin_lines$metric_label <- factor(
  equivalence_margin_lines$metric_label,
  levels = metric_config$metric_label
)

effect_x_limit <- max(
  2,
  max(abs(equivalence_margin_lines$xintercept), na.rm = TRUE),
  max(
    abs(comparisons_effect_plot$difference_ci90_low_wt_sd),
    abs(comparisons_effect_plot$difference_ci90_high_wt_sd),
    na.rm = TRUE
  )
) * 1.08

p_effect <- ggplot(
  comparisons_effect_plot,
  aes(x = mean_difference_wt_sd, y = mutant_label)
) +
  geom_rect(
    data = wt_sd_bands_axis[wt_sd_bands_axis$sd_band == "WT +/- 2 SD", , drop = FALSE],
    aes(xmin = xmin, xmax = xmax, ymin = -Inf, ymax = Inf),
    inherit.aes = FALSE, fill = "#EFEFEF", color = NA
  ) +
  geom_rect(
    data = wt_sd_bands_axis[wt_sd_bands_axis$sd_band == "WT +/- 1 SD", , drop = FALSE],
    aes(xmin = xmin, xmax = xmax, ymin = -Inf, ymax = Inf),
    inherit.aes = FALSE, fill = "#D8D8D8", color = NA
  ) +
  geom_vline(xintercept = 0, color = "#333333", linewidth = 0.55) +
  geom_vline(
    data = equivalence_margin_lines,
    aes(xintercept = xintercept),
    inherit.aes = FALSE,
    color = "#397A55", linetype = "dashed", linewidth = 0.45
  ) +
  geom_errorbar(
    aes(
      xmin = difference_ci90_low_wt_sd,
      xmax = difference_ci90_high_wt_sd,
      color = mutant_group
    ),
    orientation = "y", width = 0.16, linewidth = ICAT_LINE_MM
  ) +
  geom_point(aes(color = mutant_group), shape = 18, size = 3.8) +
  facet_wrap(~metric_label, ncol = 1) +
  scale_color_manual(values = group_colors) +
  scale_x_continuous(
    limits = c(-effect_x_limit, effect_x_limit),
    breaks = -2:2,
    labels = c("-2σ", "-1σ", "0", "+1σ", "+2σ"),
    expand = expansion(mult = 0)
  ) +
  labs(
    title = "MIC2 mean shifts relative to WT",
    subtitle = paste0(
      "Dark and light grey bands show WT +/-1 and +/-2 s.d.; green dashed lines mark +/-",
      equivalence_margin, " B1-B2 units"
    ),
    x = "Mean difference relative to WT (WT s.d. units)",
    y = NULL
  ) +
  theme_analysis +
  theme(strip.text = element_text(face = "bold"))

p_ecdf <- ggplot(
  long_data,
  aes(x = value, color = group)
) +
  stat_ecdf(linewidth = 0.9) +
  facet_wrap(~metric_label, ncol = 1, scales = "free_x") +
  scale_color_manual(values = group_colors, labels = group_labels) +
  labs(
    title = "MIC2 position distributions",
    subtitle = "Empirical cumulative distributions show the full observed distribution",
    x = "Normalized position",
    y = "Cumulative fraction",
    color = NULL
  ) +
  icat_theme_classic() +
  theme(
    legend.position = "top",
    plot.title = element_text(face = "bold", size = ICAT_FONT_TITLE_PT),
    strip.text = element_text(face = "bold")
  )

read_normalized_profiles <- function(group_name) {
  path <- file.path(
    corrected_profile_dir, group_name, "aligned_profiles_normalized.csv"
  )
  if (!file.exists(path)) stop("Missing normalized profile table: ", path)
  dat <- read.csv(path, check.names = FALSE, stringsAsFactors = FALSE)
  required <- c("group", "cell_id", "position_normalized", "channel", "intensity")
  missing <- setdiff(required, names(dat))
  if (length(missing)) {
    stop(group_name, " normalized profiles are missing columns: ",
         paste(missing, collapse = ", "))
  }
  dat <- dat[
    dat$channel %in% c("Green", "Purple") &
      is.finite(dat$position_normalized) &
      dat$position_normalized >= -0.35 &
      dat$position_normalized <= 1.35,
    required,
    drop = FALSE
  ]
  dat$group <- group_name
  dat$group_label <- unname(group_labels[group_name])
  dat
}

read_mean_normalized_profile <- function(group_name) {
  path <- file.path(
    corrected_profile_dir, group_name, "mean_profile_normalized.csv"
  )
  if (!file.exists(path)) stop("Missing mean normalized profile table: ", path)
  dat <- read.csv(path, check.names = FALSE, stringsAsFactors = FALSE)
  required <- c("channel", "position_normalized", "n", "mean")
  missing <- setdiff(required, names(dat))
  if (length(missing)) {
    stop(group_name, " mean normalized profile is missing columns: ",
         paste(missing, collapse = ", "))
  }
  dat <- dat[
    dat$channel %in% c("Green", "Purple") &
      is.finite(dat$position_normalized) &
      dat$position_normalized >= -0.35 &
      dat$position_normalized <= 1.35,
    ,
    drop = FALSE
  ]
  dat$group <- group_name
  dat$group_label <- unname(group_labels[group_name])
  dat
}

mutant_profile_groups <- group_levels[-1]
mutant_profiles <- do.call(rbind, lapply(mutant_profile_groups, read_normalized_profiles))
mutant_profile_means <- do.call(
  rbind,
  lapply(mutant_profile_groups, read_mean_normalized_profile)
)
wt_profile_reference <- read_mean_normalized_profile("WT-MIC2")

mutant_profiles$group <- factor(mutant_profiles$group, levels = mutant_profile_groups)
mutant_profiles$group_label <- factor(
  mutant_profiles$group_label,
  levels = unname(group_labels[mutant_profile_groups])
)
mutant_profile_means$group <- factor(mutant_profile_means$group, levels = mutant_profile_groups)
mutant_profile_means$group_label <- factor(
  mutant_profile_means$group_label,
  levels = unname(group_labels[mutant_profile_groups])
)

wt_reference_by_panel <- do.call(rbind, lapply(mutant_profile_groups, function(group_name) {
  out <- wt_profile_reference
  out$reference_group <- "WT-MIC2"
  out$group <- group_name
  out$group_label <- unname(group_labels[group_name])
  out
}))
wt_reference_by_panel$group <- factor(wt_reference_by_panel$group, levels = mutant_profile_groups)
wt_reference_by_panel$group_label <- factor(
  wt_reference_by_panel$group_label,
  levels = unname(group_labels[mutant_profile_groups])
)

profile_channel_colors <- c(
  "Green" = "#7A9A8A",
  "Purple" = "#8E3B9C"
)

p_mutant_profiles_wt_reference <- ggplot() +
  geom_line(
    data = mutant_profiles,
    aes(
      x = position_normalized, y = intensity,
      group = interaction(cell_id, channel), color = channel
    ),
    alpha = 0.13, linewidth = 0.22, na.rm = TRUE
  ) +
  geom_line(
    data = wt_reference_by_panel,
    aes(x = position_normalized, y = mean, color = channel),
    linewidth = 0.38, linetype = "22", alpha = 0.9, na.rm = TRUE
  ) +
  geom_line(
    data = mutant_profile_means,
    aes(x = position_normalized, y = mean, color = channel),
    linewidth = 0.62, lineend = "round", na.rm = TRUE
  ) +
  geom_vline(xintercept = c(0, 1), color = "#9B9B9B", linewidth = ICAT_LINE_MM) +
  geom_vline(
    xintercept = 0.5, color = "#555555", linetype = "dotted",
    linewidth = ICAT_LINE_MM
  ) +
  facet_grid(. ~ group_label) +
  scale_color_manual(
    values = profile_channel_colors,
    breaks = c("Green", "Purple"),
    labels = c("ICMT/Tubulin", "MIC2")
  ) +
  coord_cartesian(xlim = c(-0.25, 1.25), ylim = c(0, 1.04), clip = "off") +
  scale_x_continuous(breaks = c(0, 0.5, 1), labels = c("B1", "0.5", "B2")) +
  scale_y_continuous(breaks = c(0, 0.5, 1.0), labels = c("0", "0.5", "1.0")) +
  labs(
    x = "Normalized position",
    y = "Norm. intensity",
    color = NULL
  ) +
  icat_theme_classic() +
  theme(
    legend.position = "none",
    axis.title = element_text(size = ICAT_FONT_SMALL_PT),
    axis.text = element_text(size = ICAT_FONT_SMALL_PT, color = "black"),
    strip.background = element_blank(),
    strip.text.x = element_text(face = "bold", size = ICAT_FONT_SMALL_PT),
    panel.spacing.x = unit(1.0, "mm"),
    plot.margin = margin(1.2, 1.5, 1.2, 1.2, "mm")
  )

mutant_profile_plot_data <- rbind(
  data.frame(
    mutant_profiles[c("group", "group_label", "cell_id", "channel",
                      "position_normalized", "intensity")],
    layer = "mutant_individual",
    reference_group = NA_character_,
    stringsAsFactors = FALSE
  ),
  data.frame(
    group = mutant_profile_means$group,
    group_label = mutant_profile_means$group_label,
    cell_id = NA_character_,
    channel = mutant_profile_means$channel,
    position_normalized = mutant_profile_means$position_normalized,
    intensity = mutant_profile_means$mean,
    layer = "mutant_mean",
    reference_group = NA_character_,
    stringsAsFactors = FALSE
  ),
  data.frame(
    group = wt_reference_by_panel$group,
    group_label = wt_reference_by_panel$group_label,
    cell_id = NA_character_,
    channel = wt_reference_by_panel$channel,
    position_normalized = wt_reference_by_panel$position_normalized,
    intensity = wt_reference_by_panel$mean,
    layer = "WT_mean_reference_from_Fig1B",
    reference_group = wt_reference_by_panel$reference_group,
    stringsAsFactors = FALSE
  )
)

save_plot <- function(plot, stem, width, height) {
  ggsave(
    file.path(figure_dir, paste0(stem, ".png")), plot,
    width = width, height = height, dpi = 300, bg = "white"
  )
  ggsave(
    file.path(figure_dir, paste0(stem, ".pdf")), plot,
    width = width, height = height, device = cairo_pdf, bg = "white"
  )
}

save_plot(p_position, "01_MIC2_relative_to_boundaries", 8.2, 4.8)
save_plot(p_offset, "02_MIC2_relative_to_ICMTs", 8.2, 4.8)
save_plot(p_effect, "03_effect_sizes_vs_WT", 6.4, 6.4)
save_plot(p_ecdf, "04_MIC2_distribution_ECDF", 8.4, 6.4)
save_plot(
  p_mutant_profiles_wt_reference,
  "05_MIC2_mutant_profiles_WT_reference",
  8.2 / 2.54, 3.4 / 2.54
)

write.csv(analysis_data, file.path(table_dir, "analysis_dataset.csv"), row.names = FALSE)
write.csv(
  wt_sd_bands,
  file.path(table_dir, "WT_SD_reference_bands_for_effect_size_plot.csv"),
  row.names = FALSE
)
write.csv(
  comparisons_effect_plot,
  file.path(table_dir, "comparisons_vs_WT_effect_plot_WT_SD_units.csv"),
  row.names = FALSE
)
write.csv(
  mutant_profile_plot_data,
  file.path(table_dir, "mutant_profiles_WT_reference_plot_data.csv"),
  row.names = FALSE
)
write.csv(group_summary, file.path(table_dir, "group_summary.csv"), row.names = FALSE)
write.csv(comparisons, file.path(table_dir, "comparisons_vs_WT.csv"), row.names = FALSE)
write.csv(global_tests, file.path(table_dir, "global_tests.csv"), row.names = FALSE)
write.csv(
  direct_comparisons,
  file.path(table_dir, "comparisons_vs_WT_direct_ICMT_only.csv"),
  row.names = FALSE
)
write.csv(batch_summary, file.path(table_dir, "acquisition_batch_summary.csv"), row.names = FALSE)
write.csv(
  same_date_comparisons,
  file.path(table_dir, "same_date_sensitivity_comparisons.csv"),
  row.names = FALSE
)
write.csv(
  data.frame(
    parameter = c(
      "equivalence_margin", "alpha", "reference_group",
      "preserve_original_ZEN_direction", "included_measurement_rule",
      "primary_metrics"
    ),
    value = c(
      equivalence_margin, alpha, "WT-MIC2", "TRUE",
      "included_in_average == TRUE and finite peak positions",
      "MIC2 position across B1-B2; MIC2 minus ICMT position"
    ),
    stringsAsFactors = FALSE
  ),
  file.path(table_dir, "analysis_parameters.csv"),
  row.names = FALSE
)

readme_lines <- c(
  "# Microneme asymmetry analysis",
  "",
  "This analysis compares MIC2 peak position among WT-MIC2, ICMAP1-MIC2,",
  "ICMAP2-MIC2, and ARO-MIC2.",
  "",
  "## Run",
  "",
  "```bash",
  "Rscript Fig1_intro_spatial/03_code/peak_profiles/microneme_asymmetry_analysis.R",
  "```",
  "",
  "- B1 and B2 are normalized to 0 and 1.",
  "- Original ZEN line direction is preserved; no profile is flipped.",
  "- Only rows marked included_in_average with finite peak positions are used.",
  "- MIC2 is compared by its B1-B2 position and by MIC2 minus ICMT position.",
  "- The mutant profile figure uses the Fig. 1B profile style: light single-cell",
  "  traces, dark mutant mean traces, and dashed WT mean profiles as the reference.",
  "- The effect-size figure plots mutant-WT mean differences. Grey bands are",
  "  centered at zero and show the WT +/-1 s.d. and +/-2 s.d. ranges for each metric.",
  "  The plotted x-axis is scaled to WT s.d. units; raw differences remain",
  "  recorded in normalized B1-B2 units in comparisons_vs_WT.csv.",
  paste0("- Practical equivalence margin: +/-", equivalence_margin, " B1-B2 units."),
  "- Equivalence is tested with TOST; distribution shape is checked by KS tests.",
  "- A non-significant difference test alone is not treated as proof of equivalence.",
  "- The direct-ICMT sensitivity table excludes imputed ICMT positions.",
  "- Same-date sensitivity comparisons require at least n=3 per group per date.",
  "- Acquisition dates are unbalanced across groups, so genotype and batch are",
  "  partly confounded; consult acquisition_batch_summary.csv before attribution.",
  "",
  "Interpret comparisons_vs_WT.csv together with the effect-size figure. If TOST",
  "supports equivalence but the adjusted KS test is significant, the mean shift is",
  "smaller than the configured margin but the distributions are not identical."
)
writeLines(readme_lines, file.path(analysis_dir, "README.md"))

figure1e_legend_lines <- c(
  "e, MIC2 profiles in mutant parasites shown in d compared with the WT mean profile from b.",
  "Left, conoid-width-normalized line profiles for MIC2/Tubulin in mutant parasites.",
  "Light traces indicate individual cells; solid magenta lines indicate mutant MIC2 mean profiles; dashed magenta lines indicate the WT MIC2 mean profile from b.",
  "Green traces show ICMT/Tubulin profiles as the conoid reference; B1 and B2 mark the Tubulin-defined conoid boundaries.",
  "Right, mean MIC2 peak-position differences relative to WT, plotted in WT s.d. units.",
  "Points show mutant-WT mean differences and bars show 90% confidence intervals.",
  "Grey shading denotes +/-1 and +/-2 WT s.d.; green dashed lines indicate the predefined +/-0.15 B1-B2 practical-equivalence margin.",
  "Source data are provided as a Source Data file."
)
writeLines(figure1e_legend_lines, file.path(legend_dir, "Figure1E_legend.txt"))

cat("Microneme asymmetry analysis complete.\n")
cat("Included measurements by group:\n")
print(table(analysis_data$group))
cat("\nComparisons versus WT:\n")
print(comparisons[c(
  "metric", "mutant_group", "mean_difference_mutant_minus_wt",
  "difference_ci95_low", "difference_ci95_high", "welch_t_p_holm",
  "ks_distribution_p_holm", "equivalent_at_alpha", "conclusion"
)], row.names = FALSE)
