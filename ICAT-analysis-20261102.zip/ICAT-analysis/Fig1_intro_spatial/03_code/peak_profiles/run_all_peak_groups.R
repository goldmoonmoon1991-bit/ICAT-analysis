#!/usr/bin/env Rscript

# Run the peak-profile analysis independently for every sample folder in
# 01_raw_data and write a compact cross-group run summary.

script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
script_path <- if (length(script_arg)) {
  normalizePath(sub("^--file=", "", script_arg[[1]]), mustWork = TRUE)
} else {
  normalizePath("run_all_peak_groups.R", mustWork = TRUE)
}

code_dir <- dirname(script_path)
fig_dir <- normalizePath(file.path(code_dir, "..", ".."), mustWork = TRUE)
raw_data_dir <- file.path(fig_dir, "01_raw_data", "peak_profiles")
results_dir <- file.path(fig_dir, "04_results", "tables", "peak_profiles")
analysis_script <- file.path(code_dir, "analyze_peak_profiles.R")

requested <- sub("^--group=", "", grep(
  "^--group=",
  commandArgs(trailingOnly = TRUE),
  value = TRUE
))

groups <- sort(list.dirs(raw_data_dir, recursive = FALSE, full.names = FALSE))
groups <- groups[vapply(groups, function(group) {
  length(list.files(file.path(raw_data_dir, group), pattern = "Profile Data.*\\.csv$")) > 0L
}, logical(1))]

if (length(requested)) {
  groups <- intersect(groups, requested)
  if (!length(groups)) stop("Requested group folder was not found or contains no profile CSV files.")
}
if (!length(groups)) stop("No sample folders containing ZEN profile CSV files were found.")

dir.create(results_dir, recursive = TRUE, showWarnings = FALSE)
rows <- list()

for (group in groups) {
  cat("\n=== Analyzing", group, "===\n")
  status <- system2(
    file.path(R.home("bin"), "Rscript"),
    args = c(shQuote(analysis_script), shQuote(paste0("--group=", group)))
  )

  table_dir <- file.path(results_dir, group)
  measurement_path <- file.path(table_dir, "peak_measurements_per_cell.csv")
  position_path <- file.path(table_dir, "peak_position_summary.csv")

  if (status == 0L && file.exists(measurement_path) && file.exists(position_path)) {
    measurements <- read.csv(measurement_path, check.names = FALSE)
    positions <- read.csv(position_path, check.names = FALSE)
    get_mean <- function(structure) {
      value <- positions$mean_position[positions$structure == structure]
      if (length(value)) value[[1]] else NA_real_
    }
    direct_pass <- measurements$qc_flag == "PASS"
    imputed_pass <- measurements$qc_flag == "PASS_IMPUTED_ICMT_OVERLAP"
    accepted_pass <- direct_pass | imputed_pass
    rows[[length(rows) + 1L]] <- data.frame(
      group = group,
      status = "completed",
      raw_profile_count = nrow(measurements),
      included_in_average = sum(measurements$included_in_average),
      pass_count = sum(accepted_pass),
      direct_pass_count = sum(direct_pass),
      imputed_pass_count = sum(imputed_pass),
      review_count = sum(!accepted_pass),
      excluded_count = sum(!measurements$included_in_average),
      included_review_count = sum(
        measurements$included_in_average & !accepted_pass
      ),
      mean_icmts_position = get_mean("ICMTs"),
      mean_purple_position = get_mean("Purple")
    )
  } else {
    rows[[length(rows) + 1L]] <- data.frame(
      group = group,
      status = paste0("failed_status_", status),
      raw_profile_count = length(list.files(file.path(raw_data_dir, group), pattern = "Profile Data.*\\.csv$")),
      included_in_average = NA_integer_,
      pass_count = NA_integer_,
      direct_pass_count = NA_integer_,
      imputed_pass_count = NA_integer_,
      review_count = NA_integer_,
      excluded_count = NA_integer_,
      included_review_count = NA_integer_,
      mean_icmts_position = NA_real_,
      mean_purple_position = NA_real_
    )
  }
}

run_summary <- do.call(rbind, rows)
write.csv(run_summary, file.path(results_dir, "group_run_summary.csv"), row.names = FALSE)
print(run_summary, row.names = FALSE)

if (any(run_summary$status != "completed")) quit(status = 1L)
