#!/usr/bin/env Rscript

# Joint positional analysis of WT-MIC2 micronemes and ARO rhoptries relative
# to the two conoid boundaries (B1 = 0, B2 = 1) and ICMTs.

runtime_cache <- file.path(tempdir(), "joint-peak-profile-cache")
dir.create(runtime_cache, recursive = TRUE, showWarnings = FALSE)
Sys.setenv(XDG_CACHE_HOME = runtime_cache)

suppressPackageStartupMessages({
  library(ggplot2)
})

script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
script_path <- if (length(script_arg)) {
  normalizePath(sub("^--file=", "", script_arg[[1]]), mustWork = TRUE)
} else {
  normalizePath("rhoptry_microneme_asymmetry.R", mustWork = TRUE)
}

code_dir <- dirname(script_path)
fig_dir <- normalizePath(file.path(code_dir, "..", ".."), mustWork = TRUE)
project_root <- normalizePath(file.path(fig_dir, ".."), mustWork = TRUE)
source(file.path(project_root, "shared", "R", "plot_style.R"))
results_dir <- file.path(fig_dir, "04_results", "tables", "peak_profiles")
figure_dir <- file.path(fig_dir, "04_results", "figures", "peak_profiles", "joint_WT-MIC2_ARO")
table_dir <- file.path(fig_dir, "04_results", "tables", "peak_profiles", "joint_WT-MIC2_ARO")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)

group_config <- data.frame(
  group = c("ARO", "WT-MIC2"),
  purple_structure = c("Rhoptry", "Microneme"),
  stringsAsFactors = FALSE
)

required_columns <- c(
  "group", "cell_id", "icmt_position_normalized",
  "purple_position_normalized", "icmt_imputed",
  "included_in_average", "qc_flag"
)

read_group <- function(group, purple_structure) {
  path <- file.path(
    results_dir, group, "peak_measurements_per_cell.csv"
  )
  if (!file.exists(path)) stop("Missing single-group result: ", path)

  dat <- read.csv(path, check.names = FALSE, stringsAsFactors = FALSE)
  missing_columns <- setdiff(required_columns, names(dat))
  if (length(missing_columns)) {
    stop(group, " result is missing columns: ", paste(missing_columns, collapse = ", "))
  }

  dat <- dat[
    dat$included_in_average &
      is.finite(dat$icmt_position_normalized) &
      is.finite(dat$purple_position_normalized),
    ,
    drop = FALSE
  ]
  if (!nrow(dat)) stop("No included measurements for group: ", group)

  data.frame(
    group = group,
    purple_structure = purple_structure,
    cell_id = dat$cell_id,
    icmt_position = dat$icmt_position_normalized,
    structure_position = dat$purple_position_normalized,
    structure_minus_icmt =
      dat$purple_position_normalized - dat$icmt_position_normalized,
    absolute_structure_minus_icmt = abs(
      dat$purple_position_normalized - dat$icmt_position_normalized
    ),
    icmt_imputed = dat$icmt_imputed,
    source_qc_flag = dat$qc_flag,
    stringsAsFactors = FALSE
  )
}

paired <- do.call(rbind, lapply(seq_len(nrow(group_config)), function(i) {
  read_group(group_config$group[i], group_config$purple_structure[i])
}))

paired$group <- factor(paired$group, levels = c("ARO", "WT-MIC2"))
paired$group_label <- ifelse(
  paired$group == "ARO",
  "ARO: Rhoptry",
  "WT-MIC2: Microneme"
)
paired$group_y <- ifelse(paired$group == "ARO", 1, 2)
set.seed(27)
paired$y_jitter <- paired$group_y + runif(nrow(paired), -0.14, 0.14)

position_long <- rbind(
  data.frame(
    group = paired$group,
    group_label = paired$group_label,
    cell_id = paired$cell_id,
    marker = "ICMTs",
    position = paired$icmt_position,
    group_y = paired$group_y,
    y_jitter = paired$y_jitter,
    stringsAsFactors = FALSE
  ),
  data.frame(
    group = paired$group,
    group_label = paired$group_label,
    cell_id = paired$cell_id,
    marker = paired$purple_structure,
    position = paired$structure_position,
    group_y = paired$group_y,
    y_jitter = paired$y_jitter,
    stringsAsFactors = FALSE
  )
)

summarize_values <- function(values) {
  values <- values[is.finite(values)]
  n <- length(values)
  sem <- if (n > 1L) sd(values) / sqrt(n) else NA_real_
  critical <- if (n > 1L) qt(0.975, df = n - 1L) else NA_real_
  c(
    n = n,
    mean = if (n) mean(values) else NA_real_,
    median = if (n) median(values) else NA_real_,
    sd = if (n > 1L) sd(values) else NA_real_,
    sem = sem,
    ci95_low = if (n > 1L) mean(values) - critical * sem else NA_real_,
    ci95_high = if (n > 1L) mean(values) + critical * sem else NA_real_
  )
}

position_summary <- do.call(rbind, lapply(
  split(position_long, interaction(position_long$group, position_long$marker, drop = TRUE)),
  function(z) {
    stats <- summarize_values(z$position)
    data.frame(
      group = as.character(z$group[1]),
      marker = z$marker[1],
      group_label = z$group_label[1],
      t(stats),
      stringsAsFactors = FALSE
    )
  }
))
rownames(position_summary) <- NULL

offset_summary <- do.call(rbind, lapply(split(paired, paired$group), function(z) {
  stats <- summarize_values(z$structure_minus_icmt)
  data.frame(
    group = as.character(z$group[1]),
    purple_structure = z$purple_structure[1],
    metric = "structure_minus_icmt",
    t(stats),
    stringsAsFactors = FALSE
  )
}))
rownames(offset_summary) <- NULL

paired_test_row <- function(z) {
  tt <- t.test(z$structure_position, z$icmt_position, paired = TRUE)
  wt <- suppressWarnings(wilcox.test(
    z$structure_position, z$icmt_position, paired = TRUE, exact = FALSE
  ))
  data.frame(
    comparison = paste0(z$purple_structure[1], " versus ICMTs within ", z$group[1]),
    test_scope = "paired_within_group",
    n_group_1 = nrow(z),
    n_group_2 = nrow(z),
    mean_group_1 = mean(z$structure_position),
    mean_group_2 = mean(z$icmt_position),
    t_statistic = unname(tt$statistic),
    t_df = unname(tt$parameter),
    t_p_value_two_sided = tt$p.value,
    wilcoxon_statistic = unname(wt$statistic),
    wilcoxon_p_value_two_sided = wt$p.value,
    stringsAsFactors = FALSE
  )
}

between_test_row <- function(metric, label) {
  aro <- paired[paired$group == "ARO", metric]
  wt_values <- paired[paired$group == "WT-MIC2", metric]
  tt <- t.test(aro, wt_values)
  wt_test <- suppressWarnings(wilcox.test(aro, wt_values, exact = FALSE))
  data.frame(
    comparison = label,
    test_scope = "independent_between_groups",
    n_group_1 = length(aro),
    n_group_2 = length(wt_values),
    mean_group_1 = mean(aro),
    mean_group_2 = mean(wt_values),
    t_statistic = unname(tt$statistic),
    t_df = unname(tt$parameter),
    t_p_value_two_sided = tt$p.value,
    wilcoxon_statistic = unname(wt_test$statistic),
    wilcoxon_p_value_two_sided = wt_test$p.value,
    stringsAsFactors = FALSE
  )
}

statistical_tests <- rbind(
  do.call(rbind, lapply(split(paired, paired$group), paired_test_row)),
  between_test_row(
    "structure_position",
    "Rhoptry position in ARO versus microneme position in WT-MIC2"
  ),
  between_test_row(
    "structure_minus_icmt",
    "Rhoptry-ICMTs offset versus microneme-ICMTs offset"
  )
)
rownames(statistical_tests) <- NULL

marker_colors <- c(
  ICMTs = "#00874A",
  Rhoptry = "#D64B3B",
  Microneme = "#C000C8"
)

position_summary$group_y <- ifelse(position_summary$group == "ARO", 1, 2)
position_summary$summary_y <- position_summary$group_y + ifelse(
  position_summary$marker == "ICMTs", -0.22, 0.22
)

mean_segments <- merge(
  position_summary[position_summary$marker == "ICMTs", c("group", "mean", "group_y")],
  position_summary[position_summary$marker != "ICMTs", c("group", "mean")],
  by = "group",
  suffixes = c("_icmt", "_structure")
)

p <- ggplot() +
  geom_vline(xintercept = c(0, 1), color = "#333333", linewidth = 0.65) +
  geom_vline(xintercept = 0.5, color = "#777777", linewidth = 0.45, linetype = "dashed") +
  geom_segment(
    data = paired,
    aes(
      x = icmt_position, xend = structure_position,
      y = y_jitter, yend = y_jitter
    ),
    color = "#A7A7A7",
    alpha = 0.22,
    linewidth = 0.50
  ) +
  geom_point(
    data = position_long,
    aes(x = position, y = y_jitter, color = marker),
    alpha = 0.28,
    size = 1.8
  ) +
  geom_segment(
    data = mean_segments,
    aes(
      x = mean_icmt, xend = mean_structure,
      y = group_y, yend = group_y
    ),
    color = "#444444",
    linewidth = 2.0
  ) +
  geom_segment(
    data = position_summary,
    aes(
      x = ci95_low, xend = ci95_high,
      y = summary_y, yend = summary_y, color = marker
    ),
    linewidth = ICAT_LINE_MM
  ) +
  geom_point(
    data = position_summary,
    aes(x = mean, y = summary_y, color = marker),
    shape = 18,
    size = 4.2
  ) +
  annotate("text", x = 0, y = 2.48, label = "B1", fontface = "bold", size = ICAT_TEXT_TITLE_MM) +
  annotate(
    "text", x = 0.5, y = 2.48, label = "B midpoint",
    color = "#666666", size = ICAT_TEXT_BODY_MM
  ) +
  annotate("text", x = 1, y = 2.48, label = "B2", fontface = "bold", size = ICAT_TEXT_TITLE_MM) +
  scale_color_manual(values = marker_colors) +
  scale_x_continuous(
    breaks = seq(0, 1, by = 0.25),
    labels = sprintf("%.2f", seq(0, 1, by = 0.25)),
    expand = expansion(mult = 0)
  ) +
  scale_y_continuous(
    breaks = c(1, 2),
    labels = c("ARO: Rhoptry", "WT-MIC2: Microneme")
  ) +
  coord_cartesian(xlim = c(0, 1), ylim = c(0.55, 2.55), clip = "off") +
  labs(
    title = "Rhoptry and microneme positions relative to conoid boundaries and ICMTs",
    subtitle = paste0(
      "Original ZEN direction preserved; gray segments connect paired cell peaks\n",
      "Diamonds and horizontal bars show means and 95% CIs"
    ),
    x = "Normalized position across B1-B2",
    y = NULL,
    color = NULL
  ) +
  icat_theme_classic() +
  theme(
    legend.position = "top",
    axis.text.y = element_text(face = "bold"),
    plot.title = element_text(face = "bold"),
    plot.margin = margin(10, 18, 10, 10)
  )

ggsave(
  file.path(figure_dir, "WT_MIC2_ARO_relative_positions.png"),
  p, width = 9.2, height = 5.2, dpi = 300, bg = "white"
)
ggsave(
  file.path(figure_dir, "WT_MIC2_ARO_relative_positions.pdf"),
  p, width = 9.2, height = 5.2, device = cairo_pdf, bg = "white"
)

write.csv(paired, file.path(table_dir, "joint_peak_positions.csv"), row.names = FALSE)
write.csv(
  position_summary,
  file.path(table_dir, "joint_position_summary.csv"),
  row.names = FALSE
)
write.csv(
  offset_summary,
  file.path(table_dir, "joint_offset_summary.csv"),
  row.names = FALSE
)
write.csv(
  statistical_tests,
  file.path(table_dir, "joint_statistical_tests.csv"),
  row.names = FALSE
)

cat("Joint analysis complete.\n")
cat("ARO rhoptry measurements:", sum(paired$group == "ARO"), "\n")
cat("WT-MIC2 microneme measurements:", sum(paired$group == "WT-MIC2"), "\n")
print(position_summary[, c("group", "marker", "n", "mean", "ci95_low", "ci95_high")], row.names = FALSE)
