#!/usr/bin/env bash

# Rebuild every peak-profile analysis after files in 01_raw_data are changed.
# Single-group outputs are generated first because all downstream scripts read
# their corrected profiles and per-cell measurement tables.

set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
FIG_DIR="$(cd "${SCRIPT_DIR}/../.." && pwd)"
RAW_DATA_DIR="${FIG_DIR}/01_raw_data/peak_profiles"
RESULTS_DIR="${FIG_DIR}/04_results"
LOG_DIR="${RESULTS_DIR}/reports/peak_profiles/run_logs"
RUN_ID="$(date '+%Y%m%d_%H%M%S')"
LOG_FILE="${LOG_DIR}/run_all_analyses_${RUN_ID}.log"

mkdir -p "${LOG_DIR}"
: > "${LOG_FILE}"

CURRENT_STEP="initialization"
trap 'status=$?; printf "\n[FAILED] %s (exit code %s)\nLog: %s\n" "${CURRENT_STEP}" "${status}" "${LOG_FILE}"; exit "${status}"' ERR

if ! command -v Rscript >/dev/null 2>&1; then
  echo "Rscript was not found. Install R or add Rscript to PATH."
  exit 127
fi

if [[ ! -d "${RAW_DATA_DIR}" ]]; then
  echo "Raw-data directory was not found: ${RAW_DATA_DIR}"
  exit 1
fi

run_step() {
  local label="$1"
  local script="$2"

  CURRENT_STEP="${label}"
  if [[ ! -f "${script}" ]]; then
    echo "Required script was not found: ${script}"
    return 1
  fi

  printf "\n============================================================\n"
  printf "[%s] %s\n" "$(date '+%Y-%m-%d %H:%M:%S')" "${label}"
  printf "Script: %s\n" "${script}"
  printf "============================================================\n"
  Rscript --vanilla "${script}" 2>&1 | tee -a "${LOG_FILE}"
  printf "[DONE] %s\n" "${label}"
}

printf "Peak-profile full rebuild\n"
printf "Figure directory: %s\n" "${FIG_DIR}"
printf "Raw data: %s\n" "${RAW_DATA_DIR}"
printf "Log: %s\n" "${LOG_FILE}"

# This script discovers every sample folder in 01_raw_data and invokes
# analyze_peak_profiles.R once per group. Do not run that script again here.
run_step \
  "1/4 Rebuild all single-group profiles and QC" \
  "${SCRIPT_DIR}/run_all_peak_groups.R"

run_step \
  "2/4 Rebuild joint rhoptry-microneme position analysis" \
  "${SCRIPT_DIR}/rhoptry_microneme_asymmetry.R"

run_step \
  "3/4 Rebuild WT-versus-mutant microneme analysis" \
  "${SCRIPT_DIR}/microneme_asymmetry_analysis.R"

run_step \
  "4/4 Rebuild FWHM distances and spatial/regulatory figures" \
  "${SCRIPT_DIR}/symmetry_distance.R"

CURRENT_STEP="complete"
printf "\n============================================================\n"
printf "[SUCCESS] All analyses completed at %s\n" "$(date '+%Y-%m-%d %H:%M:%S')"
printf "Results: %s\n" "${RESULTS_DIR}"
printf "Log: %s\n" "${LOG_FILE}"
printf "============================================================\n"
