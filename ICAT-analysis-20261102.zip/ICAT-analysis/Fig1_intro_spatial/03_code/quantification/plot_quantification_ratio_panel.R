# Rebuild the horizontal Ratio(d/D) panel from per-tab CSV files.
# Run from any working directory with Rscript.

get_script_dir <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (length(file_arg) > 0) {
    return(dirname(normalizePath(sub("^--file=", "", file_arg[1]))))
  }
  if (interactive() && requireNamespace("rstudioapi", quietly = TRUE)) {
    path <- rstudioapi::getActiveDocumentContext()$path
    if (!is.null(path) && nzchar(path)) return(dirname(normalizePath(path)))
  }
  normalizePath(getwd())
}

code_dir <- get_script_dir()
fig_dir <- normalizePath(file.path(code_dir, "..", ".."), mustWork = TRUE)
project_root <- normalizePath(file.path(fig_dir, ".."), mustWork = TRUE)
source(file.path(project_root, "shared", "R", "plot_style.R"))
data_dir <- file.path(fig_dir, "01_raw_data", "quantification")
table_dir <- file.path(fig_dir, "04_results", "tables", "quantification")
figure_dir <- file.path(fig_dir, "04_results", "figures", "quantification")
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)

samples <- c("WT", "ICMAP1", "ARO", "ICMAP2")
csv_files <- file.path(data_dir, paste0(samples, ".csv"))

ratio_label <- "Ratio(d/D)"
x_min <- 0.0
x_max <- 0.8

compartments <- data.frame(
  name = c("Fm", "ICMT", "MVs", "Rhoptries"),
  color = c("#FFD57E", "#5F8B73", "#8C8C89", "#4A79B2"),
  stringsAsFactors = FALSE
)

compartment_state <- list(
  WT = c(TRUE, TRUE, TRUE, TRUE),
  ICMAP1 = c(FALSE, TRUE, TRUE, TRUE),
  ARO = c(TRUE, TRUE, TRUE, FALSE),
  ICMAP2 = c(FALSE, FALSE, FALSE, FALSE)
)

sample_colors <- c(
  WT = "#246A73",
  ICMAP1 = "#8A8F98",
  ARO = "#C05A4B",
  ICMAP2 = "#6B5CA5"
)

layout <- list(
  width = 2800,
  height = 1380,
  panel_label_x = 98,
  panel_label_y = 100,
  sample_label_x = 315,
  matrix_x = 450,
  matrix_y = 432,
  matrix_cell_w = 122,
  matrix_cell_h = 68,
  matrix_gap_y = 255,
  plot_x = 965,
  plot_y = 335,
  plot_w = 1710,
  plot_h = 930,
  axis_pad_left = 82,
  axis_pad_right = 55,
  axis_pad_top = 90,
  axis_pad_bottom = 42
)

layout$axis_x0 <- layout$plot_x + layout$axis_pad_left
layout$axis_x1 <- layout$plot_x + layout$plot_w - layout$axis_pad_right
layout$axis_y0 <- layout$plot_y + layout$axis_pad_top
layout$axis_y1 <- layout$plot_y + layout$plot_h - layout$axis_pad_bottom

read_ratio_csv <- function(sample, path) {
  if (!file.exists(path) || file.info(path)$size == 0) {
    return(data.frame(
      sample = character(),
      source_group = character(),
      point_id = integer(),
      value1 = numeric(),
      value2 = numeric(),
      ratio = numeric(),
      stringsAsFactors = FALSE
    ))
  }

  df <- read.csv(path, header = FALSE, stringsAsFactors = FALSE)
  if (nrow(df) == 0 || ncol(df) < 4) {
    return(data.frame(
      sample = character(),
      source_group = character(),
      point_id = integer(),
      value1 = numeric(),
      value2 = numeric(),
      ratio = numeric(),
      stringsAsFactors = FALSE
    ))
  }

  ratio <- suppressWarnings(as.numeric(df[[4]]))
  keep <- !is.na(ratio)
  data.frame(
    sample = sample,
    source_group = as.character(df[[1]][keep]),
    point_id = which(keep),
    value1 = suppressWarnings(as.numeric(df[[2]][keep])),
    value2 = suppressWarnings(as.numeric(df[[3]][keep])),
    ratio = ratio[keep],
    stringsAsFactors = FALSE
  )
}

ratio_data <- do.call(
  rbind,
  Map(read_ratio_csv, samples, csv_files)
)

summary_rows <- lapply(samples, function(sample) {
  values <- ratio_data$ratio[ratio_data$sample == sample]
  data.frame(
    sample = sample,
    n = length(values),
    mean = if (length(values)) mean(values) else NA_real_,
    median = if (length(values)) median(values) else NA_real_,
    sd = if (length(values) > 1) sd(values) else NA_real_,
    min = if (length(values)) min(values) else NA_real_,
    max = if (length(values)) max(values) else NA_real_,
    status = if (length(values)) "plotted" else "empty",
    stringsAsFactors = FALSE
  )
})
summary_table <- do.call(rbind, summary_rows)

write.csv(ratio_data, file.path(table_dir, "quantification_ratio_panel_R_data.csv"), row.names = FALSE)
write.csv(summary_table, file.path(table_dir, "quantification_ratio_panel_R_summary.csv"), row.names = FALSE)

row_center <- function(sample) {
  layout$matrix_y + (match(sample, samples) - 1) * layout$matrix_gap_y + layout$matrix_cell_h / 2
}

x_scale <- function(ratio) {
  layout$axis_x0 + (ratio - x_min) / (x_max - x_min) * (layout$axis_x1 - layout$axis_x0)
}

draw_left_panel <- function() {
  text(layout$panel_label_x, layout$panel_label_y, "C", cex = 10 / 9, font = 2, adj = c(0, 0))

  header_base_y <- layout$matrix_y - 72
  for (i in seq_len(nrow(compartments))) {
    x <- layout$matrix_x + (i - 1) * layout$matrix_cell_w + layout$matrix_cell_w / 2
    text(x, header_base_y, compartments$name[i], col = compartments$color[i],
         cex = 1, font = 2, srt = 90, adj = c(0, 0.5))
  }

  for (sample in samples) {
    y <- row_center(sample) - layout$matrix_cell_h / 2
    text(layout$sample_label_x, y + layout$matrix_cell_h / 2,
         sample, cex = 1, adj = c(0.5, 0.5))

    states <- compartment_state[[sample]]
    for (i in seq_along(states)) {
      x <- layout$matrix_x + (i - 1) * layout$matrix_cell_w
      fill <- if (states[i]) compartments$color[i] else "white"
      rect(x, y, x + layout$matrix_cell_w, y + layout$matrix_cell_h,
           col = fill, border = "#222222", lwd = 0.8)
    }
  }
}

draw_ratio_plot <- function(show_redbox = FALSE) {
  if (show_redbox) {
    rect(layout$plot_x, layout$plot_y,
         layout$plot_x + layout$plot_w, layout$plot_y + layout$plot_h,
         border = "#FF2B45", lwd = 2.2)
  }

  axis_y <- layout$plot_y + 58
  segments(layout$axis_x0, axis_y, layout$axis_x1, axis_y, col = "#333333", lwd = 2 / 3)

  ticks <- seq(x_min, x_max, by = 0.1)
  for (tick in ticks) {
    x <- x_scale(tick)
    segments(x, layout$axis_y0, x, layout$axis_y1, col = "#E5E7EB", lwd = 0.8)
    segments(x, axis_y - 12, x, axis_y, col = "#333333", lwd = 2 / 3)
    text(x, axis_y - 28, sprintf("%.1f", tick), cex = 8 / 9, col = "#333333", adj = c(0.5, 1))
  }
  text(layout$axis_x1, axis_y + 50, ratio_label, cex = 1, adj = c(1, 0.5), col = "#20262E")

  set.seed(31)
  grid <- seq(x_min, x_max, length.out = 260)
  density_height <- 62

  for (sample in samples) {
    values <- ratio_data$ratio[ratio_data$sample == sample]
    if (length(values) == 0) next

    center_y <- row_center(sample)
    color <- sample_colors[[sample]]

    dens <- density(values, from = x_min, to = x_max, n = length(grid), adjust = 1)
    dens_y <- approx(dens$x, dens$y, xout = grid, rule = 2)$y
    keep <- dens_y >= max(dens_y) * 0.015
    if (any(keep)) {
      lines(x_scale(grid[keep]), center_y - dens_y[keep] / max(dens_y) * density_height,
            col = color, lwd = 2.2)
    }

    jitter_y <- runif(length(values), min = -32, max = 32)
    points(x_scale(values), center_y + jitter_y,
           pch = 21, bg = color, col = "white", lwd = 0.8, cex = 0.8)

    mean_x <- x_scale(mean(values))
    segments(mean_x, center_y - 42, mean_x, center_y + 42, col = "black", lwd = 2.2)
  }
}

draw_panel <- function(show_redbox = FALSE) {
  old_par <- par(no.readonly = TRUE)
  on.exit(par(old_par))
  par(mar = c(0, 0, 0, 0), xaxs = "i", yaxs = "i")
  plot.new()
  plot.window(xlim = c(0, layout$width), ylim = c(layout$height, 0))
  draw_left_panel()
  draw_ratio_plot(show_redbox = show_redbox)
}

png(file.path(figure_dir, "quantification_ratio_panel_R_redbox.png"),
    width = layout$width, height = layout$height, res = 300, pointsize = 9)
draw_panel(show_redbox = TRUE)
dev.off()

png(file.path(figure_dir, "quantification_ratio_panel_R_clean.png"),
    width = layout$width, height = layout$height, res = 300, pointsize = 9)
draw_panel(show_redbox = FALSE)
dev.off()

pdf(file.path(figure_dir, "quantification_ratio_panel_R.pdf"),
    width = layout$width / 300, height = layout$height / 300, pointsize = 9, useDingbats = FALSE)
draw_panel(show_redbox = FALSE)
dev.off()

svg(file.path(figure_dir, "quantification_ratio_panel_R.svg"),
    width = layout$width / 300, height = layout$height / 300, pointsize = 9)
draw_panel(show_redbox = FALSE)
dev.off()

print(summary_table)
message("Saved R-generated outputs in: ", dirname(figure_dir))
