#!/usr/bin/env Rscript

script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
script_path <- normalizePath(sub("^--file=", "", script_arg[[1]]), mustWork = TRUE)
code_dir <- dirname(script_path)
fig_dir <- normalizePath(file.path(code_dir, ".."), mustWork = TRUE)
project_root <- normalizePath(file.path(fig_dir, ".."), mustWork = TRUE)
source(file.path(project_root, "shared", "R", "project_library.R"))
icat_activate_project_library(project_root)

run <- function(command, args) {
  status <- system2(command, args = shQuote(args))
  if (status != 0L) stop("Step failed: ", paste(c(command, args), collapse = " "))
}

run("bash", file.path(code_dir, "peak_profiles", "run_all_analyses.sh"))
run(file.path(R.home("bin"), "Rscript"), c("--vanilla", file.path(code_dir, "quantification", "plot_quantification_ratio_panel.R")))
