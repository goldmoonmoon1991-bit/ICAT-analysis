#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(ggplot2)
  library(scales)
  library(grid)
})

script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
script_path <- normalizePath(sub("^--file=", "", script_arg[[1]]), mustWork = TRUE)
fig_dir <- if (exists("FIG3_BASE_DIR", inherits = TRUE)) {
  normalizePath(get("FIG3_BASE_DIR", inherits = TRUE), mustWork = TRUE)
} else {
  normalizePath(file.path(dirname(script_path), "..", ".."), mustWork = TRUE)
}
find_project_root <- function(start_dir) {
  current <- normalizePath(start_dir, mustWork = TRUE)
  repeat {
    if (file.exists(file.path(current, "shared", "R", "plot_style.R"))) return(current)
    parent <- dirname(current)
    if (identical(parent, current)) stop("Could not locate project root from: ", start_dir)
    current <- parent
  }
}
project_root <- find_project_root(dirname(script_path))
source(file.path(project_root, "shared", "R", "plot_style.R"))
figure_dir <- file.path(fig_dir, "04_results", "figures", "spatial_relationship")
table_dir <- file.path(fig_dir, "04_results", "tables", "spatial_relationship")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)

aro_color <- "#a56441"
fig1_surface_summary <- file.path(
  project_root, "Fig1_intro_spatial", "04_results", "tables", "peak_profiles",
  "symmetry_distance", "surface_distance_summary.csv"
)
if (!file.exists(fig1_surface_summary)) {
  stop("Missing Fig1 ARO reference table: ", fig1_surface_summary)
}

pla_dir <- file.path(fig_dir, "01_raw_data", "PLA")
pla_samples <- c("CPH1", "CF5", "MIC2c", "MIC2n", "ICMAP1", "ICMAP2", "RON4")
pla_labels <- c(
  CPH1 = "CPH1", CF5 = "CF5", MIC2c = "MIC2\n(conoid)",
  MIC2n = "MIC2\n(non-conoid)", ICMAP1 = "ICMAP1",
  ICMAP2 = "ICMAP2", RON4 = "RON4"
)

pla <- do.call(rbind, lapply(pla_samples, function(sample) {
  values <- scan(
    file.path(pla_dir, paste0(sample, "-ICAT.csv")),
    what = numeric(), quiet = TRUE
  )
  data.frame(sample = sample, intensity = values, stringsAsFactors = FALSE)
}))
pla$sample <- factor(pla$sample, levels = pla_samples)
pla$positive <- pla$intensity > 1000

bootstrap_ci <- function(x, statistic = mean, reps = 5000L, seed = 2703L) {
  set.seed(seed + length(x))
  boot <- replicate(reps, statistic(sample(x, length(x), replace = TRUE)))
  unname(quantile(boot, c(0.025, 0.975), na.rm = TRUE))
}

pla_summary <- do.call(rbind, lapply(pla_samples, function(sample) {
  x <- pla$intensity[pla$sample == sample]
  median_ci <- bootstrap_ci(x, median)
  exact_ci <- binom.test(sum(x > 1000), length(x))$conf.int
  data.frame(
    sample = sample,
    n = length(x),
    median_intensity = median(x),
    median_ci95_low = median_ci[1],
    median_ci95_high = median_ci[2],
    positive_count = sum(x > 1000),
    positive_percent = 100 * mean(x > 1000),
    positive_ci95_low_percent = 100 * exact_ci[1],
    positive_ci95_high_percent = 100 * exact_ci[2]
  )
}))

control <- pla$intensity[pla$sample == "CPH1"]
pla_tests <- do.call(rbind, lapply(pla_samples[-1], function(sample) {
  x <- pla$intensity[pla$sample == sample]
  wt <- suppressWarnings(wilcox.test(x, control, exact = FALSE))
  ranks <- rank(c(x, control))
  u <- sum(ranks[seq_along(x)]) - length(x) * (length(x) + 1) / 2
  data.frame(
    comparison = paste(sample, "vs CPH1"),
    n_sample = length(x),
    n_control = length(control),
    rank_biserial = 2 * u / (length(x) * length(control)) - 1,
    wilcoxon_p = wt$p.value
  )
}))
pla_tests$holm_adjusted_p <- p.adjust(pla_tests$wilcoxon_p, method = "holm")

pla_colors <- c(
  CPH1 = "#B8B8B8", CF5 = "#D9A72E", MIC2c = "#63BE7B",
  MIC2n = "#D9D9D9", ICMAP1 = "#4E9CC9", ICMAP2 = "#7E82C8",
  RON4 = "#CF6A86"
)

pla_label_map <- c(
  CPH1 = "CPH1",
  CF5 = "CF5",
  MIC2c = "MIC2\n(conoid)",
  MIC2n = "MIC2\n(non-conoid)",
  ICMAP1 = "ICMAP1",
  ICMAP2 = "ICMAP2",
  RON4 = "RON4"
)

pla_rank <- pla_summary
pla_rank_order <- pla_rank$sample[order(-pla_rank$positive_percent, -pla_rank$median_intensity)]
pla_rank$sample_label <- factor(
  unname(pla_label_map[pla_rank$sample]),
  levels = unname(pla_label_map[pla_rank_order])
)
pla_rank <- pla_rank[match(pla_rank_order, pla_rank$sample), , drop = FALSE]
pla_rank$sample_label <- factor(pla_rank$sample_label, levels = levels(pla_rank$sample_label))

pla_strip_levels <- paste0(
  unname(pla_label_map[pla_rank_order]),
  "\n",
  format(round(pla_rank$positive_percent, 1), trim = TRUE, scientific = FALSE),
  "%"
)
pla_ring <- do.call(rbind, lapply(seq_len(nrow(pla_rank)), function(i) {
  data.frame(
    sample = pla_rank$sample[i],
    sample_strip = factor(pla_strip_levels[i], levels = pla_strip_levels),
    segment = c("below", "above"),
    percent = c(100 - pla_rank$positive_percent[i], pla_rank$positive_percent[i]),
    stringsAsFactors = FALSE
  )
}))
pla_ring$sample_strip <- factor(pla_ring$sample_strip, levels = pla_strip_levels)

p_pla_takehome <- ggplot(
  pla_ring,
  aes(x = 1, y = percent, fill = segment)
) +
  geom_col(width = 1, color = "white", linewidth = 0.22) +
  coord_polar(theta = "y") +
  facet_wrap(~sample_strip, nrow = 1) +
  scale_fill_manual(values = c(above = "#8E8E8E", below = "#F1F1F1")) +
  labs(title = NULL, subtitle = NULL, x = NULL, y = NULL) +
  theme_void(base_size = 8) +
  theme(
    legend.position = "none",
    strip.text = element_text(size = 7, face = "bold", lineheight = 0.9),
    strip.background = element_blank(),
    panel.spacing.x = unit(0.12, "lines"),
    plot.margin = margin(0, 4, 0, 4)
  )

fig1_surface <- read.csv(fig1_surface_summary, stringsAsFactors = FALSE)
aro_reference <- fig1_surface[
  fig1_surface$group == "ARO" &
    fig1_surface$relation == "Rhoptry to B1" &
    fig1_surface$metric == "center_distance_normalized",
  c("relation", "group", "group_label", "metric", "n", "mean", "median", "sd", "sem", "ci95_low", "ci95_high"),
  drop = FALSE
]
if (nrow(aro_reference) != 1L) {
  stop("Expected one ARO center-distance reference row in: ", fig1_surface_summary)
}
aro_reference$structure <- "ARO"

fig1_surface_per_cell <- file.path(
  project_root, "Fig1_intro_spatial", "04_results", "tables", "peak_profiles",
  "symmetry_distance", "surface_distances_per_cell.csv"
)
if (!file.exists(fig1_surface_per_cell)) {
  stop("Missing Fig1 ARO per-cell table: ", fig1_surface_per_cell)
}
aro_points <- read.csv(fig1_surface_per_cell, stringsAsFactors = FALSE)
aro_points <- aro_points[
  aro_points$group == "ARO" &
    aro_points$relation == "Rhoptry to B1" &
    is.finite(aro_points$center_distance_normalized),
  c("group", "cell_id", "relation", "center_distance_normalized", "center_distance_nm"),
  drop = FALSE
]
aro_points$structure <- "ARO"
aro_points$position_normalized <- aro_points$center_distance_normalized
aro_points$structure <- factor(aro_points$structure, levels = c("ICMT", "ARO", "MIC2", "ICAT"))

p_pla <- ggplot(pla, aes(sample, intensity)) +
  geom_violin(fill = "#E6E6E6", color = "#8A8A8A", trim = FALSE, width = 0.82, linewidth = 0.35) +
  geom_jitter(color = "#7A7A7A", width = 0.14, height = 0, size = 0.65, alpha = 0.45) +
  geom_pointrange(
    data = pla_summary,
    aes(
      x = sample, y = median_intensity,
      ymin = median_ci95_low, ymax = median_ci95_high
    ),
    inherit.aes = FALSE, shape = 21, size = 1.15, stroke = 0.28,
    fill = "white", color = "#555555", linewidth = ICAT_LINE_MM
  ) +
  geom_hline(yintercept = 1000, linetype = "dashed", linewidth = 0.35,
             color = "#666666") +
  geom_text(
    data = pla_summary,
    aes(x = sample, y = 0, label = paste0(round(positive_percent, 1), "%")),
    inherit.aes = FALSE, vjust = 1.55, size = ICAT_TEXT_SMALL_MM, color = "#333333"
  ) +
  scale_y_continuous(
    trans = pseudo_log_trans(sigma = 1000, base = 10),
    breaks = c(0, 1000, 5000, 10000, 20000, 30000),
    labels = label_number(scale = 0.001),
    expand = expansion(mult = c(0.08, 0.09))
  ) +
  scale_x_discrete(labels = pla_labels) +
  labs(
    title = "ICAT proximity screen",
    subtitle = "Gray points and gray bootstrap intervals; percent above threshold shown below each group",
    x = NULL, y = "PLA intensity (10^3 a.u.)"
  ) +
  icat_theme_classic() +
  theme(
    legend.position = "none",
    plot.title = element_text(face = "bold", size = 9.5),
    plot.subtitle = element_blank(),
    axis.text.x = element_text(size = ICAT_FONT_SMALL_PT, angle = 40, hjust = 1),
    plot.margin = margin(4, 5, 4, 4)
  )

icat_path <- file.path(
  project_root, "Fig1_intro_spatial", "04_results", "tables", "peak_profiles",
  "ICAT_B2_asymmetry", "symmetry_distance", "height_2over3",
  "purple_signal_to_B2_distance_per_cell.csv"
)
if (!file.exists(icat_path)) {
  icat_path <- file.path(
    project_root, "Fig2_ICAT_identification", "04_results", "tables", "peak_profiles",
    "ICAT_B2_asymmetry", "symmetry_distance", "height_2over3",
    "purple_signal_to_B2_distance_per_cell.csv"
  )
}
mic2_path <- file.path(
  project_root, "Fig1_intro_spatial", "04_results", "tables", "peak_profiles", "symmetry_distance",
  "microneme_width_thresholds_per_cell.csv"
)
measurement_path <- file.path(
  project_root, "Fig1_intro_spatial", "04_results", "tables", "peak_profiles", "WT-MIC2",
  "peak_measurements_per_cell.csv"
)

icat <- read.csv(icat_path, stringsAsFactors = FALSE)
mic2_all <- read.csv(mic2_path, stringsAsFactors = FALSE)
mic2 <- mic2_all[
  mic2_all$group == "WT-MIC2" & abs(mic2_all$height_fraction - 2 / 3) < 1e-6,
  , drop = FALSE
]
measurements <- read.csv(measurement_path, stringsAsFactors = FALSE)
icmt <- measurements[
  measurements$included_in_average %in% TRUE &
    !(measurements$icmt_imputed %in% TRUE) &
    is.finite(measurements$icmt_position_normalized),
  , drop = FALSE
]

position_data <- rbind(
  data.frame(
    structure = "ICMT", cell_id = icmt$cell_id,
    position_normalized = icmt$icmt_position_normalized
  ),
  data.frame(
    structure = "MIC2", cell_id = mic2$cell_id,
    position_normalized = 1 - mic2$center_distance_normalized
  ),
  data.frame(
    structure = "ICAT", cell_id = icat$cell_id,
    position_normalized = 1 - icat$center_distance_normalized
  )
)
position_data$structure <- factor(position_data$structure, levels = c("ICMT", "MIC2", "ICAT"))

position_summary <- do.call(rbind, lapply(levels(position_data$structure), function(structure) {
  x <- position_data$position_normalized[position_data$structure == structure]
  tt <- t.test(x)
  data.frame(
    structure = structure, n = length(x), mean = mean(x), median = median(x),
    sd = sd(x), sem = sd(x) / sqrt(length(x)),
    ci95_low = tt$conf.int[1], ci95_high = tt$conf.int[2]
  )
}))
position_summary$structure <- factor(position_summary$structure, levels = c("ICMT", "MIC2", "ICAT"))

aro_position_summary <- data.frame(
  structure = "ARO",
  n = aro_reference$n,
  mean = aro_reference$mean,
  median = aro_reference$median,
  sd = aro_reference$sd,
  sem = aro_reference$sem,
  ci95_low = aro_reference$ci95_low,
  ci95_high = aro_reference$ci95_high,
  stringsAsFactors = FALSE
)
aro_position_summary$structure <- factor(aro_position_summary$structure, levels = c("ARO"))

asymmetry_tests <- do.call(rbind, lapply(c("ICMT", "MIC2", "ICAT"), function(structure) {
  x <- position_data$position_normalized[position_data$structure == structure]
  alternative <- if (structure == "ICMT") "less" else "greater"
  tt <- t.test(x, mu = 0.5, alternative = alternative)
  wt <- suppressWarnings(wilcox.test(x, mu = 0.5, alternative = alternative, exact = FALSE))
  data.frame(
    structure = structure, n = length(x), mean_position = mean(x),
    expected_side = if (alternative == "less") "B1-facing" else "B2-facing",
    mean_offset_from_midline = mean(x) - 0.5,
    t_p_one_sided = tt$p.value,
    wilcoxon_p_one_sided = wt$p.value
  )
}))

icat_vs_mic2 <- t.test(
  position_data$position_normalized[position_data$structure == "ICAT"],
  position_data$position_normalized[position_data$structure == "MIC2"]
)
position_difference <- data.frame(
  comparison = "ICAT minus MIC2 normalized position",
  mean_difference = mean(icat$center_distance_normalized * -1 + 1) -
    mean(1 - mic2$center_distance_normalized),
  ci95_low = icat_vs_mic2$conf.int[1],
  ci95_high = icat_vs_mic2$conf.int[2],
  welch_p = icat_vs_mic2$p.value
)

gap_data <- rbind(
  data.frame(
    structure = "MIC2", cell_id = mic2$cell_id,
    gap_nm = mic2$surface_gap_biological_nm
  ),
  data.frame(
    structure = "ICAT", cell_id = icat$cell_id,
    gap_nm = icat$surface_gap_biological_nm
  )
)
gap_data$structure <- factor(gap_data$structure, levels = c("MIC2", "ICAT"))

gap_summary <- do.call(rbind, lapply(levels(gap_data$structure), function(structure) {
  x <- gap_data$gap_nm[gap_data$structure == structure]
  tt <- t.test(x)
  data.frame(
    structure = structure, n = length(x), mean = mean(x), median = median(x),
    q1 = unname(quantile(x, 0.25)), q3 = unname(quantile(x, 0.75)),
    ci95_low = tt$conf.int[1], ci95_high = tt$conf.int[2],
    overlap_count = sum(x == 0), overlap_percent = 100 * mean(x == 0)
  )
}))
gap_summary$structure <- factor(gap_summary$structure, levels = c("MIC2", "ICAT"))

gap_test <- suppressWarnings(wilcox.test(
  gap_data$gap_nm[gap_data$structure == "ICAT"],
  gap_data$gap_nm[gap_data$structure == "MIC2"],
  exact = FALSE, conf.int = TRUE
))
gap_difference <- data.frame(
  comparison = "ICAT versus MIC2 2/3-max surface gap",
  wilcoxon_p = gap_test$p.value,
  location_shift = if (!is.null(gap_test$estimate)) unname(gap_test$estimate) else NA_real_,
  ci95_low = if (!is.null(gap_test$conf.int)) gap_test$conf.int[1] else NA_real_,
  ci95_high = if (!is.null(gap_test$conf.int)) gap_test$conf.int[2] else NA_real_
)

structure_colors <- c(ICMT = "#19A563", MIC2 = "#D255B5", ICAT = "#8B38B5", ARO = aro_color)

p_bridge <- ggplot(
  position_data,
  aes(x = position_normalized, y = structure, color = structure)
) +
  geom_vline(xintercept = c(0, 1), linewidth = 0.5, color = "#333333") +
  geom_vline(xintercept = 0.5, linewidth = 0.35, linetype = "dashed", color = "#777777") +
  geom_jitter(width = 0, height = 0.12, size = 0.95, alpha = 0.48) +
  geom_jitter(
    data = aro_points,
    aes(x = position_normalized, y = structure),
    inherit.aes = FALSE, width = 0, height = 0.12, size = 0.95,
    alpha = 0.58, color = aro_color
  ) +
  geom_segment(
    data = position_summary,
    aes(x = ci95_low, xend = ci95_high, y = structure, yend = structure),
    inherit.aes = FALSE, linewidth = ICAT_LINE_MM, color = "black"
  ) +
  geom_point(
    data = position_summary,
    aes(x = mean, y = structure),
    inherit.aes = FALSE, shape = 21, size = 1.55, stroke = 0.35,
    fill = "white", color = "black"
  ) +
  geom_segment(
    data = aro_position_summary,
    aes(x = ci95_low, xend = ci95_high, y = structure, yend = structure),
    inherit.aes = FALSE, linewidth = ICAT_LINE_MM, color = aro_color
  ) +
  geom_point(
    data = aro_position_summary,
    aes(x = mean, y = structure),
    inherit.aes = FALSE, shape = 21, size = 1.75, stroke = 0.35,
    fill = "white", color = aro_color
  ) +
  annotate("text", x = 0, y = 4.55, label = "B1", hjust = 0, size = ICAT_TEXT_SMALL_MM) +
  annotate("text", x = 1, y = 4.55, label = "B2", hjust = 1, size = ICAT_TEXT_SMALL_MM) +
  scale_color_manual(values = structure_colors) +
  scale_y_discrete(limits = c("ICMT", "ARO", "MIC2", "ICAT")) +
  scale_x_continuous(
    limits = c(-0.02, 1.02), breaks = c(0, 0.5, 1),
    labels = c("0", "0.5", "1")
  ) +
  labs(
    title = "Common B1-B2 coordinate",
    subtitle = "Individual profiles; mean and 95% CI",
    x = "Normalized position", y = NULL
  ) +
  icat_theme_classic() +
  theme(
    legend.position = "none",
    plot.title = element_text(face = "bold", size = ICAT_FONT_TITLE_PT),
    plot.subtitle = element_text(size = ICAT_FONT_SMALL_PT, color = "#555555"),
    axis.text.y = element_text(face = "bold", size = ICAT_FONT_SMALL_PT),
    plot.margin = margin(3, 4, 3, 3)
  )

p_bridge_points <- p_bridge

bridge_density_input <- rbind(
  data.frame(
    structure = as.character(position_data$structure),
    position_normalized = position_data$position_normalized,
    stringsAsFactors = FALSE
  ),
  data.frame(
    structure = as.character(aro_points$structure),
    position_normalized = aro_points$position_normalized,
    stringsAsFactors = FALSE
  )
)
bridge_density_input <- bridge_density_input[
  is.finite(bridge_density_input$position_normalized) &
    bridge_density_input$position_normalized >= 0 &
    bridge_density_input$position_normalized <= 1,
  , drop = FALSE
]
bridge_density_levels <- c("ICMT", "ARO", "MIC2", "ICAT")
bridge_density_labels <- c(
  ICMT = "ICMTs",
  ARO = "Rhoptries",
  MIC2 = "microneme",
  ICAT = "ICAT"
)
bridge_density_y <- setNames(seq_along(bridge_density_levels), bridge_density_levels)
bridge_density_height <- 0.58

bridge_density <- do.call(rbind, lapply(bridge_density_levels, function(structure) {
  x <- bridge_density_input$position_normalized[bridge_density_input$structure == structure]
  if (length(x) < 2L || length(unique(x)) < 2L) return(NULL)
  dens <- density(x, from = 0, to = 1, n = 256, adjust = 1.8, na.rm = TRUE)
  data.frame(
    structure = structure,
    x = dens$x,
    density = dens$y,
    density_scaled = dens$y / max(dens$y, na.rm = TRUE),
    y_base = bridge_density_y[[structure]],
    stringsAsFactors = FALSE
  )
}))
bridge_density$structure <- factor(bridge_density$structure, levels = bridge_density_levels)
bridge_density$y <- bridge_density$y_base + bridge_density$density_scaled * bridge_density_height

bridge_density_peaks <- do.call(rbind, lapply(split(bridge_density, bridge_density$structure), function(z) {
  z <- z[which.max(z$density), , drop = FALSE]
  data.frame(
    structure = as.character(z$structure),
    peak_position_normalized = z$x,
    y_base = z$y_base,
    y_peak = z$y,
    stringsAsFactors = FALSE
  )
}))

p_bridge <- ggplot(bridge_density, aes(x = x, y = y, color = structure, fill = structure)) +
  geom_vline(xintercept = c(0, 1), linewidth = 0.28, color = "#333333") +
  geom_vline(xintercept = 0.5, linewidth = 0.22, linetype = "dashed", color = "#8A8A8A") +
  geom_hline(
    yintercept = unname(bridge_density_y),
    linewidth = 0.18, color = "#DADADA"
  ) +
  geom_ribbon(
    aes(ymin = y_base, ymax = y),
    alpha = 0.30, color = NA
  ) +
  geom_line(linewidth = 0.42) +
  geom_segment(
    data = bridge_density_peaks,
    aes(
      x = peak_position_normalized, xend = peak_position_normalized,
      y = y_base, yend = y_peak
    ),
    inherit.aes = FALSE, linewidth = 0.30, color = "#222222"
  ) +
  annotate("text", x = 0, y = 4.78, label = "B1", hjust = 0, size = ICAT_TEXT_SMALL_MM * 0.88) +
  annotate("text", x = 1, y = 4.78, label = "B2", hjust = 1, size = ICAT_TEXT_SMALL_MM * 0.88) +
  scale_color_manual(values = structure_colors) +
  scale_fill_manual(values = structure_colors) +
  scale_y_continuous(
    breaks = unname(bridge_density_y) + bridge_density_height * 0.38,
    labels = unname(bridge_density_labels[bridge_density_levels]),
    limits = c(0.85, 4.95),
    expand = expansion(mult = c(0, 0))
  ) +
  scale_x_continuous(
    limits = c(-0.02, 1.02), breaks = c(0, 0.5, 1),
    labels = c("0", "0.5", "1"),
    expand = expansion(mult = c(0, 0))
  ) +
  labs(x = "Normalized B1-B2 position", y = NULL) +
  icat_theme_classic() +
  theme(
    legend.position = "none",
    axis.text.y = element_text(face = "bold", size = ICAT_FONT_SMALL_PT * 0.90),
    axis.text.x = element_text(size = ICAT_FONT_SMALL_PT * 0.90),
    axis.title.x = element_text(size = ICAT_FONT_SMALL_PT * 0.95, margin = margin(t = 2)),
    axis.line.y = element_blank(),
    axis.ticks.y = element_blank(),
    plot.title = element_blank(),
    plot.subtitle = element_blank(),
    plot.margin = margin(2, 3, 2, 2)
  )

p_position <- ggplot(position_data, aes(structure, position_normalized, color = structure)) +
  geom_hline(yintercept = c(0, 1), linewidth = 0.5, color = "#333333") +
  geom_hline(yintercept = 0.5, linewidth = 0.35, linetype = "dashed", color = "#777777") +
  geom_jitter(width = 0.13, size = 1.05, alpha = 0.50) +
  geom_pointrange(
    data = position_summary,
    aes(x = structure, y = mean, ymin = ci95_low, ymax = ci95_high),
    inherit.aes = FALSE, shape = 21, size = 1.35, stroke = 0.32,
    fill = "white", color = "black", linewidth = ICAT_LINE_MM
  ) +
  annotate("text", x = 0.58, y = 0.02, label = "B1", size = ICAT_TEXT_SMALL_MM, hjust = 0) +
  annotate("text", x = 0.58, y = 0.98, label = "B2", size = ICAT_TEXT_SMALL_MM, hjust = 0, vjust = 1) +
  scale_color_manual(values = structure_colors) +
  coord_cartesian(ylim = c(-0.03, 1.03), clip = "off") +
  labs(
    title = "B1-B2 position",
    subtitle = "Mean and 95% CI",
    x = NULL, y = "Normalized position"
  ) +
  icat_theme_classic() +
  theme(
    legend.position = "none", plot.title = element_text(face = "bold", size = ICAT_FONT_TITLE_PT),
    plot.subtitle = element_text(size = ICAT_FONT_SMALL_PT, color = "#555555"),
    axis.text.x = element_text(face = "bold", size = ICAT_FONT_SMALL_PT)
  )

p_gap <- ggplot(gap_data, aes(structure, gap_nm, color = structure, fill = structure)) +
  geom_violin(width = 0.8, alpha = 0.20, linewidth = 0.35, trim = FALSE) +
  geom_jitter(width = 0.13, size = 1.0, alpha = 0.55) +
  geom_pointrange(
    data = gap_summary,
    aes(x = structure, y = mean, ymin = pmax(0, ci95_low), ymax = ci95_high),
    inherit.aes = FALSE, shape = 23, size = 1.45, stroke = 0.32,
    fill = "white", color = "black", linewidth = ICAT_LINE_MM
  ) +
  scale_color_manual(values = structure_colors[c("MIC2", "ICAT")]) +
  scale_fill_manual(values = structure_colors[c("MIC2", "ICAT")]) +
  labs(
    title = "2/3-max gap to B2",
    subtitle = "4.5x de-expanded",
    x = NULL, y = "Gap to B2 (nm)"
  ) +
  icat_theme_classic() +
  theme(
    legend.position = "none", plot.title = element_text(face = "bold", size = ICAT_FONT_TITLE_PT),
    plot.subtitle = element_text(size = ICAT_FONT_SMALL_PT, color = "#555555"),
    axis.text.x = element_text(face = "bold", size = ICAT_FONT_SMALL_PT)
  )

draw_pla_screen <- function() {
  grid.newpage()
  pushViewport(viewport(layout = grid.layout(2, 1, heights = unit(c(1.05, 3.95), "null"))))
  print(p_pla_takehome, vp = viewport(layout.pos.row = 1, layout.pos.col = 1))
  print(p_pla, vp = viewport(layout.pos.row = 2, layout.pos.col = 1))
  popViewport()
}

save_pla_screen <- function(pdf_path, png_path, width_in, height_in, dpi = 600) {
  grDevices::cairo_pdf(pdf_path, width = width_in, height = height_in)
  draw_pla_screen()
  dev.off()
  if (requireNamespace("ragg", quietly = TRUE)) {
    ragg::agg_png(png_path, width = width_in, height = height_in, units = "in", res = dpi, background = "white")
    draw_pla_screen()
    dev.off()
  } else {
    grDevices::png(png_path, width = width_in, height = height_in, units = "in", res = dpi, type = "cairo-png", bg = "white")
    draw_pla_screen()
    dev.off()
  }
}

save_pla_screen(
  pdf_path = file.path(figure_dir, "Fig3C_PLA_screen.pdf"),
  png_path = file.path(figure_dir, "Fig3C_PLA_screen.png"),
  width_in = 8.4 / 2.54,
  height_in = 8.4 / 2.54,
  dpi = 600
)
ggsave(file.path(figure_dir, "Fig3A_B1B2_bridge.pdf"), p_bridge,
       width = 4.6 / 2.54, height = 3.6 / 2.54, device = cairo_pdf, bg = "white")
ggsave(file.path(figure_dir, "Fig3A_B1B2_bridge.png"), p_bridge,
       width = 4.6 / 2.54, height = 3.6 / 2.54, dpi = 600, bg = "white")
ggsave(file.path(figure_dir, "Fig3D_B2_gap_only.pdf"), p_gap,
       width = 5.0 / 2.54, height = 4.6 / 2.54, device = cairo_pdf, bg = "white")
ggsave(file.path(figure_dir, "Fig3D_B2_gap_only.png"), p_gap,
       width = 5.0 / 2.54, height = 4.6 / 2.54, dpi = 600, bg = "white")

draw_spatial_pair <- function() {
  grid.newpage()
  pushViewport(viewport(layout = grid.layout(1, 2, widths = unit(c(1.08, 0.92), "null"))))
  print(p_position, vp = viewport(layout.pos.row = 1, layout.pos.col = 1))
  print(p_gap, vp = viewport(layout.pos.row = 1, layout.pos.col = 2))
  popViewport()
}

cairo_pdf(
  file.path(figure_dir, "Fig3D_B2_spatial_comparison.pdf"),
  width = 9.6 / 2.54, height = 5.4 / 2.54, bg = "white"
)
draw_spatial_pair()
dev.off()

png(
  file.path(figure_dir, "Fig3D_B2_spatial_comparison.png"),
  width = 9.6 / 2.54, height = 5.4 / 2.54,
  units = "in", res = 600, bg = "white", type = "cairo"
)
draw_spatial_pair()
dev.off()

write.csv(pla, file.path(table_dir, "Fig3C_PLA_per_cell.csv"), row.names = FALSE)
write.csv(pla_summary, file.path(table_dir, "Fig3C_PLA_summary.csv"), row.names = FALSE)
write.csv(pla_tests, file.path(table_dir, "Fig3C_PLA_tests.csv"), row.names = FALSE)
write.csv(position_data, file.path(table_dir, "Fig3A_B1B2_position_per_cell.csv"), row.names = FALSE)
write.csv(position_summary, file.path(table_dir, "Fig3A_B1B2_position_summary.csv"), row.names = FALSE)
write.csv(aro_reference, file.path(table_dir, "Fig3A_B1B2_ARO_reference_summary.csv"), row.names = FALSE)
write.csv(aro_points, file.path(table_dir, "Fig3A_B1B2_ARO_reference_points.csv"), row.names = FALSE)
write.csv(bridge_density_peaks, file.path(table_dir, "Fig3A_B1B2_density_peaks.csv"), row.names = FALSE)
write.csv(position_data, file.path(table_dir, "Fig3D_position_per_cell.csv"), row.names = FALSE)
write.csv(position_summary, file.path(table_dir, "Fig3D_position_summary.csv"), row.names = FALSE)
write.csv(aro_reference, file.path(table_dir, "Fig3D_ARO_reference_distance.csv"), row.names = FALSE)
write.csv(aro_points, file.path(table_dir, "Fig3D_ARO_reference_points.csv"), row.names = FALSE)
write.csv(asymmetry_tests, file.path(table_dir, "Fig3D_asymmetry_tests.csv"), row.names = FALSE)
write.csv(position_difference, file.path(table_dir, "Fig3D_ICAT_vs_MIC2_position.csv"), row.names = FALSE)
write.csv(gap_data, file.path(table_dir, "Fig3D_gap_per_cell.csv"), row.names = FALSE)
write.csv(gap_summary, file.path(table_dir, "Fig3D_gap_summary.csv"), row.names = FALSE)
write.csv(gap_difference, file.path(table_dir, "Fig3D_ICAT_vs_MIC2_gap.csv"), row.names = FALSE)

cat("Figure 3 quantitative panels complete.\n")
print(position_summary)
print(aro_reference)
print(head(aro_points, 5))
print(gap_summary)
