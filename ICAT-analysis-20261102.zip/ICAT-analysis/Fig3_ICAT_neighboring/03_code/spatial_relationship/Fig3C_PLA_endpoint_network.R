#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(ggplot2)
  library(scales)
  library(grid)
})

script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
script_path <- normalizePath(sub("^--file=", "", script_arg[[1]]), mustWork = TRUE)
fig_dir <- if (exists("FIG3_BASE_DIR", inherits = TRUE)) {
  normalizePath(get("FIG3_BASE_DIR", inherits = TRUE), mustWork = TRUE)
} else {
  normalizePath(file.path(dirname(script_path), "..", ".."), mustWork = TRUE)
}

find_project_root <- function(start_dir) {
  current <- normalizePath(start_dir, mustWork = TRUE)
  repeat {
    if (file.exists(file.path(current, "shared", "R", "plot_style.R"))) return(current)
    parent <- dirname(current)
    if (identical(parent, current)) stop("Could not locate project root from: ", start_dir)
    current <- parent
  }
}

project_root <- find_project_root(dirname(script_path))
source(file.path(project_root, "shared", "R", "plot_style.R"))

figure_dir <- file.path(fig_dir, "04_results", "figures", "spatial_relationship")
table_dir <- file.path(fig_dir, "04_results", "tables", "spatial_relationship")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)

pla_dir <- file.path(fig_dir, "01_raw_data", "PLA")
pla_samples <- c("CF5", "MIC2c", "CPH1", "ICMAP1", "ICMAP2", "MIC2n", "RON4")
pla_labels <- c(
  CF5 = "CF5",
  MIC2c = "MIC2\n(conoid)",
  CPH1 = "CPH1",
  ICMAP1 = "ICMAP1",
  ICMAP2 = "ICMAP2",
  MIC2n = "MIC2\n(non-conoid)",
  RON4 = "RON4"
)

marker_colors <- c(
  CF5 = "#D9A72E",
  MIC2c = "#93af70",
  CPH1 = "#A7B79D",
  ICMAP1 = "#5A8BBF",
  ICMAP2 = "#6F83C7",
  MIC2n = "#B6B6B6",
  RON4 = "#a56441"
)

pla <- do.call(rbind, lapply(pla_samples, function(sample) {
  values <- scan(file.path(pla_dir, paste0(sample, "-ICAT.csv")), what = numeric(), quiet = TRUE)
  data.frame(sample = sample, intensity = values, stringsAsFactors = FALSE)
}))
pla$sample <- factor(pla$sample, levels = pla_samples)

trans <- pseudo_log_trans(sigma = 1000, base = 10)
pla$z <- trans$transform(pla$intensity)
z_range <- range(pla$z, finite = TRUE)
pla$z_norm <- rescale(pla$z, from = z_range, to = c(0, 1))

pla_summary <- do.call(rbind, lapply(pla_samples, function(sample) {
  x <- pla$intensity[pla$sample == sample]
  data.frame(
    sample = sample,
    sample_label = unname(pla_labels[sample]),
    n = length(x),
    positive_count = sum(x > 1000),
    positive_percent = 100 * mean(x > 1000),
    median_intensity = median(x),
    stringsAsFactors = FALSE
  )
}))
pla_summary$sample <- factor(pla_summary$sample, levels = pla_samples)
pla_summary <- pla_summary[order(-pla_summary$positive_percent, -pla_summary$median_intensity), , drop = FALSE]

write.csv(
  pla_summary,
  file.path(table_dir, "Fig3C_PLA_endpoint_network_summary.csv"),
  row.names = FALSE
)

layout_df <- pla_summary
layout_df$sample <- factor(layout_df$sample, levels = layout_df$sample)
layout_df$sample_label <- factor(layout_df$sample_label, levels = layout_df$sample_label)

theta_start <- 133 * pi / 180
theta_end <- -12 * pi / 180
theta <- seq(theta_start, theta_end, length.out = nrow(layout_df))
layout_df$theta <- theta

ring_radius <- 1.34
strip_gap <- 0.06
strip_len <- 0.45
strip_max_w <- 0.13
label_radius <- ring_radius + strip_gap + strip_len + 0.14

sample_scale <- c(
  CF5 = 0.84,
  MIC2c = 0.82,
  CPH1 = 0.95,
  ICMAP1 = 0.98,
  ICMAP2 = 0.98,
  MIC2n = 0.96,
  RON4 = 0.98
)

layout_df$scale <- sample_scale[as.character(layout_df$sample)]
layout_df$x_ring <- ring_radius * layout_df$scale * cos(layout_df$theta)
layout_df$y_ring <- ring_radius * layout_df$scale * sin(layout_df$theta)
layout_df$x_label <- label_radius * layout_df$scale * cos(layout_df$theta)
layout_df$y_label <- label_radius * layout_df$scale * sin(layout_df$theta)
layout_df$hjust <- ifelse(cos(layout_df$theta) < -0.18, 1, ifelse(cos(layout_df$theta) > 0.18, 0, 0.5))
layout_df$vjust <- ifelse(sin(layout_df$theta) < -0.24, 1, ifelse(sin(layout_df$theta) > 0.24, 0, 0.5))

arc_theta <- seq(theta_start, theta_end, length.out = 260)
circle_df <- data.frame(
  x = ring_radius * cos(arc_theta),
  y = ring_radius * sin(arc_theta)
)

fan_edges_df <- rbind(
  data.frame(x = 0, y = 0, xend = ring_radius * cos(theta_start), yend = ring_radius * sin(theta_start)),
  data.frame(x = 0, y = 0, xend = ring_radius * cos(theta_end), yend = ring_radius * sin(theta_end))
)

spoke_df <- data.frame(
  x = 0,
  y = 0,
  xend = layout_df$x_ring,
  yend = layout_df$y_ring
)

polar_to_cart <- function(theta, r, w = 0) {
  data.frame(
    x = r * cos(theta) - w * sin(theta),
    y = r * sin(theta) + w * cos(theta)
  )
}

strip_poly <- list()
strip_points <- list()
strip_medians <- list()

for (i in seq_len(nrow(layout_df))) {
  sample <- as.character(layout_df$sample[i])
  theta_i <- layout_df$theta[i]
  scale_i <- layout_df$scale[i]
  x <- pla$z_norm[pla$sample == sample]
  if (length(x) < 2 || all(!is.finite(x))) next

  dens <- density(x, from = 0, to = 1, n = 200, adjust = 0.9)
  dens_y <- dens$y
  if (max(dens_y, na.rm = TRUE) > 0) {
    dens_y <- dens_y / max(dens_y, na.rm = TRUE)
  }
  taper <- (0.15 + 0.85 * (sin(pi * dens$x))^0.8)
  dens_y <- dens_y * taper

  base_r <- ring_radius * scale_i
  r <- base_r + strip_gap + dens$x * strip_len
  w <- dens_y * strip_max_w

  left <- polar_to_cart(theta_i, r, w)
  right <- polar_to_cart(theta_i, rev(r), -rev(w))
  poly <- rbind(left, right)
  poly$sample <- sample
  poly$group <- sample
  strip_poly[[i]] <- poly

  set.seed(5200 + i)
  jitter_w <- runif(length(x), -0.55, 0.55) * strip_max_w
  r_pt <- base_r + strip_gap + x * strip_len
  pt <- polar_to_cart(theta_i, r_pt, jitter_w)
  pt$sample <- sample
  strip_points[[i]] <- pt

  med_x <- median(x, na.rm = TRUE)
  med_r <- base_r + strip_gap + med_x * strip_len
  med <- polar_to_cart(theta_i, med_r, c(-0.04, 0.04))
  names(med) <- c("x", "y")
  med$xend <- rev(med$x)
  med$yend <- rev(med$y)
  med$sample <- sample
  strip_medians[[i]] <- med
}

strip_poly_df <- do.call(rbind, strip_poly)
strip_points_df <- do.call(rbind, strip_points)
strip_medians_df <- do.call(rbind, strip_medians)

p_endpoint <- ggplot() +
  geom_path(
    data = circle_df,
    aes(x = x, y = y),
    color = "#E1E1E1", linewidth = 0.33, lineend = "round"
  ) +
  geom_segment(
    data = fan_edges_df,
    aes(x = x, y = y, xend = xend, yend = yend),
    color = "#E1E1E1", linewidth = 0.33, lineend = "round"
  ) +
  geom_segment(
    data = spoke_df,
    aes(x = x, y = y, xend = xend, yend = yend),
    color = "#D0D0D0", linewidth = 0.23, lineend = "round"
  ) +
  geom_polygon(
    data = strip_poly_df,
    aes(x = x, y = y, group = interaction(sample, group)),
    fill = "#EDEDED", color = "#6D6D6D", linewidth = 0.25
  ) +
  geom_point(
    data = strip_points_df,
    aes(x = x, y = y),
    size = 0.48, alpha = 0.35, color = "#9A9A9A"
  ) +
  geom_segment(
    data = strip_medians_df,
    aes(x = x, y = y, xend = xend, yend = yend),
    linewidth = 0.32, color = "#5C5C5C"
  ) +
  geom_point(
    data = layout_df,
    aes(x = x_ring, y = y_ring),
    shape = 21, size = 3.8, fill = "white",
    color = marker_colors[as.character(layout_df$sample)], stroke = 0.55
  ) +
  geom_point(
    data = data.frame(x = 0, y = 0),
    aes(x = x, y = y),
    shape = 21, size = 6.4, fill = "#E26AE5", color = "#B33CC9", stroke = 0.58
  ) +
  geom_text(
    data = layout_df,
    aes(x = x_label, y = y_label, label = sample_label, hjust = hjust, vjust = vjust),
    family = "Arial", fontface = "bold", size = ICAT_FONT_BODY_PT / 2.845276,
    color = "#222222", lineheight = 0.9
  ) +
  annotate(
    "text", x = 0, y = 0.31, label = "ICAT",
    family = "Arial", fontface = "bold", size = ICAT_FONT_BODY_PT / 2.845276,
    color = "#B33CC9"
  ) +
  annotate(
    "text", x = 0, y = -0.26, label = "PLA center",
    family = "Arial", size = ICAT_FONT_SMALL_PT / 2.845276,
    color = "#7A7A7A"
  ) +
  annotate(
    "text", x = 0.96, y = 1.82,
    label = "endpoint strips show actual PLA intensity distribution",
    family = "Arial", size = ICAT_FONT_SMALL_PT / 2.845276,
    color = "#5A5A5A"
  ) +
  coord_equal(
    xlim = c(-2.70, 3.05),
    ylim = c(-2.25, 2.10),
    clip = "off"
  ) +
  labs(
    title = "ICAT-centered PLA endpoint network",
    x = NULL, y = NULL
  ) +
  icat_theme_classic() +
  theme(
    axis.line = element_blank(),
    axis.ticks = element_blank(),
    axis.text = element_blank(),
    legend.position = "none",
    plot.title = element_text(face = "bold", size = 9.3, hjust = 0),
    plot.margin = margin(5, 4, 5, 4)
  )

save_endpoint <- function(pdf_path, png_path, width_in, height_in, dpi = 600) {
  grDevices::cairo_pdf(pdf_path, width = width_in, height = height_in)
  print(p_endpoint)
  dev.off()
  if (requireNamespace("ragg", quietly = TRUE)) {
    ragg::agg_png(png_path, width = width_in, height = height_in, units = "in", res = dpi, background = "white")
    print(p_endpoint)
    dev.off()
  } else {
    grDevices::png(png_path, width = width_in, height = height_in, units = "in", res = dpi, type = "cairo-png", bg = "white")
    print(p_endpoint)
    dev.off()
  }
}

save_endpoint(
  pdf_path = file.path(figure_dir, "Fig3C_PLA_endpoint_network.pdf"),
  png_path = file.path(figure_dir, "Fig3C_PLA_endpoint_network.png"),
  width_in = 6.8,
  height_in = 5.8,
  dpi = 600
)

message("PLA endpoint network complete.")
