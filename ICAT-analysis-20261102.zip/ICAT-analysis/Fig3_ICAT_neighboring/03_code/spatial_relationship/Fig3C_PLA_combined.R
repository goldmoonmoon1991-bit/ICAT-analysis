#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(ggplot2)
  library(grid)
})

script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
script_path <- normalizePath(sub("^--file=", "", script_arg[[1]]), mustWork = TRUE)
fig_dir <- if (exists("FIG3_BASE_DIR", inherits = TRUE)) {
  normalizePath(get("FIG3_BASE_DIR", inherits = TRUE), mustWork = TRUE)
} else {
  normalizePath(file.path(dirname(script_path), "..", ".."), mustWork = TRUE)
}

find_project_root <- function(start_dir) {
  current <- normalizePath(start_dir, mustWork = TRUE)
  repeat {
    if (file.exists(file.path(current, "shared", "R", "plot_style.R"))) return(current)
    parent <- dirname(current)
    if (identical(parent, current)) stop("Could not locate project root from: ", start_dir)
    current <- parent
  }
}

project_root <- find_project_root(dirname(script_path))
source(file.path(project_root, "shared", "R", "plot_style.R"))

figure_dir <- file.path(fig_dir, "04_results", "figures", "spatial_relationship")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)

ring_env <- new.env(parent = globalenv())
screen_env <- new.env(parent = globalenv())

sys.source(
  file.path(project_root, "Fig3_ICAT_neighboring", "03_code", "spatial_relationship", "Fig3C_PLA_ring_network.R"),
  envir = ring_env
)
sys.source(
  file.path(project_root, "Fig3_ICAT_neighboring", "03_code", "spatial_relationship", "Figure3_spatial_relationship.R"),
  envir = screen_env
)

ring_plot <- ring_env$p_ring +
  labs(title = NULL, subtitle = NULL) +
  theme(plot.margin = margin(2, 2, 2, 2))

screen_plot <- screen_env$p_pla +
  labs(title = NULL, subtitle = NULL) +
  theme(
    plot.title = element_blank(),
    plot.subtitle = element_blank(),
    plot.margin = margin(2, 2, 2, 2)
  )

draw_combined <- function() {
  grid.newpage()
  pushViewport(viewport(layout = grid.layout(1, 2, widths = unit(c(0.92, 1.08), "null"))))

  print(ring_plot, vp = viewport(layout.pos.row = 1, layout.pos.col = 1))
  grid.text(
    "A",
    x = unit(0.03, "npc"), y = unit(0.98, "npc"),
    just = c("left", "top"),
    gp = gpar(fontsize = 14, fontface = "bold")
  )

  print(screen_plot, vp = viewport(layout.pos.row = 1, layout.pos.col = 2))
  grid.text(
    "B",
    x = unit(0.53, "npc"), y = unit(0.98, "npc"),
    just = c("left", "top"),
    gp = gpar(fontsize = 14, fontface = "bold")
  )

  popViewport()
}

save_combined <- function(pdf_path, png_path, width_in, height_in, dpi = 600) {
  grDevices::cairo_pdf(pdf_path, width = width_in, height = height_in)
  draw_combined()
  dev.off()
  if (requireNamespace("ragg", quietly = TRUE)) {
    ragg::agg_png(png_path, width = width_in, height = height_in, units = "in", res = dpi, background = "white")
    draw_combined()
    dev.off()
  } else {
    grDevices::png(png_path, width = width_in, height = height_in, units = "in", res = dpi, type = "cairo-png", bg = "white")
    draw_combined()
    dev.off()
  }
}

save_combined(
  pdf_path = file.path(figure_dir, "Fig3C_PLA_combined.pdf"),
  png_path = file.path(figure_dir, "Fig3C_PLA_combined.png"),
  width_in = 14.0 / 2.54,
  height_in = 9.0 / 2.54,
  dpi = 600
)

message("PLA combined figure complete.")
