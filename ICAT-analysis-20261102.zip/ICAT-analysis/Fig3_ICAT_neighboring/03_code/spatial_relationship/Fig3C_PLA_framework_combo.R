#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(ggplot2)
  library(scales)
  library(grid)
})

script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
script_path <- normalizePath(sub("^--file=", "", script_arg[[1]]), mustWork = TRUE)
fig_dir <- if (exists("FIG3_BASE_DIR", inherits = TRUE)) {
  normalizePath(get("FIG3_BASE_DIR", inherits = TRUE), mustWork = TRUE)
} else {
  normalizePath(file.path(dirname(script_path), "..", ".."), mustWork = TRUE)
}

find_project_root <- function(start_dir) {
  current <- normalizePath(start_dir, mustWork = TRUE)
  repeat {
    if (file.exists(file.path(current, "shared", "R", "plot_style.R"))) return(current)
    parent <- dirname(current)
    if (identical(parent, current)) stop("Could not locate project root from: ", start_dir)
    current <- parent
  }
}

project_root <- find_project_root(dirname(script_path))
source(file.path(project_root, "shared", "R", "plot_style.R"))

figure_dir <- file.path(fig_dir, "04_results", "figures", "spatial_relationship")
table_dir <- file.path(fig_dir, "04_results", "tables", "spatial_relationship")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)

pla_dir <- file.path(fig_dir, "01_raw_data", "PLA")
sample_levels <- c("CPH1", "CF5", "MIC2c", "MIC2n", "ICMAP1", "ICMAP2", "RON4")
sample_labels <- c(
  CPH1 = "CPH1",
  CF5 = "CF5",
  MIC2c = "MIC2c",
  MIC2n = "MIC2n",
  ICMAP1 = "ICMAP1",
  ICMAP2 = "ICMAP2",
  RON4 = "RON4"
)
sample_groups <- c(
  CPH1 = "conoid",
  CF5 = "conoid",
  MIC2c = "microneme",
  MIC2n = "microneme",
  ICMAP1 = "ICMTs",
  ICMAP2 = "ICMTs",
  RON4 = "Rhoptry"
)

marker_colors <- c(
  CPH1 = "#A7B79D",
  CF5 = "#D9A72E",
  MIC2c = "#93af70",
  MIC2n = "#B6B6B6",
  ICMAP1 = "#5A8BBF",
  ICMAP2 = "#6F83C7",
  RON4 = "#a56441"
)

files <- file.path(pla_dir, paste0(sample_levels, "-ICAT.csv"))
if (!all(file.exists(files))) {
  missing_files <- sample_levels[!file.exists(files)]
  stop("Missing PLA files: ", paste(missing_files, collapse = ", "))
}

pla <- do.call(rbind, lapply(sample_levels, function(sample) {
  values <- scan(file.path(pla_dir, paste0(sample, "-ICAT.csv")), what = numeric(), quiet = TRUE)
  data.frame(sample = sample, intensity = values, stringsAsFactors = FALSE)
}))
pla$sample <- factor(pla$sample, levels = sample_levels)

trans <- pseudo_log_trans(sigma = 1000, base = 10)
pla$z <- trans$transform(pla$intensity)
z_range <- range(pla$z, finite = TRUE)
pla$z_norm <- rescale(pla$z, from = z_range, to = c(0, 1))

pie_data <- do.call(rbind, lapply(sample_levels, function(sample) {
  x <- pla$intensity[pla$sample == sample]
  data.frame(
    Sample = sample,
    Threshold = c("Above_Ratio", "Below_Ratio"),
    Ratio = c(mean(x > 1000), mean(x <= 1000)),
    stringsAsFactors = FALSE
  )
}))
pie_data$Sample <- factor(pie_data$Sample, levels = sample_levels)

summary_data <- do.call(rbind, lapply(sample_levels, function(sample) {
  x <- pla$intensity[pla$sample == sample]
  data.frame(
    sample = sample,
    sample_label = unname(sample_labels[sample]),
    n = length(x),
    above_count = sum(x > 1000),
    above_percent = 100 * mean(x > 1000),
    median_intensity = median(x),
    stringsAsFactors = FALSE
  )
}))
summary_data$sample <- factor(summary_data$sample, levels = sample_levels)
write.csv(
  summary_data,
  file.path(table_dir, "Fig3C_PLA_framework_combo_summary.csv"),
  row.names = FALSE
)

pal_fill <- c(Above_Ratio = "#E31A1C", Below_Ratio = "#E6E6E6")

sig_map <- function(p) {
  if (!is.finite(p)) return("ns")
  if (p < 1e-4) return("****")
  if (p < 1e-3) return("***")
  if (p < 1e-2) return("**")
  if (p < 5e-2) return("*")
  "ns"
}

sig_data <- do.call(rbind, lapply(sample_levels, function(sample) {
  x_ref <- pla$intensity[pla$sample == "CPH1"]
  x <- pla$intensity[pla$sample == sample]
  pval <- if (identical(sample, "CPH1")) NA_real_ else suppressWarnings(wilcox.test(x_ref, x)$p.value)
  data.frame(
    sample = sample,
    p = pval,
    sig = sig_map(pval),
    label_y = max(pla$intensity, na.rm = TRUE) * 1.18,
    stringsAsFactors = FALSE
  )
}))
sig_data$sample <- factor(sig_data$sample, levels = sample_levels)

p_top <- ggplot(pie_data, aes(x = "", y = Ratio, fill = Threshold)) +
  geom_bar(stat = "identity", width = 0.82, color = NA) +
  coord_polar("y", start = 0) +
  facet_wrap(~Sample, nrow = 1) +
  geom_text(
    data = subset(pie_data, Threshold == "Above_Ratio"),
    aes(x = 1, y = 0, label = percent(Ratio, accuracy = 0.1)),
    inherit.aes = FALSE,
    family = "Arial",
    fontface = "plain",
    size = ICAT_FONT_BODY_PT / 2.845276,
    color = "black"
  ) +
  scale_fill_manual(values = pal_fill) +
  scale_y_continuous(
    limits = c(0, 1),
    breaks = c(0, 0.5, 1),
    labels = c("", "", ""),
    expand = expansion(mult = c(0, 0))
  ) +
  theme_void(base_size = ICAT_FONT_BODY_PT) +
  theme(
    strip.text = element_blank(),
    strip.background = element_blank(),
    panel.spacing.x = unit(0, "pt"),
    legend.position = "none",
    plot.margin = margin(0, 0, 0, 0),
    axis.text = element_blank(),
    axis.title = element_blank(),
    axis.ticks = element_blank(),
    axis.text.y = element_blank(),
    axis.ticks.y = element_blank()
  )

p_mid <- ggplot(pla, aes(x = sample, y = intensity)) +
  geom_violin(fill = "#F2F2F2", color = "black", trim = FALSE, scale = "width", linewidth = 0.45) +
  geom_jitter(width = 0.16, size = 0.85, alpha = 0.45, color = "#8E8E8E") +
  geom_boxplot(width = 0.10, fill = "white", color = "#4A4A4A", outlier.shape = NA, alpha = 0.9, linewidth = 0.35) +
  geom_hline(yintercept = 1000, linetype = "dashed", color = "#555555", linewidth = 0.45) +
  geom_text(
    data = sig_data,
    aes(x = sample, y = label_y, label = sig),
    inherit.aes = FALSE,
    family = "Arial",
    size = 3.2,
    color = "#222222"
  ) +
  scale_y_continuous(
    trans = pseudo_log_trans(sigma = 1000, base = 10),
    breaks = c(0, 1000, 5000, 10000, 20000, 30000),
    labels = label_number(scale = 0.001),
    expand = expansion(mult = c(0.02, 0.10))
  ) +
  scale_x_discrete(limits = sample_levels, labels = sample_levels) +
  coord_cartesian(clip = "off") +
  labs(x = NULL, y = "Intensity (a.u., 10^3)") +
  icat_theme_bw() +
  theme(
    axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1, family = "Arial", size = 9.6, face = "plain"),
    axis.title.y = element_text(family = "Arial", size = 11),
    axis.text.y = element_text(family = "Arial", size = 9.2),
    axis.title.x = element_blank(),
    plot.margin = margin(2, 4, 10, 4),
    panel.grid = element_blank(),
    legend.position = "none"
  )

group_spans <- data.frame(
  group = c("conoid", "microneme", "ICMTs", "Rhoptry"),
  x = c(1.5, 3.5, 5.5, 7.0),
  x0 = c(0.65, 2.65, 4.65, 6.60),
  x1 = c(2.35, 4.35, 6.35, 7.40)
)

p_group <- ggplot(group_spans, aes(x = x, y = 0.5, label = group)) +
  geom_segment(aes(x = x0, xend = x1, y = 0.78, yend = 0.78), linewidth = 0.45, color = "#444444") +
  geom_text(family = "Arial", size = 2.8, color = "#222222", vjust = 1.0) +
  xlim(0.5, 7.5) +
  ylim(0, 1) +
  theme_void(base_size = ICAT_FONT_BODY_PT) +
  theme(
    plot.margin = margin(-2, 0, 2, 0)
  )

polar_to_cart <- function(theta, r, w = 0) {
  data.frame(
    x = r * cos(theta) - w * sin(theta),
    y = r * sin(theta) + w * cos(theta)
  )
}

layout_df <- data.frame(sample = factor(sample_levels, levels = sample_levels))
layout_df$sample_label <- unname(sample_labels[as.character(layout_df$sample)])
layout_df$group <- unname(sample_groups[as.character(layout_df$sample)])
layout_df$theta <- seq(133 * pi / 180, -12 * pi / 180, length.out = nrow(layout_df))
sample_scale <- c(
  CPH1 = 0.95,
  CF5 = 0.84,
  MIC2c = 0.82,
  MIC2n = 0.96,
  ICMAP1 = 0.98,
  ICMAP2 = 0.98,
  RON4 = 0.98
)
layout_df$scale <- sample_scale[as.character(layout_df$sample)]

ring_radius <- 1.34
strip_gap <- 0.06
strip_len <- 0.45
strip_max_w <- 0.13
label_radius <- ring_radius + strip_gap + strip_len + 0.14

layout_df$x_ring <- ring_radius * layout_df$scale * cos(layout_df$theta)
layout_df$y_ring <- ring_radius * layout_df$scale * sin(layout_df$theta)
layout_df$x_label <- label_radius * layout_df$scale * cos(layout_df$theta)
layout_df$y_label <- label_radius * layout_df$scale * sin(layout_df$theta)
layout_df$hjust <- ifelse(cos(layout_df$theta) < -0.18, 1, ifelse(cos(layout_df$theta) > 0.18, 0, 0.5))
layout_df$vjust <- ifelse(sin(layout_df$theta) < -0.24, 1, ifelse(sin(layout_df$theta) > 0.24, 0, 0.5))
layout_df$above_percent <- summary_data$above_percent[match(as.character(layout_df$sample), as.character(summary_data$sample))]
layout_df$line_width <- scales::rescale(layout_df$above_percent, to = c(0.35, 3.00))

layout_df$x_node <- c(-1.55, -0.85, 0.00, 0.60, 1.30, 1.95, 2.25)
layout_df$y_node <- c(0.92, 1.24, 1.34, 1.00, 0.66, 0.10, -0.50)
layout_df$x_label <- c(-1.95, -0.92, 0.05, 0.92, 1.98, 2.30, 2.42)
layout_df$y_label <- c(1.36, 1.55, 1.64, 1.55, 1.08, 0.25, -0.74)
layout_df$hjust <- c(0, 0.5, 0.5, 0.5, 0, 0, 0)
layout_df$vjust <- c(1, 1, 1, 1, 1, 1, 1)
layout_df$curve_x <- 0
layout_df$curve_y <- 0
layout_df$curve_xend <- layout_df$x_node
layout_df$curve_yend <- layout_df$y_node
layout_df$curve_curvature <- c(0.20, 0.26, 0.16, 0.04, -0.05, -0.12, -0.16)

curve_layers <- lapply(seq_len(nrow(layout_df)), function(i) {
  geom_curve(
    data = layout_df[i, ],
    aes(x = curve_x, y = curve_y, xend = curve_xend, yend = curve_yend),
    curvature = layout_df$curve_curvature[i],
    linewidth = layout_df$line_width[i],
    color = "#8C8C8C",
    lineend = "round"
  )
})

p_bottom <- ggplot()
for (layer in curve_layers) p_bottom <- p_bottom + layer
p_bottom <- p_bottom +
  geom_point(
    data = layout_df,
    aes(x = x_node, y = y_node),
    shape = 21, size = 3.1, fill = "white", color = marker_colors[as.character(layout_df$sample)], stroke = 0.50
  ) +
  geom_point(
    data = data.frame(x = 0, y = 0),
    aes(x = x, y = y),
    shape = 21, size = 5.8, fill = "#E26AE5", color = "#B33CC9", stroke = 0.56
  ) +
  geom_text(
    data = layout_df,
    aes(x = x_label, y = y_label, label = sample_label, hjust = hjust, vjust = vjust),
    family = "Arial", fontface = "bold", size = 3.0,
    color = "#222222", lineheight = 0.92
  ) +
  annotate(
    "text", x = 0, y = 0.22, label = "ICAT",
    family = "Arial", fontface = "bold", size = 3.0,
    color = "#B33CC9"
  ) +
  coord_equal(
    xlim = c(-2.15, 2.92),
    ylim = c(-0.92, 1.95),
    clip = "off"
  ) +
  labs(x = NULL, y = NULL) +
  icat_theme_classic() +
  theme(
    axis.line = element_blank(),
    axis.ticks = element_blank(),
    axis.text = element_blank(),
    legend.position = "none",
    plot.margin = margin(0, 0, 0, 0)
  )

out_pdf <- file.path(figure_dir, "Fig3C_PLA_framework_combo.pdf")
out_png <- file.path(figure_dir, "Fig3C_PLA_framework_combo.png")

page_w_cm <- 7.5
page_h_cm <- 10.6

draw_compound <- function() {
  grid.newpage()
  pushViewport(viewport(width = unit(page_w_cm, "cm"), height = unit(page_h_cm, "cm")))
  grid.rect(gp = gpar(col = NA, fill = "white"))

  vp_top <- viewport(
    x = unit(0, "cm"), y = unit(page_h_cm - 0.9, "cm"),
    width = unit(page_w_cm, "cm"), height = unit(0.9, "cm"),
    just = c("left", "bottom")
  )
  vp_mid <- viewport(
    x = unit(0, "cm"), y = unit(page_h_cm - 5.25, "cm"),
    width = unit(page_w_cm, "cm"), height = unit(4.35, "cm"),
    just = c("left", "bottom")
  )
  vp_group <- viewport(
    x = unit(0, "cm"), y = unit(page_h_cm - 5.50, "cm"),
    width = unit(page_w_cm, "cm"), height = unit(0.40, "cm"),
    just = c("left", "bottom")
  )
  vp_bottom <- viewport(
    x = unit(0, "cm"), y = unit(0.00, "cm"),
    width = unit(page_w_cm, "cm"), height = unit(4.85, "cm"),
    just = c("left", "bottom")
  )

  pushViewport(vp_top); grid.draw(ggplotGrob(p_top)); popViewport()
  pushViewport(vp_mid); grid.draw(ggplotGrob(p_mid)); popViewport()
  pushViewport(vp_group); grid.draw(ggplotGrob(p_group)); popViewport()
  pushViewport(vp_bottom); grid.draw(ggplotGrob(p_bottom)); popViewport()
  popViewport()
}

grDevices::cairo_pdf(out_pdf, width = page_w_cm / 2.54, height = page_h_cm / 2.54)
draw_compound()
dev.off()

grDevices::png(out_png, width = page_w_cm, height = page_h_cm, units = "cm", res = 600, type = "cairo-png", bg = "white")
draw_compound()
dev.off()

message("Framework composite complete.")
