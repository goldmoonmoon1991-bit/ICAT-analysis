#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(ggplot2)
  library(scales)
  library(grid)
})

script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
script_path <- normalizePath(sub("^--file=", "", script_arg[[1]]), mustWork = TRUE)
fig_dir <- if (exists("FIG3_BASE_DIR", inherits = TRUE)) {
  normalizePath(get("FIG3_BASE_DIR", inherits = TRUE), mustWork = TRUE)
} else {
  normalizePath(file.path(dirname(script_path), "..", ".."), mustWork = TRUE)
}

find_project_root <- function(start_dir) {
  current <- normalizePath(start_dir, mustWork = TRUE)
  repeat {
    if (file.exists(file.path(current, "shared", "R", "plot_style.R"))) return(current)
    parent <- dirname(current)
    if (identical(parent, current)) stop("Could not locate project root from: ", start_dir)
    current <- parent
  }
}

project_root <- find_project_root(dirname(script_path))
source(file.path(project_root, "shared", "R", "plot_style.R"))

figure_dir <- file.path(fig_dir, "04_results", "figures", "spatial_relationship")
table_dir <- file.path(fig_dir, "04_results", "tables", "spatial_relationship")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)

pla_dir <- file.path(fig_dir, "01_raw_data", "PLA")
pla_samples <- c("CF5", "MIC2c", "CPH1", "ICMAP1", "ICMAP2", "MIC2n", "RON4")
pla_labels <- c(
  CF5 = "CF5",
  MIC2c = "MIC2\n(conoid)",
  CPH1 = "CPH1",
  ICMAP1 = "ICMAP1",
  ICMAP2 = "ICMAP2",
  MIC2n = "MIC2\n(non-conoid)",
  RON4 = "RON4"
)

pla <- do.call(rbind, lapply(pla_samples, function(sample) {
  values <- scan(file.path(pla_dir, paste0(sample, "-ICAT.csv")), what = numeric(), quiet = TRUE)
  data.frame(sample = sample, intensity = values, stringsAsFactors = FALSE)
}))
pla$sample <- factor(pla$sample, levels = pla_samples)
pla$positive <- pla$intensity > 1000

pla_summary <- do.call(rbind, lapply(pla_samples, function(sample) {
  x <- pla$intensity[pla$sample == sample]
  data.frame(
    sample = sample,
    sample_label = unname(pla_labels[sample]),
    n = length(x),
    positive_count = sum(x > 1000),
    positive_percent = 100 * mean(x > 1000),
    median_intensity = median(x),
    stringsAsFactors = FALSE
  )
}))
pla_summary$sample <- factor(pla_summary$sample, levels = pla_samples)
pla_summary <- pla_summary[order(-pla_summary$positive_percent, -pla_summary$median_intensity), , drop = FALSE]
pla_summary$sample_label <- factor(pla_summary$sample_label, levels = pla_summary$sample_label)
write.csv(
  pla_summary,
  file.path(table_dir, "Fig3C_PLA_network_summary.csv"),
  row.names = FALSE
)

node_theme_colors <- c(
  ICAT = "#E26AE5",
  CF5 = "#D9A72E",
  MIC2c = "#93af70",
  CPH1 = "#A7B79D",
  ICMAP1 = "#5A8BBF",
  ICMAP2 = "#6F83C7",
  MIC2n = "#B6B6B6",
  RON4 = "#a56441"
)

pos_scale <- function(x, to = c(0.18, 1.25)) {
  rescale(x, to = to, from = range(pla_summary$positive_percent, na.rm = TRUE))
}

node_layout <- data.frame(
  sample = pla_summary$sample,
  label = unname(pla_labels[as.character(pla_summary$sample)]),
  positive_percent = pla_summary$positive_percent,
  x = c(1.25, 1.95, 2.60, 3.25, 3.70, 4.05, 4.35),
  y = c(1.25, 0.80, 0.35, -0.05, -0.50, -0.95, -1.35),
  stringsAsFactors = FALSE
)
node_layout$stroke_col <- node_theme_colors[as.character(node_layout$sample)]
node_layout$edge_lwd <- pos_scale(node_layout$positive_percent, to = c(0.25, 1.3))
node_layout$edge_alpha <- pos_scale(node_layout$positive_percent, to = c(0.18, 0.95))

edge_df <- transform(node_layout, x0 = 0, y0 = 0, x1 = x, y1 = y)

p_network <- ggplot() +
  geom_curve(
    data = edge_df,
    aes(x = x0, y = y0, xend = x1, yend = y1, linewidth = edge_lwd, alpha = edge_alpha),
    curvature = 0.12, color = "#7A7A7A", lineend = "round"
  ) +
  geom_point(
    data = node_layout,
    aes(x = x, y = y),
    shape = 21, size = 4.2, fill = "white",
    color = node_layout$stroke_col, stroke = 0.45
  ) +
  geom_point(
    data = node_layout[node_layout$sample %in% c("CF5", "MIC2c"), , drop = FALSE],
    aes(x = x, y = y),
    shape = 21, size = 4.4, fill = "#F8F8F8",
    color = node_layout$stroke_col[node_layout$sample %in% c("CF5", "MIC2c")], stroke = 0.7
  ) +
  geom_point(
    data = data.frame(x = 0, y = 0),
    aes(x = x, y = y),
    shape = 21, size = 6.1, fill = "#E26AE5", color = "#B33CC9", stroke = 0.55
  ) +
  geom_segment(
    data = node_layout,
    aes(x = x + 0.12, xend = x + 0.34, y = y, yend = y),
    inherit.aes = FALSE, linewidth = 0.22, color = "#8A8A8A"
  ) +
  geom_text(
    data = node_layout,
    aes(x = x + 0.39, y = y, label = label),
    hjust = 0, vjust = 0.5, family = "Arial", fontface = "bold",
    size = ICAT_FONT_BODY_PT / 2.845276, color = "#1F1F1F", lineheight = 0.9
  ) +
  geom_text(
    data = node_layout,
    aes(x = x + 0.39, y = y - 0.16, label = paste0(round(positive_percent, 1), "%")),
    hjust = 0, vjust = 1, family = "Arial",
    size = ICAT_FONT_SMALL_PT / 2.845276, color = "#666666"
  ) +
  annotate(
    "text", x = 0, y = 0.28, label = "ICAT",
    family = "Arial", fontface = "bold", size = ICAT_FONT_BODY_PT / 2.845276,
    color = "#B33CC9", vjust = 0
  ) +
  annotate(
    "text", x = 0, y = -0.35, label = "PLA reference center",
    family = "Arial", size = ICAT_FONT_SMALL_PT / 2.845276,
    color = "#7A7A7A", vjust = 1
  ) +
  annotate(
    "segment", x = 0.15, xend = 4.6, y = -1.95, yend = -1.95,
    linewidth = 0.28, color = "#9A9A9A",
    arrow = arrow(length = unit(1.8, "mm"), type = "closed")
  ) +
  annotate(
    "text", x = 2.35, y = -2.20, label = "higher PLA signal  \u2192  closer implied proximity to ICAT",
    family = "Arial", size = ICAT_FONT_SMALL_PT / 2.845276,
    color = "#5A5A5A"
  ) +
  coord_cartesian(xlim = c(-0.3, 5.1), ylim = c(-2.45, 1.75), clip = "off") +
  labs(
    title = "PLA-derived ICAT proximity network",
    subtitle = "Edge thickness and darkness scale with cells above the 1,000 a.u. threshold",
    x = NULL, y = NULL
  ) +
  icat_theme_classic() +
  theme(
    axis.line = element_blank(),
    axis.ticks = element_blank(),
    axis.text = element_blank(),
    plot.title = element_text(face = "bold", size = 9.5, hjust = 0),
    plot.subtitle = element_text(size = ICAT_FONT_SMALL_PT, color = "#555555", hjust = 0),
    legend.position = "none",
    plot.margin = margin(6, 4, 6, 4)
  )

save_network <- function(pdf_path, png_path, width_in, height_in, dpi = 600) {
  grDevices::cairo_pdf(pdf_path, width = width_in, height = height_in)
  print(p_network)
  dev.off()
  if (requireNamespace("ragg", quietly = TRUE)) {
    ragg::agg_png(png_path, width = width_in, height = height_in, units = "in", res = dpi, background = "white")
    print(p_network)
    dev.off()
  } else {
    grDevices::png(png_path, width = width_in, height = height_in, units = "in", res = dpi, type = "cairo-png", bg = "white")
    print(p_network)
    dev.off()
  }
}

save_network(
  pdf_path = file.path(figure_dir, "Fig3C_PLA_network.pdf"),
  png_path = file.path(figure_dir, "Fig3C_PLA_network.png"),
  width_in = 5.3,
  height_in = 4.3,
  dpi = 600
)

message("PLA proximity network complete.")
