library(tidyverse)
library(scales)
library(ggpubr)
library(patchwork)

script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
script_path <- normalizePath(sub("^--file=", "", script_arg[[1]]), mustWork = TRUE)
fig_dir <- if (exists("FIG3_BASE_DIR", inherits = TRUE)) {
  normalizePath(get("FIG3_BASE_DIR", inherits = TRUE), mustWork = TRUE)
} else {
  normalizePath(file.path(dirname(script_path), "..", ".."), mustWork = TRUE)
}
find_project_root <- function(start_dir) {
  current <- normalizePath(start_dir, mustWork = TRUE)
  repeat {
    if (file.exists(file.path(current, "shared", "R", "plot_style.R"))) return(current)
    parent <- dirname(current)
    if (identical(parent, current)) stop("Could not locate project root from: ", start_dir)
    current <- parent
  }
}
project_root <- find_project_root(dirname(script_path))
source(file.path(project_root, "shared", "R", "plot_style.R"))
data_dir <- file.path(fig_dir, "01_raw_data", "PLA")
figure_dir <- file.path(fig_dir, "04_results", "figures", "PLA")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)

# 1. 获取文件列表
files <- list.files(data_dir, pattern = "\\.csv$", full.names = TRUE)

# 2. 批量读取并处理数据
all_data <- files %>%
  set_names(basename(files)) %>%
  map_dfr(~read_table(.x, col_names = FALSE), .id = "Sample") %>%
  pivot_longer(cols = -Sample, names_to = "temp_col", values_to = "Intensity") %>%
  filter(!is.na(Intensity)) %>%
  mutate(Sample = str_remove(Sample, "-ICAT.csv"))

# 3. 统一设置因子顺序（关键：p1和p2共用此顺序）
sample_levels <- c("CPH1","CF5","MIC2c","MIC2n","ICMAP1","ICMAP2","RON4")
all_data$Sample <- factor(all_data$Sample, levels = sample_levels)

# 4. 计算饼图比例数据
pie_data <- all_data %>%
  group_by(Sample) %>%
  summarise(
    Above_Count = sum(Intensity > 1000),
    Total_Count = n(),
    .groups = 'drop'
  ) %>%
  mutate(
    Above_Ratio = Above_Count / Total_Count,
    Below_Ratio = 1 - Above_Ratio
  ) %>%
  pivot_longer(cols = c(Above_Ratio, Below_Ratio),
               names_to = "Threshold",
               values_to = "Ratio") %>%
  mutate(Sample = factor(Sample, levels = sample_levels))

# ==========================================
# 5. 绘制主图 p1
# ==========================================
p1 <- ggplot(all_data, aes(x = Sample, y = Intensity, fill = Sample)) +
  geom_jitter(aes(color = Sample), size = 1, alpha = 0.5, width = 0.2) +
  geom_violin(trim = FALSE, alpha = 0.3, color = "black", scale = "width") +
  geom_boxplot(width = 0.1, fill = "white", outlier.shape = NA, alpha = 0.8) +
  scale_y_continuous(
    trans = pseudo_log_trans(sigma = 1000, base = 10),
    breaks = c(0, 1000, 5000, 10000, 20000, 30000),
    labels = label_number(scale = 0.001),
    expand = expansion(mult = c(0.05, 0.1))
  ) +
  geom_hline(yintercept = 1000, linetype = "dashed", color = "red", linewidth = 0.5) +
  stat_compare_means(ref.group = "CPH1", label = "p.signif", method = "wilcox.test", label.y = 1.5,
                     size = ICAT_TEXT_SMALL_MM) +
  icat_theme_bw() +
  theme(
    # 【修改】完全隐藏 X 轴信息，确保空间留给下方的饼图标签
    axis.text.x = element_blank(),
    axis.title.x = element_blank(),
    axis.ticks.x = element_line(),
    panel.grid = element_blank(),
    legend.position = "none",
    # 【修改】手动设置左边距(l=50)，为 Y 轴留出固定空间以便上下对齐
    plot.margin = margin(t = 5, r = 10, b = 0, l = 50)
  ) +
  labs(title = "PLA Intensity Distribution", y = "Intensity (a.u., 10^3)")

# ==========================================
# 6. 绘制比例图 p2
# ==========================================
p2 <- ggplot(pie_data, aes(x = "", y = Ratio, fill = Threshold)) +
  geom_bar(stat = "identity", width = 0.5, color = "white", position = "stack") +
  coord_polar("y", start = 0) +
  facet_wrap(~Sample, nrow = 1) +
  scale_fill_manual(values = c("Above_Ratio" = "#E41A1C", "Below_Ratio" = "#E6E6E6")) +
  theme_void(base_size = ICAT_FONT_BODY_PT) +
  theme(
    # 【修改】样本名改为普通字体 (plain)
    strip.text = element_text(size = 10, face = "plain", vjust = 1),
    legend.position = "none",
    # 【修改】左边距必须与 p1 严格一致 (l=50)，实现垂直对齐
    plot.margin = margin(t = 0, r = 10, b = 5, l = 50)
  ) +
  geom_text(
    data = pie_data %>% filter(Threshold == "Above_Ratio"),
    # 【修改】移除 position_stack，改用固定坐标实现圆心对齐
    aes(x = 1, y = 0, label = percent(Ratio, accuracy = 0.1)),
    inherit.aes = FALSE,
    size = ICAT_TEXT_BODY_MM,
    # 【修改】百分比文字改为普通字体 (plain)
    fontface = "plain",
    color = "black"
  )


# ==========================================
# 7. 拼图
# ==========================================
final_plot <- p1 / p2 + plot_layout(heights = c(4, 1.2))

# 1. 打印预览
print(final_plot)

# 2. 保存 PNG (用于报告)
ggsave(file.path(figure_dir, "PLA_Final_Combined.png"),
       plot = final_plot,
       width = 5,
       height = 4,
       units = "in",      # 单位：in (英寸), cm (厘米), mm (毫米)
       dpi = 300)

# 3. 保存 PDF (用于出版/后期编辑)
ggsave(file.path(figure_dir, "PLA_Final_Combined.pdf"),
       plot = final_plot,
       width = 5,
       height = 4,
       device = "pdf",
       units = "in",      # 单位：in (英寸), cm (厘米), mm (毫米)
       useDingbats = FALSE)

message("🎉 文件已保存至 Figure/ 目录！")
