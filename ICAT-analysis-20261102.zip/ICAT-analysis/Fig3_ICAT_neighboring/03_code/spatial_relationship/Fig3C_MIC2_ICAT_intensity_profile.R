#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(ggplot2)
  library(scales)
})

script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
script_path <- normalizePath(sub("^--file=", "", script_arg[[1]]), mustWork = TRUE)
fig_dir <- if (exists("FIG3_BASE_DIR", inherits = TRUE)) {
  normalizePath(get("FIG3_BASE_DIR", inherits = TRUE), mustWork = TRUE)
} else {
  normalizePath(file.path(dirname(script_path), "..", ".."), mustWork = TRUE)
}

find_project_root <- function(start_dir) {
  current <- normalizePath(start_dir, mustWork = TRUE)
  repeat {
    if (file.exists(file.path(current, "shared", "R", "plot_style.R"))) return(current)
    parent <- dirname(current)
    if (identical(parent, current)) stop("Could not locate project root from: ", start_dir)
    current <- parent
  }
}

project_root <- find_project_root(dirname(script_path))
source(file.path(project_root, "shared", "R", "plot_style.R"))

data_dir <- file.path(fig_dir, "01_raw_data", "MIC2-ICAT")
figure_dir <- file.path(fig_dir, "04_results", "figures", "spatial_relationship")
table_dir <- file.path(fig_dir, "04_results", "tables", "spatial_relationship")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)

files <- list.files(data_dir, pattern = "\\.csv$", full.names = TRUE)
if (!length(files)) stop("No CSV files found in: ", data_dir)

channel_map <- c(
  "Channel_1::ChA-T2!!R" = "MIC2",
  "Channel_2::ChA-T4!!R" = "ICAT"
)
channel_colors <- c(MIC2 = "#6BAF73", ICAT = "#D14AD6")
channel_fills <- c(MIC2 = "#D9F0DD", ICAT = "#F2D5F7")

read_profile <- function(path) {
  dat <- read.csv(path, check.names = FALSE, fileEncoding = "UTF-8-BOM", stringsAsFactors = FALSE)
  if (nrow(dat) < 4) stop("Unexpectedly short profile file: ", basename(path))
  names(dat)[1] <- "distance_nm"
  names(dat)[2:3] <- c("channel_1", "channel_2")
  dat <- dat[-1, , drop = FALSE]
  dat$distance_nm <- as.numeric(dat$distance_nm)
  dat$channel_1 <- as.numeric(dat$channel_1)
  dat$channel_2 <- as.numeric(dat$channel_2)
  dat <- dat[is.finite(dat$distance_nm), , drop = FALSE]
  dat$sample_id <- sub("\\.csv$", "", basename(path))
  dat
}

raw <- do.call(rbind, lapply(files, read_profile))

long <- rbind(
  data.frame(
    sample_id = raw$sample_id,
    distance_nm = raw$distance_nm,
    channel = "MIC2",
    intensity_raw = raw$channel_1,
    stringsAsFactors = FALSE
  ),
  data.frame(
    sample_id = raw$sample_id,
    distance_nm = raw$distance_nm,
    channel = "ICAT",
    intensity_raw = raw$channel_2,
    stringsAsFactors = FALSE
  )
)

normalize_profile <- function(x, y) {
  n <- length(x)
  k <- max(3L, floor(n * 0.10))
  idx <- unique(c(seq_len(k), (n - k + 1L):n))
  x0 <- x[idx]
  y0 <- y[idx]
  fit <- stats::lm(y0 ~ x0)
  baseline <- stats::predict(fit, newdata = data.frame(x0 = x))
  corrected <- y - baseline
  corrected[!is.finite(corrected)] <- NA_real_
  corrected <- pmax(corrected, 0)
  mx <- max(corrected, na.rm = TRUE)
  if (!is.finite(mx) || mx <= 0) return(rep(NA_real_, length(corrected)))
  corrected / mx
}

profile_list <- split(long, interaction(long$sample_id, long$channel, drop = TRUE))
processed <- lapply(profile_list, function(z) {
  ord <- order(z$distance_nm)
  z <- z[ord, , drop = FALSE]
  z$position <- scales::rescale(z$distance_nm, to = c(0, 1))
  z$intensity_norm <- normalize_profile(z$distance_nm, z$intensity_raw)
  z
})
processed_df <- do.call(rbind, processed)

grid <- seq(0, 1, by = 0.01)

interp_one <- function(z) {
  ord <- order(z$position)
  z <- z[ord, , drop = FALSE]
  stats::approx(z$position, z$intensity_norm, xout = grid, rule = 1, ties = mean)$y
}

interp_list <- lapply(split(processed_df, interaction(processed_df$sample_id, processed_df$channel, drop = TRUE)), interp_one)
interp_names <- names(interp_list)

interp_long <- do.call(rbind, lapply(seq_along(interp_list), function(i) {
  nm <- interp_names[i]
  sp <- strsplit(nm, "\\.")[[1]]
  sample_id <- sp[1]
  channel <- sp[2]
  data.frame(
    sample_id = sample_id,
    channel = channel,
    position = grid,
    intensity_norm = interp_list[[i]],
    stringsAsFactors = FALSE
  )
}))

interp_long$channel <- factor(interp_long$channel, levels = c("MIC2", "ICAT"))

summary_fun <- function(x) {
  x <- x[is.finite(x)]
  n <- length(x)
  if (n == 0) {
    return(data.frame(n = 0, mean = NA_real_, ci95_low = NA_real_, ci95_high = NA_real_))
  }
  if (n == 1) {
    return(data.frame(n = 1, mean = x[1], ci95_low = x[1], ci95_high = x[1]))
  }
  sem <- sd(x) / sqrt(n)
  tcrit <- qt(0.975, df = n - 1L)
  data.frame(
    n = n,
    mean = mean(x),
    ci95_low = mean(x) - tcrit * sem,
    ci95_high = mean(x) + tcrit * sem
  )
}

mean_by_channel <- do.call(rbind, lapply(split(interp_long, interp_long$channel), function(z) {
  out <- do.call(rbind, lapply(split(z$intensity_norm, z$position), summary_fun))
  out$position <- sort(unique(z$position))
  out$channel <- z$channel[1]
  out
}))
mean_by_channel$channel <- factor(mean_by_channel$channel, levels = c("MIC2", "ICAT"))

cell_n <- length(unique(processed_df$sample_id))
write.csv(
  processed_df,
  file.path(table_dir, "Fig3C_MIC2_ICAT_intensity_profile_per_cell.csv"),
  row.names = FALSE
)
write.csv(
  mean_by_channel,
  file.path(table_dir, "Fig3C_MIC2_ICAT_intensity_profile_mean.csv"),
  row.names = FALSE
)

p_profile <- ggplot() +
  geom_line(
    data = interp_long,
    aes(x = position, y = intensity_norm, group = interaction(sample_id, channel), color = channel),
    alpha = 0.14, linewidth = 0.42, na.rm = TRUE
  ) +
  geom_ribbon(
    data = mean_by_channel,
    aes(x = position, ymin = pmax(0, ci95_low), ymax = pmin(1.05, ci95_high), fill = channel, group = channel),
    inherit.aes = FALSE,
    alpha = 0.12,
    color = NA
  ) +
  geom_line(
    data = mean_by_channel,
    aes(x = position, y = mean, color = channel, group = channel),
    linewidth = 1.35
  ) +
  geom_vline(xintercept = 0, linewidth = 0.36, color = "#333333") +
  geom_vline(xintercept = 0.5, linewidth = 0.28, linetype = "dashed", color = "#777777") +
  geom_vline(xintercept = 1, linewidth = 0.36, color = "#333333") +
  scale_color_manual(values = channel_colors) +
  scale_fill_manual(values = channel_fills) +
  coord_cartesian(xlim = c(0, 1), ylim = c(0, 1.05), expand = FALSE) +
  labs(
    title = "MIC2-ICAT intensity profile",
    subtitle = sprintf("%d raw profiles; dark lines = mean; shading = 95%% CI", cell_n),
    x = "Normalized position across scan",
    y = "Background-corrected normalized intensity",
    color = NULL,
    fill = NULL
  ) +
  icat_theme_classic() +
  theme(
    legend.position = "top",
    legend.direction = "horizontal",
    legend.justification = "left",
    legend.box.margin = margin(0, 0, 0, 0),
    plot.margin = margin(4, 4, 4, 4),
    plot.title = element_text(face = "bold", size = 9.0),
    plot.subtitle = element_text(size = ICAT_FONT_SMALL_PT, color = "#555555"),
    axis.title = element_text(size = ICAT_FONT_BODY_PT),
    axis.text = element_text(size = ICAT_FONT_BODY_PT)
  )

out_pdf <- file.path(figure_dir, "Fig3C_MIC2_ICAT_intensity_profile.pdf")
out_png <- file.path(figure_dir, "Fig3C_MIC2_ICAT_intensity_profile.png")

grDevices::cairo_pdf(out_pdf, width = 8.0 / 2.54, height = 5.6 / 2.54)
print(p_profile)
dev.off()

grDevices::png(out_png, width = 8.0, height = 5.6, units = "cm", res = 600, type = "cairo-png", bg = "white")
print(p_profile)
dev.off()

message("MIC2-ICAT intensity profile complete.")
