#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(stats)
})

script_arg <- grep('^--file=', commandArgs(trailingOnly = FALSE), value = TRUE)
script_path <- normalizePath(sub('^--file=', '', script_arg[[1]]), mustWork = TRUE)
fig_dir <- normalizePath(file.path(dirname(script_path), '..', '..'), mustWork = TRUE)

find_project_root <- function(start_dir) {
  current <- normalizePath(start_dir, mustWork = TRUE)
  repeat {
    if (file.exists(file.path(current, 'shared', 'R', 'plot_style.R'))) return(current)
    parent <- dirname(current)
    if (identical(parent, current)) stop('Could not locate project root from: ', start_dir)
    current <- parent
  }
}

project_root <- find_project_root(dirname(script_path))
source(file.path(project_root, 'shared', 'R', 'plot_style.R'))

# Input: the same MIC2-ICAT profiles used for Fig3C.
data_dir <- file.path(fig_dir, '04_results', 'tables', 'spatial_relationship')
# Reconstruct from aligned per-cell table; includes normalized intensity and aligned positions.
infile <- file.path(data_dir, 'Fig3C_MIC2_ICAT_intensity_profile_aligned_per_cell.csv')
if (!file.exists(infile)) stop('Missing table: ', infile)

profiles <- read.csv(infile, stringsAsFactors = FALSE)

# Helper: find peak and 2/3 max crossings on a dense grid.
metric_for_profile <- function(df, threshold = 2/3) {
  df <- df[is.finite(df$aligned_position) & is.finite(df$intensity_norm), , drop = FALSE]
  df <- df[order(df$aligned_position), , drop = FALSE]
  if (nrow(df) < 4) return(NULL)
  x <- df$aligned_position
  y <- df$intensity_norm
  xr <- seq(min(x), max(x), length.out = 2001)
  yr <- stats::approx(x, y, xout = xr, rule = 2, ties = mean)$y
  yr[!is.finite(yr)] <- NA_real_
  pk_i <- which.max(yr)
  pk_x <- xr[pk_i]
  pk_y <- yr[pk_i]
  if (!is.finite(pk_y) || pk_y <= 0) return(NULL)
  thr <- threshold * pk_y

  # Left and right crossing positions around the peak.
  left_idx <- which(xr <= pk_x & yr >= thr)
  right_idx <- which(xr >= pk_x & yr >= thr)
  left_cross <- if (length(left_idx)) min(xr[left_idx]) else NA_real_
  right_cross <- if (length(right_idx)) max(xr[right_idx]) else NA_real_

  # Refine crossings by linear interpolation around threshold boundaries.
  crossing_left <- NA_real_
  if (!is.na(left_cross)) {
    i <- max(which(xr < pk_x & yr < thr))
    j <- min(which(xr >= pk_x & yr >= thr))
    # Walk left from peak to find the last below-threshold point before the above-threshold run.
    if (length(i) > 0 && length(j) > 0 && is.finite(i) && is.finite(j) && i < j) {
      x1 <- xr[i]; y1 <- yr[i]
      k <- min(which(xr >= pk_x & yr >= thr))
      if (is.finite(k) && k > 1) {
        # search backwards for first transition below->above
        idx <- which(diff(yr[seq_len(k)] >= thr) == 1)
        if (length(idx)) {
          a <- idx[length(idx)]
          b <- a + 1
          crossing_left <- x1
          if (is.finite(yr[a]) && is.finite(yr[b]) && yr[b] != yr[a]) {
            crossing_left <- xr[a] + (thr - yr[a]) * (xr[b] - xr[a]) / (yr[b] - yr[a])
          }
        }
      }
    }
  }
  crossing_right <- NA_real_
  if (!is.na(right_cross)) {
    k <- max(which(xr <= pk_x & yr >= thr))
    if (is.finite(k) && k < length(xr)) {
      idx <- which(diff(yr[seq(k, length(yr))] >= thr) == -1)
      if (length(idx)) {
        a <- k + idx[1] - 1
        b <- a + 1
        crossing_right <- xr[b]
        if (is.finite(yr[a]) && is.finite(yr[b]) && yr[b] != yr[a]) {
          crossing_right <- xr[a] + (thr - yr[a]) * (xr[b] - xr[a]) / (yr[b] - yr[a])
        }
      }
    }
  }

  data.frame(
    sample_id = df$sample_id[1],
    channel = df$channel[1],
    peak_position = pk_x,
    peak_height = pk_y,
    thr_2_3 = thr,
    left_2_3 = crossing_left,
    right_2_3 = crossing_right,
    width_2_3 = ifelse(is.finite(crossing_left) && is.finite(crossing_right), crossing_right - crossing_left, NA_real_),
    stringsAsFactors = FALSE
  )
}

metrics <- do.call(rbind, lapply(split(profiles, interaction(profiles$sample_id, profiles$channel, drop = TRUE)), metric_for_profile))

icat <- metrics[metrics$channel == 'ICAT', c('sample_id','peak_position','left_2_3')]
mic2 <- metrics[metrics$channel == 'MIC2', c('sample_id','peak_position','right_2_3')]
colnames(icat) <- c('sample_id','icat_peak','icat_left_2_3')
colnames(mic2) <- c('sample_id','mic2_peak','mic2_right_2_3')
paired <- merge(icat, mic2, by = 'sample_id')
paired$peak_distance <- abs(paired$icat_peak - paired$mic2_peak)
paired$boundary_gap_2_3 <- paired$icat_left_2_3 - paired$mic2_right_2_3

# Optional conversion into nm using the full scan length for each cell.
raw_dir <- file.path(fig_dir, '01_raw_data', 'MIC2-ICAT')
raw_files <- list.files(raw_dir, pattern = '\\.csv$', full.names = TRUE)
get_scan_len <- function(path) {
  dat <- read.csv(path, check.names = FALSE, fileEncoding = 'UTF-8-BOM', stringsAsFactors = FALSE)
  dat <- dat[-1, , drop = FALSE]
  d <- as.numeric(dat[[1]])
  d <- d[is.finite(d)]
  if (!length(d)) return(NA_real_)
  max(d) - min(d)
}
scan_lengths <- data.frame(
  sample_id = sub('\\.csv$', '', basename(raw_files)),
  scan_nm = vapply(raw_files, get_scan_len, numeric(1)),
  stringsAsFactors = FALSE
)
paired <- merge(paired, scan_lengths, by = 'sample_id', all.x = TRUE)
paired$peak_distance_nm <- paired$peak_distance * paired$scan_nm
paired$boundary_gap_2_3_nm <- paired$boundary_gap_2_3 * paired$scan_nm
paired$peak_distance_nm_actual <- paired$peak_distance_nm / 4.5
paired$boundary_gap_2_3_nm_actual <- paired$boundary_gap_2_3_nm / 4.5

out_dir <- file.path(fig_dir, '04_results', 'tables', 'spatial_relationship')
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
write.csv(metrics, file.path(out_dir, 'Fig3C_MIC2_ICAT_2_3metrics_per_profile.csv'), row.names = FALSE)
write.csv(paired, file.path(out_dir, 'Fig3C_MIC2_ICAT_peak_and_2_3_gap_per_cell.csv'), row.names = FALSE)

summary <- data.frame(
  metric = c('peak_distance', 'boundary_gap_2_3', 'peak_distance_nm', 'boundary_gap_2_3_nm', 'peak_distance_nm_actual', 'boundary_gap_2_3_nm_actual'),
  mean = c(mean(paired$peak_distance), mean(paired$boundary_gap_2_3), mean(paired$peak_distance_nm), mean(paired$boundary_gap_2_3_nm), mean(paired$peak_distance_nm_actual), mean(paired$boundary_gap_2_3_nm_actual)),
  sd = c(sd(paired$peak_distance), sd(paired$boundary_gap_2_3), sd(paired$peak_distance_nm), sd(paired$boundary_gap_2_3_nm), sd(paired$peak_distance_nm_actual), sd(paired$boundary_gap_2_3_nm_actual)),
  min = c(min(paired$peak_distance), min(paired$boundary_gap_2_3), min(paired$peak_distance_nm), min(paired$boundary_gap_2_3_nm), min(paired$peak_distance_nm_actual), min(paired$boundary_gap_2_3_nm_actual)),
  max = c(max(paired$peak_distance), max(paired$boundary_gap_2_3), max(paired$peak_distance_nm), max(paired$boundary_gap_2_3_nm), max(paired$peak_distance_nm_actual), max(paired$boundary_gap_2_3_nm_actual)),
  stringsAsFactors = FALSE
)
write.csv(summary, file.path(out_dir, 'Fig3C_MIC2_ICAT_peak_and_2_3_gap_summary.csv'), row.names = FALSE)

print(paired)
cat('\nSummary:\n')
print(summary)
