#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(cluster)
  library(grid)
  library(readxl)
})

script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
script_path <- if (length(script_arg)) {
  normalizePath(sub("^--file=", "", script_arg[[1]]), mustWork = TRUE)
} else {
  NULL
}
code_dir <- if (!is.null(script_path)) dirname(script_path) else getwd()
fig_dir <- if (exists("FIG3_BASE_DIR", inherits = TRUE)) {
  normalizePath(get("FIG3_BASE_DIR", inherits = TRUE), mustWork = TRUE)
} else {
  normalizePath(file.path(code_dir, ".."), mustWork = TRUE)
}
fig3b_results_dir <- file.path(fig_dir, "04_results", "figures", "localization_perturbation")
fig3b_final_dir <- file.path(fig_dir, "05_final_figure")

find_project_root <- function(start_dir) {
  current <- normalizePath(start_dir, mustWork = TRUE)
  repeat {
    if (file.exists(file.path(current, "shared", "R", "plot_style.R"))) return(current)
    parent <- dirname(current)
    if (identical(parent, current)) stop("Could not locate project root from: ", start_dir)
    current <- parent
  }
}
project_root <- find_project_root(code_dir)
source(file.path(project_root, "shared", "R", "plot_style.R"))

fig3b_order <- c(
  "WT", "CF5KO", "AROKD", "ICMAP1KD", "ICMAP2KD",
  "CIP3KO", "RNG2KD", "AC9KD", "CIP3KO/CF1KD"
)

# Display order used only for Panel B. This keeps the analysis order stable
# while letting us flip branches in the drawing layer without touching the
# clustering inputs.
fig3b_display_order <- c(
  "WT", "CF5KO", "AROKD", "ICMAP1KD", "ICMAP2KD",
  "CIP3KO", "RNG2KD", "AC9KD", "CIP3KO/CF1KD"
)

fig3b_structure_cols <- c(
  conoid_body = "#93af70",
  apical_ring = "#87C995",
  icmt = "#53876d",
  bridge = "#D8C95A",
  rhoptry = "#a56441"
)

display_genotype <- function(x) {
  x <- as.character(x)
  x <- gsub("CIP3KO/CF1KD", "CIP3/CF1", x, fixed = TRUE)
  x <- gsub("KD$", "", x)
  x <- gsub("KO$", "", x)
  x <- gsub("_", "", x)
  x
}

normalize_perturbation_structures <- function(primary, module) {
  terms <- tolower(c(primary, module))
  out <- character()
  add_if <- function(flag, label) {
    if (any(flag, na.rm = TRUE)) out <<- unique(c(out, label))
  }
  add_if(grepl("conoid", terms) | grepl("bridge", terms), "Conoid")
  add_if(grepl("icmt", terms), "ICMTs")
  add_if(grepl("rhoptry", terms), "Rhoptry")
  out
}

normalize_primary_target <- function(primary) {
  term <- tolower(trimws(as.character(primary)))
  if (is.na(term) || !nzchar(term) || term == "none") return(character())
  out <- character()
  if (grepl("conoid|bridge", term)) out <- c(out, "Conoid")
  if (grepl("icmt", term)) out <- c(out, "ICMTs")
  if (grepl("rhoptry", term)) out <- c(out, "Rhoptry")
  unique(out)
}

first_nonblank <- function(x) {
  x <- x[!is.na(x) & nzchar(trimws(as.character(x)))]
  if (length(x)) as.character(x[[1]]) else NA_character_
}

status_score <- function(x, type = c("structure", "abundance")) {
  type <- match.arg(type)
  x <- tolower(trimws(as.character(x)))
  out <- rep(NA_real_, length(x))
  if (type == "abundance") {
    out[grepl("normal|intact", x)] <- 0
    out[grepl("reduced|altered|partial", x)] <- 1
    out[grepl("lost|absent", x)] <- 2
  } else {
    out[x == "intact"] <- 0
    out[grepl("altered|partial|mislocal", x)] <- 1
    out[grepl("lost|full disass|disassembl", x)] <- 2
  }
  out[x %in% c("", "nd", "na") | is.na(x)] <- NA_real_
  out
}

conoid_assembly_score <- function(x) {
  x <- tolower(trimws(as.character(x)))
  out <- rep(NA_real_, length(x))
  out[x == "intact" | grepl("intact but mislocal", x)] <- 0
  out[grepl("partial", x)] <- 1
  out[grepl("lost|full disass|disassembl", x)] <- 2
  out[x %in% c("", "nd", "na") | is.na(x)] <- NA_real_
  out
}

conoid_position_score <- function(x) {
  x <- tolower(trimws(as.character(x)))
  out <- rep(0, length(x))
  out[grepl("mislocal|displac", x)] <- 1
  out[grepl("^lost$|absent", x)] <- 2
  out[x %in% c("", "nd", "na") | is.na(x)] <- NA_real_
  out
}

load_fig3b_input <- function(input_path = NULL) {
  default_input <- file.path(fig_dir, "01_raw_data", "localization_perturbation", "ICAT_localization_pertubation.xlsx")
  if (is.null(input_path) || !nzchar(input_path)) input_path <- default_input
  if (!file.exists(input_path)) {
    fallback <- file.path(fig_dir, "01_raw_data", "localization_perturbation", "ICAT_localization_pertubation.csv")
    if (file.exists(fallback)) input_path <- fallback
  }
  input_path <- normalizePath(input_path, mustWork = TRUE)

  required <- c(
    "biological_replicate", "genotype", "primary_perturbation_target", "target_module",
    "total_cells", "intact_n", "altered_n", "lost_n", "unscorable_n",
    "expected_icat_effect", "conoid_body_status", "apical_ring_status",
    "icmt_status", "bridge_status", "icat_total_signal_status"
  )

  if (grepl("\\.xlsx$", input_path, ignore.case = TRUE)) {
    raw <- readxl::read_excel(input_path, sheet = "Data", na = c("", "NA"))
  } else {
    raw <- read.csv(input_path, check.names = FALSE, stringsAsFactors = FALSE)
  }
  raw <- as.data.frame(raw, check.names = FALSE, stringsAsFactors = FALSE)
  apical_col <- if ("apical_polar_ring_status" %in% names(raw)) {
    "apical_polar_ring_status"
  } else if ("apical_ring_status" %in% names(raw)) {
    "apical_ring_status"
  } else {
    NA_character_
  }
  missing_columns <- setdiff(required, names(raw))
  missing_columns <- setdiff(missing_columns, c("apical_ring_status", "apical_polar_ring_status"))
  if (length(missing_columns)) {
    stop("Input is missing required columns: ", paste(missing_columns, collapse = ", "))
  }
  if (is.na(apical_col)) {
    stop("Input is missing required column: apical_polar_ring_status")
  }
  rhoptry_col <- if ("rhoptry_status" %in% names(raw)) "rhoptry_status" else NA_character_
  abundance_col <- if ("wb_abundance_ratio" %in% names(raw)) {
    "wb_abundance_ratio"
  } else if ("whole_cell_intensity_mean" %in% names(raw)) {
    "whole_cell_intensity_mean"
  } else if ("apical_intensity_mean" %in% names(raw)) {
    "apical_intensity_mean"
  } else {
    NA_character_
  }
  if (is.na(abundance_col)) {
    stop("Input must provide wb_abundance_ratio, whole_cell_intensity_mean, or apical_intensity_mean.")
  }

  completed <- !is.na(raw$total_cells) & nzchar(trimws(as.character(raw$total_cells)))
  dat <- raw[completed, , drop = FALSE]
  if (!nrow(dat)) {
    stop(
      "No completed rows were found. Fill total_cells, intact_n, altered_n, lost_n ",
      "and unscorable_n before running the analysis."
    )
  }

  count_columns <- c("total_cells", "intact_n", "altered_n", "lost_n", "unscorable_n")
  for (column in count_columns) dat[[column]] <- as.numeric(dat[[column]])
  if (any(!is.finite(as.matrix(dat[count_columns])))) {
    stop("All count columns must be numeric for completed rows.")
  }
  if (any(as.matrix(dat[count_columns]) < 0) ||
      any(abs(as.matrix(dat[count_columns]) - round(as.matrix(dat[count_columns]))) > 1e-8)) {
    stop("Cell counts must be non-negative integers.")
  }

  count_sum <- dat$intact_n + dat$altered_n + dat$lost_n + dat$unscorable_n
  bad_sum <- which(dat$total_cells != count_sum)
  if (length(bad_sum)) {
    warning(
      "Count mismatch in rows: ",
      paste(which(completed)[bad_sum] + 1L, collapse = ", "),
      ". Proceeding with the provided counts."
    )
  }

  dat$scored_cells <- dat$intact_n + dat$altered_n + dat$lost_n
  if (any(dat$scored_cells <= 0)) stop("Each completed row must contain at least one scorable cell.")
  dat$intact_prop <- dat$intact_n / dat$scored_cells
  dat$altered_prop <- dat$altered_n / dat$scored_cells
  dat$lost_prop <- dat$lost_n / dat$scored_cells
  dat$unscorable_prop <- dat$unscorable_n / dat$total_cells

  dat$conoid_body_score <- status_score(dat$conoid_body_status, "structure")
  dat$conoid_assembly_score <- conoid_assembly_score(dat$conoid_body_status)
  dat$conoid_position_score <- conoid_position_score(dat$conoid_body_status)
  dat$apical_ring_score <- status_score(dat[[apical_col]], "structure")
  dat$icmt_score <- status_score(dat$icmt_status, "structure")
  dat$bridge_score <- status_score(dat$bridge_status, "structure")
  dat$rhoptry_score <- if (!is.na(rhoptry_col)) status_score(dat[[rhoptry_col]], "structure") else NA_real_
  dat$icat_abundance_score <- status_score(dat$icat_total_signal_status, "abundance")
  dat$wb_abundance_ratio <- suppressWarnings(as.numeric(dat[[abundance_col]]))

  pieces <- split(dat, dat$genotype)
  summary_rows <- lapply(pieces, function(z) {
    perturb_structures <- normalize_perturbation_structures(
      first_nonblank(z$primary_perturbation_target),
      first_nonblank(z$target_module)
    )
    primary_targets <- normalize_primary_target(
      first_nonblank(z$primary_perturbation_target)
    )
    data.frame(
      genotype = z$genotype[[1]],
      primary_perturbation_target = first_nonblank(z$primary_perturbation_target),
      target_module = first_nonblank(z$target_module),
      expected_icat_effect = first_nonblank(z$expected_icat_effect),
      conoid_body_status = first_nonblank(z$conoid_body_status),
      apical_ring_status = first_nonblank(z[[apical_col]]),
      icmt_status = first_nonblank(z$icmt_status),
      bridge_status = first_nonblank(z$bridge_status),
      rhoptry_status = if (!is.na(rhoptry_col)) first_nonblank(z[[rhoptry_col]]) else NA_character_,
      n_biological_replicates = length(unique(z$biological_replicate)),
      total_scored_cells = sum(z$scored_cells),
      intact_prop = mean(z$intact_prop),
      altered_prop = mean(z$altered_prop),
      lost_prop = mean(z$lost_prop),
      unscorable_prop = mean(z$unscorable_prop),
      conoid_body_score = mean(z$conoid_body_score, na.rm = TRUE),
      conoid_assembly_score = mean(z$conoid_assembly_score, na.rm = TRUE),
      conoid_position_score = mean(z$conoid_position_score, na.rm = TRUE),
      apical_ring_score = mean(z$apical_ring_score, na.rm = TRUE),
      icmt_score = mean(z$icmt_score, na.rm = TRUE),
      bridge_score = mean(z$bridge_score, na.rm = TRUE),
      rhoptry_score = mean(z$rhoptry_score, na.rm = TRUE),
      icat_abundance_score = mean(z$icat_abundance_score, na.rm = TRUE),
      wb_abundance_ratio = mean(z$wb_abundance_ratio, na.rm = TRUE),
      perturb_structures = I(list(perturb_structures)),
      primary_targets = I(list(primary_targets)),
      stringsAsFactors = FALSE
    )
  })
  summary <- do.call(rbind, summary_rows)
  rownames(summary) <- NULL
  summary <- summary[match(fig3b_order, summary$genotype), , drop = FALSE]
  if (anyNA(summary$genotype)) {
    stop("Some genotypes from fig3b_order are missing in the Excel input.")
  }
  if (!identical(summary$genotype, fig3b_order)) {
    stop("Summary rows are not in the requested dendrogram order.")
  }
  summary$genotype <- as.character(summary$genotype)
  if (!any(is.finite(summary$wb_abundance_ratio))) {
    summary$expression_fraction <- rep(NA_real_, nrow(summary))
  } else {
    wt_baseline <- mean(summary$wb_abundance_ratio[summary$genotype == "WT"], na.rm = TRUE)
    if (!is.finite(wt_baseline) || wt_baseline <= 0) {
      wt_baseline <- max(summary$wb_abundance_ratio, na.rm = TRUE)
    }
    summary$expression_fraction <- summary$wb_abundance_ratio / wt_baseline
    summary$expression_fraction[!is.finite(summary$expression_fraction)] <- NA_real_
    summary$expression_fraction <- pmin(pmax(summary$expression_fraction, 0), 1)
  }

  dominant_labels <- c("intact", "altered", "lost")
  summary$dominant_icat_outcome <- apply(
    summary[, c("intact_prop", "altered_prop", "lost_prop")],
    1,
    function(x) {
      hits <- which(abs(x - max(x)) < 1e-10)
      if (length(hits) == 1L) dominant_labels[hits] else "mixed"
    }
  )

  pseudocount <- 0.005
  composition <- as.matrix(summary[, c("intact_prop", "altered_prop", "lost_prop")]) + pseudocount
  composition <- composition / rowSums(composition)
  summary$ilr_intact_vs_nonintact <- sqrt(2 / 3) * log(
    composition[, 1] / sqrt(composition[, 2] * composition[, 3])
  )
  summary$ilr_altered_vs_lost <- sqrt(1 / 2) * log(composition[, 2] / composition[, 3])

  feature_names <- c(
    "ilr_intact_vs_nonintact", "ilr_altered_vs_lost",
    "conoid_body_score", "apical_ring_score", "icmt_score", "bridge_score",
    "icat_abundance_score", "wb_abundance_ratio"
  )
  features <- summary[, feature_names, drop = FALSE]
  informative <- vapply(features, function(x) {
    finite <- x[is.finite(x)]
    length(finite) >= 2L && length(unique(finite)) > 1L
  }, logical(1))
  features <- features[, informative, drop = FALSE]
  if (ncol(features) < 2L) {
    stop("At least two non-constant phenotype features are required for clustering.")
  }
  if (nrow(features) < 4L) {
    stop("At least four genotypes with completed measurements are required for clustering.")
  }

  rownames(features) <- summary$genotype
  gower <- cluster::daisy(features, metric = "gower")
  hc <- hclust(as.dist(gower), method = "average")

  list(
    input_path = input_path,
    raw = raw,
    dat = dat,
    summary = summary,
    features = features,
    gower = gower,
    hc = hc
  )
}

get_hclust_display_order <- function(hc, genotype_order = fig3b_order) {
  target_order <- c(genotype_order[genotype_order %in% hc$labels], setdiff(hc$labels, genotype_order))
  target_rank <- setNames(seq_along(target_order), target_order)
  oriented_children <- vector("list", nrow(hc$merge))

  subtree_stats <- function(node) {
    if (node < 0) {
      lab <- hc$labels[-node]
      return(list(labels = lab, min_rank = target_rank[[lab]]))
    }
    children <- hc$merge[node, ]
    left <- subtree_stats(children[1])
    right <- subtree_stats(children[2])
    if (left$min_rank <= right$min_rank) {
      oriented_children[[node]] <<- children
      labs <- c(left$labels, right$labels)
    } else {
      oriented_children[[node]] <<- rev(children)
      labs <- c(right$labels, left$labels)
    }
    list(labels = labs, min_rank = min(target_rank[labs], na.rm = TRUE))
  }
  oriented <- subtree_stats(nrow(hc$merge))
  oriented$labels
}

draw_hclust_linear <- function(hc, genotype_order = fig3b_order) {
  target_order <- c(genotype_order[genotype_order %in% hc$labels], setdiff(hc$labels, genotype_order))
  target_rank <- setNames(seq_along(target_order), target_order)
  oriented_children <- vector("list", nrow(hc$merge))

  subtree_stats <- function(node) {
    if (node < 0) {
      lab <- hc$labels[-node]
      return(list(labels = lab, min_rank = target_rank[[lab]]))
    }
    children <- hc$merge[node, ]
    left <- subtree_stats(children[1])
    right <- subtree_stats(children[2])
    if (left$min_rank <= right$min_rank) {
      oriented_children[[node]] <<- children
      labs <- c(left$labels, right$labels)
    } else {
      oriented_children[[node]] <<- rev(children)
      labs <- c(right$labels, left$labels)
    }
    list(labels = labs, min_rank = min(target_rank[labs], na.rm = TRUE))
  }
  oriented <- subtree_stats(nrow(hc$merge))
  labels <- oriented$labels
  n <- length(labels)
  maxh <- max(hc$height)
  line_gp <- gpar(col = "black", lwd = 0.8, lineend = "round", linejoin = "round")
  y_pos <- setNames(seq(0.86, 0.18, length.out = n), labels)
  x_leaf <- 0.78
  x_span <- 0.54

  node_draw <- function(node) {
    if (node < 0) {
      lab <- hc$labels[-node]
      return(list(x = x_leaf, y = y_pos[[lab]], labels = lab, nleaves = 1L))
    }
    children <- oriented_children[[node]]
    left <- node_draw(children[1])
    right <- node_draw(children[2])
    node_x <- x_leaf - (hc$height[node] / maxh) * x_span
    node_y <- mean(c(left$y, right$y))

    grid.segments(
      x0 = unit(node_x, "npc"), y0 = unit(left$y, "npc"),
      x1 = unit(node_x, "npc"), y1 = unit(right$y, "npc"),
      gp = line_gp
    )
    grid.segments(
      x0 = unit(node_x, "npc"), y0 = unit(left$y, "npc"),
      x1 = unit(left$x, "npc"), y1 = unit(left$y, "npc"),
      gp = line_gp
    )
    grid.segments(
      x0 = unit(node_x, "npc"), y0 = unit(right$y, "npc"),
      x1 = unit(right$x, "npc"), y1 = unit(right$y, "npc"),
      gp = line_gp
    )
    list(
      x = node_x,
      y = node_y,
      labels = c(left$labels, right$labels),
      nleaves = left$nleaves + right$nleaves
    )
  }

  node_draw(nrow(hc$merge))
  for (lab in labels) {
    grid.text(
      display_genotype(lab), x = unit(0.90, "npc"), y = unit(y_pos[[lab]], "npc"),
      just = c("left", "center"),
      gp = gpar(fontfamily = "Arial", fontsize = 5.4, col = "black")
    )
  }

  # Compact radial scale bar.
  scale_y <- 0.03
  scale_x0 <- 0.18
  scale_x1 <- 0.40
  tick_x <- c(scale_x0, (scale_x0 + scale_x1) / 2, scale_x1)
  tick_lab <- c("0.0", "0.3", "0.6")
  grid.segments(
    x0 = unit(scale_x0, "npc"), y0 = unit(scale_y, "npc"),
    x1 = unit(scale_x1, "npc"), y1 = unit(scale_y, "npc"),
    gp = gpar(col = "black", lwd = 0.8)
  )
  for (j in seq_along(tick_x)) {
    grid.segments(
      x0 = unit(tick_x[j], "npc"), y0 = unit(scale_y, "npc"),
      x1 = unit(tick_x[j], "npc"), y1 = unit(scale_y - 0.015, "npc"),
      gp = gpar(col = "black", lwd = 0.8)
    )
    grid.text(
      tick_lab[j], x = unit(tick_x[j], "npc"), y = unit(scale_y - 0.026, "npc"),
      just = c("center", "top"),
      gp = gpar(fontfamily = "Arial", fontsize = 6.0, col = "black")
    )
  }
  invisible(data.frame(genotype = labels, y = unname(y_pos[labels]), stringsAsFactors = FALSE))
}

draw_structure_icon <- function(structure, x, y, w, h, state, base_col) {
  state_key <- if (is.na(state)) "na" else as.character(round(state))
  stroke <- switch(
    state_key,
    "0" = base_col,
    "1" = "#9A9A9A",
    "2" = "#3F3F3F",
    "na" = "#D9D9D9",
    "#9A9A9A"
  )
  fill <- switch(
    state_key,
    "0" = adjustcolor(base_col, alpha.f = 0.36),
    "1" = "#BFBFBF",
    "2" = "#4A4A4A",
    "na" = "#EEEEEE",
    "#BFBFBF"
  )
  lw <- if (state_key == "na") 0.25 else 0.35

  if (structure == "fibrils") {
    for (k in -1:1) {
      grid.segments(
        x0 = unit(x - 0.14 * w + k * 0.06 * w, "npc"),
        y0 = unit(y - 0.18 * h, "npc"),
        x1 = unit(x + 0.10 * w + k * 0.06 * w, "npc"),
        y1 = unit(y + 0.18 * h, "npc"),
        gp = gpar(col = stroke, lwd = lw, lineend = "round")
      )
    }
  } else if (structure == "conoid") {
    grid.polygon(
      x = unit(c(x - 0.18 * w, x + 0.18 * w, x + 0.10 * w, x - 0.10 * w), "npc"),
      y = unit(c(y - 0.12 * h, y - 0.12 * h, y + 0.18 * h, y + 0.18 * h), "npc"),
      gp = gpar(fill = fill, col = stroke, lwd = lw)
    )
  } else if (structure == "icmt") {
    for (k in -1:1) {
      grid.segments(
        x0 = unit(x + k * 0.06 * w, "npc"),
        y0 = unit(y - 0.16 * h, "npc"),
        x1 = unit(x + k * 0.06 * w, "npc"),
        y1 = unit(y + 0.17 * h, "npc"),
        gp = gpar(col = stroke, lwd = lw, lineend = "round")
      )
    }
  } else if (structure == "fm") {
    grid.rect(
      x = unit(x, "npc"), y = unit(y, "npc"),
      width = unit(0.34 * w, "npc"), height = unit(0.22 * h, "npc"),
      gp = gpar(fill = fill, col = stroke, lwd = lw)
    )
    grid.segments(
      x0 = unit(x - 0.14 * w, "npc"), y0 = unit(y - 0.10 * h, "npc"),
      x1 = unit(x + 0.14 * w, "npc"), y1 = unit(y + 0.10 * h, "npc"),
      gp = gpar(col = stroke, lwd = lw)
    )
    grid.segments(
      x0 = unit(x - 0.14 * w, "npc"), y0 = unit(y + 0.10 * h, "npc"),
      x1 = unit(x + 0.14 * w, "npc"), y1 = unit(y - 0.10 * h, "npc"),
      gp = gpar(col = stroke, lwd = lw)
    )
  } else if (structure == "rhoptry") {
    grid.roundrect(
      x = unit(x, "npc"), y = unit(y, "npc"),
      width = unit(0.24 * w, "npc"), height = unit(0.42 * h, "npc"),
      r = unit(0.10, "snpc"),
      gp = gpar(fill = fill, col = stroke, lwd = lw)
    )
    grid.segments(
      x0 = unit(x - 0.12 * w, "npc"), y0 = unit(y, "npc"),
      x1 = unit(x + 0.12 * w, "npc"), y1 = unit(y, "npc"),
      gp = gpar(col = stroke, lwd = lw)
    )
  }

  if (state_key == "na") {
    grid.text("·", x = unit(x, "npc"), y = unit(y, "npc"),
              gp = gpar(fontfamily = "Arial", fontsize = 5.0, col = "#9A9A9A"))
  }
}

draw_panel_B_evidence_columns <- function(summary, row_y = NULL) {
  if (is.null(row_y)) row_y <- seq(0.72, 0.20, length.out = nrow(summary))
  expr_fraction <- summary$expression_fraction
  expr_fraction[!is.finite(expr_fraction)] <- 0

  target_x <- seq(0.045, by = 0.034, length.out = 3)
  target_labels <- c("Conoid", "ICMTs", "Rhoptry")
  target_cols <- c("#93af70", "#53876d", "#a56441")

  state_x <- seq(0.215, by = 0.034, length.out = 5)
  state_labels <- c("Fibrils", "Conoid", "ICMTs", "FM", "Rhoptries")
  state_header_cols <- c("#7FA64D", "#6B8EAD", "#4E876A", "#D98A1C", "#a56441")
  state_values <- cbind(
    summary$conoid_assembly_score,
    summary$conoid_position_score,
    summary$icmt_score,
    summary$bridge_score,
    summary$rhoptry_score
  )

  loc_x0 <- 0.48
  loc_x1 <- 0.61
  expr_x0 <- 0.76
  expr_x1 <- 0.90
  cell_w <- 0.033
  cell_h <- 0.035
  bar_h <- 0.024

  grid.text("targeted\nperturbations", x = unit(mean(target_x), "npc"), y = unit(0.995, "npc"),
            just = c("center", "top"),
            gp = gpar(fontfamily = "Arial", fontsize = 6.2, col = "#111111"))
  grid.text("structural\noutcomes", x = unit(mean(state_x), "npc"), y = unit(0.995, "npc"),
            just = c("center", "top"),
            gp = gpar(fontfamily = "Arial", fontsize = 6.2, col = "#111111"))
  grid.text("ICAT apical\nretention (%)", x = unit(mean(c(loc_x0, loc_x1)), "npc"), y = unit(0.995, "npc"),
            just = c("center", "top"),
            gp = gpar(fontfamily = "Arial", fontsize = 5.4, col = "black"))
  grid.text("ICAT abundance\n(relative to WT)", x = unit(mean(c(expr_x0, expr_x1)), "npc"), y = unit(0.995, "npc"),
            just = c("center", "top"),
            gp = gpar(fontfamily = "Arial", fontsize = 5.4, col = "black"))

  for (j in seq_along(target_x)) {
    grid.text(target_labels[j], x = unit(target_x[j], "npc"), y = unit(0.825, "npc"),
              rot = 90, just = c("center", "center"),
              gp = gpar(fontfamily = "Arial", fontsize = 4.3, col = target_cols[j]))
  }
  for (j in seq_along(state_x)) {
    grid.text(state_labels[j], x = unit(state_x[j], "npc"), y = unit(0.790, "npc"),
              rot = 90, just = c("center", "center"),
              gp = gpar(fontfamily = "Arial", fontsize = 3.8, col = state_header_cols[j]))
  }

  for (i in seq_len(nrow(summary))) {
    for (j in seq_along(target_x)) {
      is_target <- target_labels[j] %in% summary$primary_targets[[i]]
      grid.rect(
        x = unit(target_x[j], "npc"), y = unit(row_y[i], "npc"),
        width = unit(cell_w, "npc"), height = unit(cell_h, "npc"),
        gp = gpar(fill = if (is_target) target_cols[j] else "#F1F1F1", col = "white", lwd = 0.45)
      )
    }

    for (j in seq_along(state_x)) {
      value <- state_values[i, j]
      grid.rect(
        x = unit(state_x[j], "npc"), y = unit(row_y[i], "npc"),
        width = unit(cell_w, "npc"), height = unit(cell_h, "npc"),
        gp = gpar(fill = "#FAFAFA", col = "#FFFFFF", lwd = 0.25)
      )
      draw_structure_icon(
        structure = c("fibrils", "conoid", "icmt", "fm", "rhoptry")[j],
        x = state_x[j], y = row_y[i], w = cell_w, h = cell_h,
        state = value, base_col = state_header_cols[j]
      )
    }

    loc_w <- loc_x1 - loc_x0
    grid.rect(x = unit(mean(c(loc_x0, loc_x1)), "npc"), y = unit(row_y[i], "npc"),
              width = unit(loc_w, "npc"), height = unit(bar_h, "npc"),
              gp = gpar(fill = "#E8E8E8", col = "#D0D0D0", lwd = 0.35))
    intact_w <- loc_w * summary$intact_prop[i]
    if (is.finite(intact_w) && intact_w > 0) {
      grid.rect(x = unit(loc_x0 + intact_w / 2, "npc"), y = unit(row_y[i], "npc"),
                width = unit(intact_w, "npc"), height = unit(bar_h, "npc"),
                gp = gpar(fill = "#8e8e8e", col = NA))
    }

    expr_w <- expr_x1 - expr_x0
    grid.rect(x = unit(mean(c(expr_x0, expr_x1)), "npc"), y = unit(row_y[i], "npc"),
              width = unit(expr_w, "npc"), height = unit(bar_h, "npc"),
              gp = gpar(fill = "#E8E8E8", col = NA))
    if (is.finite(expr_fraction[i]) && expr_fraction[i] > 0) {
      grid.rect(x = unit(expr_x0 + expr_w * expr_fraction[i] / 2, "npc"),
                y = unit(row_y[i], "npc"),
                width = unit(expr_w * expr_fraction[i], "npc"), height = unit(bar_h, "npc"),
                gp = gpar(fill = "#e26ae5", col = NA))
    }
  }

  legend_x <- c(0.18, 0.28, 0.38, 0.48)
  legend_lab <- c("intact", "altered", "lost", "ND")
  legend_fill <- c("#D8D8D8", "#8A8A8A", "#2E2E2E", "#E4E4E4")
  for (j in seq_along(legend_x)) {
    grid.rect(x = unit(legend_x[j], "npc"), y = unit(0.010, "npc"),
              width = unit(0.014, "npc"), height = unit(0.014, "npc"),
              gp = gpar(fill = legend_fill[j], col = "#BDBDBD", lwd = 0.25))
    grid.text(legend_lab[j], x = unit(legend_x[j] + 0.010, "npc"), y = unit(0.010, "npc"),
              just = c("left", "center"),
              gp = gpar(fontfamily = "Arial", fontsize = 3.4, col = "#555555"))
  }
}

draw_panel_B_summary <- function(summary, hc, genotype_order = fig3b_order) {
  display_order <- genotype_order[genotype_order %in% summary$genotype]
  summary <- summary[match(display_order, summary$genotype), , drop = FALSE]
  if (anyNA(summary$genotype)) {
    stop("Some genotypes in genotype_order are missing from summary.")
  }
  if (!identical(summary$genotype, display_order)) {
    stop("Right-side genotype rows are not aligned with the dendrogram leaves.")
  }

  pushViewport(viewport(xscale = c(0, 1), yscale = c(0, 1)))
  grid.rect(gp = gpar(col = NA, fill = "white"))
  grid.text("B", x = unit(0.02, "npc"), y = unit(0.98, "npc"),
            just = c("left", "top"), gp = gpar(fontfamily = "Arial", fontsize = 18, fontface = "bold"))

  grid.text("genotype", x = unit(0.11, "npc"), y = unit(0.86, "npc"),
            gp = gpar(fontfamily = "Arial", fontsize = 7.2, col = "black"))
  tree_x <- 0.03
  tree_y <- 0.23
  tree_w <- 0.32
  tree_h <- 0.32
  pushViewport(viewport(
    x = unit(tree_x, "npc"), y = unit(tree_y, "npc"),
    width = unit(tree_w, "npc"), height = unit(tree_h, "npc"),
    just = c("left", "bottom")
  ))
  draw_hclust_linear(hc, genotype_order = genotype_order)
  popViewport()

  right_x <- 0.40
  right_y <- 0.08
  right_w <- 0.49
  right_h <- 0.82
  row_y <- seq(0.72, 0.20, length.out = nrow(summary))

  right_vp <- viewport(
    x = unit(right_x, "npc"), y = unit(right_y, "npc"),
    width = unit(right_w, "npc"), height = unit(right_h, "npc"),
    just = c("left", "bottom")
  )
  pushViewport(right_vp)
  draw_panel_B_evidence_columns(summary, row_y = row_y)
  popViewport()

  popViewport()
}

draw_panel_B_tree_only <- function(hc, genotype_order = fig3b_order) {
  pushViewport(viewport(xscale = c(0, 1), yscale = c(0, 1)))
  grid.rect(gp = gpar(col = NA, fill = "white"))
  grid.text("genotype", x = unit(0.53, "npc"), y = unit(0.98, "npc"),
            gp = gpar(fontfamily = "Arial", fontsize = 8, col = "black"))
  pushViewport(viewport(
    x = unit(0.02, "npc"), y = unit(0.08, "npc"),
    width = unit(0.83, "npc"), height = unit(0.84, "npc"),
    just = c("left", "bottom")
  ))
  draw_hclust_linear(hc, genotype_order = genotype_order)
  popViewport()
  popViewport()
}

draw_panel_B_right_only <- function(summary, genotype_order = fig3b_order) {
  summary <- summary[match(genotype_order, summary$genotype), , drop = FALSE]
  if (anyNA(summary$genotype)) {
    stop("Some genotypes in genotype_order are missing from summary.")
  }
  if (!identical(summary$genotype, genotype_order)) {
    stop("Right-side genotype rows are not in the requested dendrogram order.")
  }

  pushViewport(viewport(xscale = c(0, 1), yscale = c(0, 1)))
  grid.rect(gp = gpar(col = NA, fill = "white"))
  draw_panel_B_evidence_columns(summary)
  popViewport()
}

save_grid_panel <- function(draw_fun, pdf_path, png_path, width_cm, height_cm, dpi = 600) {
  dir.create(dirname(pdf_path), recursive = TRUE, showWarnings = FALSE)
  dir.create(dirname(png_path), recursive = TRUE, showWarnings = FALSE)

  grDevices::cairo_pdf(pdf_path, width = width_cm / 2.54, height = height_cm / 2.54)
  grid.newpage()
  pushViewport(viewport(width = unit(width_cm, "cm"), height = unit(height_cm, "cm")))
  draw_fun()
  popViewport()
  dev.off()

  if (requireNamespace("ragg", quietly = TRUE)) {
    ragg::agg_png(png_path, width = width_cm / 2.54, height = height_cm / 2.54,
                  units = "in", res = dpi, background = "white")
    grid.newpage()
    pushViewport(viewport(width = unit(width_cm, "cm"), height = unit(height_cm, "cm")))
    draw_fun()
    popViewport()
    dev.off()
  } else {
    grDevices::png(png_path, width = width_cm / 2.54, height = height_cm / 2.54,
                   units = "in", res = dpi, type = "cairo-png", bg = "white")
    grid.newpage()
    pushViewport(viewport(width = unit(width_cm, "cm"), height = unit(height_cm, "cm")))
    draw_fun()
    popViewport()
    dev.off()
  }
}

save_fig3b_component_panels <- function(fig3b,
                                        results_dir = fig3b_results_dir,
                                        width_cm = 10.5,
                                        height_cm = 8.0,
                                        dpi = 600) {
  dir.create(results_dir, recursive = TRUE, showWarnings = FALSE)

  save_grid_panel(
    draw_fun = function() draw_panel_B_tree_only(fig3b$hc, genotype_order = fig3b_display_order),
    pdf_path = file.path(results_dir, "Fig3B_tree_only.pdf"),
    png_path = file.path(results_dir, "Fig3B_tree_only.png"),
    width_cm = 4.9,
    height_cm = height_cm,
    dpi = dpi
  )

  save_grid_panel(
    draw_fun = function() draw_panel_B_right_only(fig3b$summary, genotype_order = fig3b_display_order),
    pdf_path = file.path(results_dir, "Fig3B_right_summary_only.pdf"),
    png_path = file.path(results_dir, "Fig3B_right_summary_only.png"),
    width_cm = 6.2,
    height_cm = height_cm,
    dpi = dpi
  )
}

build_fig3b_figure <- function(input_path = NULL) {
  fig3b_data <- load_fig3b_input(input_path)
  list(
    data = fig3b_data,
    summary = fig3b_data$summary,
    hc = fig3b_data$hc
  )
}

save_fig3b_panel <- function(input_path = NULL,
                             output_prefix = file.path(fig_dir, "04_results", "Fig3B_icat_localization_panel"),
                             width_cm = 10.5,
                             height_cm = 8.0,
                             dpi = 600) {
  fig3b <- build_fig3b_figure(input_path)
  save_fig3b_component_panels(fig3b, results_dir = fig3b_results_dir, height_cm = height_cm, dpi = dpi)

  pdf_path <- paste0(output_prefix, ".pdf")
  png_path <- paste0(output_prefix, ".png")

  save_grid_panel(
    draw_fun = function() draw_panel_B_summary(fig3b$summary, fig3b$hc, genotype_order = fig3b_display_order),
    pdf_path = pdf_path,
    png_path = png_path,
    width_cm = width_cm,
    height_cm = height_cm,
    dpi = dpi
  )

  invisible(fig3b)
}

if (sys.nframe() == 0L) {
  args <- commandArgs(trailingOnly = TRUE)
  get_arg <- function(prefix, default) {
    hit <- grep(paste0("^", prefix, "="), args, value = TRUE)
    if (length(hit) > 1L) stop("Provide at most one ", prefix, " argument.")
    if (length(hit)) sub(paste0("^", prefix, "="), "", hit[[1]]) else default
  }

  input_path <- get_arg("--input", NULL)
  output_prefix <- get_arg("--output", file.path(fig_dir, "04_results", "Fig3B_icat_localization_panel"))
  save_fig3b_panel(input_path = input_path, output_prefix = output_prefix)
  cat("Fig3B panel written to:", normalizePath(dirname(output_prefix)), "\n")
}
