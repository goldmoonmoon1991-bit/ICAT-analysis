#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(cluster)
  library(ggplot2)
  library(ggrepel)
})

args <- commandArgs(trailingOnly = TRUE)
get_arg <- function(prefix, default) {
  hit <- grep(paste0("^", prefix, "="), args, value = TRUE)
  if (length(hit) > 1L) stop("Provide at most one ", prefix, " argument.")
  if (length(hit)) sub(paste0("^", prefix, "="), "", hit[[1]]) else default
}

script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
script_path <- normalizePath(sub("^--file=", "", script_arg[[1]]), mustWork = TRUE)
fig_dir <- if (exists("FIG3_BASE_DIR", inherits = TRUE)) {
  normalizePath(get("FIG3_BASE_DIR", inherits = TRUE), mustWork = TRUE)
} else {
  normalizePath(file.path(dirname(script_path), "..", ".."), mustWork = TRUE)
}
find_project_root <- function(start_dir) {
  current <- normalizePath(start_dir, mustWork = TRUE)
  repeat {
    if (file.exists(file.path(current, "shared", "R", "plot_style.R"))) return(current)
    parent <- dirname(current)
    if (identical(parent, current)) stop("Could not locate project root from: ", start_dir)
    current <- parent
  }
}
project_root <- find_project_root(dirname(script_path))
source(file.path(project_root, "shared", "R", "plot_style.R"))
default_input <- file.path(fig_dir, "01_raw_data", "localization_perturbation", "ICAT_localization_pertubation.xlsx")
if (!file.exists(default_input)) {
  default_input <- file.path(fig_dir, "01_raw_data", "localization_perturbation", "ICAT_localization_pertubation.csv")
}
input_path <- normalizePath(get_arg("--input", default_input), mustWork = TRUE)
output_root <- get_arg(
  "--output",
  file.path(fig_dir, "04_results")
)
figure_dir <- file.path(output_root, "figures", "localization_perturbation")
table_dir <- file.path(output_root, "tables", "localization_perturbation")
report_dir <- file.path(output_root, "reports", "localization_perturbation")
for (path in c(figure_dir, table_dir, report_dir)) {
  dir.create(path, recursive = TRUE, showWarnings = FALSE)
}

required <- c(
  "biological_replicate", "genotype", "primary_perturbation_target", "target_module",
  "total_cells", "intact_n", "altered_n", "lost_n", "unscorable_n",
  "expected_icat_effect", "conoid_body_status", "apical_ring_status",
  "icmt_status", "bridge_status", "icat_total_signal_status",
  "wb_abundance_ratio"
)

if (grepl("\\.xlsx$", input_path, ignore.case = TRUE)) {
  if (!requireNamespace("readxl", quietly = TRUE)) {
    stop("The readxl package is required to read .xlsx input files.")
  }
  raw <- as.data.frame(
    readxl::read_excel(input_path, sheet = "Data", na = c("", "NA")),
    check.names = FALSE, stringsAsFactors = FALSE
  )
} else {
  raw <- read.csv(input_path, check.names = FALSE, stringsAsFactors = FALSE)
}
apical_col <- if ("apical_polar_ring_status" %in% names(raw)) {
  "apical_polar_ring_status"
} else if ("apical_ring_status" %in% names(raw)) {
  "apical_ring_status"
} else {
  NA_character_
}
missing_columns <- setdiff(required, names(raw))
missing_columns <- setdiff(missing_columns, c("apical_ring_status", "apical_polar_ring_status"))
if (length(missing_columns)) {
  stop("Input is missing required columns: ", paste(missing_columns, collapse = ", "))
}
if (is.na(apical_col)) stop("Input is missing required column: apical_polar_ring_status")

completed <- !is.na(raw$total_cells) & nzchar(trimws(as.character(raw$total_cells)))
dat <- raw[completed, , drop = FALSE]
if (!nrow(dat)) {
  stop(
    "No completed rows were found. Fill total_cells, intact_n, altered_n, lost_n ",
    "and unscorable_n before running the analysis."
  )
}

count_columns <- c("total_cells", "intact_n", "altered_n", "lost_n", "unscorable_n")
for (column in count_columns) dat[[column]] <- as.numeric(dat[[column]])
if (any(!is.finite(as.matrix(dat[count_columns])))) {
  stop("All count columns must be numeric for completed rows.")
}
if (any(as.matrix(dat[count_columns]) < 0) ||
    any(abs(as.matrix(dat[count_columns]) - round(as.matrix(dat[count_columns]))) > 1e-8)) {
  stop("Cell counts must be non-negative integers.")
}

count_sum <- dat$intact_n + dat$altered_n + dat$lost_n + dat$unscorable_n
bad_sum <- which(dat$total_cells != count_sum)
if (length(bad_sum)) {
  warning(
    "Count mismatch in rows: ",
    paste(which(completed)[bad_sum] + 1L, collapse = ", "),
    ". Proceeding with the provided counts."
  )
}

dat$scored_cells <- dat$intact_n + dat$altered_n + dat$lost_n
if (any(dat$scored_cells <= 0)) stop("Each completed row must contain at least one scorable cell.")
dat$intact_prop <- dat$intact_n / dat$scored_cells
dat$altered_prop <- dat$altered_n / dat$scored_cells
dat$lost_prop <- dat$lost_n / dat$scored_cells
dat$unscorable_prop <- dat$unscorable_n / dat$total_cells

status_score <- function(x, type = "structure") {
  x <- tolower(trimws(as.character(x)))
  if (type == "abundance") {
    map <- c(normal = 0, reduced = 1, lost = 2, nd = NA_real_)
  } else {
    map <- c(intact = 0, altered = 1, lost = 2, nd = NA_real_)
  }
  out <- unname(map[x])
  out[x == ""] <- NA_real_
  out
}

dat$conoid_body_score <- status_score(dat$conoid_body_status)
dat$apical_ring_score <- status_score(dat[[apical_col]])
dat$icmt_score <- status_score(dat$icmt_status)
dat$bridge_score <- status_score(dat$bridge_status)
dat$icat_abundance_score <- status_score(dat$icat_total_signal_status, "abundance")
dat$wb_abundance_ratio <- suppressWarnings(as.numeric(dat$wb_abundance_ratio))

mean_or_na <- function(x) if (all(is.na(x))) NA_real_ else mean(x, na.rm = TRUE)
first_nonblank <- function(x) {
  x <- x[!is.na(x) & nzchar(trimws(as.character(x)))]
  if (length(x)) as.character(x[[1]]) else NA_character_
}
display_genotype <- function(x) {
  x <- gsub("CIP3KO/CF1KD", "CIP3/CF1", x, fixed = TRUE)
  x <- gsub("_KO_CF1_KD$", "/CF1", x)
  x <- gsub("_(KO|KD)$", "", x)
  x <- gsub("(KO|KD)$", "", x)
  gsub("_", " ", x)
}
pcoa_plot_label <- function(x) {
  out <- display_genotype(x)
  out[out == "CF5"] <- "CF5^{KO}"
  out[out == "ARO"] <- "ARO^{KD}"
  out[out == "ICMAP1"] <- "ICMAP1^{KD}"
  out[out == "ICMAP2"] <- "ICMAP2^{KD}"
  out[out == "CIP3"] <- "CIP3^{KO}"
  out[out == "RNG2"] <- "RNG2^{KD}"
  out[out == "AC9"] <- "AC9^{KD}"
  out[out == "CIP3/CF1"] <- "CIP3^{KD}*'/'*CF1^{KO}"
  out
}
make_group_enclosures <- function(df, group_col, x_col, y_col, level = 0.68) {
  groups <- split(df, df[[group_col]])
  x_span <- max(diff(range(df[[x_col]], finite = TRUE)), 1e-8)
  y_span <- max(diff(range(df[[y_col]], finite = TRUE)), 1e-8)
  pad <- 0.050 * max(x_span, y_span)
  theta <- seq(0, 2 * pi, length.out = 121)

  pieces <- lapply(names(groups), function(group_name) {
    z <- groups[[group_name]]
    x <- z[[x_col]]
    y <- z[[y_col]]
    center <- c(mean(x), mean(y))

    if (nrow(z) >= 3L) {
      cov_xy <- cov(cbind(x, y))
      if (any(!is.finite(cov_xy)) || det(cov_xy) <= 1e-12) {
        rx <- max(sd(x), pad)
        ry <- max(sd(y), pad)
        coords <- cbind(center[1] + rx * cos(theta), center[2] + ry * sin(theta))
      } else {
        circle <- rbind(cos(theta), sin(theta))
        coords <- t(center + sqrt(qchisq(level, df = 2)) * chol(cov_xy) %*% circle)
      }
    } else if (nrow(z) == 2L) {
      dx <- diff(x)
      dy <- diff(y)
      angle <- atan2(dy, dx)
      half_len <- sqrt(dx^2 + dy^2) / 2 + pad * 0.65
      half_wid <- pad * 0.52
      local_x <- half_len * cos(theta)
      local_y <- half_wid * sin(theta)
      coords <- cbind(
        center[1] + local_x * cos(angle) - local_y * sin(angle),
        center[2] + local_x * sin(angle) + local_y * cos(angle)
      )
    } else {
      rx <- pad
      ry <- pad * y_span / max(x_span, 1e-8)
      coords <- cbind(center[1] + rx * cos(theta), center[2] + ry * sin(theta))
    }

    data.frame(
      group = group_name,
      enclosure_type = if (nrow(z) >= 3L) "ellipse" else "low_n",
      x = coords[, 1],
      y = coords[, 2],
      stringsAsFactors = FALSE
    )
  })
  do.call(rbind, pieces)
}

pieces <- split(dat, dat$genotype)
summary_rows <- lapply(pieces, function(z) {
  data.frame(
    genotype = z$genotype[[1]],
    primary_perturbation_target = first_nonblank(z$primary_perturbation_target),
    target_module = first_nonblank(z$target_module),
    expected_icat_effect = first_nonblank(z$expected_icat_effect),
    n_biological_replicates = length(unique(z$biological_replicate)),
    total_scored_cells = sum(z$scored_cells),
    intact_prop = mean(z$intact_prop),
    altered_prop = mean(z$altered_prop),
    lost_prop = mean(z$lost_prop),
    unscorable_prop = mean(z$unscorable_prop),
    conoid_body_score = mean_or_na(z$conoid_body_score),
    apical_ring_score = mean_or_na(z$apical_ring_score),
    icmt_score = mean_or_na(z$icmt_score),
    bridge_score = mean_or_na(z$bridge_score),
    icat_abundance_score = mean_or_na(z$icat_abundance_score),
    wb_abundance_ratio = mean_or_na(z$wb_abundance_ratio),
    stringsAsFactors = FALSE
  )
})
summary <- do.call(rbind, summary_rows)
rownames(summary) <- NULL

dominant_labels <- c("intact", "altered", "lost")
summary$dominant_icat_outcome <- apply(
  summary[, c("intact_prop", "altered_prop", "lost_prop")],
  1,
  function(x) {
    hits <- which(abs(x - max(x)) < 1e-10)
    if (length(hits) == 1L) dominant_labels[hits] else "mixed"
  }
)

# Two independent ILR coordinates preserve the three-part localization
# composition without placing three linearly dependent proportions in Gower space.
pseudocount <- 0.005
composition <- as.matrix(summary[, c("intact_prop", "altered_prop", "lost_prop")]) + pseudocount
composition <- composition / rowSums(composition)
summary$ilr_intact_vs_nonintact <- sqrt(2 / 3) * log(
  composition[, 1] / sqrt(composition[, 2] * composition[, 3])
)
summary$ilr_altered_vs_lost <- sqrt(1 / 2) * log(composition[, 2] / composition[, 3])

feature_names <- c(
  "ilr_intact_vs_nonintact", "ilr_altered_vs_lost",
  "conoid_body_score", "apical_ring_score", "icmt_score", "bridge_score",
  "icat_abundance_score", "wb_abundance_ratio"
)
features <- summary[, feature_names, drop = FALSE]
informative <- vapply(features, function(x) {
  finite <- x[is.finite(x)]
  length(finite) >= 2L && length(unique(finite)) > 1L
}, logical(1))
features <- features[, informative, drop = FALSE]
if (ncol(features) < 2L) {
  stop("At least two non-constant phenotype features are required for clustering.")
}
if (nrow(features) < 4L) {
  stop("At least four genotypes with completed measurements are required for clustering.")
}

rownames(features) <- summary$genotype
gower <- daisy(features, metric = "gower")
hc <- hclust(as.dist(gower), method = "average")
pcoa <- cmdscale(as.dist(gower), k = 2, eig = TRUE, add = TRUE)
pcoa_data <- data.frame(
  genotype = summary$genotype,
  PCoA1 = pcoa$points[, 1],
  PCoA2 = pcoa$points[, 2],
  target_module = summary$target_module,
  dominant_icat_outcome = summary$dominant_icat_outcome,
  stringsAsFactors = FALSE
)
pcoa_data$display_genotype <- display_genotype(pcoa_data$genotype)
pcoa_data$plot_label <- pcoa_plot_label(pcoa_data$genotype)

variance <- pmax(pcoa$eig, 0)
variance_percent <- 100 * variance / sum(variance)
outcome_colors <- c(
  intact = "#111111", altered = "#2F79B7", lost = "#D7301F", mixed = "#6A6A6A"
)
module_shapes <- c(
  control = 21, global_conoid = 22, icmt_associated = 23,
  bridge_inner_surface = 24, bridge_complex = 25, other = 21
)
missing_modules <- setdiff(unique(pcoa_data$target_module), names(module_shapes))
if (length(missing_modules)) module_shapes[missing_modules] <- 21
module_labels <- c(
  control = "control", global_conoid = "global conoid",
  icmt_associated = "ICMT", bridge_inner_surface = "bridge-inner",
  bridge_complex = "bridge", other = "other"
)
missing_module_labels <- setdiff(unique(pcoa_data$target_module), names(module_labels))
if (length(missing_module_labels)) module_labels[missing_module_labels] <- missing_module_labels
pcoa_enclosures <- make_group_enclosures(
  pcoa_data,
  group_col = "dominant_icat_outcome",
  x_col = "PCoA1",
  y_col = "PCoA2"
)

feature_sources <- c(
  ilr_intact_vs_nonintact = "Excel counts: intact_n, altered_n, lost_n",
  ilr_altered_vs_lost = "Excel counts: intact_n, altered_n, lost_n",
  conoid_body_score = "conoid_body_status",
  apical_ring_score = "apical_polar_ring_status/apical_ring_status",
  icmt_score = "icmt_status",
  bridge_score = "bridge_status",
  icat_abundance_score = "icat_total_signal_status",
  wb_abundance_ratio = "wb_abundance_ratio"
)
feature_descriptions <- c(
  ilr_intact_vs_nonintact = "ICAT apical retention versus altered/lost localization",
  ilr_altered_vs_lost = "Altered versus lost ICAT localization among non-intact cells",
  conoid_body_score = "Conoid body structural severity",
  apical_ring_score = "Conoid/apical position structural severity",
  icmt_score = "ICMT structural severity",
  bridge_score = "Fibrous material/bridge structural severity",
  icat_abundance_score = "IF-based ICAT abundance severity",
  wb_abundance_ratio = "Western blot ICAT abundance relative to WT"
)
coords <- pcoa$points[, 1:2, drop = FALSE]
colnames(coords) <- c("PCoA1", "PCoA2")
pcoa_feature_contribution <- do.call(rbind, lapply(names(features), function(feature_name) {
  values <- features[[feature_name]]
  ok <- is.finite(values)
  r1 <- suppressWarnings(cor(values[ok], coords[ok, "PCoA1"], method = "spearman"))
  r2 <- suppressWarnings(cor(values[ok], coords[ok, "PCoA2"], method = "spearman"))
  data.frame(
    feature = feature_name,
    excel_source = unname(feature_sources[feature_name]),
    interpretation = unname(feature_descriptions[feature_name]),
    spearman_r_PCoA1 = r1,
    spearman_r_PCoA2 = r2,
    abs_r_PCoA1 = abs(r1),
    abs_r_PCoA2 = abs(r2),
    stringsAsFactors = FALSE
  )
}))
pcoa_feature_contribution$PCoA1_percent <- 100 *
  pcoa_feature_contribution$abs_r_PCoA1 / sum(pcoa_feature_contribution$abs_r_PCoA1)
pcoa_feature_contribution$PCoA2_percent <- 100 *
  pcoa_feature_contribution$abs_r_PCoA2 / sum(pcoa_feature_contribution$abs_r_PCoA2)
pcoa_feature_contribution$combined_strength <- sqrt(
  pcoa_feature_contribution$abs_r_PCoA1^2 +
    pcoa_feature_contribution$abs_r_PCoA2^2
)
pcoa_feature_contribution$combined_percent <- 100 *
  pcoa_feature_contribution$combined_strength / sum(pcoa_feature_contribution$combined_strength)
pcoa_feature_contribution <- pcoa_feature_contribution[
  order(-pcoa_feature_contribution$combined_percent),
  c(
    "feature", "excel_source", "interpretation",
    "spearman_r_PCoA1", "spearman_r_PCoA2",
    "PCoA1_percent", "PCoA2_percent", "combined_percent"
  )
]

# Display-only jitter and orthogonal leader lines for the PCoA panel.
# The original PCoA coordinates are retained in PCoA1/PCoA2 and in the output table;
# PCoA1_plot/PCoA2_plot are used only to reduce visual overlap in the figure.
set.seed(20260711)
x_span <- max(diff(range(pcoa_data$PCoA1, finite = TRUE)), 1e-8)
y_span <- max(diff(range(pcoa_data$PCoA2, finite = TRUE)), 1e-8)

pcoa_data$PCoA1_plot <- pcoa_data$PCoA1
pcoa_data$PCoA2_plot <- pcoa_data$PCoA2

# Mild jitter for all points, stronger vertical jitter for the dense black cluster.
pcoa_data$PCoA1_plot <- pcoa_data$PCoA1 + runif(nrow(pcoa_data), -0.006 * x_span, 0.006 * x_span)
pcoa_data$PCoA2_plot <- pcoa_data$PCoA2 + runif(nrow(pcoa_data), -0.018 * y_span, 0.018 * y_span)

dense_black <- pcoa_data$dominant_icat_outcome == "intact"
if (sum(dense_black) > 1L) {
  pcoa_data$PCoA1_plot[dense_black] <- pcoa_data$PCoA1[dense_black] +
    runif(sum(dense_black), -0.014 * x_span, 0.014 * x_span)
  pcoa_data$PCoA2_plot[dense_black] <- pcoa_data$PCoA2[dense_black] +
    runif(sum(dense_black), -0.060 * y_span, 0.060 * y_span)
}

# Recompute group enclosures using displayed coordinates so ellipses still wrap the points.
pcoa_enclosures_plot <- make_group_enclosures(
  pcoa_data,
  group_col = "dominant_icat_outcome",
  x_col = "PCoA1_plot",
  y_col = "PCoA2_plot"
)

# Put labels to the left/right side of each outcome cluster.
# With direction = "x", ggrepel only moves labels horizontally, so leader lines stay horizontal.
pcoa_data$label_side <- rep(1, nrow(pcoa_data))
for (idx in split(seq_len(nrow(pcoa_data)), pcoa_data$dominant_icat_outcome)) {
  center_x <- mean(pcoa_data$PCoA1_plot[idx], na.rm = TRUE)
  pcoa_data$label_side[idx] <- ifelse(pcoa_data$PCoA1_plot[idx] >= center_x, 1, -1)
}
pcoa_data$label_nudge_x <- pcoa_data$label_side * 0.105 * x_span

p_2d <- ggplot(pcoa_data, aes(PCoA1_plot, PCoA2_plot)) +
  geom_polygon(
    data = pcoa_enclosures_plot,
    aes(x = x, y = y, fill = group, group = group),
    inherit.aes = FALSE,
    alpha = 0.040, color = NA,
    show.legend = FALSE
  ) +
  geom_path(
    data = pcoa_enclosures_plot,
    aes(x = x, y = y, color = group, group = group),
    inherit.aes = FALSE,
    linewidth = 0.22, alpha = 0.55,
    show.legend = FALSE
  ) +
  geom_point(
    aes(color = dominant_icat_outcome),
    size = 1.55,
    stroke = 0,
    alpha = 0.95,
    show.legend = FALSE
  ) +
  geom_label_repel(
    aes(
      label = plot_label,
      color = dominant_icat_outcome
    ),
    nudge_x = pcoa_data$label_nudge_x,
    nudge_y = 0,
    direction = "x",
    fill = "white",
    linewidth = 0.14,
    label.r = unit(0.040, "lines"),
    label.padding = unit(0.030, "lines"),
    size = ICAT_TEXT_SMALL_MM * 0.88,
    parse = TRUE,
    box.padding = unit(0.16, "lines"),
    point.padding = unit(0.10, "lines"),
    min.segment.length = unit(0, "lines"),
    segment.color = "#8C8C8C",
    segment.size = 0.10,
    segment.alpha = 0.85,
    segment.curvature = 0,
    force = 12,
    force_pull = 0.04,
    max.overlaps = Inf,
    max.iter = 100000,
    max.time = 3,
    seed = 20260711,
    show.legend = FALSE
  ) +
  scale_color_manual(values = outcome_colors, drop = FALSE) +
  scale_fill_manual(values = outcome_colors, drop = FALSE) +
  scale_x_continuous(expand = expansion(mult = c(0.32, 0.32))) +
  scale_y_continuous(expand = expansion(mult = c(0.30, 0.30))) +
  coord_cartesian(clip = "off") +
  labs(
    title = NULL,
    subtitle = NULL,
    x = paste0("PCoA1 (", round(variance_percent[1], 1), "% variance)"),
    y = paste0("PCoA2 (", round(variance_percent[2], 1), "% variance)"),
    color = "Dominant ICAT outcome"
  ) +
  icat_theme_classic() +
  theme(
    axis.title = element_text(size = 7),
    axis.text = element_text(size = 7, color = "black"),
    axis.line = element_line(linewidth = 0.25, color = "black"),
    axis.ticks = element_line(linewidth = 0.25, color = "black"),
    legend.position = "none",
    plot.margin = margin(4, 12, 4, 12)
  )

stacked <- summary[, c("genotype", "intact_prop", "altered_prop", "lost_prop")]
stacked_long <- rbind(
  data.frame(genotype = stacked$genotype, outcome = "intact", proportion = stacked$intact_prop),
  data.frame(genotype = stacked$genotype, outcome = "altered", proportion = stacked$altered_prop),
  data.frame(genotype = stacked$genotype, outcome = "lost", proportion = stacked$lost_prop)
)
stacked_long$genotype <- factor(stacked_long$genotype, levels = hc$labels[hc$order])
stacked_long$outcome <- factor(stacked_long$outcome, levels = c("lost", "altered", "intact"))

p_stacked <- ggplot(stacked_long, aes(genotype, proportion, fill = outcome)) +
  geom_col(width = 0.72, color = "white", linewidth = 0.35) +
  scale_fill_manual(values = outcome_colors[c("lost", "altered", "intact")]) +
  scale_x_discrete(labels = display_genotype) +
  scale_y_continuous(labels = function(x) paste0(round(100 * x), "%"), expand = c(0, 0)) +
  labs(
    title = "ICAT localization outcomes",
    subtitle = "Genotypes ordered by the Gower dendrogram",
    x = NULL, y = "Mean cell fraction", fill = NULL
  ) +
  icat_theme_classic() +
  theme(
    plot.title = element_text(face = "bold"),
    axis.text.x = element_text(angle = 40, hjust = 1, size = ICAT_FONT_SMALL_PT),
    axis.title.y = element_text(size = ICAT_FONT_BODY_PT),
    legend.position = "top"
  )

ratio_rows <- lapply(split(dat, dat$genotype), function(z) {
  values <- z$intact_prop
  n_rep <- length(values)
  mean_value <- mean(values)
  if (n_rep >= 2L) {
    half_width <- qt(0.975, df = n_rep - 1L) * sd(values) / sqrt(n_rep)
  } else {
    half_width <- NA_real_
  }
  data.frame(
    genotype = z$genotype[[1]], n_biological_replicates = n_rep,
    intact_ratio_mean = mean_value,
    ci_low = ifelse(is.na(half_width), NA_real_, max(0, mean_value - half_width)),
    ci_high = ifelse(is.na(half_width), NA_real_, min(1, mean_value + half_width)),
    stringsAsFactors = FALSE
  )
})
ratio_summary <- do.call(rbind, ratio_rows)
rownames(ratio_summary) <- NULL
genotype_order <- hc$labels[hc$order]
dat$genotype_plot <- factor(dat$genotype, levels = rev(genotype_order))
ratio_summary$genotype_plot <- factor(
  ratio_summary$genotype, levels = rev(genotype_order)
)

p_ratio <- ggplot() +
  geom_errorbar(
    data = ratio_summary,
    aes(y = genotype_plot, xmin = ci_low, xmax = ci_high),
    width = 0, linewidth = ICAT_LINE_MM, color = "#4B4B4B",
    orientation = "y", na.rm = TRUE
  ) +
  geom_point(
    data = dat,
    aes(x = intact_prop, y = genotype_plot),
    shape = 21, size = 2.0, stroke = 0.45,
    fill = "white", color = "#5B9F63",
    position = position_jitter(height = 0.08, width = 0, seed = 17)
  ) +
  geom_point(
    data = ratio_summary,
    aes(x = intact_ratio_mean, y = genotype_plot),
    shape = 18, size = 2.8, color = "#5B9F63"
  ) +
  scale_x_continuous(
    limits = c(0, 1), breaks = seq(0, 1, 0.25),
    labels = function(x) paste0(round(100 * x), "%"),
    expand = expansion(mult = c(0.01, 0.03))
  ) +
  scale_y_discrete(labels = display_genotype) +
  labs(
    title = "Intact ICAT localization ratio",
    subtitle = "Biological replicates; mean ± 95% CI",
    x = "Cells with intact ICAT localization", y = NULL
  ) +
  icat_theme_classic() +
  theme(
    plot.title = element_text(face = "bold"),
    plot.subtitle = element_text(size = ICAT_FONT_SMALL_PT),
    axis.text.y = element_text(size = ICAT_FONT_SMALL_PT),
    axis.text.x = element_text(size = ICAT_FONT_SMALL_PT),
    plot.margin = margin(6, 8, 6, 6)
  )

severity_columns <- c(
  conoid_body_score = "Conoid body", apical_ring_score = "Apical ring",
  icmt_score = "ICMT", bridge_score = "Bridge",
  icat_abundance_score = "ICAT abundance"
)
heatmap_rows <- list()
for (column in names(severity_columns)) {
  heatmap_rows[[length(heatmap_rows) + 1L]] <- data.frame(
    genotype = summary$genotype,
    feature = severity_columns[[column]],
    severity = summary[[column]],
    stringsAsFactors = FALSE
  )
}
heatmap_data <- do.call(rbind, heatmap_rows)
heatmap_data$genotype <- factor(heatmap_data$genotype, levels = hc$labels[hc$order])
heatmap_data$feature <- factor(heatmap_data$feature, levels = rev(unname(severity_columns)))

p_heatmap <- ggplot(heatmap_data, aes(genotype, feature, fill = severity)) +
  geom_tile(color = "white", linewidth = 0.7) +
  geom_text(
    aes(label = ifelse(is.na(severity), "ND", sprintf("%.1f", severity))),
    size = ICAT_TEXT_BODY_MM
  ) +
  scale_fill_gradient2(
    low = "#E6E6E6", mid = "#D8C95A", high = "#E6613F",
    midpoint = 1, limits = c(0, 2), na.value = "#FFFFFF",
    breaks = c(0, 1, 2), labels = c("intact", "altered", "lost")
  ) +
  scale_x_discrete(labels = display_genotype) +
  labs(
    title = "Structural dependency matrix",
    subtitle = "Mean structural severity; Gower order",
    x = NULL, y = NULL, fill = "Mean severity"
  ) +
  icat_theme_classic() +
  theme(
    plot.title = element_text(face = "bold"),
    axis.text.x = element_text(angle = 40, hjust = 1, size = ICAT_FONT_SMALL_PT),
    axis.text.y = element_text(size = ICAT_FONT_SMALL_PT),
    axis.ticks = element_blank(),
    legend.position = "bottom",
    legend.title = element_text(size = ICAT_FONT_BODY_PT),
    legend.text = element_text(size = ICAT_FONT_SMALL_PT)
  ) +
  guides(fill = guide_colorbar(
    direction = "horizontal", title.position = "top",
    barwidth = unit(4.2, "cm"), barheight = unit(0.28, "cm")
  ))

ggsave(file.path(figure_dir, "Fig3B_2D_Gower_PCoA.pdf"), p_2d,
       width = 8.5 / 2.54, height = 5.2 / 2.54, device = cairo_pdf, bg = "white")
ggsave(file.path(figure_dir, "Fig3B_2D_Gower_PCoA.png"), p_2d,
       width = 8.5 / 2.54, height = 5.2 / 2.54, dpi = 600, bg = "white")
ggsave(file.path(figure_dir, "Fig3B_localization_stacked.pdf"), p_stacked,
       width = 10.5 / 2.54, height = 5.7 / 2.54, device = cairo_pdf, bg = "white")
ggsave(file.path(figure_dir, "Fig3B_localization_stacked.png"), p_stacked,
       width = 10.5 / 2.54, height = 5.7 / 2.54, dpi = 600, bg = "white")
ggsave(file.path(figure_dir, "Fig3B_intact_localization_ratio.pdf"), p_ratio,
       width = 8.5 / 2.54, height = 6.0 / 2.54, device = cairo_pdf, bg = "white")
ggsave(file.path(figure_dir, "Fig3B_intact_localization_ratio.png"), p_ratio,
       width = 8.5 / 2.54, height = 6.0 / 2.54, dpi = 600, bg = "white")
ggsave(file.path(figure_dir, "Fig3B_structural_dependency_heatmap.pdf"), p_heatmap,
       width = 10.5 / 2.54, height = 6.5 / 2.54, device = cairo_pdf, bg = "white")
ggsave(file.path(figure_dir, "Fig3B_structural_dependency_heatmap.png"), p_heatmap,
       width = 10.5 / 2.54, height = 6.5 / 2.54, dpi = 600, bg = "white")

pdf(file.path(figure_dir, "Fig3B_Gower_dendrogram.pdf"), width = 7, height = 4.8, pointsize = 9)
par(mar = c(5, 4, 3, 1), lwd = 2 / 3)
plot(hc, main = "Average-linkage clustering of Gower distances", xlab = "", sub = "", cex.main = 10 / 9)
dev.off()

write.csv(dat, file.path(table_dir, "IFA_processed_replicates.csv"), row.names = FALSE)
write.csv(summary, file.path(table_dir, "IFA_genotype_summary.csv"), row.names = FALSE)
write.csv(ratio_summary, file.path(table_dir, "IFA_intact_ratio_95CI.csv"), row.names = FALSE)
write.csv(pcoa_data, file.path(table_dir, "IFA_Gower_PCoA_coordinates.csv"), row.names = FALSE)
write.csv(
  pcoa_feature_contribution,
  file.path(table_dir, "IFA_PCoA_feature_contributions.csv"),
  row.names = FALSE
)
write.csv(as.matrix(gower), file.path(table_dir, "IFA_Gower_distance_matrix.csv"))
writeLines(
  c(
    "Clustering method: Gower distance with average-linkage hierarchical clustering.",
    "2D visualization: principal coordinates analysis (PCoA) of the same Gower distance matrix.",
    "Localization composition: intact/altered/lost transformed to two ILR coordinates with pseudocount 0.005.",
    "Feature contribution table: Spearman correlations between each input feature and PCoA coordinates; percentages are normalized absolute correlation strengths, not PCA loadings.",
    "Target module and expected ICAT effect are annotations only and are excluded from clustering.",
    paste("Features used:", paste(names(features), collapse = ", "))
  ),
  file.path(report_dir, "analysis_method.txt")
)

cat("Analysis complete.\n")
cat("Genotypes:", nrow(summary), "\n")
cat("Features used:", paste(names(features), collapse = ", "), "\n")
cat("Output:", normalizePath(output_root), "\n")
