#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(cluster)
  library(ggplot2)
  library(ggrepel)
  library(grid)
})

args <- commandArgs(trailingOnly = TRUE)
get_arg <- function(prefix, default) {
  hit <- grep(paste0("^", prefix, "="), args, value = TRUE)
  if (length(hit) > 1L) stop("Provide at most one ", prefix, " argument.")
  if (length(hit)) sub(paste0("^", prefix, "="), "", hit[[1]]) else default
}

script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
script_path <- normalizePath(sub("^--file=", "", script_arg[[1]]), mustWork = TRUE)
fig_dir <- if (exists("FIG3_BASE_DIR", inherits = TRUE)) {
  normalizePath(get("FIG3_BASE_DIR", inherits = TRUE), mustWork = TRUE)
} else {
  normalizePath(file.path(dirname(script_path), "..", ".."), mustWork = TRUE)
}
find_project_root <- function(start_dir) {
  current <- normalizePath(start_dir, mustWork = TRUE)
  repeat {
    if (file.exists(file.path(current, "shared", "R", "plot_style.R"))) return(current)
    parent <- dirname(current)
    if (identical(parent, current)) stop("Could not locate project root from: ", start_dir)
    current <- parent
  }
}
project_root <- find_project_root(dirname(script_path))
source(file.path(project_root, "shared", "R", "plot_style.R"))
default_input <- file.path(fig_dir, "01_raw_data", "localization_perturbation", "ICAT_localization_pertubation.xlsx")
if (!file.exists(default_input)) {
  default_input <- file.path(fig_dir, "01_raw_data", "localization_perturbation", "ICAT_localization_pertubation.csv")
}
input_path <- normalizePath(get_arg("--input", default_input), mustWork = TRUE)
output_root <- get_arg(
  "--output",
  file.path(fig_dir, "04_results")
)
figure_dir <- file.path(output_root, "figures", "localization_perturbation")
table_dir <- file.path(output_root, "tables", "localization_perturbation")
report_dir <- file.path(output_root, "reports", "localization_perturbation")
for (path in c(figure_dir, table_dir, report_dir)) {
  dir.create(path, recursive = TRUE, showWarnings = FALSE)
}

required <- c(
  "biological_replicate", "genotype", "primary_perturbation_target", "target_module",
  "total_cells", "intact_n", "altered_n", "lost_n", "unscorable_n",
  "expected_icat_effect", "conoid_body_status", "apical_ring_status",
  "icmt_status", "bridge_status", "rhoptry_status", "icat_total_signal_status",
  "wb_abundance_ratio"
)

if (grepl("\\.xlsx$", input_path, ignore.case = TRUE)) {
  if (!requireNamespace("readxl", quietly = TRUE)) {
    stop("The readxl package is required to read .xlsx input files.")
  }
  raw <- as.data.frame(
    readxl::read_excel(input_path, sheet = "Data", na = c("", "NA")),
    check.names = FALSE, stringsAsFactors = FALSE
  )
} else {
  raw <- read.csv(input_path, check.names = FALSE, stringsAsFactors = FALSE)
}
apical_col <- if ("apical_polar_ring_status" %in% names(raw)) {
  "apical_polar_ring_status"
} else if ("apical_ring_status" %in% names(raw)) {
  "apical_ring_status"
} else {
  NA_character_
}
missing_columns <- setdiff(required, names(raw))
missing_columns <- setdiff(missing_columns, c("apical_ring_status", "apical_polar_ring_status"))
if (length(missing_columns)) {
  stop("Input is missing required columns: ", paste(missing_columns, collapse = ", "))
}
if (is.na(apical_col)) stop("Input is missing required column: apical_polar_ring_status")
rhoptry_col <- if ("rhoptry_status" %in% names(raw)) "rhoptry_status" else NA_character_
abundance_col <- if ("wb_abundance_ratio" %in% names(raw)) "wb_abundance_ratio" else NA_character_
if (is.na(rhoptry_col)) stop("Input is missing required column: rhoptry_status")
if (is.na(abundance_col)) stop("Input is missing required column: wb_abundance_ratio")

completed <- !is.na(raw$total_cells) & nzchar(trimws(as.character(raw$total_cells)))
dat <- raw[completed, , drop = FALSE]
if (!nrow(dat)) {
  stop(
    "No completed rows were found. Fill total_cells, intact_n, altered_n, lost_n ",
    "and unscorable_n before running the analysis."
  )
}

count_columns <- c("total_cells", "intact_n", "altered_n", "lost_n", "unscorable_n")
for (column in count_columns) dat[[column]] <- as.numeric(dat[[column]])
if (any(!is.finite(as.matrix(dat[count_columns])))) {
  stop("All count columns must be numeric for completed rows.")
}
if (any(as.matrix(dat[count_columns]) < 0) ||
    any(abs(as.matrix(dat[count_columns]) - round(as.matrix(dat[count_columns]))) > 1e-8)) {
  stop("Cell counts must be non-negative integers.")
}

count_sum <- dat$intact_n + dat$altered_n + dat$lost_n + dat$unscorable_n
bad_sum <- which(dat$total_cells != count_sum)
if (length(bad_sum)) {
  warning(
    "Count mismatch in rows: ",
    paste(which(completed)[bad_sum] + 1L, collapse = ", "),
    ". Proceeding with the provided counts."
  )
}

dat$scored_cells <- dat$intact_n + dat$altered_n + dat$lost_n
if (any(dat$scored_cells <= 0)) stop("Each completed row must contain at least one scorable cell.")
dat$intact_prop <- dat$intact_n / dat$scored_cells
dat$altered_prop <- dat$altered_n / dat$scored_cells
dat$lost_prop <- dat$lost_n / dat$scored_cells
dat$unscorable_prop <- dat$unscorable_n / dat$total_cells

status_score <- function(x, type = "structure") {
  x <- tolower(trimws(as.character(x)))
  if (type == "abundance") {
    map <- c(normal = 0, reduced = 1, lost = 2, nd = NA_real_)
  } else {
    map <- c(intact = 0, altered = 1, lost = 2, nd = NA_real_)
  }
  out <- unname(map[x])
  out[x == ""] <- NA_real_
  out
}

dat$conoid_body_score <- status_score(dat$conoid_body_status)
dat$apical_ring_score <- status_score(dat[[apical_col]])
dat$icmt_score <- status_score(dat$icmt_status)
dat$bridge_score <- status_score(dat$bridge_status)
dat$rhoptry_score <- status_score(dat$rhoptry_status)
dat$icat_abundance_score <- status_score(dat$icat_total_signal_status, "abundance")
dat$wb_abundance_ratio <- suppressWarnings(as.numeric(dat$wb_abundance_ratio))

mean_or_na <- function(x) if (all(is.na(x))) NA_real_ else mean(x, na.rm = TRUE)
first_nonblank <- function(x) {
  x <- x[!is.na(x) & nzchar(trimws(as.character(x)))]
  if (length(x)) as.character(x[[1]]) else NA_character_
}
normalize_perturbation_structures <- function(primary, module) {
  terms <- tolower(c(primary, module))
  out <- character()
  add_if <- function(flag, label) {
    if (any(flag, na.rm = TRUE)) out <<- unique(c(out, label))
  }
  add_if(grepl("conoid", terms) | grepl("bridge", terms), "Conoid")
  add_if(grepl("icmt", terms), "ICMTs")
  add_if(grepl("rhoptry", terms), "Rhoptry")
  out
}
normalize_primary_target <- function(primary) {
  term <- tolower(trimws(as.character(primary)))
  if (is.na(term) || !nzchar(term) || term == "none") return(character())
  out <- character()
  if (grepl("conoid|bridge", term)) out <- c(out, "Conoid")
  if (grepl("icmt", term)) out <- c(out, "ICMTs")
  if (grepl("rhoptry", term)) out <- c(out, "Rhoptry")
  unique(out)
}
display_genotype <- function(x) {
  x <- gsub("CIP3KO/CF1KD", "CIP3/CF1", x, fixed = TRUE)
  x <- gsub("_KO_CF1_KD$", "/CF1", x)
  x <- gsub("_(KO|KD)$", "", x)
  x <- gsub("(KO|KD)$", "", x)
  gsub("_", " ", x)
}
pcoa_plot_label <- function(x) {
  out <- display_genotype(x)
  out[out == "CF5"] <- "CF5^{KO}"
  out[out == "ARO"] <- "ARO^{KD}"
  out[out == "ICMAP1"] <- "ICMAP1^{KD}"
  out[out == "ICMAP2"] <- "ICMAP2^{KD}"
  out[out == "CIP3"] <- "CIP3^{KO}"
  out[out == "RNG2"] <- "RNG2^{KD}"
  out[out == "AC9"] <- "AC9^{KD}"
  out[out == "CIP3/CF1"] <- "CIP3^{KD}*'/'*CF1^{KO}"
  out
}

fig3b_order <- c(
  "WT", "CF5KO", "AROKD", "ICMAP1KD", "ICMAP2KD",
  "CIP3KO", "RNG2KD", "AC9KD", "CIP3KO/CF1KD"
)
fig3b_display_order <- fig3b_order

get_hclust_display_order <- function(hc, genotype_order = fig3b_order) {
  target_order <- c(genotype_order[genotype_order %in% hc$labels], setdiff(hc$labels, genotype_order))
  target_rank <- setNames(seq_along(target_order), target_order)
  oriented_children <- vector("list", nrow(hc$merge))

  subtree_stats <- function(node) {
    if (node < 0) {
      lab <- hc$labels[-node]
      return(list(labels = lab, mean_rank = target_rank[[lab]]))
    }
    children <- hc$merge[node, ]
    left <- subtree_stats(children[1])
    right <- subtree_stats(children[2])
    if (left$mean_rank <= right$mean_rank) {
      oriented_children[[node]] <<- children
      labs <- c(left$labels, right$labels)
    } else {
      oriented_children[[node]] <<- rev(children)
      labs <- c(right$labels, left$labels)
    }
    list(labels = labs, mean_rank = mean(target_rank[labs], na.rm = TRUE))
  }
  oriented <- subtree_stats(nrow(hc$merge))
  oriented$labels
}

draw_top_dendrogram <- function(hc, summary, genotype_order = fig3b_order) {
  target_order <- c(genotype_order[genotype_order %in% hc$labels], setdiff(hc$labels, genotype_order))
  target_rank <- setNames(seq_along(target_order), target_order)
  oriented_children <- vector("list", nrow(hc$merge))
  leaf_group <- setNames(summary$dominant_icat_outcome, summary$genotype)

  subtree_stats <- function(node) {
    if (node < 0) {
      lab <- hc$labels[-node]
      return(list(labels = lab, mean_rank = target_rank[[lab]], group = leaf_group[[lab]]))
    }
    children <- hc$merge[node, ]
    left <- subtree_stats(children[1])
    right <- subtree_stats(children[2])
    if (left$mean_rank <= right$mean_rank) {
      oriented_children[[node]] <<- children
      labs <- c(left$labels, right$labels)
    } else {
      oriented_children[[node]] <<- rev(children)
      labs <- c(right$labels, left$labels)
    }
    group <- if (identical(left$group, right$group)) left$group else "mixed"
    list(labels = labs, mean_rank = mean(target_rank[labs], na.rm = TRUE), group = group)
  }
  oriented <- subtree_stats(nrow(hc$merge))
  labels <- oriented$labels
  n <- length(labels)
  maxh <- max(hc$height)
  x_pos <- setNames(seq(0.10, 0.94, length.out = n), labels)
  y_leaf <- 0.22
  y_span <- 0.56
  branch_col <- function(group) {
    switch(group,
      intact = "#9A9A9A",
      altered = "#3A7AC2",
      lost = "#D7281E",
      mixed = "#9A9A9A",
      "#9A9A9A"
    )
  }
  label_col <- function(group) {
    switch(group,
      altered = "#3A7AC2",
      lost = "#D7281E",
      "#1F1F1F"
    )
  }
  line_gp <- function(group) gpar(col = branch_col(group), lwd = 0.9, lineend = "round", linejoin = "round")

  node_draw <- function(node) {
    if (node < 0) {
      lab <- hc$labels[-node]
      return(list(x = x_pos[[lab]], y = y_leaf, labels = lab, group = leaf_group[[lab]], nleaves = 1L))
    }
    children <- oriented_children[[node]]
    left <- node_draw(children[1])
    right <- node_draw(children[2])
    node_y <- y_leaf + (hc$height[node] / maxh) * y_span
    node_x <- mean(c(left$x, right$x))
    group <- if (identical(left$group, right$group)) left$group else "mixed"

    grid.segments(
      x0 = unit(node_x, "npc"), y0 = unit(left$y, "npc"),
      x1 = unit(node_x, "npc"), y1 = unit(node_y, "npc"),
      gp = line_gp(group)
    )
    grid.segments(
      x0 = unit(node_x, "npc"), y0 = unit(left$y, "npc"),
      x1 = unit(left$x, "npc"), y1 = unit(left$y, "npc"),
      gp = line_gp(group)
    )
    grid.segments(
      x0 = unit(node_x, "npc"), y0 = unit(right$y, "npc"),
      x1 = unit(right$x, "npc"), y1 = unit(right$y, "npc"),
      gp = line_gp(group)
    )
    list(
      x = node_x, y = node_y, labels = c(left$labels, right$labels),
      group = group, nleaves = left$nleaves + right$nleaves
    )
  }
  node_draw(nrow(hc$merge))

  for (lab in labels) {
    lab_group <- leaf_group[[lab]]
    grid.draw(textGrob(
      label = parse(text = pcoa_plot_label(lab)),
      x = unit(x_pos[[lab]], "npc"), y = unit(0.06, "npc"),
      just = c("center", "top"),
      gp = gpar(fontfamily = "Arial", fontsize = 6.1,
                col = label_col(lab_group))
    ))
  }
  grid.segments(
    x0 = unit(0.17, "npc"), y0 = unit(0.95, "npc"),
    x1 = unit(0.29, "npc"), y1 = unit(0.95, "npc"),
    gp = gpar(col = "#9A9A9A", lwd = 0.7)
  )
  for (tick_x in c(0.17, 0.23, 0.29)) {
    grid.segments(
      x0 = unit(tick_x, "npc"), y0 = unit(0.95, "npc"),
      x1 = unit(tick_x, "npc"), y1 = unit(0.88, "npc"),
      gp = gpar(col = "#9A9A9A", lwd = 0.7)
    )
  }
  grid.text("0.0", x = unit(0.165, "npc"), y = unit(0.87, "npc"),
            just = c("center", "top"),
            gp = gpar(fontfamily = "Arial", fontsize = 5.8, col = "#9A9A9A"))
  grid.text("0.3", x = unit(0.23, "npc"), y = unit(0.87, "npc"),
            just = c("center", "top"),
            gp = gpar(fontfamily = "Arial", fontsize = 5.8, col = "#9A9A9A"))
  grid.text("0.6", x = unit(0.29, "npc"), y = unit(0.87, "npc"),
            just = c("center", "top"),
            gp = gpar(fontfamily = "Arial", fontsize = 5.8, col = "#9A9A9A"))
}

draw_mini_phenotype_icon <- function(x, y, w, h, genotype, summary_row) {
  outcome <- as.character(summary_row$dominant_icat_outcome)
  base_col <- switch(
    outcome,
    intact = "#A7B79D",
    altered = "#3A7AC2",
    lost = "#D7281E",
    mixed = "#B3B3B3",
    "#B3B3B3"
  )
  faint <- adjustcolor(base_col, alpha.f = 0.28)
  rod_col <- switch(
    outcome,
    intact = "#B07A5F",
    altered = "#4A8BC2",
    lost = "#D7281E",
    mixed = "#9A9A9A",
    "#9A9A9A"
  )
  if (genotype == "RNG2KD") {
    grid.polygon(
      x = unit(c(x - 0.12 * w, x + 0.14 * w, x + 0.08 * w, x - 0.18 * w), "npc"),
      y = unit(c(y - 0.02 * h, y + 0.16 * h, y + 0.22 * h, y + 0.05 * h), "npc"),
      gp = gpar(fill = "white", col = base_col, lwd = 0.75)
    )
    grid.segments(
      x0 = unit(x - 0.14 * w, "npc"), y0 = unit(y - 0.01 * h, "npc"),
      x1 = unit(x + 0.08 * w, "npc"), y1 = unit(y + 0.22 * h, "npc"),
      gp = gpar(col = rod_col, lwd = 0.75)
    )
    grid.segments(
      x0 = unit(x - 0.03 * w, "npc"), y0 = unit(y - 0.04 * h, "npc"),
      x1 = unit(x + 0.13 * w, "npc"), y1 = unit(y + 0.20 * h, "npc"),
      gp = gpar(col = rod_col, lwd = 0.75)
    )
    grid.circle(
      x = unit(x + 0.14 * w, "npc"), y = unit(y + 0.10 * h, "npc"),
      r = unit(0.10 * w, "npc"),
      gp = gpar(fill = adjustcolor(base_col, alpha.f = 0.10), col = base_col, lwd = 0.65)
    )
  } else if (genotype %in% c("AC9KD", "CIP3KO/CF1KD")) {
    grid.circle(
      x = unit(x, "npc"), y = unit(y, "npc"),
      r = unit(0.16 * w, "npc"),
      gp = gpar(fill = "white", col = base_col, lwd = 0.7, lty = 2)
    )
    grid.segments(
      x0 = unit(x - 0.12 * w, "npc"), y0 = unit(y - 0.03 * h, "npc"),
      x1 = unit(x + 0.12 * w, "npc"), y1 = unit(y - 0.03 * h, "npc"),
      gp = gpar(col = "#A9A9A9", lwd = 0.5, lty = 3)
    )
  } else {
    grid.polygon(
      x = unit(c(x - 0.14 * w, x + 0.14 * w, x + 0.10 * w, x - 0.10 * w), "npc"),
      y = unit(c(y - 0.10 * h, y - 0.10 * h, y + 0.20 * h, y + 0.20 * h), "npc"),
      gp = gpar(fill = "white", col = base_col, lwd = 0.7)
    )
    grid.circle(
      x = unit(x, "npc"), y = unit(y - 0.10 * h, "npc"),
      r = unit(0.14 * w, "npc"),
      gp = gpar(fill = "white", col = base_col, lwd = 0.7)
    )
    grid.segments(
      x0 = unit(x - 0.05 * w, "npc"), y0 = unit(y - 0.12 * h, "npc"),
      x1 = unit(x - 0.05 * w, "npc"), y1 = unit(y + 0.18 * h, "npc"),
      gp = gpar(col = rod_col, lwd = 0.7)
    )
    grid.segments(
      x0 = unit(x + 0.02 * w, "npc"), y0 = unit(y - 0.12 * h, "npc"),
      x1 = unit(x + 0.02 * w, "npc"), y1 = unit(y + 0.18 * h, "npc"),
      gp = gpar(col = rod_col, lwd = 0.7)
    )
    if (genotype == "AROKD") {
      grid.roundrect(
        x = unit(x + 0.13 * w, "npc"), y = unit(y + 0.03 * h, "npc"),
        width = unit(0.09 * w, "npc"), height = unit(0.10 * h, "npc"),
        r = unit(0.03, "snpc"),
        gp = gpar(fill = adjustcolor("#a56441", alpha.f = 0.30), col = "#a56441", lwd = 0.55)
      )
    }
  }
}

draw_phenotype_row <- function(summary, hc, genotype_order = fig3b_order) {
  display_order <- get_hclust_display_order(hc, genotype_order)
  summary <- summary[match(display_order, summary$genotype), , drop = FALSE]
  x_pos <- setNames(seq(0.16, 0.94, length.out = nrow(summary)), summary$genotype)
  for (i in seq_len(nrow(summary))) {
    row <- summary[i, ]
    draw_mini_phenotype_icon(
      x = x_pos[[row$genotype]], y = 0.52, w = 0.084, h = 0.68,
      genotype = row$genotype, summary_row = row
    )
  }
}

draw_framework_combo <- function(summary, hc, pcoa_plot, genotype_order = fig3b_order) {
  display_order <- get_hclust_display_order(hc, genotype_order)
  summary <- summary[match(display_order, summary$genotype), , drop = FALSE]
  if (anyNA(summary$genotype)) {
    stop("Some genotypes from genotype_order are missing in the summary.")
  }
  if (!identical(summary$genotype, display_order)) {
    stop("Framework rows are not aligned with the dendrogram order.")
  }

  grid.rect(gp = gpar(col = NA, fill = "white"))
  grid.text("B", x = unit(0.02, "npc"), y = unit(0.985, "npc"),
            just = c("left", "top"),
            gp = gpar(fontfamily = "Arial", fontsize = 18, fontface = "bold"))

  layout <- grid.layout(
    nrow = 3, ncol = 1,
    heights = unit(c(2.00, 1.70, 4.40), "cm")
  )
  pushViewport(viewport(layout = layout))

  pushViewport(viewport(layout.pos.row = 1, layout.pos.col = 1))
  draw_top_dendrogram(hc, summary, genotype_order = genotype_order)
  popViewport()

  pushViewport(viewport(layout.pos.row = 2, layout.pos.col = 1))
  draw_phenotype_row(summary, hc, genotype_order = genotype_order)
  popViewport()

  pushViewport(viewport(layout.pos.row = 3, layout.pos.col = 1))
  grid.draw(ggplotGrob(pcoa_plot))
  popViewport()

  popViewport()
}

draw_structure_icon <- function(structure, x, y, w, h, state, base_col) {
  state_key <- if (is.na(state)) "na" else as.character(round(state))
  stroke <- switch(
    state_key,
    "0" = base_col,
    "1" = "#9A9A9A",
    "2" = "#3F3F3F",
    "na" = "#D9D9D9",
    "#9A9A9A"
  )
  fill <- switch(
    state_key,
    "0" = adjustcolor(base_col, alpha.f = 0.36),
    "1" = "#BFBFBF",
    "2" = "#4A4A4A",
    "na" = "#EEEEEE",
    "#BFBFBF"
  )
  lw <- if (state_key == "na") 0.25 else 0.35

  if (structure == "fibrils") {
    for (k in -1:1) {
      grid.segments(
        x0 = unit(x - 0.14 * w + k * 0.06 * w, "npc"),
        y0 = unit(y - 0.18 * h, "npc"),
        x1 = unit(x + 0.10 * w + k * 0.06 * w, "npc"),
        y1 = unit(y + 0.18 * h, "npc"),
        gp = gpar(col = stroke, lwd = lw, lineend = "round")
      )
    }
  } else if (structure == "conoid") {
    grid.polygon(
      x = unit(c(x - 0.18 * w, x + 0.18 * w, x + 0.10 * w, x - 0.10 * w), "npc"),
      y = unit(c(y - 0.12 * h, y - 0.12 * h, y + 0.18 * h, y + 0.18 * h), "npc"),
      gp = gpar(fill = fill, col = stroke, lwd = lw)
    )
  } else if (structure == "icmt") {
    for (k in -1:1) {
      grid.segments(
        x0 = unit(x + k * 0.06 * w, "npc"),
        y0 = unit(y - 0.16 * h, "npc"),
        x1 = unit(x + k * 0.06 * w, "npc"),
        y1 = unit(y + 0.17 * h, "npc"),
        gp = gpar(col = stroke, lwd = lw, lineend = "round")
      )
    }
  } else if (structure == "fm") {
    grid.rect(
      x = unit(x, "npc"), y = unit(y, "npc"),
      width = unit(0.34 * w, "npc"), height = unit(0.22 * h, "npc"),
      gp = gpar(fill = fill, col = stroke, lwd = lw)
    )
    grid.segments(
      x0 = unit(x - 0.14 * w, "npc"), y0 = unit(y - 0.10 * h, "npc"),
      x1 = unit(x + 0.14 * w, "npc"), y1 = unit(y + 0.10 * h, "npc"),
      gp = gpar(col = stroke, lwd = lw)
    )
    grid.segments(
      x0 = unit(x - 0.14 * w, "npc"), y0 = unit(y + 0.10 * h, "npc"),
      x1 = unit(x + 0.14 * w, "npc"), y1 = unit(y - 0.10 * h, "npc"),
      gp = gpar(col = stroke, lwd = lw)
    )
  } else if (structure == "rhoptry") {
    grid.roundrect(
      x = unit(x, "npc"), y = unit(y, "npc"),
      width = unit(0.24 * w, "npc"), height = unit(0.42 * h, "npc"),
      r = unit(0.10, "snpc"),
      gp = gpar(fill = fill, col = stroke, lwd = lw)
    )
    grid.segments(
      x0 = unit(x - 0.12 * w, "npc"), y0 = unit(y, "npc"),
      x1 = unit(x + 0.12 * w, "npc"), y1 = unit(y, "npc"),
      gp = gpar(col = stroke, lwd = lw)
    )
  }
  if (state_key == "na") {
    grid.text("·", x = unit(x, "npc"), y = unit(y, "npc"),
              gp = gpar(fontfamily = "Arial", fontsize = 5.0, col = "#9A9A9A"))
  }
}

draw_panel_B_evidence_columns <- function(summary, row_y = NULL) {
  if (is.null(row_y)) row_y <- seq(0.72, 0.20, length.out = nrow(summary))
  expr_fraction <- summary$expression_fraction
  expr_fraction[!is.finite(expr_fraction)] <- 0

  target_x <- seq(0.045, by = 0.034, length.out = 3)
  target_labels <- c("Conoid", "ICMTs", "Rhoptry")
  target_cols <- c("#93af70", "#53876d", "#a56441")

  state_x <- seq(0.215, by = 0.034, length.out = 5)
  state_labels <- c("Fibrils", "Conoid", "ICMTs", "FM", "Rhoptries")
  state_header_cols <- c("#7FA64D", "#6B8EAD", "#4E876A", "#D98A1C", "#a56441")
  state_values <- cbind(
    summary$conoid_assembly_score,
    summary$conoid_position_score,
    summary$icmt_score,
    summary$bridge_score,
    summary$rhoptry_score
  )

  loc_x0 <- 0.48
  loc_x1 <- 0.61
  expr_x0 <- 0.76
  expr_x1 <- 0.90
  cell_w <- 0.033
  cell_h <- 0.035
  bar_h <- 0.024

  grid.text("targeted\nperturbations", x = unit(mean(target_x), "npc"), y = unit(0.995, "npc"),
            just = c("center", "top"),
            gp = gpar(fontfamily = "Arial", fontsize = 6.2, col = "#111111"))
  grid.text("structural\noutcomes", x = unit(mean(state_x), "npc"), y = unit(0.995, "npc"),
            just = c("center", "top"),
            gp = gpar(fontfamily = "Arial", fontsize = 6.2, col = "#111111"))
  grid.text("ICAT apical\nretention (%)", x = unit(mean(c(loc_x0, loc_x1)), "npc"), y = unit(0.995, "npc"),
            just = c("center", "top"),
            gp = gpar(fontfamily = "Arial", fontsize = 5.4, col = "black"))
  grid.text("ICAT abundance\n(relative to WT)", x = unit(mean(c(expr_x0, expr_x1)), "npc"), y = unit(0.995, "npc"),
            just = c("center", "top"),
            gp = gpar(fontfamily = "Arial", fontsize = 5.4, col = "black"))

  for (j in seq_along(target_x)) {
    grid.text(target_labels[j], x = unit(target_x[j], "npc"), y = unit(0.825, "npc"),
              rot = 90, just = c("center", "center"),
              gp = gpar(fontfamily = "Arial", fontsize = 4.3, col = target_cols[j]))
  }
  for (j in seq_along(state_x)) {
    grid.text(state_labels[j], x = unit(state_x[j], "npc"), y = unit(0.790, "npc"),
              rot = 90, just = c("center", "center"),
              gp = gpar(fontfamily = "Arial", fontsize = 3.8, col = state_header_cols[j]))
  }

  for (i in seq_len(nrow(summary))) {
    for (j in seq_along(target_x)) {
      is_target <- target_labels[j] %in% summary$primary_targets[[i]]
      grid.rect(
        x = unit(target_x[j], "npc"), y = unit(row_y[i], "npc"),
        width = unit(cell_w, "npc"), height = unit(cell_h, "npc"),
        gp = gpar(fill = if (is_target) target_cols[j] else "#F1F1F1", col = "white", lwd = 0.45)
      )
    }

    for (j in seq_along(state_x)) {
      value <- state_values[i, j]
      grid.rect(
        x = unit(state_x[j], "npc"), y = unit(row_y[i], "npc"),
        width = unit(cell_w, "npc"), height = unit(cell_h, "npc"),
        gp = gpar(fill = "#FAFAFA", col = "#FFFFFF", lwd = 0.25)
      )
      draw_structure_icon(
        structure = c("fibrils", "conoid", "icmt", "fm", "rhoptry")[j],
        x = state_x[j], y = row_y[i], w = cell_w, h = cell_h,
        state = value, base_col = state_header_cols[j]
      )
    }

    loc_w <- loc_x1 - loc_x0
    grid.rect(x = unit(mean(c(loc_x0, loc_x1)), "npc"), y = unit(row_y[i], "npc"),
              width = unit(loc_w, "npc"), height = unit(bar_h, "npc"),
              gp = gpar(fill = "#E8E8E8", col = "#D0D0D0", lwd = 0.35))
    intact_w <- loc_w * summary$intact_prop[i]
    if (is.finite(intact_w) && intact_w > 0) {
      grid.rect(x = unit(loc_x0 + intact_w / 2, "npc"), y = unit(row_y[i], "npc"),
                width = unit(intact_w, "npc"), height = unit(bar_h, "npc"),
                gp = gpar(fill = "#8e8e8e", col = NA))
    }

    expr_w <- expr_x1 - expr_x0
    grid.rect(x = unit(mean(c(expr_x0, expr_x1)), "npc"), y = unit(row_y[i], "npc"),
              width = unit(expr_w, "npc"), height = unit(bar_h, "npc"),
              gp = gpar(fill = "#E8E8E8", col = NA))
    if (is.finite(expr_fraction[i]) && expr_fraction[i] > 0) {
      grid.rect(x = unit(expr_x0 + expr_w * expr_fraction[i] / 2, "npc"),
                y = unit(row_y[i], "npc"),
                width = unit(expr_w * expr_fraction[i], "npc"), height = unit(bar_h, "npc"),
                gp = gpar(fill = "#e26ae5", col = NA))
    }
  }

  legend_x <- c(0.18, 0.28, 0.38, 0.48)
  legend_lab <- c("intact", "altered", "lost", "ND")
  legend_fill <- c("#D8D8D8", "#8A8A8A", "#2E2E2E", "#E4E4E4")
  grid.text(
    "Outcome types", x = unit(0.58, "npc"), y = unit(0.085, "npc"),
    just = c("left", "center"),
    gp = gpar(fontfamily = "Arial", fontsize = 5.4, col = "#555555")
  )
  for (j in seq_along(legend_x)) {
    grid.rect(x = unit(legend_x[j], "npc"), y = unit(0.040, "npc"),
              width = unit(0.014, "npc"), height = unit(0.014, "npc"),
              gp = gpar(fill = legend_fill[j], col = "#BDBDBD", lwd = 0.25))
    grid.text(legend_lab[j], x = unit(legend_x[j] + 0.010, "npc"), y = unit(0.040, "npc"),
              just = c("left", "center"),
              gp = gpar(fontfamily = "Arial", fontsize = 3.4, col = "#555555"))
  }
}

draw_hclust_linear <- function(hc, genotype_order = fig3b_order) {
  target_order <- c(genotype_order[genotype_order %in% hc$labels], setdiff(hc$labels, genotype_order))
  target_rank <- setNames(seq_along(target_order), target_order)
  oriented_children <- vector("list", nrow(hc$merge))

  subtree_stats <- function(node) {
    if (node < 0) {
      lab <- hc$labels[-node]
      return(list(labels = lab, min_rank = target_rank[[lab]]))
    }
    children <- hc$merge[node, ]
    left <- subtree_stats(children[1])
    right <- subtree_stats(children[2])
    if (left$min_rank <= right$min_rank) {
      oriented_children[[node]] <<- children
      labs <- c(left$labels, right$labels)
    } else {
      oriented_children[[node]] <<- rev(children)
      labs <- c(right$labels, left$labels)
    }
    list(labels = labs, min_rank = min(target_rank[labs], na.rm = TRUE))
  }
  oriented <- subtree_stats(nrow(hc$merge))
  labels <- oriented$labels
  n <- length(labels)
  maxh <- max(hc$height)
  line_gp <- gpar(col = "black", lwd = 0.8, lineend = "round", linejoin = "round")
  y_pos <- setNames(seq(0.86, 0.18, length.out = n), labels)
  x_leaf <- 0.78
  x_span <- 0.54

  node_draw <- function(node) {
    if (node < 0) {
      lab <- hc$labels[-node]
      return(list(x = x_leaf, y = y_pos[[lab]], labels = lab, nleaves = 1L))
    }
    children <- oriented_children[[node]]
    left <- node_draw(children[1])
    right <- node_draw(children[2])
    node_x <- x_leaf - (hc$height[node] / maxh) * x_span
    node_y <- mean(c(left$y, right$y))

    grid.segments(
      x0 = unit(node_x, "npc"), y0 = unit(left$y, "npc"),
      x1 = unit(node_x, "npc"), y1 = unit(right$y, "npc"),
      gp = line_gp
    )
    grid.segments(
      x0 = unit(node_x, "npc"), y0 = unit(left$y, "npc"),
      x1 = unit(left$x, "npc"), y1 = unit(left$y, "npc"),
      gp = line_gp
    )
    grid.segments(
      x0 = unit(node_x, "npc"), y0 = unit(right$y, "npc"),
      x1 = unit(right$x, "npc"), y1 = unit(right$y, "npc"),
      gp = line_gp
    )
    list(
      x = node_x,
      y = node_y,
      labels = c(left$labels, right$labels),
      nleaves = left$nleaves + right$nleaves
    )
  }

  node_draw(nrow(hc$merge))
  for (lab in labels) {
    grid.text(
      display_genotype(lab), x = unit(0.90, "npc"), y = unit(y_pos[[lab]], "npc"),
      just = c("left", "center"),
      gp = gpar(fontfamily = "Arial", fontsize = 5.4, col = "black")
    )
  }

  scale_y <- 0.03
  scale_x0 <- 0.18
  scale_x1 <- 0.40
  tick_x <- c(scale_x0, (scale_x0 + scale_x1) / 2, scale_x1)
  tick_lab <- c("0.0", "0.3", "0.6")
  grid.segments(
    x0 = unit(scale_x0, "npc"), y0 = unit(scale_y, "npc"),
    x1 = unit(scale_x1, "npc"), y1 = unit(scale_y, "npc"),
    gp = gpar(col = "black", lwd = 0.8)
  )
  for (j in seq_along(tick_x)) {
    grid.segments(
      x0 = unit(tick_x[j], "npc"), y0 = unit(scale_y, "npc"),
      x1 = unit(tick_x[j], "npc"), y1 = unit(scale_y - 0.015, "npc"),
      gp = gpar(col = "black", lwd = 0.8)
    )
    grid.text(
      tick_lab[j], x = unit(tick_x[j], "npc"), y = unit(scale_y - 0.026, "npc"),
      just = c("center", "top"),
      gp = gpar(fontfamily = "Arial", fontsize = 6.0, col = "black")
    )
  }
  invisible(data.frame(genotype = labels, y = unname(y_pos[labels]), stringsAsFactors = FALSE))
}

draw_panel_B_summary <- function(summary, hc, genotype_order = fig3b_order) {
  display_order <- genotype_order[genotype_order %in% summary$genotype]
  summary <- summary[match(display_order, summary$genotype), , drop = FALSE]
  if (anyNA(summary$genotype)) {
    stop("Some genotypes in genotype_order are missing from summary.")
  }
  if (!identical(summary$genotype, display_order)) {
    stop("Right-side genotype rows are not aligned with the dendrogram leaves.")
  }

  pushViewport(viewport(xscale = c(0, 1), yscale = c(0, 1)))
  grid.rect(gp = gpar(col = NA, fill = "white"))
  grid.text("genotype", x = unit(0.11, "npc"), y = unit(0.86, "npc"),
            gp = gpar(fontfamily = "Arial", fontsize = 7.2, col = "black"))
  tree_x <- 0.03
  tree_y <- 0.23
  tree_w <- 0.32
  tree_h <- 0.32
  pushViewport(viewport(
    x = unit(tree_x, "npc"), y = unit(tree_y, "npc"),
    width = unit(tree_w, "npc"), height = unit(tree_h, "npc"),
    just = c("left", "bottom")
  ))
  draw_hclust_linear(hc, genotype_order = genotype_order)
  popViewport()

  right_x <- 0.40
  right_y <- 0.08
  right_w <- 0.49
  right_h <- 0.82
  row_y <- seq(0.72, 0.20, length.out = nrow(summary))

  right_vp <- viewport(
    x = unit(right_x, "npc"), y = unit(right_y, "npc"),
    width = unit(right_w, "npc"), height = unit(right_h, "npc"),
    just = c("left", "bottom")
  )
  pushViewport(right_vp)
  draw_panel_B_evidence_columns(summary, row_y = row_y)
  popViewport()

  popViewport()
}

save_combined_panel_B <- function(summary, hc, pcoa_plot,
                                  pdf_path, png_path,
                                  width_cm = 13.5, height_cm = 9.2,
                                  dpi = 600) {
  dir.create(dirname(pdf_path), recursive = TRUE, showWarnings = FALSE)
  dir.create(dirname(png_path), recursive = TRUE, showWarnings = FALSE)

  draw_fun <- function() {
    pushViewport(viewport(xscale = c(0, 1), yscale = c(0, 1)))
    grid.rect(gp = gpar(col = NA, fill = "white"))
    grid.text("B", x = unit(0.02, "npc"), y = unit(0.985, "npc"),
              just = c("left", "top"),
              gp = gpar(fontfamily = "Arial", fontsize = 18, fontface = "bold"))
    top_h <- 0.56
    bottom_h <- 0.42
    pushViewport(viewport(x = unit(0, "npc"), y = unit(1 - top_h, "npc"),
                          width = unit(1, "npc"), height = unit(top_h, "npc"),
                          just = c("left", "bottom")))
    draw_panel_B_summary(summary, hc, genotype_order = fig3b_order)
    popViewport()
    pushViewport(viewport(x = unit(0, "npc"), y = unit(0, "npc"),
                          width = unit(1, "npc"), height = unit(bottom_h, "npc"),
                          just = c("left", "bottom")))
    grid.draw(ggplotGrob(pcoa_plot))
    popViewport()
    popViewport()
  }

  grDevices::cairo_pdf(pdf_path, width = width_cm / 2.54, height = height_cm / 2.54)
  grid.newpage()
  pushViewport(viewport(width = unit(width_cm, "cm"), height = unit(height_cm, "cm")))
  draw_fun()
  popViewport()
  dev.off()

  if (requireNamespace("ragg", quietly = TRUE)) {
    ragg::agg_png(png_path, width = width_cm / 2.54, height = height_cm / 2.54,
                  units = "in", res = dpi, background = "white")
    grid.newpage()
    pushViewport(viewport(width = unit(width_cm, "cm"), height = unit(height_cm, "cm")))
    draw_fun()
    popViewport()
    dev.off()
  }
}

save_framework_combo <- function(summary, hc, pcoa_plot,
                                 pdf_path, png_path,
                                 width_cm = 13.5, height_cm = 8.10,
                                 dpi = 600) {
  dir.create(dirname(pdf_path), recursive = TRUE, showWarnings = FALSE)
  dir.create(dirname(png_path), recursive = TRUE, showWarnings = FALSE)

  grDevices::cairo_pdf(pdf_path, width = width_cm / 2.54, height = height_cm / 2.54)
  grid.newpage()
  pushViewport(viewport(width = unit(width_cm, "cm"), height = unit(height_cm, "cm")))
  draw_framework_combo(summary, hc, pcoa_plot)
  popViewport()
  dev.off()

  if (requireNamespace("ragg", quietly = TRUE)) {
    ragg::agg_png(
      png_path, width = width_cm / 2.54, height = height_cm / 2.54,
      units = "in", res = dpi, background = "white"
    )
    grid.newpage()
    pushViewport(viewport(width = unit(width_cm, "cm"), height = unit(height_cm, "cm")))
    draw_framework_combo(summary, hc, pcoa_plot)
    popViewport()
    dev.off()
  } else {
    grDevices::png(
      png_path, width = width_cm / 2.54, height = height_cm / 2.54,
      units = "in", res = dpi, type = "cairo-png", bg = "white"
    )
    grid.newpage()
    pushViewport(viewport(width = unit(width_cm, "cm"), height = unit(height_cm, "cm")))
    draw_framework_combo(summary, hc, pcoa_plot)
    popViewport()
    dev.off()
  }
}

make_group_enclosures <- function(df, group_col, x_col, y_col, level = 0.68) {
  groups <- split(df, df[[group_col]])
  x_span <- max(diff(range(df[[x_col]], finite = TRUE)), 1e-8)
  y_span <- max(diff(range(df[[y_col]], finite = TRUE)), 1e-8)
  pad <- 0.050 * max(x_span, y_span)
  theta <- seq(0, 2 * pi, length.out = 121)

  pieces <- lapply(names(groups), function(group_name) {
    z <- groups[[group_name]]
    x <- z[[x_col]]
    y <- z[[y_col]]
    center <- c(mean(x), mean(y))

    if (nrow(z) >= 3L) {
      cov_xy <- cov(cbind(x, y))
      if (any(!is.finite(cov_xy)) || det(cov_xy) <= 1e-12) {
        rx <- max(sd(x), pad)
        ry <- max(sd(y), pad)
        coords <- cbind(center[1] + rx * cos(theta), center[2] + ry * sin(theta))
      } else {
        circle <- rbind(cos(theta), sin(theta))
        coords <- t(center + sqrt(qchisq(level, df = 2)) * chol(cov_xy) %*% circle)
      }
    } else if (nrow(z) == 2L) {
      dx <- diff(x)
      dy <- diff(y)
      angle <- atan2(dy, dx)
      half_len <- sqrt(dx^2 + dy^2) / 2 + pad * 0.65
      half_wid <- pad * 0.52
      local_x <- half_len * cos(theta)
      local_y <- half_wid * sin(theta)
      coords <- cbind(
        center[1] + local_x * cos(angle) - local_y * sin(angle),
        center[2] + local_x * sin(angle) + local_y * cos(angle)
      )
    } else {
      rx <- pad
      ry <- pad * y_span / max(x_span, 1e-8)
      coords <- cbind(center[1] + rx * cos(theta), center[2] + ry * sin(theta))
    }

    data.frame(
      group = group_name,
      enclosure_type = if (nrow(z) >= 3L) "ellipse" else "low_n",
      x = coords[, 1],
      y = coords[, 2],
      stringsAsFactors = FALSE
    )
  })
  do.call(rbind, pieces)
}

pieces <- split(dat, dat$genotype)
summary_rows <- lapply(pieces, function(z) {
  data.frame(
    genotype = z$genotype[[1]],
    primary_perturbation_target = first_nonblank(z$primary_perturbation_target),
    target_module = first_nonblank(z$target_module),
    expected_icat_effect = first_nonblank(z$expected_icat_effect),
    conoid_body_status = first_nonblank(z$conoid_body_status),
    apical_ring_status = first_nonblank(z[[apical_col]]),
    icmt_status = first_nonblank(z$icmt_status),
    bridge_status = first_nonblank(z$bridge_status),
    rhoptry_status = first_nonblank(z[[rhoptry_col]]),
    n_biological_replicates = length(unique(z$biological_replicate)),
    total_scored_cells = sum(z$scored_cells),
    intact_prop = mean(z$intact_prop),
    altered_prop = mean(z$altered_prop),
    lost_prop = mean(z$lost_prop),
    unscorable_prop = mean(z$unscorable_prop),
    conoid_body_score = mean_or_na(z$conoid_body_score),
    conoid_assembly_score = mean_or_na(z$conoid_assembly_score),
    conoid_position_score = mean_or_na(z$conoid_position_score),
    apical_ring_score = mean_or_na(z$apical_ring_score),
    icmt_score = mean_or_na(z$icmt_score),
    bridge_score = mean_or_na(z$bridge_score),
    rhoptry_score = mean_or_na(z$rhoptry_score),
    icat_abundance_score = mean_or_na(z$icat_abundance_score),
    wb_abundance_ratio = mean_or_na(z[[abundance_col]]),
    perturb_structures = I(list(normalize_perturbation_structures(
      first_nonblank(z$primary_perturbation_target),
      first_nonblank(z$target_module)
    ))),
    primary_targets = I(list(normalize_primary_target(
      first_nonblank(z$primary_perturbation_target)
    ))),
    stringsAsFactors = FALSE
  )
})
summary <- do.call(rbind, summary_rows)
rownames(summary) <- NULL
summary <- summary[match(fig3b_order, summary$genotype), , drop = FALSE]
if (anyNA(summary$genotype)) {
  stop("Some genotypes from fig3b_order are missing in the Excel input.")
}
if (!identical(summary$genotype, fig3b_order)) {
  stop("Summary rows are not in the requested dendrogram order.")
}
summary$genotype <- as.character(summary$genotype)
if (!any(is.finite(summary$wb_abundance_ratio))) {
  summary$expression_fraction <- rep(NA_real_, nrow(summary))
} else {
  wt_baseline <- mean(summary$wb_abundance_ratio[summary$genotype == "WT"], na.rm = TRUE)
  if (!is.finite(wt_baseline) || wt_baseline <= 0) {
    wt_baseline <- max(summary$wb_abundance_ratio, na.rm = TRUE)
  }
  summary$expression_fraction <- summary$wb_abundance_ratio / wt_baseline
  summary$expression_fraction[!is.finite(summary$expression_fraction)] <- NA_real_
  summary$expression_fraction <- pmin(pmax(summary$expression_fraction, 0), 1)
}

dominant_labels <- c("intact", "altered", "lost")
summary$dominant_icat_outcome <- apply(
  summary[, c("intact_prop", "altered_prop", "lost_prop")],
  1,
  function(x) {
    hits <- which(abs(x - max(x)) < 1e-10)
    if (length(hits) == 1L) dominant_labels[hits] else "mixed"
  }
)

# Two independent ILR coordinates preserve the three-part localization
# composition without placing three linearly dependent proportions in Gower space.
pseudocount <- 0.005
composition <- as.matrix(summary[, c("intact_prop", "altered_prop", "lost_prop")]) + pseudocount
composition <- composition / rowSums(composition)
summary$ilr_intact_vs_nonintact <- sqrt(2 / 3) * log(
  composition[, 1] / sqrt(composition[, 2] * composition[, 3])
)
summary$ilr_altered_vs_lost <- sqrt(1 / 2) * log(composition[, 2] / composition[, 3])

feature_names <- c(
  "ilr_intact_vs_nonintact", "ilr_altered_vs_lost",
  "conoid_body_score", "apical_ring_score", "icmt_score", "bridge_score",
  "icat_abundance_score", "wb_abundance_ratio"
)
features <- summary[, feature_names, drop = FALSE]
informative <- vapply(features, function(x) {
  finite <- x[is.finite(x)]
  length(finite) >= 2L && length(unique(finite)) > 1L
}, logical(1))
features <- features[, informative, drop = FALSE]
if (ncol(features) < 2L) {
  stop("At least two non-constant phenotype features are required for clustering.")
}
if (nrow(features) < 4L) {
  stop("At least four genotypes with completed measurements are required for clustering.")
}

rownames(features) <- summary$genotype
gower <- daisy(features, metric = "gower")
hc <- hclust(as.dist(gower), method = "average")
pcoa <- cmdscale(as.dist(gower), k = 2, eig = TRUE, add = TRUE)
pcoa_data <- data.frame(
  genotype = summary$genotype,
  PCoA1 = pcoa$points[, 1],
  PCoA2 = pcoa$points[, 2],
  target_module = summary$target_module,
  dominant_icat_outcome = summary$dominant_icat_outcome,
  stringsAsFactors = FALSE
)
pcoa_data$display_genotype <- display_genotype(pcoa_data$genotype)
pcoa_data$plot_label <- pcoa_plot_label(pcoa_data$genotype)

variance <- pmax(pcoa$eig, 0)
variance_percent <- 100 * variance / sum(variance)
outcome_colors <- c(
  intact = "#111111", altered = "#2F79B7", lost = "#D7301F", mixed = "#6A6A6A"
)
module_shapes <- c(
  control = 21, global_conoid = 22, icmt_associated = 23,
  bridge_inner_surface = 24, bridge_complex = 25, other = 21
)
missing_modules <- setdiff(unique(pcoa_data$target_module), names(module_shapes))
if (length(missing_modules)) module_shapes[missing_modules] <- 21
module_labels <- c(
  control = "control", global_conoid = "global conoid",
  icmt_associated = "ICMT", bridge_inner_surface = "bridge-inner",
  bridge_complex = "bridge", other = "other"
)
missing_module_labels <- setdiff(unique(pcoa_data$target_module), names(module_labels))
if (length(missing_module_labels)) module_labels[missing_module_labels] <- missing_module_labels
pcoa_enclosures <- make_group_enclosures(
  pcoa_data,
  group_col = "dominant_icat_outcome",
  x_col = "PCoA1",
  y_col = "PCoA2"
)

feature_sources <- c(
  ilr_intact_vs_nonintact = "Excel counts: intact_n, altered_n, lost_n",
  ilr_altered_vs_lost = "Excel counts: intact_n, altered_n, lost_n",
  conoid_body_score = "conoid_body_status",
  apical_ring_score = "apical_polar_ring_status/apical_ring_status",
  icmt_score = "icmt_status",
  bridge_score = "bridge_status",
  icat_abundance_score = "icat_total_signal_status",
  wb_abundance_ratio = "wb_abundance_ratio"
)
feature_descriptions <- c(
  ilr_intact_vs_nonintact = "ICAT apical retention versus altered/lost localization",
  ilr_altered_vs_lost = "Altered versus lost ICAT localization among non-intact cells",
  conoid_body_score = "Conoid body structural severity",
  apical_ring_score = "Conoid/apical position structural severity",
  icmt_score = "ICMT structural severity",
  bridge_score = "Fibrous material/bridge structural severity",
  icat_abundance_score = "IF-based ICAT abundance severity",
  wb_abundance_ratio = "Western blot ICAT abundance relative to WT"
)
coords <- pcoa$points[, 1:2, drop = FALSE]
colnames(coords) <- c("PCoA1", "PCoA2")
pcoa_feature_contribution <- do.call(rbind, lapply(names(features), function(feature_name) {
  values <- features[[feature_name]]
  ok <- is.finite(values)
  r1 <- suppressWarnings(cor(values[ok], coords[ok, "PCoA1"], method = "spearman"))
  r2 <- suppressWarnings(cor(values[ok], coords[ok, "PCoA2"], method = "spearman"))
  data.frame(
    feature = feature_name,
    excel_source = unname(feature_sources[feature_name]),
    interpretation = unname(feature_descriptions[feature_name]),
    spearman_r_PCoA1 = r1,
    spearman_r_PCoA2 = r2,
    abs_r_PCoA1 = abs(r1),
    abs_r_PCoA2 = abs(r2),
    stringsAsFactors = FALSE
  )
}))
pcoa_feature_contribution$PCoA1_percent <- 100 *
  pcoa_feature_contribution$abs_r_PCoA1 / sum(pcoa_feature_contribution$abs_r_PCoA1)
pcoa_feature_contribution$PCoA2_percent <- 100 *
  pcoa_feature_contribution$abs_r_PCoA2 / sum(pcoa_feature_contribution$abs_r_PCoA2)
pcoa_feature_contribution$combined_strength <- sqrt(
  pcoa_feature_contribution$abs_r_PCoA1^2 +
    pcoa_feature_contribution$abs_r_PCoA2^2
)
pcoa_feature_contribution$combined_percent <- 100 *
  pcoa_feature_contribution$combined_strength / sum(pcoa_feature_contribution$combined_strength)
pcoa_feature_contribution <- pcoa_feature_contribution[
  order(-pcoa_feature_contribution$combined_percent),
  c(
    "feature", "excel_source", "interpretation",
    "spearman_r_PCoA1", "spearman_r_PCoA2",
    "PCoA1_percent", "PCoA2_percent", "combined_percent"
  )
]

set.seed(20260711)
p_2d <- ggplot(pcoa_data, aes(PCoA1, PCoA2)) +
  geom_polygon(
    data = pcoa_enclosures,
    aes(x = x, y = y, fill = group, group = group),
    inherit.aes = FALSE,
    alpha = 0.040, color = NA,
    show.legend = FALSE
  ) +
  geom_path(
    data = pcoa_enclosures,
    aes(x = x, y = y, color = group, group = group),
    inherit.aes = FALSE,
    linewidth = 0.22, alpha = 0.55,
    show.legend = FALSE
  ) +
  geom_point(aes(color = dominant_icat_outcome),
             size = 1.45, stroke = 0, show.legend = FALSE) +
  geom_text_repel(
    aes(
      label = plot_label,
      color = dominant_icat_outcome
    ),
    size = ICAT_TEXT_SMALL_MM, parse = TRUE,
    box.padding = unit(0.18, "lines"),
    point.padding = unit(1.05, "lines"),
    min.segment.length = unit(0, "lines"),
    segment.color = "#8C8C8C",
    segment.size = 0.12,
    segment.alpha = 1,
    segment.curvature = 0,
    force = 35,
    force_pull = 0.08,
    max.overlaps = Inf,
    seed = 20260711,
    fontface = "plain",
    show.legend = FALSE
  ) +
  scale_color_manual(values = outcome_colors, drop = FALSE) +
  scale_fill_manual(values = outcome_colors, drop = FALSE) +
  scale_x_continuous(
    breaks = c(-0.5, 0, 0.5, 1.0),
    labels = function(x) formatC(x, format = "f", digits = 1),
    expand = expansion(mult = c(0.18, 0.08))
  ) +
  scale_y_continuous(
    breaks = c(-0.25, 0, 0.25, 0.50),
    labels = function(x) formatC(x, format = "f", digits = 2),
    expand = expansion(mult = c(0.14, 0.12))
  ) +
  labs(
    title = NULL,
    subtitle = NULL,
    x = paste0("PCoA1 (", round(variance_percent[1], 1), "% variance)"),
    y = paste0("PCoA2 (", round(variance_percent[2], 1), "% variance)"),
    color = "Dominant ICAT outcome"
  ) +
  coord_cartesian(clip = "off") +
  icat_theme_classic() +
  theme(
    axis.title.x = element_text(size = 6.2, margin = margin(t = 2)),
    axis.title.y = element_text(size = 6.2, margin = margin(r = 2)),
    axis.text = element_text(size = 6.0, color = "black"),
    axis.line = element_line(linewidth = 0.25, color = "black"),
    axis.ticks = element_line(linewidth = 0.25, color = "black"),
    legend.position = "none",
    plot.margin = margin(2.0, 2.4, 1.6, 1.8)
  )

stacked <- summary[, c("genotype", "intact_prop", "altered_prop", "lost_prop")]
stacked_long <- rbind(
  data.frame(genotype = stacked$genotype, outcome = "intact", proportion = stacked$intact_prop),
  data.frame(genotype = stacked$genotype, outcome = "altered", proportion = stacked$altered_prop),
  data.frame(genotype = stacked$genotype, outcome = "lost", proportion = stacked$lost_prop)
)
stacked_long$genotype <- factor(stacked_long$genotype, levels = hc$labels[hc$order])
stacked_long$outcome <- factor(stacked_long$outcome, levels = c("lost", "altered", "intact"))

p_stacked <- ggplot(stacked_long, aes(genotype, proportion, fill = outcome)) +
  geom_col(width = 0.72, color = "white", linewidth = 0.35) +
  scale_fill_manual(values = outcome_colors[c("lost", "altered", "intact")]) +
  scale_x_discrete(labels = display_genotype) +
  scale_y_continuous(labels = function(x) paste0(round(100 * x), "%"), expand = c(0, 0)) +
  labs(
    title = "ICAT localization outcomes",
    subtitle = "Genotypes ordered by the Gower dendrogram",
    x = NULL, y = "Mean cell fraction", fill = NULL
  ) +
  icat_theme_classic() +
  theme(
    plot.title = element_text(face = "bold"),
    axis.text.x = element_text(angle = 40, hjust = 1, size = ICAT_FONT_SMALL_PT),
    axis.title.y = element_text(size = ICAT_FONT_BODY_PT),
    legend.position = "top"
  )

ratio_rows <- lapply(split(dat, dat$genotype), function(z) {
  values <- z$intact_prop
  n_rep <- length(values)
  mean_value <- mean(values)
  if (n_rep >= 2L) {
    half_width <- qt(0.975, df = n_rep - 1L) * sd(values) / sqrt(n_rep)
  } else {
    half_width <- NA_real_
  }
  data.frame(
    genotype = z$genotype[[1]], n_biological_replicates = n_rep,
    intact_ratio_mean = mean_value,
    ci_low = ifelse(is.na(half_width), NA_real_, max(0, mean_value - half_width)),
    ci_high = ifelse(is.na(half_width), NA_real_, min(1, mean_value + half_width)),
    stringsAsFactors = FALSE
  )
})
ratio_summary <- do.call(rbind, ratio_rows)
rownames(ratio_summary) <- NULL
genotype_order <- hc$labels[hc$order]
dat$genotype_plot <- factor(dat$genotype, levels = rev(genotype_order))
ratio_summary$genotype_plot <- factor(
  ratio_summary$genotype, levels = rev(genotype_order)
)

p_ratio <- ggplot() +
  geom_errorbar(
    data = ratio_summary,
    aes(y = genotype_plot, xmin = ci_low, xmax = ci_high),
    width = 0, linewidth = ICAT_LINE_MM, color = "#4B4B4B",
    orientation = "y", na.rm = TRUE
  ) +
  geom_point(
    data = dat,
    aes(x = intact_prop, y = genotype_plot),
    shape = 21, size = 2.0, stroke = 0.45,
    fill = "white", color = "#5B9F63",
    position = position_jitter(height = 0.08, width = 0, seed = 17)
  ) +
  geom_point(
    data = ratio_summary,
    aes(x = intact_ratio_mean, y = genotype_plot),
    shape = 18, size = 2.8, color = "#5B9F63"
  ) +
  scale_x_continuous(
    limits = c(0, 1), breaks = seq(0, 1, 0.25),
    labels = function(x) paste0(round(100 * x), "%"),
    expand = expansion(mult = c(0.01, 0.03))
  ) +
  scale_y_discrete(labels = display_genotype) +
  labs(
    title = "Intact ICAT localization ratio",
    subtitle = "Biological replicates; mean ± 95% CI",
    x = "Cells with intact ICAT localization", y = NULL
  ) +
  icat_theme_classic() +
  theme(
    plot.title = element_text(face = "bold"),
    plot.subtitle = element_text(size = ICAT_FONT_SMALL_PT),
    axis.text.y = element_text(size = ICAT_FONT_SMALL_PT),
    axis.text.x = element_text(size = ICAT_FONT_SMALL_PT),
    plot.margin = margin(6, 8, 6, 6)
  )

severity_columns <- c(
  conoid_body_score = "Conoid body", apical_ring_score = "Apical ring",
  icmt_score = "ICMT", bridge_score = "Bridge",
  icat_abundance_score = "ICAT abundance"
)
heatmap_rows <- list()
for (column in names(severity_columns)) {
  heatmap_rows[[length(heatmap_rows) + 1L]] <- data.frame(
    genotype = summary$genotype,
    feature = severity_columns[[column]],
    severity = summary[[column]],
    stringsAsFactors = FALSE
  )
}
heatmap_data <- do.call(rbind, heatmap_rows)
heatmap_data$genotype <- factor(heatmap_data$genotype, levels = hc$labels[hc$order])
heatmap_data$feature <- factor(heatmap_data$feature, levels = rev(unname(severity_columns)))

p_heatmap <- ggplot(heatmap_data, aes(genotype, feature, fill = severity)) +
  geom_tile(color = "white", linewidth = 0.7) +
  geom_text(
    aes(label = ifelse(is.na(severity), "ND", sprintf("%.1f", severity))),
    size = ICAT_TEXT_BODY_MM
  ) +
  scale_fill_gradient2(
    low = "#E6E6E6", mid = "#D8C95A", high = "#E6613F",
    midpoint = 1, limits = c(0, 2), na.value = "#FFFFFF",
    breaks = c(0, 1, 2), labels = c("intact", "altered", "lost")
  ) +
  scale_x_discrete(labels = display_genotype) +
  labs(
    title = "Structural dependency matrix",
    subtitle = "Mean structural severity; Gower order",
    x = NULL, y = NULL, fill = "Mean severity"
  ) +
  icat_theme_classic() +
  theme(
    plot.title = element_text(face = "bold"),
    axis.text.x = element_text(angle = 40, hjust = 1, size = ICAT_FONT_SMALL_PT),
    axis.text.y = element_text(size = ICAT_FONT_SMALL_PT),
    axis.ticks = element_blank(),
    legend.position = "bottom",
    legend.title = element_text(size = ICAT_FONT_BODY_PT),
    legend.text = element_text(size = ICAT_FONT_SMALL_PT)
  ) +
  guides(fill = guide_colorbar(
    direction = "horizontal", title.position = "top",
    barwidth = unit(4.2, "cm"), barheight = unit(0.28, "cm")
  ))

ggsave(file.path(figure_dir, "Fig3B_2D_Gower_PCoA.pdf"), p_2d,
       width = 6 / 2.54, height = 3.3 / 2.54, device = cairo_pdf, bg = "white")
ggsave(file.path(figure_dir, "Fig3B_2D_Gower_PCoA.png"), p_2d,
       width = 6 / 2.54, height = 3.3 / 2.54, dpi = 600, bg = "white")
ggsave(file.path(figure_dir, "Fig3B_localization_stacked.pdf"), p_stacked,
       width = 10.5 / 2.54, height = 5.7 / 2.54, device = cairo_pdf, bg = "white")
ggsave(file.path(figure_dir, "Fig3B_localization_stacked.png"), p_stacked,
       width = 10.5 / 2.54, height = 5.7 / 2.54, dpi = 600, bg = "white")
ggsave(file.path(figure_dir, "Fig3B_intact_localization_ratio.pdf"), p_ratio,
       width = 8.5 / 2.54, height = 6.0 / 2.54, device = cairo_pdf, bg = "white")
ggsave(file.path(figure_dir, "Fig3B_intact_localization_ratio.png"), p_ratio,
       width = 8.5 / 2.54, height = 6.0 / 2.54, dpi = 600, bg = "white")
ggsave(file.path(figure_dir, "Fig3B_structural_dependency_heatmap.pdf"), p_heatmap,
       width = 10.5 / 2.54, height = 6.5 / 2.54, device = cairo_pdf, bg = "white")
ggsave(file.path(figure_dir, "Fig3B_structural_dependency_heatmap.png"), p_heatmap,
       width = 10.5 / 2.54, height = 6.5 / 2.54, dpi = 600, bg = "white")

save_combined_panel_B(
  summary = summary,
  hc = hc,
  pcoa_plot = p_2d,
  pdf_path = file.path(figure_dir, "Fig3B_combined_summary_PCoA.pdf"),
  png_path = file.path(figure_dir, "Fig3B_combined_summary_PCoA.png"),
  width_cm = 13.5,
  height_cm = 9.2,
  dpi = 600
)

save_framework_combo(
  summary = summary,
  hc = hc,
  pcoa_plot = p_2d,
  pdf_path = file.path(figure_dir, "Fig3B_framework_combo.pdf"),
  png_path = file.path(figure_dir, "Fig3B_framework_combo.png"),
  width_cm = 13.5,
  height_cm = 8.10,
  dpi = 600
)

pdf(file.path(figure_dir, "Fig3B_Gower_dendrogram.pdf"), width = 7, height = 4.8, pointsize = 9)
par(mar = c(5, 4, 3, 1), lwd = 2 / 3)
plot(hc, main = "Average-linkage clustering of Gower distances", xlab = "", sub = "", cex.main = 10 / 9)
dev.off()

write.csv(dat, file.path(table_dir, "IFA_processed_replicates.csv"), row.names = FALSE)
write.csv(summary, file.path(table_dir, "IFA_genotype_summary.csv"), row.names = FALSE)
write.csv(ratio_summary, file.path(table_dir, "IFA_intact_ratio_95CI.csv"), row.names = FALSE)
write.csv(pcoa_data, file.path(table_dir, "IFA_Gower_PCoA_coordinates.csv"), row.names = FALSE)
write.csv(
  pcoa_feature_contribution,
  file.path(table_dir, "IFA_PCoA_feature_contributions.csv"),
  row.names = FALSE
)
write.csv(as.matrix(gower), file.path(table_dir, "IFA_Gower_distance_matrix.csv"))
writeLines(
  c(
    "Clustering method: Gower distance with average-linkage hierarchical clustering.",
    "2D visualization: principal coordinates analysis (PCoA) of the same Gower distance matrix.",
    "Localization composition: intact/altered/lost transformed to two ILR coordinates with pseudocount 0.005.",
    "Feature contribution table: Spearman correlations between each input feature and PCoA coordinates; percentages are normalized absolute correlation strengths, not PCA loadings.",
    "Target module and expected ICAT effect are annotations only and are excluded from clustering.",
    paste("Features used:", paste(names(features), collapse = ", "))
  ),
  file.path(report_dir, "analysis_method.txt")
)

cat("Analysis complete.\n")
cat("Genotypes:", nrow(summary), "\n")
cat("Features used:", paste(names(features), collapse = ", "), "\n")
cat("Output:", normalizePath(output_root), "\n")
