#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(ggplot2)
  library(grid)
})

script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
script_path <- normalizePath(sub("^--file=", "", script_arg[[1]]), mustWork = TRUE)
code_dir <- dirname(script_path)
fig_dir <- normalizePath(file.path(code_dir, ".."), mustWork = TRUE)
find_project_root <- function(start_dir) {
  current <- normalizePath(start_dir, mustWork = TRUE)
  repeat {
    if (file.exists(file.path(current, "shared", "R", "plot_style.R"))) return(current)
    parent <- dirname(current)
    if (identical(parent, current)) stop("Could not locate project root from: ", start_dir)
    current <- parent
  }
}
project_root <- find_project_root(code_dir)
source(file.path(project_root, "shared", "R", "plot_style.R"))

FIG3_BASE_DIR <- fig_dir
source(file.path(code_dir, "spatial_relationship", "Figure3_spatial_relationship.R"))
source(file.path(code_dir, "localization_perturbation", "ICAT_localization_pertubation_analysis.R"))
source(file.path(code_dir, "Fig3B_icat_localization_panel.R"))
fig3b_data <- build_fig3b_figure(
  file.path(fig_dir, "01_raw_data", "localization_perturbation", "ICAT_localization_pertubation.xlsx")
)

final_dir <- file.path(fig_dir, "05_final_figure")
dir.create(final_dir, recursive = TRUE, showWarnings = FALSE)

panel_w <- c(A = 6.0, B = 10.0, C = 8.0, D = 8.0)
panel_h <- c(A = 8.0, B = 8.0, C = 7.5, D = 7.5)
gap_x <- 0.18
gap_y <- 0.22
margin_x <- 0.15
margin_y <- 0.15
page_w <- margin_x * 2 + panel_w["A"] + gap_x + panel_w["B"]
page_h <- margin_y * 2 + panel_h["A"] + gap_y + panel_h["C"]

panel_border <- "white"
label_gp <- gpar(fontfamily = "Arial", fontsize = 18, fontface = "bold", col = "black")
small_gp <- gpar(fontfamily = "Arial", fontsize = 8, col = "black")

draw_panel_letter <- function(letter, x = 0.02, y = 0.98) {
  grid.text(letter, x = unit(x, "npc"), y = unit(y, "npc"),
            just = c("left", "top"), gp = label_gp)
}

draw_panel_A_schematic <- function() {
  pushViewport(viewport(xscale = c(0, 1), yscale = c(0, 1)))
  grid.rect(gp = gpar(col = NA, fill = "white"))
  grid.text("A", x = unit(0.02, "npc"), y = unit(0.98, "npc"),
            just = c("left", "top"), gp = label_gp)

  # Conoid outline
  conoid_x <- c(0.18, 0.33, 0.44, 0.57, 0.70, 0.61, 0.57, 0.26, 0.18)
  conoid_y <- c(0.22, 0.22, 0.36, 0.36, 0.22, 0.62, 0.82, 0.82, 0.22)
  grid.polygon(
    x = unit(conoid_x, "npc"), y = unit(conoid_y, "npc"),
    gp = gpar(fill = "#FBFBFB", col = "#BFD0A7", lwd = 1.2)
  )

  # Interior stripes and features
  grid.segments(
    x0 = unit(c(0.29, 0.31, 0.33), "npc"),
    y0 = unit(c(0.30, 0.30, 0.30), "npc"),
    x1 = unit(c(0.29, 0.31, 0.33), "npc"),
    y1 = unit(c(0.76, 0.76, 0.76), "npc"),
    gp = gpar(col = c("#CFCFCF", "#63BE7B", "#63BE7B"), lwd = 1.3)
  )
  grid.segments(
    x0 = unit(c(0.35, 0.37, 0.39, 0.41), "npc"),
    y0 = unit(c(0.44, 0.43, 0.42, 0.41), "npc"),
    x1 = unit(c(0.41, 0.43, 0.45, 0.47), "npc"),
    y1 = unit(c(0.68, 0.67, 0.66, 0.65), "npc"),
    gp = gpar(col = c("#F0BE5B", "#F0BE5B", "#F0BE5B", "#F0BE5B"), lwd = 0.9)
  )
  grid.circle(
    x = unit(c(0.24, 0.25, 0.26, 0.27), "npc"),
    y = unit(c(0.32, 0.40, 0.48, 0.56), "npc"),
    r = unit(0.028, "npc"),
    gp = gpar(fill = "#D9D9D9", col = "#C0C0C0", lwd = 0.4)
  )
  grid.circle(x = unit(0.50, "npc"), y = unit(0.52, "npc"), r = unit(0.035, "npc"),
              gp = gpar(fill = "#E5B2D7", col = "#DA8AC3", lwd = 0.5))
  grid.segments(
    x0 = unit(0.62, "npc"), y0 = unit(0.30, "npc"),
    x1 = unit(0.62, "npc"), y1 = unit(0.78, "npc"),
    gp = gpar(col = "#D82FD3", lwd = 3.2, lineend = "round")
  )
  grid.segments(
    x0 = unit(0.58, "npc"), y0 = unit(0.36, "npc"),
    x1 = unit(0.59, "npc"), y1 = unit(0.70, "npc"),
    gp = gpar(col = "#9E3FBF", lwd = 1.8, lineend = "round")
  )

  grid.text("microneme", x = unit(0.50, "npc"), y = unit(0.93, "npc"),
            gp = gpar(fontfamily = "Arial", fontsize = 9, col = "#B080D0"))
  grid.segments(x0 = unit(0.51, "npc"), y0 = unit(0.90, "npc"),
                x1 = unit(0.52, "npc"), y1 = unit(0.74, "npc"),
                gp = gpar(col = "#7F7F7F", lwd = 1.0, arrow = arrow(type = "closed", length = unit(0.12, "inches"))))

  grid.text("rhoptries", x = unit(0.12, "npc"), y = unit(0.18, "npc"),
            just = "left", gp = gpar(fontfamily = "Arial", fontsize = 8.5, col = "#B96B41"))
  grid.text("ICMTs", x = unit(0.12, "npc"), y = unit(0.08, "npc"),
            just = "left", gp = gpar(fontfamily = "Arial", fontsize = 8.5, col = "#4E8862"))
  grid.text("Fibrous material (Fm)", x = unit(0.12, "npc"), y = unit(0.00, "npc"),
            just = "left", gp = gpar(fontfamily = "Arial", fontsize = 8.5, col = "#F2BE56"))
  grid.text("ICAT", x = unit(0.72, "npc"), y = unit(0.06, "npc"),
            just = "left", gp = gpar(fontfamily = "Arial", fontsize = 9, col = "#F05DE8"))
  grid.text("L", x = unit(0.08, "npc"), y = unit(0.48, "npc"),
            gp = gpar(fontfamily = "Arial", fontsize = 10, col = "#666666"))
  grid.text("R", x = unit(0.72, "npc"), y = unit(0.48, "npc"),
            gp = gpar(fontfamily = "Arial", fontsize = 10, col = "#666666"))
  popViewport()
}

draw_panel_A <- function(p_bridge) {
  pushViewport(viewport(xscale = c(0, 1), yscale = c(0, 1)))
  # top schematic
  pushViewport(viewport(x = unit(0, "npc"), y = unit(0.60, "npc"),
                        width = unit(1, "npc"), height = unit(0.40, "npc"),
                        just = c("left", "bottom")))
  draw_panel_A_schematic()
  popViewport()

  # lower coordinate plot
  pushViewport(viewport(x = unit(0, "npc"), y = unit(0, "npc"),
                        width = unit(1, "npc"), height = unit(0.60, "npc"),
                        just = c("left", "bottom")))
  grid.draw(ggplotGrob(p_bridge))
  popViewport()
  popViewport()
}

draw_panel_D <- function(p_position, p_gap) {
  pushViewport(viewport(xscale = c(0, 1), yscale = c(0, 1)))
  left_w <- 0.50
  gap <- 0.02
  pushViewport(viewport(x = unit(0, "npc"), y = unit(0, "npc"),
                        width = unit(left_w - gap, "npc"), height = unit(1, "npc"),
                        just = c("left", "bottom")))
  grid.draw(ggplotGrob(p_position))
  popViewport()
  pushViewport(viewport(x = unit(left_w + gap, "npc"), y = unit(0, "npc"),
                        width = unit(1 - left_w - gap, "npc"), height = unit(1, "npc"),
                        just = c("left", "bottom")))
  grid.draw(ggplotGrob(p_gap))
  popViewport()
  popViewport()
}

grDevices::cairo_pdf(
  file.path(final_dir, "Figure3_ICAT_neighboring.pdf"),
  width = page_w / 2.54, height = page_h / 2.54
)
grid.newpage()
pushViewport(viewport(width = unit(page_w, "cm"), height = unit(page_h, "cm")))

vp_A <- viewport(
  x = unit(margin_x, "cm"),
  y = unit(page_h - margin_y - panel_h["A"], "cm"),
  width = unit(panel_w["A"], "cm"),
  height = unit(panel_h["A"], "cm"),
  just = c("left", "bottom")
)
vp_B <- viewport(
  x = unit(margin_x + panel_w["A"] + gap_x, "cm"),
  y = unit(page_h - margin_y - panel_h["B"], "cm"),
  width = unit(panel_w["B"], "cm"),
  height = unit(panel_h["B"], "cm"),
  just = c("left", "bottom")
)
vp_C <- viewport(
  x = unit(margin_x, "cm"),
  y = unit(margin_y, "cm"),
  width = unit(panel_w["C"], "cm"),
  height = unit(panel_h["C"], "cm"),
  just = c("left", "bottom")
)
vp_D <- viewport(
  x = unit(margin_x + panel_w["C"] + gap_x, "cm"),
  y = unit(margin_y, "cm"),
  width = unit(panel_w["D"], "cm"),
  height = unit(panel_h["D"], "cm"),
  just = c("left", "bottom")
)

pushViewport(vp_A)
draw_panel_A(p_bridge)
popViewport()

pushViewport(vp_B)
draw_panel_B_summary(fig3b_data$summary, fig3b_data$hc, genotype_order = fig3b_order)
popViewport()

pushViewport(vp_C)
grid.text("C", x = unit(0.02, "npc"), y = unit(0.98, "npc"),
          just = c("left", "top"), gp = label_gp)
grid.draw(ggplotGrob(p_2d))
popViewport()

pushViewport(vp_D)
grid.text("D", x = unit(0.02, "npc"), y = unit(0.98, "npc"),
          just = c("left", "top"), gp = label_gp)
draw_panel_D(p_position, p_gap)
popViewport()

popViewport()
dev.off()

ragg::agg_png(
  file.path(final_dir, "Figure3_ICAT_neighboring.png"),
  width = page_w / 2.54, height = page_h / 2.54, units = "in", res = 600, background = "white"
)
grid.newpage()
pushViewport(viewport(width = unit(page_w, "cm"), height = unit(page_h, "cm")))
pushViewport(vp_A)
draw_panel_A(p_bridge)
popViewport()
pushViewport(vp_B)
draw_panel_B_summary(fig3b_data$summary, fig3b_data$hc, genotype_order = fig3b_order)
popViewport()
pushViewport(vp_C)
grid.text("C", x = unit(0.02, "npc"), y = unit(0.98, "npc"),
          just = c("left", "top"), gp = label_gp)
grid.draw(ggplotGrob(p_2d))
popViewport()
pushViewport(vp_D)
grid.text("D", x = unit(0.02, "npc"), y = unit(0.98, "npc"),
          just = c("left", "top"), gp = label_gp)
draw_panel_D(p_position, p_gap)
popViewport()
popViewport()
dev.off()

cat("Assembled Figure 3 written to:", normalizePath(final_dir), "\n")
