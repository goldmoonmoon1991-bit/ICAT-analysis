#!/usr/bin/env Rscript

script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
script_path <- normalizePath(sub("^--file=", "", script_arg[[1]]), mustWork = TRUE)
code_dir <- dirname(script_path)
fig_dir <- normalizePath(file.path(code_dir, "..", ".."), mustWork = TRUE)
project_root <- normalizePath(file.path(fig_dir, ".."), mustWork = TRUE)
renv_lib <- file.path(project_root, "renv", "library", "macos", "R-4.5", "aarch64-apple-darwin24.4.0")
if (dir.exists(renv_lib)) {
  .libPaths(c(renv_lib, .libPaths()))
}
source(file.path(project_root, "shared", "R", "project_library.R"))
icat_activate_project_library(project_root)

suppressPackageStartupMessages({
  library(dplyr)
  library(readr)
  library(stringr)
  library(tidyr)
})

fig6_dir <- file.path(project_root, "Fig6_ICAT_interactome")
raw_microneme_dir <- file.path(fig6_dir, "01_raw_data", "microneme_protein")
processed_dir <- file.path(fig6_dir, "02_processed_data", "interactome")
table_dir <- file.path(fig6_dir, "04_results", "tables", "interactome")
report_dir <- file.path(fig6_dir, "04_results", "reports", "interactome")

analysis_name <- "microneme_internal_preference_diagnostics"
analysis_table_dir <- file.path(table_dir, analysis_name)
analysis_report_dir <- file.path(report_dir, analysis_name)
dir.create(analysis_table_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(analysis_report_dir, recursive = TRUE, showWarnings = FALSE)

internal_file <- file.path(raw_microneme_dir, "microneme_internal_genes.csv")
construct_preference_file <- file.path(
  table_dir,
  "ICAT_construct_preference",
  "Figure6_ICAT_list_driven_construct_heatmap_subgroup_brackets_right_labels_rawFC_checked_HOOK_plotted_proteins.csv"
)
full_wide_file <- file.path(processed_dir, "Figure6_interactome_wide_source_data.csv")
n_term_file <- file.path(
  table_dir,
  "ICAT_N_term_TurboID",
  "Figure6_ICAT_N_term_quantified_proteins_annotated.csv"
)

required_files <- c(internal_file, construct_preference_file, full_wide_file, n_term_file)
missing_files <- required_files[!file.exists(required_files)]
if (length(missing_files)) {
  stop("Missing required input files: ", paste(missing_files, collapse = ", "))
}

clean_gene_id <- function(x) {
  x %>%
    as.character() %>%
    str_replace("^\ufeff", "") %>%
    str_squish()
}

safe_ratio <- function(bait1, ctrl1, bait2, ctrl2, pseudocount) {
  rowMeans(
    cbind(
      log2((bait1 + pseudocount) / (ctrl1 + pseudocount)),
      log2((bait2 + pseudocount) / (ctrl2 + pseudocount))
    ),
    na.rm = TRUE
  )
}

internal_list <- readr::read_csv(internal_file, show_col_types = FALSE) %>%
  transmute(
    gene = clean_gene_id(Gene_ID),
    protein_label = str_squish(as.character(Gene_Name))
  ) %>%
  filter(!is.na(gene), gene != "") %>%
  distinct(gene, .keep_all = TRUE) %>%
  mutate(
    curation_note = if_else(gene == "TGME49_289100", "excluded_from_internal: MIC18/HOOK curated as surface", "curated_internal")
  )

internal_for_diagnostic <- internal_list %>%
  filter(gene != "TGME49_289100")

construct_pref <- readr::read_csv(construct_preference_file, show_col_types = FALSE) %>%
  mutate(gene = clean_gene_id(gene)) %>%
  select(
    gene,
    heatmap_label = protein_label,
    heatmap_broad_class = broad_class,
    icat_n_log2,
    icat_n_percentile,
    icat_n_quantified,
    full_length_log2,
    full_length_percentile,
    full_length_quantified,
    quantified_both,
    preference_delta_FL_minus_N,
    preference_label,
    bias_score,
    preferred_raw_log2,
    bias_negative_raw_preferred,
    bias_label,
    bias_display_score
  )

full_wide <- readr::read_csv(full_wide_file, show_col_types = FALSE) %>%
  mutate(gene = clean_gene_id(gene))
n_term <- readr::read_csv(n_term_file, show_col_types = FALSE) %>%
  mutate(gene = clean_gene_id(gene))

full_cols <- c(
  "normalized_total_spectra_exp1_control",
  "normalized_total_spectra_exp1_rapa",
  "normalized_total_spectra_exp2_control",
  "normalized_total_spectra_exp2_rapa"
)
n_cols <- c("PG1", "PG2", "PG3", "PG4")

full_pc <- min(as.matrix(full_wide[, full_cols])[as.matrix(full_wide[, full_cols]) > 0], na.rm = TRUE) / 2
n_pc <- min(as.matrix(n_term[, n_cols])[as.matrix(n_term[, n_cols]) > 0], na.rm = TRUE) / 2

full_quant <- full_wide %>%
  transmute(
    gene,
    FL_control_exp1 = normalized_total_spectra_exp1_control,
    FL_bait_exp1 = normalized_total_spectra_exp1_rapa,
    FL_control_exp2 = normalized_total_spectra_exp2_control,
    FL_bait_exp2 = normalized_total_spectra_exp2_rapa,
    FL_control_total = FL_control_exp1 + FL_control_exp2,
    FL_bait_total = FL_bait_exp1 + FL_bait_exp2,
    FL_total_signal = FL_control_total + FL_bait_total,
    FL_detected_samples = (FL_control_exp1 > 0) + (FL_bait_exp1 > 0) + (FL_control_exp2 > 0) + (FL_bait_exp2 > 0),
    FL_bait_detected_reps = (FL_bait_exp1 > 0) + (FL_bait_exp2 > 0),
    FL_control_detected_reps = (FL_control_exp1 > 0) + (FL_control_exp2 > 0),
    FL_exp1_log2 = log2((FL_bait_exp1 + full_pc) / (FL_control_exp1 + full_pc)),
    FL_exp2_log2 = log2((FL_bait_exp2 + full_pc) / (FL_control_exp2 + full_pc)),
    FL_positive_reps = (FL_exp1_log2 > 0) + (FL_exp2_log2 > 0),
    FL_abs_replicate_delta = abs(FL_exp1_log2 - FL_exp2_log2),
    FL_pc_sensitivity = abs(
      safe_ratio(FL_bait_exp1, FL_control_exp1, FL_bait_exp2, FL_control_exp2, full_pc * 2) -
        safe_ratio(FL_bait_exp1, FL_control_exp1, FL_bait_exp2, FL_control_exp2, full_pc / 2)
    ),
    FL_unique_peptide_total = rowSums(
      cbind(
        unique_peptide_count_exp1_control,
        unique_peptide_count_exp1_rapa,
        unique_peptide_count_exp2_control,
        unique_peptide_count_exp2_rapa
      ),
      na.rm = TRUE
    )
  )

n_quant <- n_term %>%
  transmute(
    gene,
    N_cyto_exp1 = PG1,
    N_bait_exp1 = PG2,
    N_cyto_exp2 = PG3,
    N_bait_exp2 = PG4,
    N_cyto_total = N_cyto_exp1 + N_cyto_exp2,
    N_bait_total = N_bait_exp1 + N_bait_exp2,
    N_total_signal = N_cyto_total + N_bait_total,
    N_detected_samples = (N_cyto_exp1 > 0) + (N_bait_exp1 > 0) + (N_cyto_exp2 > 0) + (N_bait_exp2 > 0),
    N_bait_detected_reps = (N_bait_exp1 > 0) + (N_bait_exp2 > 0),
    N_cyto_detected_reps = (N_cyto_exp1 > 0) + (N_cyto_exp2 > 0),
    N_exp1_log2 = log2((N_bait_exp1 + n_pc) / (N_cyto_exp1 + n_pc)),
    N_exp2_log2 = log2((N_bait_exp2 + n_pc) / (N_cyto_exp2 + n_pc)),
    N_positive_reps = (N_exp1_log2 > 0) + (N_exp2_log2 > 0),
    N_abs_replicate_delta = abs(N_exp1_log2 - N_exp2_log2),
    N_pc_sensitivity = abs(
      safe_ratio(N_bait_exp1, N_cyto_exp1, N_bait_exp2, N_cyto_exp2, n_pc * 2) -
        safe_ratio(N_bait_exp1, N_cyto_exp1, N_bait_exp2, N_cyto_exp2, n_pc / 2)
    )
  )

diagnostic <- internal_for_diagnostic %>%
  left_join(construct_pref, by = "gene") %>%
  left_join(full_quant, by = "gene") %>%
  left_join(n_quant, by = "gene") %>%
  mutate(
    in_construct_heatmap = !is.na(heatmap_label),
    icat_n_quantified = coalesce(icat_n_quantified, FALSE),
    full_length_quantified = coalesce(full_length_quantified, FALSE),
    quantified_both = coalesce(quantified_both, FALSE),
    preferred_bait = case_when(
      !in_construct_heatmap ~ "not_plotted",
      quantified_both & is.finite(preference_delta_FL_minus_N) & preference_delta_FL_minus_N > 0.20 ~ "FL",
      quantified_both & is.finite(preference_delta_FL_minus_N) & preference_delta_FL_minus_N < -0.20 ~ "N",
      quantified_both ~ "balanced",
      full_length_quantified & !icat_n_quantified ~ "FL_only",
      icat_n_quantified & !full_length_quantified ~ "N_only",
      TRUE ~ "not_quantified"
    ),
    preferred_total_signal = case_when(
      preferred_bait %in% c("FL", "FL_only") ~ FL_total_signal,
      preferred_bait %in% c("N", "N_only") ~ N_total_signal,
      TRUE ~ NA_real_
    ),
    preferred_bait_signal = case_when(
      preferred_bait %in% c("FL", "FL_only") ~ FL_bait_total,
      preferred_bait %in% c("N", "N_only") ~ N_bait_total,
      TRUE ~ NA_real_
    ),
    preferred_detected_reps = case_when(
      preferred_bait %in% c("FL", "FL_only") ~ FL_bait_detected_reps,
      preferred_bait %in% c("N", "N_only") ~ N_bait_detected_reps,
      TRUE ~ NA_real_
    ),
    preferred_positive_reps = case_when(
      preferred_bait %in% c("FL", "FL_only") ~ FL_positive_reps,
      preferred_bait %in% c("N", "N_only") ~ N_positive_reps,
      TRUE ~ NA_real_
    ),
    preferred_pc_sensitivity = case_when(
      preferred_bait %in% c("FL", "FL_only") ~ FL_pc_sensitivity,
      preferred_bait %in% c("N", "N_only") ~ N_pc_sensitivity,
      TRUE ~ NA_real_
    ),
    single_bait_only_flag = preferred_bait %in% c("FL_only", "N_only"),
    negative_preferred_raw_flag = coalesce(bias_negative_raw_preferred, FALSE),
    low_preferred_signal_flag = is.finite(preferred_bait_signal) & preferred_bait_signal < 5,
    one_rep_preferred_detection_flag = is.finite(preferred_detected_reps) & preferred_detected_reps < 2,
    one_rep_positive_flag = is.finite(preferred_positive_reps) & preferred_positive_reps < 2,
    pseudocount_sensitive_flag = is.finite(preferred_pc_sensitivity) & preferred_pc_sensitivity > 0.5,
    evidence_class = case_when(
      !in_construct_heatmap ~ "not plotted / not quantified",
      negative_preferred_raw_flag ~ "artifact-likely: preferred raw log2FC < 0",
      single_bait_only_flag ~ "weak: single-bait-only preference",
      low_preferred_signal_flag | one_rep_preferred_detection_flag | pseudocount_sensitive_flag ~ "weak: low-signal or pseudocount-sensitive",
      one_rep_positive_flag ~ "partial: not positive in both preferred-bait replicates",
      preferred_bait == "balanced" ~ "balanced / no directional preference",
      TRUE ~ "supported by positive raw log2FC"
    ),
    possibility4_assessment = case_when(
      evidence_class %in% c(
        "artifact-likely: preferred raw log2FC < 0",
        "weak: single-bait-only preference",
        "weak: low-signal or pseudocount-sensitive",
        "partial: not positive in both preferred-bait replicates"
      ) ~ "consistent_with_possibility_4",
      evidence_class == "supported by positive raw log2FC" ~ "not_explained_by_possibility_4_alone",
      evidence_class == "balanced / no directional preference" ~ "no_directional_bias_to_explain",
      TRUE ~ "not_assessable"
    )
  ) %>%
  arrange(
    factor(possibility4_assessment, levels = c(
      "consistent_with_possibility_4",
      "not_explained_by_possibility_4_alone",
      "no_directional_bias_to_explain",
      "not_assessable"
    )),
    preferred_bait,
    protein_label
  )

summary_table <- diagnostic %>%
  count(possibility4_assessment, evidence_class, name = "n") %>%
  arrange(desc(n), possibility4_assessment)

plotted_summary <- diagnostic %>%
  filter(in_construct_heatmap) %>%
  summarise(
    internal_plotted_n = n(),
    directional_or_single_bait_n = sum(preferred_bait != "balanced", na.rm = TRUE),
    possibility4_consistent_n = sum(possibility4_assessment == "consistent_with_possibility_4", na.rm = TRUE),
    supported_positive_raw_n = sum(evidence_class == "supported by positive raw log2FC", na.rm = TRUE),
    balanced_n = sum(evidence_class == "balanced / no directional preference", na.rm = TRUE),
    negative_preferred_raw_n = sum(negative_preferred_raw_flag, na.rm = TRUE),
    single_bait_only_n = sum(single_bait_only_flag, na.rm = TRUE)
  )

readr::write_csv(
  diagnostic,
  file.path(analysis_table_dir, "Figure6_microneme_internal_preference_possibility4_diagnostics.csv")
)
readr::write_csv(
  summary_table,
  file.path(analysis_table_dir, "Figure6_microneme_internal_preference_possibility4_summary.csv")
)
readr::write_csv(
  plotted_summary,
  file.path(analysis_table_dir, "Figure6_microneme_internal_preference_possibility4_plotted_summary.csv")
)

internal_lines <- diagnostic %>%
  filter(in_construct_heatmap) %>%
  transmute(
    line = paste0(
      "- ", protein_label,
      " (", gene, "): preferred=", preferred_bait,
      "; FL log2=", ifelse(is.finite(full_length_log2), round(full_length_log2, 2), "NA"),
      "; N log2=", ifelse(is.finite(icat_n_log2), round(icat_n_log2, 2), "NA"),
      "; assessment=", evidence_class,
      "."
    )
  ) %>%
  pull(line)

report_lines <- c(
  "# Microneme Internal Bait-Preference Diagnostic",
  "",
  "## Question",
  "",
  "This diagnostic tests whether apparent bait-preference among curated microneme-internal proteins can be explained by possibility 4: low abundance, missing values, single-bait detection, negative raw enrichment, or pseudocount-sensitive ratios.",
  "",
  "MIC18/HOOK (TGME49_289100) was excluded from the microneme-internal diagnostic because it was manually curated as microneme-surface in the current construct heatmap.",
  "",
  "## Key Rule",
  "",
  "A bait preference was considered weak or artifact-prone when the apparent preferred bait had negative raw log2FC, was quantified in only one bait dataset, had low preferred-bait spectral evidence, was detected in only one preferred-bait replicate, was not positive in both preferred-bait replicates, or was pseudocount-sensitive.",
  "",
  "## Plotted Internal Proteins",
  "",
  internal_lines,
  "",
  "## Summary",
  "",
  paste(capture.output(print(plotted_summary)), collapse = "\n"),
  "",
  "## Output Tables",
  "",
  paste0("- Full diagnostic table: `", file.path(analysis_table_dir, "Figure6_microneme_internal_preference_possibility4_diagnostics.csv"), "`"),
  paste0("- Summary table: `", file.path(analysis_table_dir, "Figure6_microneme_internal_preference_possibility4_summary.csv"), "`")
)

writeLines(
  report_lines,
  file.path(analysis_report_dir, "Figure6_microneme_internal_preference_possibility4_report.md")
)

message("Microneme internal preference diagnostic completed.")
message("Tables: ", analysis_table_dir)
message("Report: ", analysis_report_dir)
