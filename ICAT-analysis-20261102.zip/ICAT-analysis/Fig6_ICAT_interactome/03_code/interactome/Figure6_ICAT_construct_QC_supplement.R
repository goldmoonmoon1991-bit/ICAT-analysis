#!/usr/bin/env Rscript

script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
script_path <- normalizePath(sub("^--file=", "", script_arg[[1]]), mustWork = TRUE)
code_dir <- dirname(script_path)
fig_dir <- normalizePath(file.path(code_dir, "..", ".."), mustWork = TRUE)
project_root <- normalizePath(file.path(fig_dir, ".."), mustWork = TRUE)
renv_lib <- file.path(project_root, "renv", "library", "macos", "R-4.5", "aarch64-apple-darwin24.4.0")
if (dir.exists(renv_lib)) {
  .libPaths(c(renv_lib, .libPaths()))
}
source(file.path(project_root, "shared", "R", "project_library.R"))
source(file.path(project_root, "shared", "R", "plot_style.R"))
icat_activate_project_library(project_root)

suppressPackageStartupMessages({
  library(dplyr)
  library(ggplot2)
  library(patchwork)
  library(readr)
  library(scales)
  library(stringr)
  library(tidyr)
})

processed_dir <- file.path(fig_dir, "02_processed_data", "interactome")
table_dir <- file.path(fig_dir, "04_results", "tables", "interactome")
report_dir <- file.path(fig_dir, "04_results", "reports", "interactome")
figure_dir <- file.path(fig_dir, "04_results", "figures", "interactome")
legend_dir <- file.path(fig_dir, "04_results", "legends")

analysis_name <- "ICAT_construct_QC_supplement"
analysis_table_dir <- file.path(table_dir, analysis_name)
analysis_report_dir <- file.path(report_dir, analysis_name)
analysis_figure_dir <- file.path(figure_dir, analysis_name)

dir.create(analysis_table_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(analysis_report_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(analysis_figure_dir, "pdf"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(analysis_figure_dir, "png"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(analysis_figure_dir, "svg"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(analysis_figure_dir, "tiff"), recursive = TRUE, showWarnings = FALSE)
dir.create(legend_dir, recursive = TRUE, showWarnings = FALSE)

full_wide_file <- file.path(processed_dir, "Figure6_interactome_wide_source_data.csv")
n_term_file <- file.path(
  table_dir,
  "ICAT_N_term_TurboID",
  "Figure6_ICAT_N_term_quantified_proteins_annotated.csv"
)
construct_heatmap_file <- file.path(
  table_dir,
  "ICAT_construct_preference",
  "Figure6_ICAT_list_driven_construct_heatmap_subgroup_brackets_right_labels_rawFC_checked_HOOK_plotted_proteins.csv"
)

required_files <- c(full_wide_file, n_term_file, construct_heatmap_file)
missing_files <- required_files[!file.exists(required_files)]
if (length(missing_files)) {
  stop("Missing required input files: ", paste(missing_files, collapse = ", "))
}

theme_set(
  theme_classic(base_size = 6.5, base_family = "Arial") +
    theme(
      axis.line = element_line(linewidth = 0.28, colour = "black"),
      axis.ticks = element_line(linewidth = 0.25, colour = "black"),
      axis.text = element_text(size = 5.7, colour = "black"),
      axis.title = element_text(size = 6.2, colour = "black"),
      legend.position = "top",
      legend.title = element_text(size = 5.8),
      legend.text = element_text(size = 5.4),
      panel.grid = element_blank(),
      plot.title = element_text(size = 7.2, face = "bold", hjust = 0),
      plot.title.position = "plot",
      strip.background = element_rect(fill = "white", colour = "black", linewidth = 0.3),
      strip.text = element_text(size = 6.2, face = "bold", colour = "#2F3438")
    )
)

sample_meta <- tibble::tribble(
  ~dataset_id, ~dataset_label, ~sample_col, ~sample_label, ~replicate, ~condition, ~condition_label, ~sample_order,
  "ICAT_FL", "Full-length ICAT", "normalized_total_spectra_exp1_control", "FL exp1 ctrl", "exp1", "control", "Control", 1,
  "ICAT_FL", "Full-length ICAT", "normalized_total_spectra_exp1_rapa", "FL exp1 rapa", "exp1", "bait", "Rapalog", 2,
  "ICAT_FL", "Full-length ICAT", "normalized_total_spectra_exp2_control", "FL exp2 ctrl", "exp2", "control", "Control", 3,
  "ICAT_FL", "Full-length ICAT", "normalized_total_spectra_exp2_rapa", "FL exp2 rapa", "exp2", "bait", "Rapalog", 4,
  "ICAT_N", "ICAT N-term", "PG1", "N exp1 cyto", "exp1", "control", "Cytosolic", 1,
  "ICAT_N", "ICAT N-term", "PG2", "N exp1 bait", "exp1", "bait", "ICAT N", 2,
  "ICAT_N", "ICAT N-term", "PG3", "N exp2 cyto", "exp2", "control", "Cytosolic", 3,
  "ICAT_N", "ICAT N-term", "PG4", "N exp2 bait", "exp2", "bait", "ICAT N", 4
)

full_wide <- readr::read_csv(full_wide_file, show_col_types = FALSE) %>%
  mutate(
    feature_id = paste0("FL_", row_id),
    gene = as.character(gene)
  )

n_term <- readr::read_csv(n_term_file, show_col_types = FALSE) %>%
  mutate(
    feature_id = paste0("N_", row_number()),
    gene = as.character(gene)
  )

construct_heatmap <- readr::read_csv(construct_heatmap_file, show_col_types = FALSE)

make_sample_long <- function(data, dataset_id, feature_col = "feature_id") {
  cols <- sample_meta %>%
    filter(dataset_id == .env$dataset_id) %>%
    pull(sample_col)

  data %>%
    select(feature_id = all_of(feature_col), gene, all_of(cols)) %>%
    pivot_longer(
      cols = all_of(cols),
      names_to = "sample_col",
      values_to = "normalized_spectra"
    ) %>%
    mutate(
      dataset_id = .env$dataset_id,
      normalized_spectra = replace_na(normalized_spectra, 0)
    ) %>%
    left_join(sample_meta, by = c("dataset_id", "sample_col"))
}

full_long <- make_sample_long(full_wide, "ICAT_FL")
n_long <- make_sample_long(n_term, "ICAT_N")

sample_long <- bind_rows(full_long, n_long) %>%
  mutate(
    dataset_label = factor(dataset_label, levels = c("Full-length ICAT", "ICAT N-term")),
    condition_label = factor(condition_label, levels = c("Control", "Rapalog", "Cytosolic", "ICAT N")),
    sample_label = factor(sample_label, levels = sample_meta$sample_label)
  )

sample_qc <- sample_long %>%
  group_by(dataset_id, dataset_label, sample_col, sample_label, replicate, condition, condition_label, sample_order) %>%
  summarise(
    total_normalized_spectra = sum(normalized_spectra, na.rm = TRUE),
    proteins_detected = sum(normalized_spectra > 0, na.rm = TRUE),
    median_spectra_detected = median(normalized_spectra[normalized_spectra > 0], na.rm = TRUE),
    upper_quartile_spectra_detected = quantile(normalized_spectra[normalized_spectra > 0], 0.75, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  arrange(dataset_id, sample_order)

make_correlation_table <- function(data, dataset_id) {
  meta <- sample_meta %>%
    filter(dataset_id == .env$dataset_id) %>%
    arrange(sample_order)
  cols <- meta$sample_col
  values <- data %>%
    select(all_of(cols)) %>%
    mutate(across(everything(), ~ replace_na(.x, 0)))
  nonzero <- unlist(values, use.names = FALSE)
  nonzero <- nonzero[is.finite(nonzero) & nonzero > 0]
  pseudocount <- min(nonzero, na.rm = TRUE) / 2
  mat <- log2(as.matrix(values) + pseudocount)
  cors <- cor(mat, method = "pearson", use = "pairwise.complete.obs")
  as.data.frame(as.table(cors), stringsAsFactors = FALSE) %>%
    transmute(
      dataset_id,
      sample_x_col = Var1,
      sample_y_col = Var2,
      pearson_r = Freq
    ) %>%
    left_join(
      meta %>% select(sample_x_col = sample_col, sample_x = sample_label, x_order = sample_order),
      by = "sample_x_col"
    ) %>%
    left_join(
      meta %>% select(sample_y_col = sample_col, sample_y = sample_label, y_order = sample_order),
      by = "sample_y_col"
    ) %>%
    left_join(meta %>% distinct(dataset_id, dataset_label), by = "dataset_id")
}

sample_correlations <- bind_rows(
  make_correlation_table(full_wide, "ICAT_FL"),
  make_correlation_table(n_term, "ICAT_N")
) %>%
  mutate(
    dataset_label = factor(dataset_label, levels = c("Full-length ICAT", "ICAT N-term")),
    sample_x = factor(sample_x, levels = sample_meta$sample_label),
    sample_y = factor(sample_y, levels = rev(sample_meta$sample_label))
  )

nonzero_full <- full_wide %>%
  select(starts_with("normalized_total_spectra_")) %>%
  unlist(use.names = FALSE)
nonzero_full <- nonzero_full[is.finite(nonzero_full) & nonzero_full > 0]
full_pseudocount <- min(nonzero_full, na.rm = TRUE) / 2

nonzero_n <- n_term %>%
  select(PG1, PG2, PG3, PG4) %>%
  unlist(use.names = FALSE)
nonzero_n <- nonzero_n[is.finite(nonzero_n) & nonzero_n > 0]
n_pseudocount <- min(nonzero_n, na.rm = TRUE) / 2

replicate_logfc <- bind_rows(
  full_wide %>%
    transmute(
      dataset_id = "ICAT_FL",
      dataset_label = "Full-length ICAT",
      gene,
      exp1_log2fc = log2((normalized_total_spectra_exp1_rapa + full_pseudocount) /
        (normalized_total_spectra_exp1_control + full_pseudocount)),
      exp2_log2fc = log2((normalized_total_spectra_exp2_rapa + full_pseudocount) /
        (normalized_total_spectra_exp2_control + full_pseudocount))
    ),
  n_term %>%
    transmute(
      dataset_id = "ICAT_N",
      dataset_label = "ICAT N-term",
      gene,
      exp1_log2fc = log2((PG2 + n_pseudocount) / (PG1 + n_pseudocount)),
      exp2_log2fc = log2((PG4 + n_pseudocount) / (PG3 + n_pseudocount))
    )
) %>%
  mutate(
    dataset_label = factor(dataset_label, levels = c("Full-length ICAT", "ICAT N-term")),
    mean_log2fc = rowMeans(pick(exp1_log2fc, exp2_log2fc), na.rm = TRUE),
    abs_delta_replicates = abs(exp1_log2fc - exp2_log2fc),
    in_construct_heatmap = gene %in% construct_heatmap$gene
  ) %>%
  filter(is.finite(exp1_log2fc), is.finite(exp2_log2fc))

replicate_stats <- replicate_logfc %>%
  group_by(dataset_id, dataset_label) %>%
  summarise(
    quantified_proteins = n(),
    pearson_r = cor(exp1_log2fc, exp2_log2fc, method = "pearson"),
    spearman_rho = cor(exp1_log2fc, exp2_log2fc, method = "spearman"),
    median_abs_replicate_delta = median(abs_delta_replicates, na.rm = TRUE),
    proteins_in_construct_heatmap = sum(in_construct_heatmap, na.rm = TRUE),
    .groups = "drop"
  )

coverage_summary <- sample_qc %>%
  group_by(dataset_id, dataset_label) %>%
  summarise(
    min_detected_proteins = min(proteins_detected, na.rm = TRUE),
    max_detected_proteins = max(proteins_detected, na.rm = TRUE),
    min_total_spectra = min(total_normalized_spectra, na.rm = TRUE),
    max_total_spectra = max(total_normalized_spectra, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  left_join(replicate_stats, by = c("dataset_id", "dataset_label"))

readr::write_csv(sample_qc, file.path(analysis_table_dir, "Figure6_ICAT_construct_QC_sample_metrics.csv"))
readr::write_csv(sample_correlations, file.path(analysis_table_dir, "Figure6_ICAT_construct_QC_sample_correlations.csv"))
readr::write_csv(replicate_stats, file.path(analysis_table_dir, "Figure6_ICAT_construct_QC_replicate_concordance.csv"))
readr::write_csv(replicate_logfc, file.path(analysis_table_dir, "Figure6_ICAT_construct_QC_replicate_log2FC_source_data.csv"))
readr::write_csv(coverage_summary, file.path(analysis_table_dir, "Figure6_ICAT_construct_QC_summary.csv"))

condition_cols <- c(
  "Control" = "#BAC4CC",
  "Rapalog" = "#C94855",
  "Cytosolic" = "#BAC4CC",
  "ICAT N" = "#4F6F99"
)
dataset_cols <- c("Full-length ICAT" = "#C94855", "ICAT N-term" = "#4F6F99")

sample_label_theme <- theme(
  axis.text.x = element_text(angle = 45, hjust = 1, vjust = 1, size = 5.6),
  legend.position = "none"
)

p_total <- ggplot(sample_qc, aes(sample_label, total_normalized_spectra / 1000, fill = condition_label)) +
  geom_col(width = 0.72, colour = "white", linewidth = 0.18) +
  facet_wrap(~dataset_label, scales = "free_x", nrow = 1) +
  scale_fill_manual(values = condition_cols, drop = FALSE) +
  labs(
    title = "a  Total spectra",
    x = NULL,
    y = "Normalized spectra (x10^3)"
  ) +
  sample_label_theme

p_detected <- ggplot(sample_qc, aes(sample_label, proteins_detected, fill = condition_label)) +
  geom_col(width = 0.72, colour = "white", linewidth = 0.18) +
  facet_wrap(~dataset_label, scales = "free_x", nrow = 1) +
  scale_fill_manual(values = condition_cols, drop = FALSE) +
  scale_y_continuous(labels = comma) +
  labs(
    title = "b  Protein coverage",
    x = NULL,
    y = "Proteins detected"
  ) +
  sample_label_theme

p_cor <- ggplot(sample_correlations, aes(sample_x, sample_y, fill = pearson_r)) +
  geom_tile(colour = "white", linewidth = 0.18) +
  geom_text(aes(label = number(pearson_r, accuracy = 0.01)), size = 1.7, colour = "#202529") +
  facet_wrap(~dataset_label, scales = "free", nrow = 1) +
  scale_fill_gradientn(
    colours = c("#F2F4F5", "#B8C4CE", "#5D7180", "#2E3741"),
    values = rescale(c(0.5, 0.75, 0.9, 1)),
    limits = c(0.5, 1),
    oob = squish,
    guide = "none"
  ) +
  labs(
    title = "c  Sample correlation",
    x = NULL,
    y = NULL
  ) +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1, vjust = 1, size = 5.2),
    axis.text.y = element_text(size = 5.2),
    axis.ticks = element_blank(),
    strip.text = element_text(size = 6.4, face = "bold"),
    legend.position = "none",
    legend.title = element_text(size = 5.8),
    legend.text = element_text(size = 5.4),
    panel.border = element_blank()
  )

stats_labels <- replicate_stats %>%
  mutate(
    label = paste0(
      "Pearson r = ", number(pearson_r, accuracy = 0.01),
      "\nSpearman rho = ", number(spearman_rho, accuracy = 0.01),
      "\nn = ", comma(quantified_proteins)
    ),
    x = -Inf,
    y = Inf
  )

p_replicates <- ggplot(replicate_logfc, aes(exp1_log2fc, exp2_log2fc)) +
  geom_hline(yintercept = 0, linewidth = 0.22, colour = "#D0D5D8") +
  geom_vline(xintercept = 0, linewidth = 0.22, colour = "#D0D5D8") +
  geom_abline(slope = 1, intercept = 0, linewidth = 0.28, colour = "#7F878E", linetype = "22") +
  geom_point(aes(colour = dataset_label), size = 0.42, alpha = 0.22, stroke = 0) +
  geom_point(
    data = replicate_logfc %>% filter(in_construct_heatmap),
    aes(colour = dataset_label),
    size = 0.9,
    alpha = 0.85,
    stroke = 0
  ) +
  geom_label(
    data = stats_labels,
    aes(x = x, y = y, label = label),
    inherit.aes = FALSE,
    hjust = -0.02,
    vjust = 1.02,
    size = 1.7,
    linewidth = 0,
    fill = alpha("white", 0.82),
    colour = "#2F3438",
    label.padding = unit(0.08, "lines")
  ) +
  facet_wrap(~dataset_label, nrow = 1) +
  scale_colour_manual(values = dataset_cols, guide = "none") +
  coord_cartesian(xlim = c(-6, 6), ylim = c(-6, 6)) +
  labs(
    title = "d  Replicate log2FC concordance",
    x = "Experiment 1 log2 fold-change",
    y = "Experiment 2 log2 fold-change"
  ) +
  theme(
    strip.text = element_text(size = 6.4, face = "bold"),
    axis.text = element_text(size = 5.6),
    axis.title = element_text(size = 6.1)
  )

qc_figure <- (p_total | p_detected) / (p_cor | p_replicates) +
  plot_layout(heights = c(0.82, 1.18), widths = c(1, 1.25), guides = "keep") &
  plot_annotation(
    theme = theme(
      plot.margin = margin(2, 2, 2, 2)
    )
  )

save_pub_plot <- function(plot, name, width_mm = 183, height_mm = 132, dpi = 600) {
  width_in <- width_mm / 25.4
  height_in <- height_mm / 25.4
  ggsave(
    file.path(analysis_figure_dir, "pdf", paste0(name, ".pdf")),
    plot,
    width = width_in,
    height = height_in,
    device = cairo_pdf,
    bg = "white"
  )
  ggsave(
    file.path(analysis_figure_dir, "png", paste0(name, ".png")),
    plot,
    width = width_in,
    height = height_in,
    dpi = dpi,
    bg = "white"
  )
  ggsave(
    file.path(analysis_figure_dir, "tiff", paste0(name, ".tiff")),
    plot,
    width = width_in,
    height = height_in,
    dpi = dpi,
    compression = "lzw",
    bg = "white"
  )
  if (requireNamespace("svglite", quietly = TRUE)) {
    ggsave(
      file.path(analysis_figure_dir, "svg", paste0(name, ".svg")),
      plot,
      width = width_in,
      height = height_in,
      device = svglite::svglite,
      bg = "white"
    )
  }
}

figure_name <- "Figure6_ICAT_construct_QC_supplement"
save_pub_plot(qc_figure, figure_name)

format_range <- function(x) {
  paste0(comma(min(x, na.rm = TRUE), accuracy = 1), "-", comma(max(x, na.rm = TRUE), accuracy = 1))
}

summary_lines <- c(
  "# ICAT Construct QC Supplement Report",
  "",
  "## Purpose",
  "",
  "This supplementary QC figure evaluates whether the ICAT N-term TurboID and full-length ICAT proximity proteomics datasets have sufficient sample-level quality and replicate concordance to support construct-level enrichment comparisons.",
  "",
  "## Figure Contract",
  "",
  "- Core conclusion: both datasets provide interpretable sample-level proteomic measurements and replicate-level log2FC estimates for the construct preference analysis.",
  "- Evidence chain: sample spectra totals, protein coverage, sample-level Pearson correlations, and replicate log2FC concordance.",
  "- Archetype: quantitative grid supplementary QC figure.",
  "",
  "## Key QC Summary",
  "",
  paste0("- Full-length ICAT detected proteins per sample: ", format_range(sample_qc %>% filter(dataset_id == "ICAT_FL") %>% pull(proteins_detected)), "."),
  paste0("- ICAT N-term detected proteins per sample: ", format_range(sample_qc %>% filter(dataset_id == "ICAT_N") %>% pull(proteins_detected)), "."),
  paste0("- Full-length ICAT replicate log2FC Pearson r: ", number(replicate_stats$pearson_r[replicate_stats$dataset_id == "ICAT_FL"], accuracy = 0.01), "."),
  paste0("- ICAT N-term replicate log2FC Pearson r: ", number(replicate_stats$pearson_r[replicate_stats$dataset_id == "ICAT_N"], accuracy = 0.01), "."),
  paste0("- Construct-heatmap proteins represented in full-length replicate log2FC source: ", comma(replicate_stats$proteins_in_construct_heatmap[replicate_stats$dataset_id == "ICAT_FL"]), "."),
  paste0("- Construct-heatmap proteins represented in ICAT N-term replicate log2FC source: ", comma(replicate_stats$proteins_in_construct_heatmap[replicate_stats$dataset_id == "ICAT_N"]), "."),
  "",
  "## Notes For Interpretation",
  "",
  "- Sample correlations were computed from log2(normalized spectra + pseudocount), using one-half of the minimum non-zero normalized spectra value within each dataset as the pseudocount.",
  "- Replicate log2FC was computed independently for exp1 and exp2 in each dataset.",
  "- Full-length ICAT log2FC compares rapalog versus control within each experiment.",
  "- ICAT N-term log2FC compares ICAT N-term TurboID versus cytosolic TurboID within each experiment.",
  "- Construct-heatmap proteins are overplotted in the replicate concordance panel to show that the main figure proteins are represented in the QC source data.",
  "",
  "## Outputs",
  "",
  paste0("- Figure: `", file.path(analysis_figure_dir, "pdf", paste0(figure_name, ".pdf")), "`"),
  paste0("- Sample QC table: `", file.path(analysis_table_dir, "Figure6_ICAT_construct_QC_sample_metrics.csv"), "`"),
  paste0("- Sample correlation table: `", file.path(analysis_table_dir, "Figure6_ICAT_construct_QC_sample_correlations.csv"), "`"),
  paste0("- Replicate concordance table: `", file.path(analysis_table_dir, "Figure6_ICAT_construct_QC_replicate_concordance.csv"), "`")
)
writeLines(summary_lines, file.path(analysis_report_dir, "Figure6_ICAT_construct_QC_supplement_report.md"))

legend_lines <- c(
  "Figure 6 - figure supplement | ICAT proximity proteomics quality control.",
  "a, Total normalized spectra for the four full-length ICAT samples and four ICAT N-term samples. Full-length ICAT samples compare rapalog and control conditions across two experiments; ICAT N-term samples compare ICAT N-term TurboID with cytosolic TurboID across two experiments.",
  "b, Number of proteins with non-zero normalized spectra in each sample.",
  "c, Pearson correlation heatmaps calculated from log2(normalized spectra + pseudocount) values, where the pseudocount was one-half of the minimum non-zero value in each dataset.",
  "d, Replicate concordance of protein-level log2 fold-change values. Grey dashed lines indicate identity between experiments. Full-length ICAT log2FC values compare rapalog versus control; ICAT N-term log2FC values compare ICAT N-term TurboID versus cytosolic TurboID. Larger points denote proteins included in the construct preference heatmap. Source data are provided in the associated QC tables."
)
writeLines(legend_lines, file.path(legend_dir, "Figure6_ICAT_construct_QC_supplement_legend.txt"))

message("ICAT construct QC supplement completed.")
message("Tables: ", analysis_table_dir)
message("Figures: ", analysis_figure_dir)
message("Report: ", analysis_report_dir)
