#!/usr/bin/env Rscript

script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
script_path <- normalizePath(sub("^--file=", "", script_arg[[1]]), mustWork = TRUE)
code_dir <- dirname(script_path)
fig_dir <- normalizePath(file.path(code_dir, "..", ".."), mustWork = TRUE)
project_root <- normalizePath(file.path(fig_dir, ".."), mustWork = TRUE)
source(file.path(project_root, "shared", "R", "project_library.R"))
source(file.path(project_root, "shared", "R", "plot_style.R"))
icat_activate_project_library(project_root)

suppressPackageStartupMessages({
  library(dplyr)
  library(ggplot2)
  library(ggrepel)
  library(patchwork)
  library(readr)
  library(scales)
  library(stringr)
  library(tidyr)
})

raw_dir <- file.path(fig_dir, "01_raw_data")
microneme_dir <- file.path(raw_dir, "microneme_protein")
table_dir <- file.path(fig_dir, "04_results", "tables", "interactome")
report_dir <- file.path(fig_dir, "04_results", "reports", "interactome")
figure_dir <- file.path(fig_dir, "04_results", "figures", "interactome")
legend_dir <- file.path(fig_dir, "04_results", "legends")

analysis_name <- "ICAT_N_term_TurboID"
analysis_table_dir <- file.path(table_dir, analysis_name)
analysis_report_dir <- file.path(report_dir, analysis_name)
analysis_figure_dir <- file.path(figure_dir, analysis_name)

dir.create(analysis_table_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(analysis_report_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(analysis_figure_dir, "pdf"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(analysis_figure_dir, "png"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(analysis_figure_dir, "tiff"), recursive = TRUE, showWarnings = FALSE)
dir.create(legend_dir, recursive = TRUE, showWarnings = FALSE)

loose_file <- file.path(raw_dir, "ICAT-F1-1.xls")
strict_file <- file.path(raw_dir, "ICAT-F1-2.xls")
full_length_file <- file.path(
  table_dir,
  "Figure6_interactome_candidate_summary_with_database_annotations.csv"
)
surface_file <- file.path(microneme_dir, "microneme_surface_distributed_genes.csv")
internal_file <- file.path(microneme_dir, "microneme_internal_genes.csv")

required_files <- c(loose_file, strict_file, full_length_file, surface_file, internal_file)
missing_files <- required_files[!file.exists(required_files)]
if (length(missing_files)) {
  stop("Missing required input files: ", paste(missing_files, collapse = ", "))
}

theme_set(icat_theme_classic() + theme(panel.grid = element_blank()))

clean_gene_id <- function(x) {
  x %>%
    as.character() %>%
    str_replace("^\ufeff", "") %>%
    str_squish()
}

as_flag <- function(x) {
  if (is.logical(x)) {
    return(coalesce(x, FALSE))
  }
  tolower(as.character(x)) %in% c("true", "t", "1", "yes", "y")
}

flag_col <- function(data, col) {
  if (!col %in% names(data)) {
    return(rep(FALSE, nrow(data)))
  }
  as_flag(data[[col]])
}

format_p <- function(x) {
  ifelse(is.na(x), "NA", format.pval(x, digits = 2, eps = 1e-4))
}

auc_from_values <- function(group_values, rest_values) {
  n_group <- length(group_values)
  n_rest <- length(rest_values)
  if (n_group < 1 || n_rest < 1) {
    return(NA_real_)
  }
  values <- c(group_values, rest_values)
  ranks <- rank(values, ties.method = "average")
  w <- sum(ranks[seq_len(n_group)]) - n_group * (n_group + 1) / 2
  w / (n_group * n_rest)
}

safe_wilcox_greater <- function(group_values, rest_values) {
  if (length(group_values) < 2 || length(rest_values) < 2) {
    return(NA_real_)
  }
  suppressWarnings(wilcox.test(group_values, rest_values, alternative = "greater", exact = FALSE)$p.value)
}

read_microneme_list <- function(path, class_label) {
  readr::read_csv(path, show_col_types = FALSE) %>%
    mutate(gene = clean_gene_id(Gene_ID)) %>%
    transmute(
      gene,
      display_name = str_squish(Gene_Name),
      microneme_class = class_label
    ) %>%
    filter(!is.na(gene), gene != "") %>%
    distinct(gene, .keep_all = TRUE)
}

read_proteome_discoverer_text <- function(path, threshold_label) {
  raw <- suppressWarnings(
    readr::read_tsv(
      path,
      skip = 3,
      show_col_types = FALSE,
      name_repair = "unique"
    )
  )
  protein_col <- names(raw)[str_detect(names(raw), "^Identified Proteins")]
  if (!length(protein_col)) {
    stop("Could not find Identified Proteins column in ", path)
  }
  protein_col <- protein_col[[1]]

  parse_number_safe <- function(x) readr::parse_number(as.character(x), locale = readr::locale(grouping_mark = ","))

  raw %>%
    transmute(
      source_threshold = threshold_label,
      row_id = suppressWarnings(as.integer(.data[["#"]])),
      protein_description = as.character(.data[[protein_col]]),
      accession_number = as.character(.data[["Accession Number"]]),
      molecular_weight = as.character(.data[["Molecular Weight"]]),
      gene = clean_gene_id(str_extract(protein_description, "TGME49_[0-9]+")),
      gene_product = str_squish(str_match(protein_description, "gene_product=([^|]+)")[, 2]),
      PG1 = parse_number_safe(.data[["PG1"]]),
      PG2 = parse_number_safe(.data[["PG2"]]),
      PG3 = parse_number_safe(.data[["PG3"]]),
      PG4 = parse_number_safe(.data[["PG4"]])
    ) %>%
    filter(!is.na(gene), gene != "") %>%
    group_by(gene) %>%
    summarise(
      source_threshold = first(source_threshold),
      accession_number = first(na.omit(accession_number)),
      gene_product = first(na.omit(gene_product)),
      molecular_weight = first(na.omit(molecular_weight)),
      PG1 = sum(PG1, na.rm = TRUE),
      PG2 = sum(PG2, na.rm = TRUE),
      PG3 = sum(PG3, na.rm = TRUE),
      PG4 = sum(PG4, na.rm = TRUE),
      .groups = "drop"
    )
}

surface_reference <- read_microneme_list(surface_file, "Surface")
internal_reference <- read_microneme_list(internal_file, "Internal")
microneme_reference <- bind_rows(surface_reference, internal_reference) %>%
  distinct(gene, .keep_all = TRUE)

full_annotation <- readr::read_csv(full_length_file, show_col_types = FALSE) %>%
  mutate(
    gene = clean_gene_id(gene),
    hyperlp_allocation = as.character(hyperlp_allocation),
    gene_product_full = as.character(gene_product),
    hyperlp_description = as.character(hyperlp_description),
    apical_flag = flag_col(., "apical_flag"),
    microneme_flag = flag_col(., "microneme_flag"),
    rhoptry_flag = flag_col(., "rhoptry_flag"),
    dense_granule_flag = flag_col(., "dense_granule_flag"),
    imc_or_cytoskeleton_flag = flag_col(., "imc_or_cytoskeleton_flag")
  ) %>%
  distinct(gene, .keep_all = TRUE)

loose_n <- read_proteome_discoverer_text(loose_file, "F1-1_loose")
strict_n <- read_proteome_discoverer_text(strict_file, "F1-2_strict") %>%
  select(gene, strict_detected = source_threshold)

nonzero_values <- loose_n %>%
  select(PG1, PG2, PG3, PG4) %>%
  unlist(use.names = FALSE)
nonzero_values <- nonzero_values[is.finite(nonzero_values) & nonzero_values > 0]
pseudocount <- min(nonzero_values, na.rm = TRUE) / 2

icat_n_quant <- loose_n %>%
  left_join(strict_n %>% mutate(strict_detected = TRUE), by = "gene") %>%
  mutate(strict_detected = coalesce(strict_detected, FALSE)) %>%
  left_join(
    full_annotation %>%
      select(
        gene,
        hyperlp_allocation,
        hyperlp_description,
        gene_product_full,
        apical_flag,
        microneme_flag,
        rhoptry_flag,
        dense_granule_flag,
        imc_or_cytoskeleton_flag
      ),
    by = "gene"
  ) %>%
  mutate(
    gene_product = coalesce(gene_product, gene_product_full),
    exp1_log2_N_vs_cyto = log2((PG2 + pseudocount) / (PG1 + pseudocount)),
    exp2_log2_N_vs_cyto = log2((PG4 + pseudocount) / (PG3 + pseudocount)),
    mean_log2_N_vs_cyto = (exp1_log2_N_vs_cyto + exp2_log2_N_vs_cyto) / 2,
    min_log2_N_vs_cyto = pmin(exp1_log2_N_vs_cyto, exp2_log2_N_vs_cyto),
    experiments_N_enriched = (exp1_log2_N_vs_cyto > 0) + (exp2_log2_N_vs_cyto > 0),
    samples_detected = (PG1 > 0) + (PG2 > 0) + (PG3 > 0) + (PG4 > 0),
    text_for_annotation = str_to_lower(paste(
      coalesce(gene_product, ""),
      coalesce(hyperlp_description, ""),
      coalesce(hyperlp_allocation, ""),
      sep = " | "
    )),
    conoid_core_keyword = str_detect(
      text_for_annotation,
      "conoid|intraconoidal|preconoidal|icmap|pcr[0-9]|tlap|morn|centrin|sas6|doublecortin|dcx|mapm|spmt|apical polar"
    ),
    conoid_broad = conoid_core_keyword | apical_flag | imc_or_cytoskeleton_flag,
    microneme_surface_curated = gene %in% surface_reference$gene,
    microneme_internal_curated = gene %in% internal_reference$gene,
    microneme_curated = gene %in% microneme_reference$gene,
    microneme_any = microneme_curated | microneme_flag | str_detect(text_for_annotation, "microneme|micronemal|\\bmic[0-9]|ama1|plp1"),
    apical_secretory_or_cytoskeleton = conoid_broad | microneme_any | rhoptry_flag | dense_granule_flag,
    rank_N_desc = rank(-mean_log2_N_vs_cyto, ties.method = "first"),
    rank_fraction_N = rank_N_desc / n(),
    enrichment_percentile_N = 1 - (rank_N_desc - 0.5) / n()
  ) %>%
  arrange(rank_N_desc)

full_length_quant <- full_annotation %>%
  filter(as_flag(science_peptide_filter), is.finite(mean_log2_rapa_vs_control)) %>%
  mutate(
    text_for_annotation = str_to_lower(paste(
      coalesce(gene_product_full, ""),
      coalesce(hyperlp_description, ""),
      coalesce(hyperlp_allocation, ""),
      sep = " | "
    )),
    conoid_core_keyword = str_detect(
      text_for_annotation,
      "conoid|intraconoidal|preconoidal|icmap|pcr[0-9]|tlap|morn|centrin|sas6|doublecortin|dcx|mapm|spmt|apical polar"
    ),
    conoid_broad = conoid_core_keyword | apical_flag | imc_or_cytoskeleton_flag,
    microneme_surface_curated = gene %in% surface_reference$gene,
    microneme_internal_curated = gene %in% internal_reference$gene,
    microneme_curated = gene %in% microneme_reference$gene,
    microneme_any = microneme_curated | microneme_flag | str_detect(text_for_annotation, "microneme|micronemal|\\bmic[0-9]|ama1|plp1"),
    apical_secretory_or_cytoskeleton = conoid_broad | microneme_any | rhoptry_flag | dense_granule_flag,
    rank_FL_desc = rank(-mean_log2_rapa_vs_control, ties.method = "first"),
    rank_fraction_FL = rank_FL_desc / n(),
    enrichment_percentile_FL = 1 - (rank_FL_desc - 0.5) / n()
  ) %>%
  arrange(rank_FL_desc)

sample_map <- tibble::tribble(
  ~sample, ~confirmed_condition, ~replicate, ~spectra_column,
  "PG1", "cytosolic_TurboID_control", "exp1", "PG1",
  "PG2", "ICAT_N_TurboID", "exp1", "PG2",
  "PG3", "cytosolic_TurboID_control", "exp2", "PG3",
  "PG4", "ICAT_N_TurboID", "exp2", "PG4"
)

category_definitions <- tibble::tribble(
  ~category_id, ~category_label, ~category_short_label,
  "conoid_core_keyword", "Conoid core keyword", "Conoid core",
  "conoid_broad", "Conoid / apical cytoskeleton", "Conoid broad",
  "microneme_surface_curated", "Microneme surface curated", "Surface MIC",
  "microneme_any", "Microneme all", "All microneme",
  "microneme_internal_curated", "Microneme internal curated", "Internal MIC",
  "rhoptry_flag", "Rhoptry", "Rhoptry",
  "dense_granule_flag", "Dense granule", "Dense granule"
)

make_dataset_long <- function(data, dataset_id, dataset_label, score_col, rank_col, pct_col) {
  bind_rows(lapply(seq_len(nrow(category_definitions)), function(i) {
    category <- category_definitions[i, ]
    if (!category$category_id %in% names(data)) {
      return(tibble::tibble())
    }
    data %>%
      transmute(
        dataset_id,
        dataset_label,
        gene,
        accession_number = if ("accession_number" %in% names(data)) accession_number else NA_character_,
        gene_product = if ("gene_product" %in% names(data)) gene_product else gene_product_full,
        hyperlp_allocation,
        score = .data[[score_col]],
        rank_fraction = .data[[rank_col]],
        enrichment_percentile = .data[[pct_col]],
        category_id = category$category_id,
        category_label = category$category_label,
        category_short_label = category$category_short_label,
        in_category = .data[[category$category_id]]
      ) %>%
      filter(in_category, is.finite(score))
  }))
}

dataset_members <- bind_rows(
  make_dataset_long(icat_n_quant, "ICAT_N", "ICAT N-term", "mean_log2_N_vs_cyto", "rank_fraction_N", "enrichment_percentile_N"),
  make_dataset_long(full_length_quant, "ICAT_FL", "Full-length ICAT", "mean_log2_rapa_vs_control", "rank_fraction_FL", "enrichment_percentile_FL")
)

all_dataset_scores <- bind_rows(
  icat_n_quant %>%
    transmute(dataset_id = "ICAT_N", dataset_label = "ICAT N-term", gene, score = mean_log2_N_vs_cyto),
  full_length_quant %>%
    transmute(dataset_id = "ICAT_FL", dataset_label = "Full-length ICAT", gene, score = mean_log2_rapa_vs_control)
)

category_tests <- bind_rows(lapply(unique(all_dataset_scores$dataset_id), function(dataset) {
  data <- if (dataset == "ICAT_N") icat_n_quant else full_length_quant
  score_col <- if (dataset == "ICAT_N") "mean_log2_N_vs_cyto" else "mean_log2_rapa_vs_control"
  dataset_label <- if (dataset == "ICAT_N") "ICAT N-term" else "Full-length ICAT"
  bind_rows(lapply(seq_len(nrow(category_definitions)), function(i) {
    category <- category_definitions[i, ]
    if (!category$category_id %in% names(data)) {
      return(tibble::tibble())
    }
    feature <- data[[category$category_id]] %in% TRUE
    group_values <- data[[score_col]][feature & is.finite(data[[score_col]])]
    rest_values <- data[[score_col]][!feature & is.finite(data[[score_col]])]
    tibble::tibble(
      dataset_id = dataset,
      dataset_label = dataset_label,
      category_id = category$category_id,
      category_label = category$category_label,
      category_short_label = category$category_short_label,
      n = length(group_values),
      background_n = length(rest_values),
      median_score = median(group_values, na.rm = TRUE),
      background_median_score = median(rest_values, na.rm = TRUE),
      median_shift = median_score - background_median_score,
      AUC = auc_from_values(group_values, rest_values),
      wilcox_p = safe_wilcox_greater(group_values, rest_values)
    )
  })) %>%
    mutate(wilcox_fdr_bh = p.adjust(wilcox_p, method = "BH"))
}))

top_rank_recovery <- bind_rows(lapply(c(0.05, 0.10, 0.20, 0.30), function(frac) {
  bind_rows(
    category_definitions %>%
      rowwise() %>%
      mutate(
        dataset_id = "ICAT_N",
        dataset_label = "ICAT N-term",
        top_fraction = frac,
        top_n = ceiling(nrow(icat_n_quant) * frac),
        category_n = sum(icat_n_quant[[category_id]] %in% TRUE, na.rm = TRUE),
        recovered_n = sum(icat_n_quant[[category_id]] %in% TRUE & icat_n_quant$rank_N_desc <= top_n, na.rm = TRUE),
        recovered_fraction = if_else(category_n > 0, recovered_n / category_n, NA_real_),
        recovery_over_random = recovered_fraction / top_fraction
      ) %>%
      ungroup(),
    category_definitions %>%
      rowwise() %>%
      mutate(
        dataset_id = "ICAT_FL",
        dataset_label = "Full-length ICAT",
        top_fraction = frac,
        top_n = ceiling(nrow(full_length_quant) * frac),
        category_n = sum(full_length_quant[[category_id]] %in% TRUE, na.rm = TRUE),
        recovered_n = sum(full_length_quant[[category_id]] %in% TRUE & full_length_quant$rank_FL_desc <= top_n, na.rm = TRUE),
        recovered_fraction = if_else(category_n > 0, recovered_n / category_n, NA_real_),
        recovery_over_random = recovered_fraction / top_fraction
      ) %>%
      ungroup()
  )
}))

top_candidates <- icat_n_quant %>%
  filter(conoid_broad | microneme_any | rank_N_desc <= 100) %>%
  mutate(
    hit_focus = case_when(
      conoid_core_keyword ~ "conoid_core",
      conoid_broad ~ "conoid_broad",
      microneme_surface_curated ~ "microneme_surface",
      microneme_any ~ "microneme",
      TRUE ~ "top100_other"
    )
  ) %>%
  arrange(rank_N_desc) %>%
  select(
    rank_N_desc,
    gene,
    accession_number,
    gene_product,
    hyperlp_allocation,
    PG1,
    PG2,
    PG3,
    PG4,
    exp1_log2_N_vs_cyto,
    exp2_log2_N_vs_cyto,
    mean_log2_N_vs_cyto,
    min_log2_N_vs_cyto,
    strict_detected,
    conoid_core_keyword,
    conoid_broad,
    microneme_surface_curated,
    microneme_internal_curated,
    microneme_any,
    hit_focus
  )

distribution_plot_data <- dataset_members %>%
  filter(category_id %in% c("conoid_core_keyword", "conoid_broad", "microneme_surface_curated", "microneme_any")) %>%
  mutate(
    category_short_label = factor(category_short_label, levels = c("Conoid core", "Conoid broad", "Surface MIC", "All microneme")),
    dataset_label = factor(dataset_label, levels = c("ICAT N-term", "Full-length ICAT"))
  )

palette_category <- c(
  "Conoid core" = "#526C8F",
  "Conoid broad" = "#6EA585",
  "Surface MIC" = "#C9343F",
  "All microneme" = "#D8872A"
)

distribution_plot <- ggplot(
  distribution_plot_data,
  aes(category_short_label, enrichment_percentile, fill = category_short_label)
) +
  geom_hline(yintercept = 0.5, linewidth = ICAT_LINE_MM, colour = "#A4ABB3", linetype = "22") +
  geom_violin(width = 0.72, trim = FALSE, alpha = 0.78, colour = "#2F343A", linewidth = ICAT_LINE_MM) +
  geom_boxplot(width = 0.12, outlier.shape = NA, fill = "white", colour = "#2F343A", linewidth = ICAT_LINE_MM) +
  geom_point(
    position = position_jitter(width = 0.08, height = 0, seed = 20260819),
    size = 0.8,
    alpha = 0.42,
    stroke = 0,
    colour = "#2F343A"
  ) +
  facet_wrap(~ dataset_label, nrow = 1) +
  scale_fill_manual(values = palette_category, guide = "none") +
  scale_y_continuous(labels = percent_format(accuracy = 1)) +
  coord_cartesian(ylim = c(0, 1)) +
  labs(
    x = NULL,
    y = "Within-dataset enrichment percentile",
    title = "A  ICAT N-term and full-length ICAT rank distributions",
    subtitle = "Higher percentile indicates stronger enrichment within each experiment."
  ) +
  theme(
    axis.text.x = element_text(angle = 25, hjust = 1),
    plot.margin = margin(5, 5, 5, 5)
  )

effect_plot_data <- category_tests %>%
  filter(category_id %in% c("conoid_core_keyword", "conoid_broad", "microneme_surface_curated", "microneme_any")) %>%
  mutate(
    category_short_label = factor(category_short_label, levels = rev(c("Conoid core", "Conoid broad", "Surface MIC", "All microneme"))),
    dataset_label = factor(dataset_label, levels = c("ICAT N-term", "Full-length ICAT")),
    fdr_class = case_when(
      wilcox_fdr_bh < 0.05 ~ "FDR < 0.05",
      wilcox_fdr_bh < 0.10 ~ "FDR < 0.10",
      TRUE ~ "n.s."
    )
  )

effect_plot <- ggplot(effect_plot_data, aes(AUC, category_short_label)) +
  geom_vline(xintercept = 0.5, linewidth = ICAT_LINE_MM, colour = "#A4ABB3", linetype = "22") +
  geom_point(aes(colour = fdr_class), size = 2.4, alpha = 0.95) +
  geom_text(
    aes(x = 0.98, label = paste0("AUC ", number(AUC, accuracy = 0.01), "\nFDR ", format_p(wilcox_fdr_bh))),
    hjust = 1,
    size = ICAT_TEXT_SMALL_MM,
    colour = "#2F343A"
  ) +
  facet_wrap(~ dataset_label, nrow = 1) +
  scale_colour_manual(values = c("FDR < 0.05" = "#C9343F", "FDR < 0.10" = "#D8872A", "n.s." = "#7A8795"), name = NULL) +
  scale_x_continuous(limits = c(0.35, 1.0), breaks = c(0.4, 0.5, 0.6, 0.7, 0.8, 0.9)) +
  labs(
    x = "AUC versus all other quantified proteins",
    y = NULL,
    title = "B  Structure-set enrichment effect size",
    subtitle = "One-sided rank tests ask whether each structure set shifts toward stronger enrichment."
  ) +
  guides(colour = guide_legend(nrow = 1, byrow = TRUE)) +
  theme(
    legend.position = "top",
    plot.margin = margin(5, 5, 5, 5)
  )

recovery_plot_data <- top_rank_recovery %>%
  filter(category_id %in% c("conoid_core_keyword", "conoid_broad", "microneme_surface_curated", "microneme_any")) %>%
  mutate(
    category_short_label = factor(category_short_label, levels = c("Conoid core", "Conoid broad", "Surface MIC", "All microneme")),
    dataset_label = factor(dataset_label, levels = c("ICAT N-term", "Full-length ICAT"))
  )

recovery_plot <- ggplot(
  recovery_plot_data,
  aes(top_fraction, recovery_over_random, colour = category_short_label)
) +
  geom_hline(yintercept = 1, linewidth = ICAT_LINE_MM, colour = "#A4ABB3", linetype = "22") +
  geom_line(linewidth = 0.65) +
  geom_point(size = 1.35) +
  facet_wrap(~ dataset_label, nrow = 1) +
  scale_colour_manual(values = palette_category, name = NULL) +
  scale_x_continuous(labels = percent_format(accuracy = 1), breaks = c(0.05, 0.10, 0.20, 0.30)) +
  labs(
    x = "Top-ranked enrichment window",
    y = "Recovery over random expectation",
    title = "C  High-rank concentration",
    subtitle = "Values above 1 indicate concentration near the high-enrichment end."
  ) +
  guides(colour = guide_legend(nrow = 1, byrow = TRUE)) +
  theme(
    legend.position = "top",
    plot.margin = margin(5, 5, 5, 5)
  )

scatter_label_data <- icat_n_quant %>%
  filter((conoid_core_keyword & mean_log2_N_vs_cyto > 0.7) | microneme_surface_curated) %>%
  arrange(desc(conoid_core_keyword), rank_N_desc) %>%
  slice_head(n = 12) %>%
  mutate(label_class = if_else(conoid_core_keyword, "Conoid core", "Surface MIC"))

scatter_plot <- icat_n_quant %>%
  mutate(
    point_class = case_when(
      conoid_core_keyword ~ "Conoid core",
      microneme_surface_curated ~ "Surface MIC",
      microneme_any ~ "All microneme",
      conoid_broad ~ "Conoid broad",
      TRUE ~ "Other"
    ),
    point_class = factor(point_class, levels = c("Other", "Conoid broad", "All microneme", "Surface MIC", "Conoid core"))
  ) %>%
  ggplot(aes(exp1_log2_N_vs_cyto, exp2_log2_N_vs_cyto, colour = point_class)) +
  geom_hline(yintercept = 0, linewidth = ICAT_LINE_MM, colour = "#A4ABB3", linetype = "22") +
  geom_vline(xintercept = 0, linewidth = ICAT_LINE_MM, colour = "#A4ABB3", linetype = "22") +
  geom_abline(slope = 1, intercept = 0, linewidth = ICAT_LINE_MM, colour = "#A4ABB3", linetype = "22") +
  geom_point(size = 0.85, alpha = 0.48, stroke = 0) +
  ggrepel::geom_text_repel(
    data = scatter_label_data,
    aes(exp1_log2_N_vs_cyto, exp2_log2_N_vs_cyto, label = gene, colour = label_class),
    inherit.aes = FALSE,
    size = ICAT_TEXT_SMALL_MM,
    segment.size = ICAT_LINE_MM,
    min.segment.length = 0,
    box.padding = 0.14,
    seed = 20260819,
    max.overlaps = Inf,
    show.legend = FALSE
  ) +
  scale_colour_manual(
    values = c(
      "Other" = "#C7CCD1",
      "Conoid broad" = "#6EA585",
      "All microneme" = "#D8872A",
      "Surface MIC" = "#C9343F",
      "Conoid core" = "#526C8F"
    ),
    name = NULL
  ) +
  labs(
    x = expression(Exp1~log[2]*"(ICAT N / cytosolic TurboID)"),
    y = expression(Exp2~log[2]*"(ICAT N / cytosolic TurboID)"),
    title = "D  ICAT N-term replicate consistency",
    subtitle = "Conoid candidates are labelled; microneme surface genes remain weak."
  ) +
  guides(colour = guide_legend(nrow = 2, byrow = TRUE, override.aes = list(size = 1.8, alpha = 0.9))) +
  theme(
    legend.position = "top",
    legend.text = element_text(size = ICAT_FONT_SMALL_PT),
    plot.margin = margin(5, 5, 5, 5)
  )

main_figure <- distribution_plot / effect_plot / recovery_plot
main_figure <- main_figure + plot_layout(heights = c(0.95, 0.95, 0.9))

save_pub_plot <- function(plot, basename, width_mm, height_mm, dpi = 600) {
  ggplot2::ggsave(
    filename = file.path(analysis_figure_dir, "pdf", paste0(basename, ".pdf")),
    plot = plot,
    width = width_mm,
    height = height_mm,
    units = "mm",
    device = cairo_pdf
  )
  ragg::agg_png(
    filename = file.path(analysis_figure_dir, "png", paste0(basename, ".png")),
    width = width_mm,
    height = height_mm,
    units = "mm",
    res = dpi
  )
  print(plot)
  dev.off()
  ragg::agg_tiff(
    filename = file.path(analysis_figure_dir, "tiff", paste0(basename, ".tiff")),
    width = width_mm,
    height = height_mm,
    units = "mm",
    res = dpi,
    compression = "lzw"
  )
  print(plot)
  dev.off()
}

save_pub_plot(main_figure, "Figure6_ICAT_N_term_TurboID_summary", 183, 210)
save_pub_plot(distribution_plot, "Figure6_ICAT_N_term_TurboID_rank_distribution", 183, 82)
save_pub_plot(effect_plot, "Figure6_ICAT_N_term_TurboID_effect_size", 183, 86)
save_pub_plot(recovery_plot, "Figure6_ICAT_N_term_TurboID_top_rank_recovery", 150, 82)
save_pub_plot(scatter_plot, "Figure6_ICAT_N_term_TurboID_replicate_scatter", 120, 94)

readr::write_csv(sample_map, file.path(analysis_table_dir, "Figure6_ICAT_N_term_inferred_sample_map.csv"))
readr::write_csv(sample_map, file.path(analysis_table_dir, "Figure6_ICAT_N_term_confirmed_sample_map.csv"))
readr::write_csv(icat_n_quant, file.path(analysis_table_dir, "Figure6_ICAT_N_term_quantified_proteins_annotated.csv"))
readr::write_csv(top_candidates, file.path(analysis_table_dir, "Figure6_ICAT_N_term_focus_candidates.csv"))
readr::write_csv(category_tests, file.path(analysis_table_dir, "Figure6_ICAT_N_vs_full_length_category_tests.csv"))
readr::write_csv(top_rank_recovery, file.path(analysis_table_dir, "Figure6_ICAT_N_vs_full_length_top_rank_recovery.csv"))
readr::write_csv(dataset_members, file.path(analysis_table_dir, "Figure6_ICAT_N_vs_full_length_category_members.csv"))

key_lines <- category_tests %>%
  filter(category_id %in% c("conoid_core_keyword", "conoid_broad", "microneme_surface_curated", "microneme_any")) %>%
  arrange(dataset_id, category_id) %>%
  mutate(
    line = paste0(
      "- ", dataset_label, " | ", category_label,
      ": n=", n,
      ", median score=", number(median_score, accuracy = 0.01),
      ", AUC=", number(AUC, accuracy = 0.01),
      ", BH FDR=", format_p(wilcox_fdr_bh)
    )
  ) %>%
  pull(line)

top_n_lines <- top_candidates %>%
  filter(conoid_core_keyword | microneme_surface_curated) %>%
  arrange(rank_N_desc) %>%
  slice_head(n = 25) %>%
  transmute(
    line = paste0(
      "- rank ", rank_N_desc, " | ", gene, " | ",
      coalesce(gene_product, "NA"),
      " | mean log2(N/control)=",
      number(mean_log2_N_vs_cyto, accuracy = 0.01),
      " | strict=", strict_detected
    )
  ) %>%
  pull(line)

report_lines <- c(
  "# ICAT N-term TurboID analysis",
  "",
  "## Purpose",
  "This independent analysis evaluates proteins enriched by the ICAT N-terminal conoid-targeting sequence fused to TurboID relative to cytosolic TurboID controls, and compares its structure-class enrichment profile with the full-length ICAT proximity dataset.",
  "",
  "## Confirmed sample map",
  "- PG1 and PG3 were treated as cytosolic TurboID control replicates.",
  "- PG2 and PG4 were treated as ICAT N-term TurboID replicates.",
  "- This direction uses the confirmed sample assignment supplied by the user.",
  "",
  "## Key rank-test results",
  key_lines,
  "",
  "## ICAT N-term focus candidates",
  top_n_lines,
  "",
  "## Interpretation",
  "ICAT N-term TurboID recovers multiple conoid-associated candidates, including MORN, PCR, CGP, TLAP, and ICMAP proteins, but the conoid keyword set does not show a statistically significant global right-shift in this exploratory rank test.",
  "By contrast, full-length ICAT shows the expected strong microneme-surface enrichment. ICAT N-term shows only weak, non-significant microneme-surface/microneme-all shifts, supporting the interpretation that the N-terminal conoid-targeting sequence has much weaker microneme-surface proximity than full-length ICAT.",
  "Use enrichment percentiles and AUCs for cross-dataset interpretation rather than directly comparing raw log2 fold-changes between experimental systems."
)

writeLines(
  report_lines,
  file.path(analysis_report_dir, "Figure6_ICAT_N_term_TurboID_report.md")
)

legend_lines <- c(
  "Figure 6 | ICAT N-terminal TurboID recovers conoid-associated candidates but lacks the microneme-surface enrichment observed with full-length ICAT.",
  "A, Within-dataset enrichment percentile distributions for conoid and microneme protein sets in ICAT N-term TurboID and full-length ICAT proximity datasets.",
  "B, Structure-set enrichment effect sizes. AUC values summarize whether proteins in each structure class rank above the remaining quantified background within each dataset; one-sided Wilcoxon p values were adjusted by Benjamini-Hochberg correction within each dataset.",
  "C, High-rank recovery curves for structure classes across top-ranked enrichment windows.",
  "D, Exp1 versus Exp2 ICAT N-term TurboID enrichment scatter plot. PG2/PG4 are ICAT N-term samples and PG1/PG3 are cytosolic TurboID controls."
)

writeLines(
  legend_lines,
  file.path(legend_dir, "Figure6_ICAT_N_term_TurboID_legend.txt")
)

message("ICAT N-term TurboID analysis completed.")
message("Pseudocount: ", signif(pseudocount, 4))
message("Tables: ", analysis_table_dir)
message("Figures: ", analysis_figure_dir)
message("Report: ", file.path(analysis_report_dir, "Figure6_ICAT_N_term_TurboID_report.md"))
