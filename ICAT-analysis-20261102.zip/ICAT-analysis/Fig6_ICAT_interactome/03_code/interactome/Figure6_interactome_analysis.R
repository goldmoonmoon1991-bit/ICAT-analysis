#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(dplyr)
  library(ggplot2)
  library(ggrepel)
  library(patchwork)
  library(readr)
  library(readxl)
  library(stringr)
  library(tidyr)
})

script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
script_path <- normalizePath(sub("^--file=", "", script_arg[[1]]), mustWork = TRUE)
code_dir <- dirname(script_path)
fig_dir <- normalizePath(file.path(code_dir, "..", ".."), mustWork = TRUE)
project_root <- normalizePath(file.path(fig_dir, ".."), mustWork = TRUE)
source(file.path(project_root, "shared", "R", "project_library.R"))
source(file.path(project_root, "shared", "R", "plot_style.R"))
icat_activate_project_library(project_root)

raw_dir <- file.path(fig_dir, "01_raw_data")
processed_dir <- file.path(fig_dir, "02_processed_data", "interactome")
table_dir <- file.path(fig_dir, "04_results", "tables", "interactome")
report_dir <- file.path(fig_dir, "04_results", "reports", "interactome")
figure_dir <- file.path(fig_dir, "04_results", "figures", "interactome")
legend_dir <- file.path(fig_dir, "04_results", "legends")

dir.create(processed_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(report_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(figure_dir, "pdf"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(figure_dir, "png"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(figure_dir, "tiff"), recursive = TRUE, showWarnings = FALSE)
dir.create(legend_dir, recursive = TRUE, showWarnings = FALSE)

spectra_file <- file.path(raw_dir, "Samples View Report for PQ_ProtID_Report_20260720.xls")
peptide_file <- file.path(raw_dir, "Samples View Report for PQ_ProtID_Report_peptide_20260720.xls")
sample_map_file <- file.path(raw_dir, "Figure6_sample_map.csv")
database_dir <- file.path(raw_dir, "database")
hyperlp_file <- file.path(database_dir, "HyperLp.csv")
crispr_file <- file.path(database_dir, "CRISPR rank-ordered genes.xlsx")

extract_field <- function(x, key) {
  value <- str_match(x, paste0("\\b", key, "=([^|]+)"))[, 2]
  str_squish(value)
}

clean_report <- function(path, value_name) {
  table_lines <- readLines(path, warn = FALSE)
  table_lines <- table_lines[-seq_len(3)]
  table_lines <- sub("\\t+$", "", table_lines)
  table_lines <- table_lines[!str_detect(table_lines, "^END OF FILE\\s*$")]

  raw <- readr::read_tsv(
    I(paste(table_lines, collapse = "\n")),
    col_types = cols(.default = col_character()),
    name_repair = "minimal",
    show_col_types = FALSE,
    progress = FALSE
  )

  stopifnot(ncol(raw) >= 15)

  names(raw)[seq_len(11)] <- c(
    "row_id",
    "visible",
    "starred",
    "protein_description",
    "accession_number",
    "alternate_id",
    "molecular_weight",
    "protein_grouping_ambiguity",
    "quantitative_variance_1",
    "quantitative_variance_2",
    "taxonomy"
  )

  sample_count <- ncol(raw) - 11
  names(raw)[12:ncol(raw)] <- paste0("sample_", seq_len(sample_count))

  raw %>%
    mutate(
      row_id = as.integer(row_id),
      visible = visible == "true",
      protein_grouping_ambiguity = protein_grouping_ambiguity == "true",
      molecular_weight_kda = parse_number(molecular_weight),
      quantitative_variance_1_percent = parse_number(quantitative_variance_1),
      quantitative_variance_2_percent = parse_number(quantitative_variance_2),
      transcript = extract_field(protein_description, "transcript"),
      gene = extract_field(protein_description, "gene"),
      organism = extract_field(protein_description, "organism"),
      gene_product = extract_field(protein_description, "gene_product"),
      transcript_product = extract_field(protein_description, "transcript_product"),
      location = extract_field(protein_description, "location"),
      protein_length_aa = as.integer(extract_field(protein_description, "protein_length")),
      sequence_SO = extract_field(protein_description, "sequence_SO"),
      SO = extract_field(protein_description, "SO"),
      is_pseudo = extract_field(protein_description, "is_pseudo") == "true"
    ) %>%
    mutate(across(starts_with("sample_"), readr::parse_number)) %>%
    pivot_longer(
      cols = starts_with("sample_"),
      names_to = "sample_id",
      values_to = value_name
    ) %>%
    mutate(sample_id = str_remove(sample_id, "^sample_"))
}

spectra_long <- clean_report(spectra_file, "normalized_total_spectra")
peptide_long <- clean_report(peptide_file, "unique_peptide_count")

sample_map <- readr::read_csv(
  sample_map_file,
  col_types = cols(.default = col_character()),
  show_col_types = FALSE
) %>%
  mutate(
    condition = factor(condition, levels = c("control", "rapa")),
    sample_label = factor(sample_label, levels = sample_label)
  )

annotation_cols <- c(
  "row_id",
  "visible",
  "starred",
  "protein_description",
  "accession_number",
  "alternate_id",
  "molecular_weight",
  "protein_grouping_ambiguity",
  "taxonomy",
  "molecular_weight_kda",
  "quantitative_variance_1_percent",
  "quantitative_variance_2_percent",
  "transcript",
  "gene",
  "organism",
  "gene_product",
  "transcript_product",
  "location",
  "protein_length_aa",
  "sequence_SO",
  "SO",
  "is_pseudo",
  "sample_id"
)

merged_long <- spectra_long %>%
  select(any_of(annotation_cols), normalized_total_spectra) %>%
  full_join(
    peptide_long %>%
      select(row_id, accession_number, sample_id, unique_peptide_count),
    by = c("row_id", "accession_number", "sample_id")
  ) %>%
  mutate(
    normalized_total_spectra = replace_na(normalized_total_spectra, 0),
    unique_peptide_count = replace_na(unique_peptide_count, 0)
  ) %>%
  left_join(sample_map, by = "sample_id") %>%
  relocate(experiment, condition, sample_label, .after = sample_id)

sample_count <- n_distinct(merged_long$sample_id)
experiment_count <- n_distinct(sample_map$experiment)
spectra_pseudocount <- min(merged_long$normalized_total_spectra[merged_long$normalized_total_spectra > 0], na.rm = TRUE) / 2

wide_source <- merged_long %>%
  select(
    row_id,
    accession_number,
    gene,
    transcript,
    gene_product,
    molecular_weight_kda,
    taxonomy,
    protein_grouping_ambiguity,
    sample_label,
    normalized_total_spectra,
    unique_peptide_count
  ) %>%
  pivot_wider(
    names_from = sample_label,
    values_from = c(normalized_total_spectra, unique_peptide_count),
    names_glue = "{.value}_{sample_label}"
  ) %>%
  arrange(row_id)

paired_enrichment <- merged_long %>%
  select(
    row_id,
    accession_number,
    gene,
    transcript,
    gene_product,
    molecular_weight_kda,
    taxonomy,
    protein_grouping_ambiguity,
    experiment,
    condition,
    normalized_total_spectra,
    unique_peptide_count
  ) %>%
  pivot_wider(
    names_from = condition,
    values_from = c(normalized_total_spectra, unique_peptide_count),
    values_fill = 0
  ) %>%
  mutate(
    normalized_log2_ratio_rapa_control = log2((normalized_total_spectra_rapa + spectra_pseudocount) / (normalized_total_spectra_control + spectra_pseudocount)),
    significance_b_abundance_proxy = log10(((normalized_total_spectra_rapa + normalized_total_spectra_control) / 2) + spectra_pseudocount),
    rapa_minus_control_spectra = normalized_total_spectra_rapa - normalized_total_spectra_control,
    rapa_peptide_supported = unique_peptide_count_rapa >= 2,
    control_peptide_supported = unique_peptide_count_control >= 2,
    science_peptide_filter_experiment = pmax(unique_peptide_count_rapa, unique_peptide_count_control, na.rm = TRUE) >= 2
  )

add_significance_b <- function(data, window_fraction = 0.15, min_window = 101) {
  data <- data %>%
    arrange(significance_b_abundance_proxy)
  n <- nrow(data)
  if (!n) return(data)

  window_size <- min(n, max(min_window, ceiling(n * window_fraction)))
  if (window_size %% 2 == 0 && window_size < n) window_size <- window_size + 1
  half_window <- floor(window_size / 2)
  ratios <- data$normalized_log2_ratio_rapa_control

  global_center <- median(ratios, na.rm = TRUE)
  global_scale <- mad(ratios, center = global_center, constant = 1.4826, na.rm = TRUE)
  if (!is.finite(global_scale) || global_scale <= 0) {
    global_scale <- sd(ratios, na.rm = TRUE)
  }
  if (!is.finite(global_scale) || global_scale <= 0) {
    global_scale <- 1
  }

  local_center <- numeric(n)
  local_scale <- numeric(n)

  for (i in seq_len(n)) {
    lo <- max(1L, i - half_window)
    hi <- min(n, i + half_window)
    if ((hi - lo + 1L) < window_size) {
      if (lo == 1L) hi <- min(n, window_size)
      if (hi == n) lo <- max(1L, n - window_size + 1L)
    }

    local_ratios <- ratios[lo:hi]
    center <- median(local_ratios, na.rm = TRUE)
    scale <- mad(local_ratios, center = center, constant = 1.4826, na.rm = TRUE)
    if (!is.finite(scale) || scale <= 0) scale <- global_scale

    local_center[[i]] <- center
    local_scale[[i]] <- scale
  }

  z <- (ratios - local_center) / local_scale
  p_two_sided <- 2 * pnorm(abs(z), lower.tail = FALSE)

  data %>%
    mutate(
      significance_b_local_center = local_center,
      significance_b_local_scale = local_scale,
      significance_b_z = z,
      significance_b_pvalue = p_two_sided,
      significance_b_fdr_bh = p.adjust(significance_b_pvalue, method = "BH")
    )
}

significance_b_results <- paired_enrichment %>%
  filter(science_peptide_filter_experiment) %>%
  group_by(experiment) %>%
  group_split() %>%
  lapply(add_significance_b) %>%
  bind_rows() %>%
  select(
    row_id,
    accession_number,
    experiment,
    significance_b_abundance_proxy,
    significance_b_local_center,
    significance_b_local_scale,
    significance_b_z,
    significance_b_pvalue,
    significance_b_fdr_bh
  )

paired_enrichment <- paired_enrichment %>%
  left_join(
    significance_b_results,
    by = c("row_id", "accession_number", "experiment", "significance_b_abundance_proxy")
  )

paired_wide <- paired_enrichment %>%
  select(
    row_id,
    accession_number,
    experiment,
    normalized_log2_ratio_rapa_control,
    normalized_total_spectra_control,
    normalized_total_spectra_rapa,
    unique_peptide_count_control,
    unique_peptide_count_rapa,
    rapa_peptide_supported,
    science_peptide_filter_experiment,
    significance_b_abundance_proxy,
    significance_b_z,
    significance_b_pvalue,
    significance_b_fdr_bh
  ) %>%
  pivot_wider(
    names_from = experiment,
    values_from = c(
      normalized_log2_ratio_rapa_control,
      normalized_total_spectra_control,
      normalized_total_spectra_rapa,
      unique_peptide_count_control,
      unique_peptide_count_rapa,
      rapa_peptide_supported,
      science_peptide_filter_experiment,
      significance_b_abundance_proxy,
      significance_b_z,
      significance_b_pvalue,
      significance_b_fdr_bh
    )
  )

candidate_summary <- merged_long %>%
  group_by(
    row_id,
    accession_number,
    gene,
    transcript,
    gene_product,
    molecular_weight_kda,
    protein_length_aa,
    taxonomy,
    protein_grouping_ambiguity
  ) %>%
  summarise(
    mean_normalized_total_spectra = mean(normalized_total_spectra, na.rm = TRUE),
    median_normalized_total_spectra = median(normalized_total_spectra, na.rm = TRUE),
    max_normalized_total_spectra = max(normalized_total_spectra, na.rm = TRUE),
    sd_normalized_total_spectra = sd(normalized_total_spectra, na.rm = TRUE),
    cv_percent = if_else(
      mean_normalized_total_spectra > 0,
      100 * sd_normalized_total_spectra / mean_normalized_total_spectra,
      NA_real_
    ),
    mean_unique_peptide_count = mean(unique_peptide_count, na.rm = TRUE),
    min_unique_peptide_count = min(unique_peptide_count, na.rm = TRUE),
    max_unique_peptide_count = max(unique_peptide_count, na.rm = TRUE),
    samples_with_spectra = sum(normalized_total_spectra > 0, na.rm = TRUE),
    samples_with_unique_peptides = sum(unique_peptide_count > 0, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  left_join(paired_wide, by = c("row_id", "accession_number")) %>%
  mutate(
    mean_control_spectra = rowMeans(pick(starts_with("normalized_total_spectra_control_")), na.rm = TRUE),
    mean_rapa_spectra = rowMeans(pick(starts_with("normalized_total_spectra_rapa_")), na.rm = TRUE),
    mean_control_unique_peptides = rowMeans(pick(starts_with("unique_peptide_count_control_")), na.rm = TRUE),
    mean_rapa_unique_peptides = rowMeans(pick(starts_with("unique_peptide_count_rapa_")), na.rm = TRUE),
    exp1_log2_rapa_vs_control = normalized_log2_ratio_rapa_control_exp1,
    exp2_log2_rapa_vs_control = normalized_log2_ratio_rapa_control_exp2,
    mean_log2_rapa_vs_control = rowMeans(pick(exp1_log2_rapa_vs_control, exp2_log2_rapa_vs_control), na.rm = TRUE),
    min_log2_rapa_vs_control = pmin(exp1_log2_rapa_vs_control, exp2_log2_rapa_vs_control, na.rm = TRUE),
    experiments_rapa_enriched = (exp1_log2_rapa_vs_control > 0) + (exp2_log2_rapa_vs_control > 0),
    experiments_with_rapa_peptide_support = rapa_peptide_supported_exp1 + rapa_peptide_supported_exp2,
    experiments_passing_science_peptide_filter = science_peptide_filter_experiment_exp1 + science_peptide_filter_experiment_exp2,
    significance_b_fdr_exp1 = significance_b_fdr_bh_exp1,
    significance_b_fdr_exp2 = significance_b_fdr_bh_exp2,
    significance_b_pvalue_exp1 = significance_b_pvalue_exp1,
    significance_b_pvalue_exp2 = significance_b_pvalue_exp2,
    max_significance_b_fdr = pmax(significance_b_fdr_exp1, significance_b_fdr_exp2, na.rm = TRUE),
    min_significance_b_fdr = pmin(significance_b_fdr_exp1, significance_b_fdr_exp2, na.rm = TRUE),
    fdr_display_bin = case_when(
      max_significance_b_fdr < 1e-10 ~ "<1e-10",
      max_significance_b_fdr < 1e-9 ~ "<1e-9",
      max_significance_b_fdr < 1e-7 ~ "<1e-7",
      max_significance_b_fdr < 1e-6 ~ "<1e-6",
      max_significance_b_fdr < 1e-5 ~ "<1e-5",
      max_significance_b_fdr < 1e-4 ~ "<1e-4",
      max_significance_b_fdr < 1e-3 ~ "<1e-3",
      max_significance_b_fdr < 1e-2 ~ "<1e-2",
      TRUE ~ ">=1e-2"
    ),
    fdr_display_bin = factor(
      fdr_display_bin,
      levels = c("<1e-2", "<1e-3", "<1e-4", "<1e-5", "<1e-6", "<1e-7", "<1e-9", "<1e-10", ">=1e-2")
    ),
    high_confidence_observed = samples_with_spectra == sample_count &
      min_unique_peptide_count >= 2,
    science_peptide_filter = experiments_passing_science_peptide_filter == experiment_count,
    significance_b_fdr_0_01_both_experiments = significance_b_fdr_exp1 < 0.01 &
      significance_b_fdr_exp2 < 0.01,
    reproducible_rapa_enriched = experiments_rapa_enriched == experiment_count,
    rapa_enrichment_candidate = science_peptide_filter &
      reproducible_rapa_enriched &
      significance_b_fdr_0_01_both_experiments,
    exclusion_reason = case_when(
      rapa_enrichment_candidate ~ "FDR < 0.01 in both experiments",
      !science_peptide_filter ~ "Excluded by peptide filter",
      !reproducible_rapa_enriched ~ "Not rapa-enriched in both experiments",
      is.na(significance_b_fdr_exp1) & is.na(significance_b_fdr_exp2) ~ "No Significance B FDR in either experiment",
      is.na(significance_b_fdr_exp1) ~ "No Significance B FDR in exp1",
      is.na(significance_b_fdr_exp2) ~ "No Significance B FDR in exp2",
      significance_b_fdr_exp1 >= 0.01 & significance_b_fdr_exp2 >= 0.01 ~ "FDR >= 0.01 in both experiments",
      significance_b_fdr_exp1 >= 0.01 ~ "FDR >= 0.01 in exp1",
      significance_b_fdr_exp2 >= 0.01 ~ "FDR >= 0.01 in exp2",
      TRUE ~ "Excluded by candidate screen"
    ),
    icat_keyword = str_detect(
      str_to_lower(paste(gene, gene_product, accession_number)),
      "icat|imap|icmt|conoid"
    )
  ) %>%
  arrange(
    desc(rapa_enrichment_candidate),
    max_significance_b_fdr,
    desc(mean_log2_rapa_vs_control),
    desc(mean_rapa_spectra),
    accession_number
  ) %>%
  mutate(candidate_rank = row_number()) %>%
  relocate(candidate_rank)

sample_qc <- merged_long %>%
  group_by(sample_id, experiment, condition, sample_label) %>%
  summarise(
    total_normalized_spectra = sum(normalized_total_spectra, na.rm = TRUE),
    proteins_with_spectra = sum(normalized_total_spectra > 0, na.rm = TRUE),
    total_unique_peptide_counts = sum(unique_peptide_count, na.rm = TRUE),
    proteins_with_unique_peptides = sum(unique_peptide_count > 0, na.rm = TRUE),
    median_spectra_detected_proteins = median(normalized_total_spectra[normalized_total_spectra > 0], na.rm = TRUE),
    .groups = "drop"
  ) %>%
  arrange(as.integer(sample_id))

top_label_count <- min(28, sum(candidate_summary$rapa_enrichment_candidate, na.rm = TRUE))
if (!top_label_count) top_label_count <- min(28, nrow(candidate_summary))
top_labeled <- candidate_summary %>%
  filter(if (any(rapa_enrichment_candidate, na.rm = TRUE)) rapa_enrichment_candidate else TRUE) %>%
  slice_head(n = top_label_count) %>%
  arrange(
    desc(exp1_log2_rapa_vs_control + exp2_log2_rapa_vs_control),
    desc(exp2_log2_rapa_vs_control),
    desc(exp1_log2_rapa_vs_control)
  ) %>%
  mutate(
    figure_label = as.character(row_number()),
    display_name = case_when(
      !is.na(gene) & gene != "" ~ gene,
      TRUE ~ accession_number
    ),
    list_label = paste0(figure_label, ". ", display_name),
    rank_group = as.character(fdr_display_bin)
  )

candidate_summary <- candidate_summary %>%
  left_join(
    top_labeled %>% select(row_id, accession_number, figure_label, rank_group),
    by = c("row_id", "accession_number")
  )

readr::write_csv(merged_long, file.path(processed_dir, "Figure6_interactome_long_source_data.csv"))
readr::write_csv(wide_source, file.path(processed_dir, "Figure6_interactome_wide_source_data.csv"))
readr::write_csv(paired_enrichment, file.path(processed_dir, "Figure6_interactome_paired_enrichment_source_data.csv"))
readr::write_csv(significance_b_results, file.path(table_dir, "Figure6_interactome_significance_b_by_experiment.csv"))
readr::write_csv(candidate_summary, file.path(table_dir, "Figure6_interactome_candidate_summary.csv"))
readr::write_csv(
  top_labeled %>%
    select(
      figure_label,
      candidate_rank,
      accession_number,
      gene,
      gene_product,
      exp1_log2_rapa_vs_control,
      exp2_log2_rapa_vs_control,
      significance_b_fdr_exp1,
      significance_b_fdr_exp2,
      max_significance_b_fdr,
      fdr_display_bin
    ),
  file.path(table_dir, "Figure6_interactome_figure_labeled_candidates.csv")
)
readr::write_csv(
  candidate_summary %>%
    filter(
      science_peptide_filter,
      reproducible_rapa_enriched,
      mean_log2_rapa_vs_control >= 1,
      !rapa_enrichment_candidate
    ) %>%
    arrange(desc(mean_log2_rapa_vs_control)) %>%
    select(
      candidate_rank,
      accession_number,
      gene,
      gene_product,
      exp1_log2_rapa_vs_control,
      exp2_log2_rapa_vs_control,
      significance_b_fdr_exp1,
      significance_b_fdr_exp2,
      max_significance_b_fdr,
      exclusion_reason
    ),
  file.path(table_dir, "Figure6_interactome_nearby_excluded_points.csv")
)
readr::write_csv(sample_qc, file.path(table_dir, "Figure6_interactome_sample_qc.csv"))
readr::write_csv(
  candidate_summary %>% slice_head(n = 100),
  file.path(table_dir, "Figure6_interactome_top100_ranked_candidates.csv")
)
foldchange_export_cols <- c(
  "candidate_rank",
  "figure_label",
  "accession_number",
  "gene",
  "gene_product",
  "molecular_weight_kda",
  "protein_length_aa",
  "exp1_log2_rapa_vs_control",
  "exp2_log2_rapa_vs_control",
  "mean_log2_rapa_vs_control",
  "min_log2_rapa_vs_control",
  "mean_control_spectra",
  "mean_rapa_spectra",
  "mean_control_unique_peptides",
  "mean_rapa_unique_peptides",
  "science_peptide_filter",
  "reproducible_rapa_enriched",
  "significance_b_fdr_exp1",
  "significance_b_fdr_exp2",
  "max_significance_b_fdr",
  "rapa_enrichment_candidate",
  "exclusion_reason"
)
readr::write_csv(
  candidate_summary %>%
    filter(
      science_peptide_filter,
      mean_log2_rapa_vs_control > 1
    ) %>%
    arrange(desc(mean_log2_rapa_vs_control), desc(min_log2_rapa_vs_control), gene) %>%
    select(any_of(foldchange_export_cols)),
  file.path(table_dir, "Figure6_interactome_log2FC_gt1_mean_noFDR.csv")
)
readr::write_csv(
  candidate_summary %>%
    filter(
      science_peptide_filter,
      exp1_log2_rapa_vs_control > 1,
      exp2_log2_rapa_vs_control > 1
    ) %>%
    arrange(desc(mean_log2_rapa_vs_control), desc(min_log2_rapa_vs_control), gene) %>%
    select(any_of(foldchange_export_cols)),
  file.path(table_dir, "Figure6_interactome_log2FC_gt1_both_experiments_noFDR.csv")
)

hyperlp <- read.csv(hyperlp_file, check.names = FALSE)
names(hyperlp)[1] <- "hyperlp_gene_id"
known_hyperlp_locations <- c(
  "19S proteasome",
  "20S proteasome",
  "40S ribosome",
  "60S ribosome",
  "apical 1",
  "apical 2",
  "apicoplast",
  "cytosol",
  "dense granules",
  "endomembrane vesicles",
  "ER 1",
  "ER 2",
  "Golgi",
  "IMC",
  "micronemes",
  "mitochondrion - membranes",
  "mitochondrion - soluble",
  "nucleolus",
  "nucleus - chromatin",
  "nucleus - non-chromatin",
  "PM - integral",
  "PM - peripheral 1",
  "PM - peripheral 2",
  "rhoptries 1",
  "rhoptries 2",
  "tubulin cytoskeleton",
  "unknown"
)

as_numeric_safe <- function(x) {
  suppressWarnings(readr::parse_number(as.character(x)))
}

hyperlp_annotation <- hyperlp %>%
  mutate(
    tagm_mcmc_probability_numeric = as_numeric_safe(tagm.mcmc.probability),
    tagm_mcmc_allocation_pred_numeric = as_numeric_safe(tagm.mcmc.allocation.pred),
    hyperlp_allocation_resolved = case_when(
      tagm.mcmc.allocation %in% known_hyperlp_locations ~ tagm.mcmc.allocation,
      tagm.mcmc.probability %in% known_hyperlp_locations ~ tagm.mcmc.probability,
      tagm.mcmc.probability.lowerquantile %in% known_hyperlp_locations ~ tagm.mcmc.probability.lowerquantile,
      tagm.mcmc.allocation.pred %in% known_hyperlp_locations ~ tagm.mcmc.allocation.pred,
      tagm.map.allocation %in% known_hyperlp_locations ~ tagm.map.allocation,
      tagm.map.probability %in% known_hyperlp_locations ~ tagm.map.probability,
      tagm.map.outlier %in% known_hyperlp_locations ~ tagm.map.outlier,
      TRUE ~ NA_character_
    )
  ) %>%
  transmute(
    gene = hyperlp_gene_id,
    hyperlp_accession = Accession,
    hyperlp_description = Description,
    hyperlp_allocation = hyperlp_allocation_resolved,
    hyperlp_allocation_probability = coalesce(tagm_mcmc_probability_numeric, tagm_mcmc_allocation_pred_numeric),
    hyperlp_loc_probability = as_numeric_safe(tagm.mcmc.loc.prob),
    hyperlp_apical_probability = coalesce(as_numeric_safe(`tagm.mcmc.joint.apical.1`), 0) +
      coalesce(as_numeric_safe(`tagm.mcmc.joint.apical.2`), 0),
    hyperlp_microneme_probability = coalesce(as_numeric_safe(`tagm.mcmc.joint.micronemes`), 0),
    hyperlp_rhoptry_probability = coalesce(as_numeric_safe(`tagm.mcmc.joint.rhoptries.1`), 0) +
      coalesce(as_numeric_safe(`tagm.mcmc.joint.rhoptries.2`), 0),
    hyperlp_dense_granule_probability = coalesce(as_numeric_safe(`tagm.mcmc.joint.dense.granules`), 0),
    hyperlp_pm_probability = coalesce(as_numeric_safe(`tagm.mcmc.joint.PM.integral`), 0) +
      coalesce(as_numeric_safe(`tagm.mcmc.joint.PM.peripheral.1`), 0) +
      coalesce(as_numeric_safe(`tagm.mcmc.joint.PM.peripheral.2`), 0),
    hyperlp_tubulin_cytoskeleton_probability = coalesce(as_numeric_safe(`tagm.mcmc.joint.tubulin.cytoskeleton`), 0),
    hyperlp_imc_probability = coalesce(as_numeric_safe(`tagm.mcmc.joint.IMC`), 0),
    num_tmds_tmhmm = as_numeric_safe(Num.TMDs.TMHMM),
    signalp5 = str_to_upper(str_squish(as.character(SignalP5.0))),
    num_tmds_sp_corrected = as_numeric_safe(Num.TMDs.SP.corrected),
    hyperlp_crispr_score = as_numeric_safe(CRISPR.Score),
    hyperlp_conservation_score = as_numeric_safe(Conservation.score),
    hyperlp_conservation_profile = na_if(str_squish(as.character(Assigned.conservation.profile)), ""),
    apical_flag = str_detect(hyperlp_allocation, "^apical") | hyperlp_apical_probability >= 0.5,
    microneme_flag = hyperlp_allocation == "micronemes" | hyperlp_microneme_probability >= 0.5,
    rhoptry_flag = str_detect(hyperlp_allocation, "^rhoptries") | hyperlp_rhoptry_probability >= 0.5,
    dense_granule_flag = hyperlp_allocation == "dense granules" | hyperlp_dense_granule_probability >= 0.5,
    secretory_organelle_flag = microneme_flag | rhoptry_flag | dense_granule_flag,
    imc_or_cytoskeleton_flag = hyperlp_allocation %in% c("IMC", "tubulin cytoskeleton") |
      hyperlp_imc_probability >= 0.5 |
      hyperlp_tubulin_cytoskeleton_probability >= 0.5,
    apical_secretory_cytoskeleton_flag = apical_flag |
      secretory_organelle_flag |
      imc_or_cytoskeleton_flag,
    pm_surface_flag = str_detect(hyperlp_allocation, "^PM") | hyperlp_pm_probability >= 0.5,
    signalp_flag = signalp5 %in% c("SP", "TRUE"),
    has_tmd_flag = coalesce(num_tmds_tmhmm, 0) > 0 |
      coalesce(num_tmds_sp_corrected, 0) > 0,
    multi_tmd_flag = pmax(coalesce(num_tmds_tmhmm, 0), coalesce(num_tmds_sp_corrected, 0)) >= 2,
    secretory_or_membrane_feature = signalp_flag | has_tmd_flag,
    coccidia_or_toxo_restricted_flag = str_detect(
      hyperlp_conservation_profile,
      "Toxoplasma/Hammondia|Coccidia"
    ) & !str_detect(hyperlp_conservation_profile, "Plasmodium|Piroplasms"),
    broadly_conserved_flag = str_detect(hyperlp_conservation_profile, "SAR|Other eukaryotes") |
      hyperlp_conservation_score >= 0.9,
    microneme_surface_like_proxy = microneme_flag & secretory_or_membrane_feature
  )

crispr_rank <- suppressWarnings(readxl::read_excel(crispr_file, sheet = "Sheet1")) %>%
  transmute(
    crispr_gt1_id = ID,
    crispr_description = `Protein desprition`,
    crispr_rank = `Rank numbers`,
    crispr_mean_phenotype = `mean phenotype`,
    crispr_rank_percentile = crispr_rank / max(crispr_rank, na.rm = TRUE),
    crispr_top20pct = crispr_rank_percentile <= 0.2,
    crispr_top10pct = crispr_rank_percentile <= 0.1
  )

annotated_candidates <- candidate_summary %>%
  mutate(
    gene_numeric_id = str_match(gene, "^TGME49_(\\d+)")[, 2],
    crispr_gt1_id = if_else(!is.na(gene_numeric_id), paste0("TGGT1_", gene_numeric_id), NA_character_)
  ) %>%
  left_join(hyperlp_annotation, by = "gene") %>%
  left_join(crispr_rank, by = "crispr_gt1_id") %>%
  mutate(
    has_hyperlp_annotation = !is.na(hyperlp_allocation),
    has_crispr_rank = !is.na(crispr_rank),
    candidate_class = if_else(rapa_enrichment_candidate, "FDR candidate", "background")
  )

enrichment_universe <- annotated_candidates %>%
  filter(science_peptide_filter, has_hyperlp_annotation)

fisher_for_flag <- function(
  data,
  flag_col,
  feature_label = flag_col,
  feature_family = "Localization/feature",
  universe_label = "HyperLp-annotated peptide-filtered proteins"
) {
  flag <- data[[flag_col]]
  hit <- data$rapa_enrichment_candidate
  complete <- !is.na(flag) & !is.na(hit)
  tab <- table(hit = hit[complete], flag = flag[complete])
  for (rn in c("FALSE", "TRUE")) {
    if (!rn %in% rownames(tab)) tab <- rbind(tab, setNames(c(0, 0), colnames(tab)))
  }
  for (cn in c("FALSE", "TRUE")) {
    if (!cn %in% colnames(tab)) tab <- cbind(tab, setNames(c(0, 0), cn))
  }
  tab <- tab[c("FALSE", "TRUE"), c("FALSE", "TRUE")]
  ft <- fisher.test(tab, alternative = "greater")
  tibble::tibble(
    feature = flag_col,
    feature_label = feature_label,
    feature_family = feature_family,
    universe = universe_label,
    candidates_with_feature = unname(tab["TRUE", "TRUE"]),
    candidates_total = sum(tab["TRUE", ]),
    background_with_feature = unname(tab["FALSE", "TRUE"]),
    background_total = sum(tab["FALSE", ]),
    candidate_fraction = if_else(candidates_total > 0, candidates_with_feature / candidates_total, NA_real_),
    background_fraction = if_else(background_total > 0, background_with_feature / background_total, NA_real_),
    odds_ratio = unname(ft$estimate),
    p_value = ft$p.value
  )
}

crispr_enrichment_universe <- annotated_candidates %>%
  filter(science_peptide_filter, has_crispr_rank)

feature_tests <- tibble::tribble(
  ~feature, ~feature_label, ~feature_family, ~universe_label,
  "apical_flag", "Apical", "Localization", "HyperLp-annotated peptide-filtered proteins",
  "microneme_flag", "Microneme", "Localization", "HyperLp-annotated peptide-filtered proteins",
  "microneme_surface_like_proxy", "Microneme + SignalP/TMD", "Localization + structure", "HyperLp-annotated peptide-filtered proteins",
  "rhoptry_flag", "Rhoptry", "Localization", "HyperLp-annotated peptide-filtered proteins",
  "dense_granule_flag", "Dense granule", "Localization", "HyperLp-annotated peptide-filtered proteins",
  "secretory_organelle_flag", "Secretory organelle", "Localization", "HyperLp-annotated peptide-filtered proteins",
  "apical_secretory_cytoskeleton_flag", "Apical/secretory/cytoskeleton", "Localization", "HyperLp-annotated peptide-filtered proteins",
  "imc_or_cytoskeleton_flag", "IMC/cytoskeleton", "Localization", "HyperLp-annotated peptide-filtered proteins",
  "pm_surface_flag", "PM surface-like", "Localization", "HyperLp-annotated peptide-filtered proteins",
  "signalp_flag", "Signal peptide", "Structure", "HyperLp-annotated peptide-filtered proteins",
  "has_tmd_flag", "Any TMD", "Structure", "HyperLp-annotated peptide-filtered proteins",
  "multi_tmd_flag", ">=2 TMDs", "Structure", "HyperLp-annotated peptide-filtered proteins",
  "secretory_or_membrane_feature", "SignalP/TMD", "Structure", "HyperLp-annotated peptide-filtered proteins",
  "coccidia_or_toxo_restricted_flag", "Coccidia/Toxo-biased", "Conservation", "HyperLp-annotated peptide-filtered proteins",
  "broadly_conserved_flag", "Broadly conserved", "Conservation", "HyperLp-annotated peptide-filtered proteins"
)

feature_enrichment <- bind_rows(
  lapply(seq_len(nrow(feature_tests)), function(i) {
    fisher_for_flag(
      enrichment_universe,
      feature_tests$feature[[i]],
      feature_tests$feature_label[[i]],
      feature_tests$feature_family[[i]],
      feature_tests$universe_label[[i]]
    )
  }),
  fisher_for_flag(
    crispr_enrichment_universe,
    "crispr_top20pct",
    "CRISPR top 20%",
    "Essentiality",
    "CRISPR-mapped peptide-filtered proteins"
  ),
  fisher_for_flag(
    crispr_enrichment_universe,
    "crispr_top10pct",
    "CRISPR top 10%",
    "Essentiality",
    "CRISPR-mapped peptide-filtered proteins"
  )
) %>%
  mutate(
    fdr_bh = p.adjust(p_value, method = "BH"),
    candidate_fraction_label = scales::percent(candidate_fraction, accuracy = 0.1),
    background_fraction_label = scales::percent(background_fraction, accuracy = 0.1)
  )

safe_wilcox_p <- function(x, y, alternative = "less") {
  x <- x[is.finite(x)]
  y <- y[is.finite(y)]
  if (length(x) < 1 || length(y) < 1) return(NA_real_)
  wilcox.test(x, y, alternative = alternative)$p.value
}

crispr_compare <- annotated_candidates %>%
  filter(science_peptide_filter) %>%
  summarise(
    candidate_n = sum(rapa_enrichment_candidate),
    background_n = sum(!rapa_enrichment_candidate),
    candidate_with_gt1_rank_n = sum(rapa_enrichment_candidate & has_crispr_rank),
    background_with_gt1_rank_n = sum(!rapa_enrichment_candidate & has_crispr_rank),
    candidate_median_rank = median(crispr_rank[rapa_enrichment_candidate], na.rm = TRUE),
    background_median_rank = median(crispr_rank[!rapa_enrichment_candidate], na.rm = TRUE),
    candidate_median_percentile = median(crispr_rank_percentile[rapa_enrichment_candidate], na.rm = TRUE),
    background_median_percentile = median(crispr_rank_percentile[!rapa_enrichment_candidate], na.rm = TRUE),
    candidate_median_mean_phenotype = median(crispr_mean_phenotype[rapa_enrichment_candidate], na.rm = TRUE),
    background_median_mean_phenotype = median(crispr_mean_phenotype[!rapa_enrichment_candidate], na.rm = TRUE),
    wilcox_rank_p_lower = safe_wilcox_p(
      crispr_rank[rapa_enrichment_candidate],
      crispr_rank[!rapa_enrichment_candidate],
      alternative = "less"
    ),
    wilcox_phenotype_p_lower = safe_wilcox_p(
      crispr_mean_phenotype[rapa_enrichment_candidate],
      crispr_mean_phenotype[!rapa_enrichment_candidate],
      alternative = "less"
    ),
    candidate_with_hyperlp_crispr_n = sum(rapa_enrichment_candidate & is.finite(hyperlp_crispr_score)),
    background_with_hyperlp_crispr_n = sum(!rapa_enrichment_candidate & is.finite(hyperlp_crispr_score)),
    candidate_median_hyperlp_crispr_score = median(hyperlp_crispr_score[rapa_enrichment_candidate], na.rm = TRUE),
    background_median_hyperlp_crispr_score = median(hyperlp_crispr_score[!rapa_enrichment_candidate], na.rm = TRUE),
    wilcox_hyperlp_crispr_p_lower = safe_wilcox_p(
      hyperlp_crispr_score[rapa_enrichment_candidate],
      hyperlp_crispr_score[!rapa_enrichment_candidate],
      alternative = "less"
    )
  )

compare_continuous_feature <- function(
  data,
  value_col,
  feature_label,
  feature_family,
  alternative = "two.sided",
  direction_note = "two-sided"
) {
  value <- data[[value_col]]
  hit <- data$rapa_enrichment_candidate
  x <- value[hit]
  y <- value[!hit]
  x <- x[is.finite(x)]
  y <- y[is.finite(y)]
  p <- if (length(x) >= 1 && length(y) >= 1) {
    wilcox.test(x, y, alternative = alternative)$p.value
  } else {
    NA_real_
  }

  tibble::tibble(
    feature = value_col,
    feature_label = feature_label,
    feature_family = feature_family,
    test = "Wilcoxon rank-sum",
    alternative = direction_note,
    candidate_n = length(x),
    background_n = length(y),
    candidate_median = median(x, na.rm = TRUE),
    background_median = median(y, na.rm = TRUE),
    candidate_mean = mean(x, na.rm = TRUE),
    background_mean = mean(y, na.rm = TRUE),
    p_value = p
  )
}

continuous_feature_compare <- bind_rows(
  compare_continuous_feature(
    annotated_candidates %>% filter(science_peptide_filter),
    "molecular_weight_kda",
    "Molecular weight",
    "Protein properties"
  ),
  compare_continuous_feature(
    annotated_candidates %>% filter(science_peptide_filter),
    "protein_length_aa",
    "Protein length",
    "Protein properties"
  ),
  compare_continuous_feature(
    annotated_candidates %>% filter(science_peptide_filter, has_hyperlp_annotation),
    "num_tmds_sp_corrected",
    "SP-corrected TMD count",
    "Structure"
  ),
  compare_continuous_feature(
    annotated_candidates %>% filter(science_peptide_filter, has_hyperlp_annotation),
    "hyperlp_conservation_score",
    "Conservation score",
    "Conservation"
  ),
  compare_continuous_feature(
    annotated_candidates %>% filter(science_peptide_filter, has_crispr_rank),
    "crispr_rank_percentile",
    "CRISPR rank percentile",
    "Essentiality",
    alternative = "less",
    direction_note = "candidate lower than background"
  ),
  compare_continuous_feature(
    annotated_candidates %>% filter(science_peptide_filter, has_crispr_rank),
    "crispr_mean_phenotype",
    "CRISPR mean phenotype",
    "Essentiality",
    alternative = "less",
    direction_note = "candidate lower than background"
  ),
  compare_continuous_feature(
    annotated_candidates %>% filter(science_peptide_filter, has_hyperlp_annotation),
    "hyperlp_crispr_score",
    "HyperLp CRISPR score",
    "Essentiality",
    alternative = "less",
    direction_note = "candidate lower than background"
  )
) %>%
  mutate(fdr_bh = p.adjust(p_value, method = "BH"))

candidate_feature_summary <- annotated_candidates %>%
  filter(rapa_enrichment_candidate) %>%
  select(
    figure_label,
    candidate_rank,
    gene,
    accession_number,
    gene_product,
    molecular_weight_kda,
    protein_length_aa,
    exp1_log2_rapa_vs_control,
    exp2_log2_rapa_vs_control,
    significance_b_fdr_exp1,
    significance_b_fdr_exp2,
    fdr_display_bin,
    hyperlp_allocation,
    hyperlp_allocation_probability,
    hyperlp_apical_probability,
    hyperlp_microneme_probability,
    hyperlp_rhoptry_probability,
    hyperlp_dense_granule_probability,
    hyperlp_pm_probability,
    hyperlp_imc_probability,
    hyperlp_tubulin_cytoskeleton_probability,
    apical_flag,
    microneme_flag,
    rhoptry_flag,
    dense_granule_flag,
    secretory_organelle_flag,
    imc_or_cytoskeleton_flag,
    apical_secretory_cytoskeleton_flag,
    pm_surface_flag,
    signalp_flag,
    has_tmd_flag,
    multi_tmd_flag,
    secretory_or_membrane_feature,
    microneme_surface_like_proxy,
    num_tmds_tmhmm,
    signalp5,
    num_tmds_sp_corrected,
    hyperlp_conservation_score,
    hyperlp_conservation_profile,
    coccidia_or_toxo_restricted_flag,
    broadly_conserved_flag,
    hyperlp_crispr_score,
    crispr_gt1_id,
    crispr_rank,
    crispr_rank_percentile,
    crispr_mean_phenotype
  ) %>%
  arrange(as.integer(figure_label))

readr::write_csv(annotated_candidates, file.path(table_dir, "Figure6_interactome_candidate_summary_with_database_annotations.csv"))
readr::write_csv(candidate_feature_summary, file.path(table_dir, "Figure6_interactome_FDR_candidates_database_annotations.csv"))
readr::write_csv(feature_enrichment, file.path(table_dir, "Figure6_interactome_feature_enrichment_tests.csv"))
readr::write_csv(crispr_compare, file.path(table_dir, "Figure6_interactome_crispr_candidate_comparison.csv"))
readr::write_csv(continuous_feature_compare, file.path(table_dir, "Figure6_interactome_continuous_feature_comparisons.csv"))

fig_palette <- c(
  `<1e-2` = "#2F7D63",
  `<1e-3` = "#82B943",
  `<1e-4` = "#1CA6B8",
  `<1e-5` = "#146C78",
  `<1e-6` = "#D12B9A",
  `<1e-7` = "#D7B51D",
  `<1e-9` = "#7FBF3F",
  `<1e-10` = "#C9343F",
  `>=1e-2` = "#9CA3AF",
  neutral = "#CFCFCF",
  axis = "#222222"
)

theme_set(icat_theme_classic() + theme(panel.grid = element_blank()))

scatter_data <- candidate_summary %>%
  filter(science_peptide_filter) %>%
  mutate(
    is_labeled = !is.na(figure_label),
    rank_group = replace_na(rank_group, "background")
  )

xmax <- max(scatter_data$exp1_log2_rapa_vs_control, na.rm = TRUE)
ymax <- max(scatter_data$exp2_log2_rapa_vs_control, na.rm = TRUE)
xmin <- min(scatter_data$exp1_log2_rapa_vs_control, na.rm = TRUE)
ymin <- min(scatter_data$exp2_log2_rapa_vs_control, na.rm = TRUE)
axis_max <- ceiling(max(xmax, ymax, 2))
axis_min <- floor(min(xmin, ymin, 0))

scatter_panel <- ggplot(scatter_data, aes(exp1_log2_rapa_vs_control, exp2_log2_rapa_vs_control)) +
  geom_hline(yintercept = 0, linewidth = ICAT_LINE_MM, colour = "#B8B8B8") +
  geom_vline(xintercept = 0, linewidth = ICAT_LINE_MM, colour = "#B8B8B8") +
  geom_point(
    data = scatter_data %>% filter(!is_labeled),
    colour = fig_palette[["neutral"]],
    alpha = 0.62,
    size = 1.15
  ) +
  geom_point(
    data = scatter_data %>% filter(is_labeled),
    aes(colour = rank_group),
    shape = 18,
    size = 2.2,
    alpha = 0.95
  ) +
  geom_text_repel(
    data = scatter_data %>% filter(is_labeled),
    aes(label = figure_label, colour = rank_group),
    size = ICAT_TEXT_BODY_MM,
    fontface = "bold",
    min.segment.length = 0,
    segment.size = ICAT_LINE_MM,
    box.padding = 0.18,
    point.padding = 0.1,
    max.overlaps = Inf,
    seed = 6,
    show.legend = FALSE
  ) +
  annotate(
    "label",
    x = axis_min + 0.6 * (axis_max - axis_min),
    y = axis_max - 0.01 * (axis_max - axis_min),
    label = "ICAT proximity-labeling\nrapa vs control",
    hjust = 0.5,
    vjust = 1,
    size = ICAT_TEXT_BODY_MM,
    fontface = "bold",
    linewidth = ICAT_LINE_MM,
    fill = "white",
    colour = fig_palette[["axis"]]
  ) +
  scale_colour_manual(
    values = c(
      `<1e-2` = fig_palette[["<1e-2"]],
      `<1e-3` = fig_palette[["<1e-3"]],
      `<1e-4` = fig_palette[["<1e-4"]],
      `<1e-5` = fig_palette[["<1e-5"]],
      `<1e-6` = fig_palette[["<1e-6"]],
      `<1e-7` = fig_palette[["<1e-7"]],
      `<1e-9` = fig_palette[["<1e-9"]],
      `<1e-10` = fig_palette[["<1e-10"]]
    ),
    guide = "none"
  ) +
  coord_cartesian(
    xlim = c(axis_min, axis_max),
    ylim = c(axis_min, axis_max),
    clip = "off"
  ) +
  labs(
    x = expression(Exp1:~normalized~log[2]*"-ratio (rapa/control)"),
    y = expression(Exp2:~normalized~log[2]*"-ratio (rapa/control)"),
    title = "A  DiQ-BioID-like enrichment reproducibility"
  ) +
  theme(
    aspect.ratio = 1,
    plot.margin = margin(4, 8, 4, 4)
  )

label_panel <- top_labeled %>%
  mutate(
    label_y = rev(seq_len(n())),
    label_x = if_else(candidate_rank <= 14, 0, 0.52)
  )

fdr_legend_data <- tibble::tibble(
  label = c("FDR:", "<1e-2", "<1e-3", "<1e-4", "<1e-5", "<1e-6", "<1e-7", "<1e-9", "<1e-10"),
  x = c(0.03, 0.18, 0.36, 0.54, 0.72, 0.18, 0.36, 0.54, 0.72),
  y = c(0.7, 0.7, 0.7, 0.7, 0.7, 0.28, 0.28, 0.28, 0.28),
  colour = c(fig_palette[["axis"]], fig_palette[c("<1e-2", "<1e-3", "<1e-4", "<1e-5", "<1e-6", "<1e-7", "<1e-9", "<1e-10")])
)

fdr_legend_panel <- ggplot(fdr_legend_data, aes(x, y, label = label)) +
  annotate("rect", xmin = 0, xmax = 1, ymin = 0.05, ymax = 0.92, fill = "white", colour = fig_palette[["axis"]], linewidth = ICAT_LINE_MM) +
  geom_text(aes(colour = label), hjust = 0, size = ICAT_TEXT_SMALL_MM) +
  scale_colour_manual(values = setNames(fdr_legend_data$colour, fdr_legend_data$label), guide = "none") +
  coord_cartesian(xlim = c(0, 1), ylim = c(0, 1), clip = "off") +
  theme_void(base_family = "Arial") +
  theme(plot.margin = margin(8, 4, 0, 8))

list_panel <- ggplot(label_panel, aes(label_x, label_y, label = list_label, colour = rank_group)) +
  geom_text(hjust = 0, size = ICAT_TEXT_SMALL_MM * 0.92, lineheight = 0.92) +
  scale_colour_manual(
    values = c(
      `<1e-2` = fig_palette[["<1e-2"]],
      `<1e-3` = fig_palette[["<1e-3"]],
      `<1e-4` = fig_palette[["<1e-4"]],
      `<1e-5` = fig_palette[["<1e-5"]],
      `<1e-6` = fig_palette[["<1e-6"]],
      `<1e-7` = fig_palette[["<1e-7"]],
      `<1e-9` = fig_palette[["<1e-9"]],
      `<1e-10` = fig_palette[["<1e-10"]]
    ),
    guide = "none"
  ) +
  coord_cartesian(xlim = c(0, 1), ylim = c(0.5, top_label_count + 0.5), clip = "off") +
  theme_void(base_family = "Arial") +
  labs(title = "FDR < 0.01 in both experiments") +
  theme(
    plot.title = element_text(size = ICAT_FONT_TITLE_PT, face = "bold", hjust = 0),
    plot.margin = margin(16, 4, 4, 8)
  )

sample_qc_long <- sample_qc %>%
  select(sample_label, total_normalized_spectra, proteins_with_spectra) %>%
  pivot_longer(c(total_normalized_spectra, proteins_with_spectra), names_to = "metric", values_to = "value") %>%
  mutate(
    metric = recode(
      metric,
      total_normalized_spectra = "Total normalized spectra",
      proteins_with_spectra = "Detected proteins"
    )
  )

qc_panel <- ggplot(sample_qc_long, aes(sample_label, value, fill = metric)) +
  geom_col(width = 0.7, linewidth = 0) +
  facet_wrap(~metric, nrow = 1, scales = "free_y") +
  scale_fill_manual(values = c("Total normalized spectra" = "#2A9D8F", "Detected proteins" = "#4A5568")) +
  scale_y_continuous(labels = scales::comma, expand = expansion(mult = c(0, 0.12))) +
  labs(x = NULL, y = NULL, title = "B  Sample-level QC") +
  theme(
    legend.position = "none",
    strip.background = element_blank(),
    strip.text = element_text(hjust = 0, face = "bold"),
    axis.text.x = element_text(angle = 30, hjust = 1)
  )

right_panel <- fdr_legend_panel / list_panel + plot_layout(heights = c(0.22, 1))

figure <- (scatter_panel | right_panel) / qc_panel +
  plot_layout(widths = c(1, 1), heights = c(1.35, 0.55))

figure_base <- file.path(figure_dir, "Figure6_interactome_DiQBioID_like_scatter")
ggsave(
  filename = file.path(figure_dir, "pdf", paste0(basename(figure_base), ".pdf")),
  plot = figure,
  width = 183,
  height = 155,
  units = "mm",
  device = cairo_pdf
)
ragg::agg_png(
  filename = file.path(figure_dir, "png", paste0(basename(figure_base), ".png")),
  width = 183,
  height = 155,
  units = "mm",
  res = 600
)
print(figure)
dev.off()
ragg::agg_tiff(
  filename = file.path(figure_dir, "tiff", paste0(basename(figure_base), ".tiff")),
  width = 183,
  height = 155,
  units = "mm",
  res = 600,
  compression = "lzw"
)
print(figure)
dev.off()

feature_plot_order <- c(
  "Apical",
  "Microneme",
  "Microneme + SignalP/TMD",
  "Rhoptry",
  "Dense granule",
  "Secretory organelle",
  "Apical/secretory/cytoskeleton",
  "IMC/cytoskeleton",
  "Signal peptide",
  "Any TMD",
  "PM surface-like",
  "CRISPR top 20%"
)

feature_plot_enrichment <- feature_enrichment %>%
  filter(feature_label %in% feature_plot_order) %>%
  mutate(feature_label = factor(feature_label, levels = rev(feature_plot_order)))

feature_fraction_plot_data <- feature_plot_enrichment %>%
  select(feature_label, candidate_fraction, background_fraction, fdr_bh) %>%
  pivot_longer(
    c(candidate_fraction, background_fraction),
    names_to = "group",
    values_to = "fraction"
  ) %>%
  mutate(
    group = recode(
      group,
      candidate_fraction = "FDR candidates",
      background_fraction = "Peptide-filtered set"
    ),
    feature_label = feature_label
  )

feature_xmax <- max(feature_plot_enrichment$candidate_fraction, feature_plot_enrichment$background_fraction, na.rm = TRUE)
feature_xmax <- min(1, max(0.58, feature_xmax + 0.26))

feature_panel <- ggplot(feature_fraction_plot_data, aes(fraction, feature_label, fill = group)) +
  geom_col(position = position_dodge(width = 0.72), width = 0.62, linewidth = 0) +
  geom_text(
    data = feature_plot_enrichment,
    aes(
      x = pmax(candidate_fraction, background_fraction) + 0.025,
      y = factor(feature_label, levels = levels(feature_fraction_plot_data$feature_label)),
      label = paste0("OR=", signif(odds_ratio, 2), ", FDR=", signif(fdr_bh, 2))
    ),
    inherit.aes = FALSE,
    hjust = 0,
    size = ICAT_TEXT_SMALL_MM
  ) +
  scale_fill_manual(values = c("FDR candidates" = "#C9343F", "Peptide-filtered set" = "#B9C0C9")) +
  scale_x_continuous(labels = scales::percent_format(accuracy = 1), limits = c(0, feature_xmax), expand = expansion(mult = c(0, 0.02))) +
  labs(
    x = "Fraction of proteins",
    y = NULL,
    fill = NULL,
    title = "C  Feature enrichment"
  ) +
  theme(legend.position = "top")

crispr_plot_data <- annotated_candidates %>%
  filter(science_peptide_filter, has_crispr_rank) %>%
  mutate(
    candidate_class = if_else(rapa_enrichment_candidate, "FDR candidate", "Background"),
    candidate_class = factor(candidate_class, levels = c("Background", "FDR candidate"))
  )

crispr_panel <- ggplot(crispr_plot_data, aes(candidate_class, crispr_rank_percentile, fill = candidate_class)) +
  geom_boxplot(width = 0.55, outlier.shape = NA, linewidth = ICAT_LINE_MM, alpha = 0.85) +
  geom_jitter(width = 0.12, height = 0, alpha = 0.22, size = 0.8, colour = "#4A5568") +
  scale_fill_manual(values = c("Background" = "#B9C0C9", "FDR candidate" = "#C9343F")) +
  scale_x_discrete(labels = c("Background" = "Peptide-filtered\nset", "FDR candidate" = "FDR\ncandidates")) +
  scale_y_continuous(labels = scales::percent_format(accuracy = 1), limits = c(0, 1)) +
  labs(
    x = NULL,
    y = "CRISPR rank percentile\n(lower = stronger phenotype)",
    title = "D  CRISPR rank"
  ) +
  theme(legend.position = "none")

protein_length_fdr <- continuous_feature_compare$fdr_bh[continuous_feature_compare$feature == "protein_length_aa"]

size_plot_data <- annotated_candidates %>%
  filter(science_peptide_filter, is.finite(protein_length_aa)) %>%
  mutate(
    candidate_class = if_else(rapa_enrichment_candidate, "FDR candidate", "Background"),
    candidate_class = factor(candidate_class, levels = c("Background", "FDR candidate"))
  )

size_panel <- ggplot(size_plot_data, aes(candidate_class, protein_length_aa, fill = candidate_class)) +
  geom_boxplot(width = 0.55, outlier.shape = NA, linewidth = ICAT_LINE_MM, alpha = 0.85) +
  geom_jitter(width = 0.12, height = 0, alpha = 0.22, size = 0.8, colour = "#4A5568") +
  scale_fill_manual(values = c("Background" = "#B9C0C9", "FDR candidate" = "#C9343F")) +
  scale_x_discrete(labels = c("Background" = "Peptide-filtered\nset", "FDR candidate" = "FDR\ncandidates")) +
  scale_y_log10(labels = scales::comma) +
  labs(
    x = NULL,
    y = "Protein length (aa, log10)",
    title = paste0("E  Protein length (FDR=", signif(protein_length_fdr, 2), ")")
  ) +
  theme(legend.position = "none")

annotation_figure <- feature_panel | (crispr_panel / size_panel)
annotation_figure <- annotation_figure + plot_layout(widths = c(1.35, 0.78))
annotation_base <- file.path(figure_dir, "Figure6_interactome_database_annotation_summary")
ggsave(
  filename = file.path(figure_dir, "pdf", paste0(basename(annotation_base), ".pdf")),
  plot = annotation_figure,
  width = 183,
  height = 145,
  units = "mm",
  device = cairo_pdf
)
ragg::agg_png(
  filename = file.path(figure_dir, "png", paste0(basename(annotation_base), ".png")),
  width = 183,
  height = 145,
  units = "mm",
  res = 600
)
print(annotation_figure)
dev.off()
ragg::agg_tiff(
  filename = file.path(figure_dir, "tiff", paste0(basename(annotation_base), ".tiff")),
  width = 183,
  height = 145,
  units = "mm",
  res = 600,
  compression = "lzw"
)
print(annotation_figure)
dev.off()

top_lines <- top_labeled %>%
  transmute(
    line = paste0(
      figure_label,
      ". ",
      coalesce(gene, accession_number),
      " (",
      accession_number,
      "): exp1 log2 ",
      round(exp1_log2_rapa_vs_control, 2),
      ", exp2 log2 ",
      round(exp2_log2_rapa_vs_control, 2),
      ", mean log2 ",
      round(mean_log2_rapa_vs_control, 2),
      ", FDR exp1 ",
      signif(significance_b_fdr_exp1, 3),
      ", FDR exp2 ",
      signif(significance_b_fdr_exp2, 3),
      ", mean rapa peptides ",
      round(mean_rapa_unique_peptides, 2)
    )
  ) %>%
  pull(line)

db_summary_lines <- c(
  paste0(
    "FDR candidates with HyperLp localization annotation: ",
    sum(annotated_candidates$rapa_enrichment_candidate & annotated_candidates$has_hyperlp_annotation, na.rm = TRUE),
    "/",
    sum(annotated_candidates$rapa_enrichment_candidate, na.rm = TRUE),
    "."
  ),
  paste0(
    "Apical: ",
    sum(candidate_feature_summary$apical_flag, na.rm = TRUE),
    " annotated FDR candidate(s); Fisher OR=",
    signif(feature_enrichment$odds_ratio[feature_enrichment$feature == "apical_flag"], 2),
    ", BH FDR=",
    signif(feature_enrichment$fdr_bh[feature_enrichment$feature == "apical_flag"], 2),
    "."
  ),
  paste0(
    "Microneme: ",
    sum(candidate_feature_summary$microneme_flag, na.rm = TRUE),
    " annotated FDR candidate(s); Fisher OR=",
    signif(feature_enrichment$odds_ratio[feature_enrichment$feature == "microneme_flag"], 2),
    ", BH FDR=",
    signif(feature_enrichment$fdr_bh[feature_enrichment$feature == "microneme_flag"], 2),
    "."
  ),
  paste0(
    "Microneme surface-like proxy: ",
    sum(candidate_feature_summary$microneme_surface_like_proxy, na.rm = TRUE),
    " annotated FDR candidate(s); Fisher OR=",
    signif(feature_enrichment$odds_ratio[feature_enrichment$feature == "microneme_surface_like_proxy"], 2),
    ", BH FDR=",
    signif(feature_enrichment$fdr_bh[feature_enrichment$feature == "microneme_surface_like_proxy"], 2),
    "."
  ),
  paste0(
    "Secretory organelle class (microneme/rhoptry/dense granule): ",
    sum(candidate_feature_summary$secretory_organelle_flag, na.rm = TRUE),
    " annotated FDR candidate(s); Fisher OR=",
    signif(feature_enrichment$odds_ratio[feature_enrichment$feature == "secretory_organelle_flag"], 2),
    ", BH FDR=",
    signif(feature_enrichment$fdr_bh[feature_enrichment$feature == "secretory_organelle_flag"], 2),
    "."
  ),
  paste0(
    "Apical/secretory/cytoskeleton class: ",
    sum(candidate_feature_summary$apical_secretory_cytoskeleton_flag, na.rm = TRUE),
    " annotated FDR candidate(s); Fisher OR=",
    signif(feature_enrichment$odds_ratio[feature_enrichment$feature == "apical_secretory_cytoskeleton_flag"], 2),
    ", BH FDR=",
    signif(feature_enrichment$fdr_bh[feature_enrichment$feature == "apical_secretory_cytoskeleton_flag"], 2),
    "."
  ),
  paste0(
    "SignalP/TMD structural feature: ",
    sum(candidate_feature_summary$secretory_or_membrane_feature, na.rm = TRUE),
    " annotated FDR candidate(s); Fisher OR=",
    signif(feature_enrichment$odds_ratio[feature_enrichment$feature == "secretory_or_membrane_feature"], 2),
    ", BH FDR=",
    signif(feature_enrichment$fdr_bh[feature_enrichment$feature == "secretory_or_membrane_feature"], 2),
    "."
  ),
  paste0(
    "CRISPR rank: ",
    crispr_compare$candidate_with_gt1_rank_n,
    "/",
    crispr_compare$candidate_n,
    " FDR candidates mapped by TGME49/TGGT1 numeric ID. Candidate median rank percentile=",
    scales::percent(crispr_compare$candidate_median_percentile, accuracy = 0.1),
    "; background median rank percentile=",
    scales::percent(crispr_compare$background_median_percentile, accuracy = 0.1),
    "; one-sided Wilcoxon p=",
    signif(crispr_compare$wilcox_rank_p_lower, 3),
    "."
  ),
  paste0(
    "Continuous common-feature screen: strongest mapped comparison by nominal p-value is ",
    continuous_feature_compare$feature_label[which.min(continuous_feature_compare$p_value)],
    " (candidate median ",
    signif(continuous_feature_compare$candidate_median[which.min(continuous_feature_compare$p_value)], 3),
    " versus background median ",
    signif(continuous_feature_compare$background_median[which.min(continuous_feature_compare$p_value)], 3),
    ", BH FDR ",
    signif(continuous_feature_compare$fdr_bh[which.min(continuous_feature_compare$p_value)], 2),
    ")."
  ),
  "Common-feature readout: the FDR candidate set is heterogeneous. It contains one apical candidate and one microneme candidate with SignalP/TMD support, but it does not show a strong shared PM-surface, broad secretory/membrane, or uniformly strong CRISPR phenotype signature in the current database mapping."
)

report <- c(
  "# Fig 6 ICAT interactome DiQ-BioID-like analysis",
  "",
  "## Inputs",
  "",
  paste0("- Protein spectral report: ", basename(spectra_file)),
  paste0("- Peptide-count report: ", basename(peptide_file)),
  paste0("- Sample map: ", basename(sample_map_file)),
  paste0("- Parsed proteins: ", n_distinct(merged_long$row_id)),
  paste0("- Parsed sample labels: ", paste(sample_map$sample_label, collapse = ", ")),
  "",
  "## Method",
  "",
  "Samples 1 and 3 are controls; samples 2 and 4 are rapa-treated samples. Exp1 compares sample 2 versus sample 1, and exp2 compares sample 4 versus sample 3.",
  paste0("For each protein and experiment, normalized log2-ratio = log2((rapa + ", signif(spectra_pseudocount, 4), ") / (control + ", signif(spectra_pseudocount, 4), ")), where the pseudocount is half the smallest positive normalized spectral value."),
  "Intensity-based Significance B was implemented for each experiment by comparing each protein's log2-ratio with proteins of similar abundance. Two-sided p-values were adjusted within each experiment using Benjamini-Hochberg FDR.",
  "The current export contains total unique peptide counts but not separate total peptide-count evidence. The Science-style peptide filter is therefore implemented conservatively as at least two unique peptides in either member of each paired experiment.",
  "Candidate ranking follows the reference Science-style reproducibility plot: proteins are sorted by FDR<0.01 status in both experiments, worst replicate FDR, mean log2(rapa/control), and mean rapa spectra.",
  "Figure labels are ordered by combined enrichment, exp1 log2(rapa/control) + exp2 log2(rapa/control), so numbering runs from the upper-right region toward lower-left enriched candidates.",
  "",
  "## Operational candidate flag",
  "",
  "A protein is flagged as a rapa-enrichment candidate when it passes the peptide filter in both experiments, has positive log2(rapa/control) in both experiments, and has Significance B BH FDR < 0.01 in both experiments.",
  paste0("Proteins passing peptide filter in both experiments: ", sum(candidate_summary$science_peptide_filter, na.rm = TRUE), "."),
  paste0("Proteins passing FDR < 0.01 in both experiments and positive rapa enrichment: ", sum(candidate_summary$rapa_enrichment_candidate, na.rm = TRUE), "."),
  "Because the input is normalized total spectra rather than raw MaxQuant intensity, this is a Perseus Significance B-style implementation on the available abundance proxy. A true 1:1 Perseus rerun would require the original intensity/ratio table.",
  "",
  "## Top ranked proteins",
  "",
  top_lines,
  "",
  "## Database annotation summary",
  "",
  db_summary_lines,
  "",
  "## Outputs",
  "",
  "- Figure6_interactome_long_source_data.csv",
  "- Figure6_interactome_wide_source_data.csv",
  "- Figure6_interactome_paired_enrichment_source_data.csv",
  "- Figure6_interactome_significance_b_by_experiment.csv",
  "- Figure6_interactome_figure_labeled_candidates.csv",
  "- Figure6_interactome_nearby_excluded_points.csv",
  "- Figure6_interactome_candidate_summary_with_database_annotations.csv",
  "- Figure6_interactome_FDR_candidates_database_annotations.csv",
  "- Figure6_interactome_feature_enrichment_tests.csv",
  "- Figure6_interactome_crispr_candidate_comparison.csv",
  "- Figure6_interactome_continuous_feature_comparisons.csv",
  "- Figure6_interactome_candidate_summary.csv",
  "- Figure6_interactome_sample_qc.csv",
  "- Figure6_interactome_top100_ranked_candidates.csv",
  "- Figure6_interactome_log2FC_gt1_mean_noFDR.csv",
  "- Figure6_interactome_log2FC_gt1_both_experiments_noFDR.csv",
  "- Figure6_interactome_DiQBioID_like_scatter.pdf/png/tiff",
  "- Figure6_interactome_database_annotation_summary.pdf/png/tiff"
)
writeLines(report, file.path(report_dir, "Figure6_interactome_DiQBioID_like_report.md"))

legend <- c(
  "Figure 6 ICAT interactome rapa-enrichment reproducibility analysis using a Perseus Significance B-style workflow.",
  "A, DiQ-BioID-like scatter plot showing normalized log2-ratio (rapa/control) in exp1 and exp2. Grey points indicate proteins passing the peptide filter that do not meet the final candidate screen. Coloured diamonds and numbers indicate proteins with positive rapa enrichment and Significance B Benjamini-Hochberg FDR < 0.01 in both experiments. Candidate colours indicate the worse FDR across the two experiments using the FDR bins shown in the inset; numbers are ordered by combined enrichment from upper right toward lower left.",
  "B, Sample-level QC showing total normalized spectra and detected proteins for exp1_control, exp1_rapa, exp2_control and exp2_rapa.",
  "C, Database annotation enrichment comparing FDR candidates with the peptide-filtered annotated background. Apical, microneme, rhoptry, dense granule, IMC/cytoskeleton, SignalP/TMD, conservation and CRISPR top-rank features were screened by Fisher's exact test with Benjamini-Hochberg FDR correction. Microneme + SignalP/TMD is a surface-like proxy, not a direct surface-localization annotation.",
  "D, CRISPR rank percentile distribution after TGME49-to-TGGT1 numeric-ID mapping; lower percentile indicates a stronger phenotype.",
  "E, Protein length distribution for FDR candidates versus the peptide-filtered background. Candidate proteins are shorter than the background by Wilcoxon rank-sum test after Benjamini-Hochberg correction.",
  "Significance B was calculated from normalized total spectra as the available abundance proxy; the peptide filter uses total unique peptide counts from the peptide-count report."
)
writeLines(legend, file.path(legend_dir, "Figure6_interactome_DiQBioID_like_scatter_legend.txt"))

message("Parsed ", n_distinct(merged_long$row_id), " proteins across ", sample_count, " samples.")
message("Wrote Fig 6 DiQ-BioID-like enrichment tables, report, legend, and PDF/PNG/TIFF figure.")
