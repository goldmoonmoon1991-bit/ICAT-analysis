#!/usr/bin/env Rscript

script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
script_path <- normalizePath(sub("^--file=", "", script_arg[[1]]), mustWork = TRUE)
code_dir <- dirname(script_path)
fig_dir <- normalizePath(file.path(code_dir, "..", ".."), mustWork = TRUE)
project_root <- normalizePath(file.path(fig_dir, ".."), mustWork = TRUE)
renv_lib <- file.path(project_root, "renv", "library", "macos", "R-4.5", "aarch64-apple-darwin24.4.0")
if (dir.exists(renv_lib)) {
  .libPaths(c(renv_lib, .libPaths()))
}
source(file.path(project_root, "shared", "R", "project_library.R"))
source(file.path(project_root, "shared", "R", "plot_style.R"))
icat_activate_project_library(project_root)

suppressPackageStartupMessages({
  library(circlize)
  library(ComplexHeatmap)
  library(dplyr)
  library(ggplot2)
  library(grid)
  library(patchwork)
  library(readr)
  library(scales)
  library(stringr)
  library(tidyr)
})

fig2_table_dir <- file.path(project_root, "Fig2_ICAT_identification", "04_results", "tables")
raw_microneme_dir <- file.path(fig_dir, "01_raw_data", "microneme_protein")
table_dir <- file.path(fig_dir, "04_results", "tables", "interactome")
figure_dir <- file.path(fig_dir, "04_results", "figures", "interactome")
legend_dir <- file.path(fig_dir, "04_results", "legends")

analysis_name <- "ICAT_construct_preference_topology_filtered_exploratory"
analysis_table_dir <- file.path(table_dir, analysis_name)
analysis_figure_dir <- file.path(figure_dir, analysis_name)

dir.create(analysis_table_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(analysis_figure_dir, "pdf"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(analysis_figure_dir, "png"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(analysis_figure_dir, "svg"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(analysis_figure_dir, "tiff"), recursive = TRUE, showWarnings = FALSE)
dir.create(legend_dir, recursive = TRUE, showWarnings = FALSE)

conoid_file <- file.path(fig2_table_dir, "Figure2B_landmark_coordinates.csv")
mic_surface_file <- file.path(raw_microneme_dir, "microneme_surface_distributed_genes.csv")
mic_internal_file <- file.path(raw_microneme_dir, "microneme_internal_genes.csv")
n_term_file <- file.path(
  table_dir,
  "ICAT_N_term_TurboID",
  "Figure6_ICAT_N_term_quantified_proteins_annotated.csv"
)
full_length_file <- file.path(
  table_dir,
  "Figure6_interactome_candidate_summary_with_database_annotations.csv"
)
internal_diagnostic_file <- file.path(
  table_dir,
  "microneme_internal_preference_diagnostics",
  "Figure6_microneme_internal_preference_possibility4_diagnostics.csv"
)

required_files <- c(conoid_file, mic_surface_file, mic_internal_file, n_term_file, full_length_file, internal_diagnostic_file)
missing_files <- required_files[!file.exists(required_files)]
if (length(missing_files)) {
  stop("Missing required input files: ", paste(missing_files, collapse = ", "))
}

theme_set(
  icat_theme_classic() +
    theme(
      panel.grid = element_blank(),
      plot.title.position = "plot"
    )
)

clean_gene_id <- function(x) {
  x %>%
    as.character() %>%
    str_replace("^\ufeff", "") %>%
    str_squish()
}

as_flag <- function(x) {
  if (is.logical(x)) {
    return(coalesce(x, FALSE))
  }
  tolower(as.character(x)) %in% c("true", "t", "1", "yes", "y")
}

short_label <- function(label, gene) {
  label <- str_squish(as.character(label))
  label <- ifelse(is.na(label) | label == "", gene, label)
  label <- str_replace_all(label, "_", "-")
  label <- str_replace_all(label, "SAS6L", "SAS6-like")
  label <- str_replace_all(label, "MORN repeat-containing protein", "MORN")
  label
}

conoid_class_order <- c("outer", "bridge", "inner")

conoid_list <- readr::read_csv(conoid_file, show_col_types = FALSE) %>%
  mutate(
    conoid_spatial_class = str_to_lower(str_squish(as.character(Spatial_class)))
  ) %>%
  filter(conoid_spatial_class %in% c(conoid_class_order, "candidate")) %>%
  transmute(
    gene = clean_gene_id(GeneID),
    protein_label = short_label(coalesce(Label, CryoEM_name, Fallback_label), gene),
    category = ifelse(conoid_spatial_class == "candidate", "ICAT bait", paste0("Conoid ", conoid_spatial_class)),
    broad_class = ifelse(conoid_spatial_class == "candidate", "ICAT", paste0("Conoid ", conoid_spatial_class)),
    list_source = "Figure2B conoid landmark"
  )

surface_list <- readr::read_csv(mic_surface_file, show_col_types = FALSE) %>%
  transmute(
    gene = clean_gene_id(Gene_ID),
    protein_label = short_label(Gene_Name, gene),
    category = "Microneme surface",
    broad_class = "Microneme surface",
    list_source = "Curated microneme surface"
  )

internal_list <- readr::read_csv(mic_internal_file, show_col_types = FALSE) %>%
  transmute(
    gene = clean_gene_id(Gene_ID),
    protein_label = short_label(Gene_Name, gene),
    category = "Microneme internal",
    broad_class = "Microneme internal",
    list_source = "Curated microneme internal"
  )

target_list <- bind_rows(conoid_list, surface_list, internal_list) %>%
  filter(!is.na(gene), gene != "") %>%
  group_by(gene) %>%
  summarise(
    protein_label = first(na.omit(protein_label)),
    category = paste(unique(category), collapse = "; "),
    broad_class = case_when(
      any(broad_class == "ICAT") ~ "ICAT",
      any(broad_class == "Microneme surface") ~ "Microneme surface",
      any(broad_class == "Microneme internal") ~ "Microneme internal",
      any(broad_class == "Conoid outer") ~ "Conoid outer",
      any(broad_class == "Conoid bridge") ~ "Conoid bridge",
      any(broad_class == "Conoid inner") ~ "Conoid inner",
      TRUE ~ first(broad_class)
    ),
    list_source = paste(unique(list_source), collapse = "; "),
    .groups = "drop"
  ) %>%
  mutate(
    protein_label = ifelse(gene == "TGME49_289100", "HOOK", protein_label),
    category = ifelse(gene == "TGME49_289100", "Microneme surface; HOOK", category),
    broad_class = ifelse(gene == "TGME49_289100", "Microneme surface", broad_class),
    list_source = ifelse(
      gene == "TGME49_289100",
      paste(list_source, "curation override: MIC18/HOOK as microneme surface", sep = "; "),
      list_source
    )
  )

n_term <- readr::read_csv(n_term_file, show_col_types = FALSE) %>%
  mutate(gene = clean_gene_id(gene)) %>%
  transmute(
    gene,
    icat_n_log2 = mean_log2_N_vs_cyto,
    icat_n_percentile = enrichment_percentile_N,
    icat_n_quantified = is.finite(mean_log2_N_vs_cyto)
  )

full_length <- readr::read_csv(full_length_file, show_col_types = FALSE) %>%
  mutate(
    gene = clean_gene_id(gene),
    science_peptide_filter = as_flag(science_peptide_filter)
  ) %>%
  filter(science_peptide_filter, is.finite(mean_log2_rapa_vs_control)) %>%
  mutate(
    rank_FL_desc = rank(-mean_log2_rapa_vs_control, ties.method = "first"),
    enrichment_percentile_FL = 1 - (rank_FL_desc - 0.5) / n()
  ) %>%
  transmute(
    gene,
    full_length_log2 = mean_log2_rapa_vs_control,
    full_length_percentile = enrichment_percentile_FL,
    full_length_quantified = is.finite(mean_log2_rapa_vs_control)
  )

internal_diagnostic <- readr::read_csv(internal_diagnostic_file, show_col_types = FALSE) %>%
  mutate(gene = clean_gene_id(gene)) %>%
  transmute(
    gene,
    internal_p4_assessment = possibility4_assessment,
    internal_evidence_class = evidence_class,
    internal_negative_preferred_raw = as_flag(negative_preferred_raw_flag),
    internal_single_bait_only = as_flag(single_bait_only_flag),
    internal_low_preferred_signal = as_flag(low_preferred_signal_flag),
    internal_one_rep_detection = as_flag(one_rep_preferred_detection_flag),
    internal_one_rep_positive = as_flag(one_rep_positive_flag),
    internal_pseudocount_sensitive = as_flag(pseudocount_sensitive_flag)
  )

heatmap_source <- target_list %>%
  left_join(n_term, by = "gene") %>%
  left_join(full_length, by = "gene") %>%
  left_join(internal_diagnostic, by = "gene") %>%
  mutate(
    icat_n_quantified = coalesce(icat_n_quantified, FALSE),
    full_length_quantified = coalesce(full_length_quantified, FALSE),
    quantified_any = icat_n_quantified | full_length_quantified,
    quantified_both = icat_n_quantified & full_length_quantified,
    preference_delta_FL_minus_N = full_length_percentile - icat_n_percentile,
    preference_label = case_when(
      !quantified_both ~ "single bait only",
      preference_delta_FL_minus_N > 0.20 ~ "Full-length-high",
      preference_delta_FL_minus_N < -0.20 ~ "ICAT N-high",
      TRUE ~ "balanced"
    )
  )

class_order_top <- c(
  "ICAT",
  "Microneme surface",
  "Microneme internal",
  "Conoid outer",
  "Conoid bridge",
  "Conoid inner"
)
class_label_map <- c(
  "ICAT" = "ICAT",
  "Microneme surface" = "MIC surface",
  "Microneme internal" = "MIC internal",
  "Conoid outer" = "outer",
  "Conoid bridge" = "bridge",
  "Conoid inner" = "inner"
)

plot_source <- heatmap_source %>%
  filter(quantified_any) %>%
  mutate(
    broad_class = factor(broad_class, levels = class_order_top),
    row_label_base = ifelse(
      duplicated(protein_label) | duplicated(protein_label, fromLast = TRUE),
      paste0(protein_label, " ", gene),
      protein_label
    ),
    bias_score = case_when(
      quantified_both ~ preference_delta_FL_minus_N,
      full_length_quantified & !icat_n_quantified ~ 0.65,
      icat_n_quantified & !full_length_quantified ~ -0.65,
      TRUE ~ NA_real_
    ),
    preferred_raw_log2 = case_when(
      is.finite(bias_score) & bias_score > 0 ~ full_length_log2,
      is.finite(bias_score) & bias_score < 0 ~ icat_n_log2,
      TRUE ~ NA_real_
    ),
    bias_negative_raw_preferred = is.finite(bias_score) &
      bias_score != 0 &
      is.finite(preferred_raw_log2) &
      preferred_raw_log2 < 0,
    internal_p4_uninterpretable = broad_class == "Microneme internal" &
      is.finite(bias_score) &
      bias_score != 0 &
      (
        coalesce(internal_p4_assessment == "consistent_with_possibility_4", FALSE) |
          coalesce(internal_negative_preferred_raw, FALSE) |
          coalesce(internal_single_bait_only, FALSE) |
          coalesce(internal_low_preferred_signal, FALSE) |
          coalesce(internal_one_rep_detection, FALSE) |
          coalesce(internal_pseudocount_sensitive, FALSE)
      ),
    bias_uninterpretable = bias_negative_raw_preferred | internal_p4_uninterpretable,
    bias_label = case_when(
      bias_negative_raw_preferred ~ "hatched: preferred raw log2FC < 0",
      internal_p4_uninterpretable ~ "hatched: MIC internal preference matches low-signal/missing-value diagnostic",
      quantified_both & preference_delta_FL_minus_N > 0.20 ~ paste0("FL +", number(100 * preference_delta_FL_minus_N, accuracy = 1), " pp"),
      quantified_both & preference_delta_FL_minus_N < -0.20 ~ paste0("N +", number(100 * abs(preference_delta_FL_minus_N), accuracy = 1), " pp"),
      quantified_both ~ "balanced",
      icat_n_quantified & !full_length_quantified ~ "N only",
      full_length_quantified & !icat_n_quantified ~ "FL only",
      TRUE ~ "not detected"
    ),
    bias_display_score = ifelse(bias_uninterpretable, NA_real_, bias_score),
    interpreted_preference = case_when(
      bias_uninterpretable ~ "not_interpreted",
      !is.finite(bias_score) ~ "not_interpreted",
      bias_score > 0.20 ~ "FL_high",
      bias_score < -0.20 ~ "N_high",
      TRUE ~ "balanced"
    )
  ) %>%
  arrange(broad_class, desc(full_length_percentile), desc(icat_n_percentile), protein_label)

plot_source <- plot_source %>%
  mutate(broad_class = droplevels(broad_class))

row_title_labels <- unname(class_label_map[levels(plot_source$broad_class)])

supergroup_align <- list(
  Microneme = which(plot_source$broad_class %in% c("Microneme surface", "Microneme internal")),
  Conoid = which(plot_source$broad_class %in% c("Conoid outer", "Conoid bridge", "Conoid inner"))
)
supergroup_align <- supergroup_align[lengths(supergroup_align) > 0]
draw_subgroup_brackets <- function() {
  slice_levels <- levels(plot_source$broad_class)

  locate_row_title_slices <- function(classes) {
    slice_ids <- match(classes, slice_levels)
    slice_ids <- slice_ids[is.finite(slice_ids)]
    slice_vps <- paste0("Enrichment\npercentile_row_title_", slice_ids)

    slice_boxes <- lapply(slice_vps, function(vp_name) {
      seekViewport(vp_name)
      lower_left <- deviceLoc(unit(0, "npc"), unit(0, "npc"))
      upper_right <- deviceLoc(unit(1, "npc"), unit(1, "npc"))
      list(
        x0 = convertX(lower_left$x, "inches", valueOnly = TRUE),
        x1 = convertX(upper_right$x, "inches", valueOnly = TRUE),
        y0 = convertY(lower_left$y, "inches", valueOnly = TRUE),
        y1 = convertY(upper_right$y, "inches", valueOnly = TRUE)
      )
    })

    list(
      x0 = min(vapply(slice_boxes, `[[`, numeric(1), "x0")),
      x1 = max(vapply(slice_boxes, `[[`, numeric(1), "x1")),
      y0 = min(vapply(slice_boxes, `[[`, numeric(1), "y0")),
      y1 = max(vapply(slice_boxes, `[[`, numeric(1), "y1"))
    )
  }

  draw_group_bracket <- function(classes) {
    box <- locate_row_title_slices(classes)
    seekViewport("heatmap_Enrichment\npercentile")
    parent_lower_left <- deviceLoc(unit(0, "npc"), unit(0, "npc"))
    parent_upper_right <- deviceLoc(unit(1, "npc"), unit(1, "npc"))
    parent <- list(
      x0 = convertX(parent_lower_left$x, "inches", valueOnly = TRUE),
      x1 = convertX(parent_upper_right$x, "inches", valueOnly = TRUE),
      y0 = convertY(parent_lower_left$y, "inches", valueOnly = TRUE),
      y1 = convertY(parent_upper_right$y, "inches", valueOnly = TRUE)
    )

    to_parent_x <- function(x) (x - parent$x0) / (parent$x1 - parent$x0)
    to_parent_y <- function(y) (y - parent$y0) / (parent$y1 - parent$y0)

    bracket_x <- to_parent_x(box$x1 + convertWidth(unit(0.7, "mm"), "inches", valueOnly = TRUE))
    tick_x <- to_parent_x(box$x1 + convertWidth(unit(2.2, "mm"), "inches", valueOnly = TRUE))
    y0 <- to_parent_y(box$y0)
    y1 <- to_parent_y(box$y1)
    y_pad <- to_parent_y(parent$y0 + convertHeight(unit(0.65, "mm"), "inches", valueOnly = TRUE)) -
      to_parent_y(parent$y0)
    y0 <- y0 + y_pad
    y1 <- y1 - y_pad
    gp <- gpar(col = "#7F878E", lwd = 0.65, lineend = "square")

    grid.lines(unit(c(bracket_x, bracket_x), "npc"), unit(c(y0, y1), "npc"), gp = gp)
    grid.lines(unit(c(bracket_x, tick_x), "npc"), unit(c(y0, y0), "npc"), gp = gp)
    grid.lines(unit(c(bracket_x, tick_x), "npc"), unit(c(y1, y1), "npc"), gp = gp)
  }

  draw_group_bracket(c("Microneme surface", "Microneme internal"))
  draw_group_bracket(c("Conoid outer", "Conoid bridge", "Conoid inner"))
}

if (nrow(plot_source) < 2) {
  stop("Not enough list proteins were quantified in either bait dataset for heatmap plotting.")
}

mat_enrichment <- plot_source %>%
  select(icat_n_percentile, full_length_percentile) %>%
  as.matrix()
rownames(mat_enrichment) <- plot_source$row_label_base
colnames(mat_enrichment) <- c("N", "FL")

mat_bias <- matrix(plot_source$bias_display_score, ncol = 1)
rownames(mat_bias) <- plot_source$row_label_base
colnames(mat_bias) <- "\u0394"
bias_hatched <- plot_source$bias_uninterpretable

protein_label_annotation <- rowAnnotation(
  protein = anno_text(
    plot_source$row_label_base,
    just = "left",
    location = unit(0, "npc"),
    gp = gpar(fontsize = 5.5, fontface = "bold", col = "#2F3438")
  ),
  width = unit(22, "mm"),
  show_annotation_name = FALSE,
  gap = unit(0, "mm")
)

cell_mm <- 2.95
heatmap_height <- unit(nrow(plot_source) * cell_mm, "mm")
enrichment_width <- unit(ncol(mat_enrichment) * cell_mm, "mm")
bias_width <- unit(cell_mm, "mm")

enrichment_col <- circlize::colorRamp2(
  c(0, 0.5, 0.75, 1),
  c("#F1F3F4", "#C7D0D7", "#778793", "#2E3741")
)
bias_col <- circlize::colorRamp2(
  c(-0.7, 0, 0.7),
  c("#4F6F99", "#F1F3F4", "#C94855")
)

cluster_rows_no_na <- function(m) {
  if (nrow(m) < 2) {
    return(NULL)
  }
  m[!is.finite(m)] <- 0
  hclust(dist(m), method = "average")
}

ht_opt$TITLE_PADDING <- unit(c(1.2, 1.2), "mm")

ht_enrichment <- Heatmap(
  mat_enrichment,
  name = "Enrichment\npercentile",
  col = enrichment_col,
  na_col = "#F7F7F7",
  cluster_rows = cluster_rows_no_na,
  cluster_row_slices = FALSE,
  row_split = plot_source$broad_class,
  row_gap = unit(0, "mm"),
  row_dend_side = "left",
  row_dend_width = unit(7, "mm"),
  row_dend_gp = gpar(col = "#AEB6BE", lwd = 0.45),
  show_row_names = FALSE,
  row_title = row_title_labels,
  row_title_gp = gpar(fontsize = 5.8, fontface = "bold", col = "#33383D"),
  row_title_rot = 90,
  cluster_columns = FALSE,
  column_gap = unit(0, "mm"),
  show_column_dend = FALSE,
  column_names_side = "top",
  column_names_rot = 0,
  column_names_gp = gpar(fontsize = 6.4, fontface = "bold", col = "#2F3438"),
  width = enrichment_width,
  height = heatmap_height,
  rect_gp = gpar(col = NA),
  border = FALSE,
  heatmap_legend_param = list(
    direction = "horizontal",
    title_position = "topcenter",
    at = c(0, 0.25, 0.5, 0.75, 1),
    labels = c("0", "25", "50", "75", "100"),
    legend_width = unit(28, "mm"),
    grid_height = unit(2.3, "mm"),
    title_gp = gpar(fontsize = 6.4, fontface = "bold"),
    labels_gp = gpar(fontsize = 5.6)
  )
)

ht_bias <- Heatmap(
  mat_bias,
  name = "Bait\npreference",
  col = bias_col,
  na_col = "#F2F3F4",
  cluster_rows = FALSE,
  cluster_columns = FALSE,
  column_gap = unit(0, "mm"),
  show_row_names = FALSE,
  show_row_dend = FALSE,
  show_column_dend = FALSE,
  column_names_side = "top",
  column_names_rot = 0,
  column_names_gp = gpar(fontsize = 6.4, fontface = "bold", col = "#2F3438"),
  width = bias_width,
  height = heatmap_height,
  rect_gp = gpar(col = NA),
  border = FALSE,
  cell_fun = function(j, i, x, y, width, height, fill) {
    if (isTRUE(bias_hatched[[i]])) {
      grid.rect(x, y, width, height, gp = gpar(fill = "#F2F3F4", col = NA))
      grid.segments(
        x - width * 0.34,
        y - height * 0.34,
        x + width * 0.34,
        y + height * 0.34,
        gp = gpar(col = "#AEB6BE", lwd = 0.45)
      )
    }
  },
  heatmap_legend_param = list(
    direction = "horizontal",
    title_position = "topcenter",
    at = c(-0.6, 0, 0.6),
    labels = c("N", "balanced", "FL"),
    legend_width = unit(28, "mm"),
    grid_height = unit(2.3, "mm"),
    title_gp = gpar(fontsize = 6.4, fontface = "bold"),
    labels_gp = gpar(fontsize = 5.6)
  )
)

heatmap_grob <- grid.grabExpr(
  draw(
    ht_enrichment + ht_bias + protein_label_annotation,
    main_heatmap = "Enrichment\npercentile",
    heatmap_legend_side = "bottom",
    merge_legends = FALSE,
    ht_gap = unit(0, "mm"),
    padding = unit(c(2, 0.5, 4, 0.5), "mm"),
    post_fun = function(ht_list) {
      if (identical(Sys.getenv("ICAT_DEBUG_HT_COMPONENTS"), "1")) {
        print(list_components())
      }
      draw_subgroup_brackets()
    }
  )
)

heatmap_plot <- patchwork::wrap_elements(full = heatmap_grob) &
  theme(plot.margin = margin(0, 0, 0, 0))

save_pub_plot <- function(plot, name, width_mm = 74, height_mm = 102, dpi = 600) {
  width_in <- width_mm / 25.4
  height_in <- height_mm / 25.4
  ggsave(
    file.path(analysis_figure_dir, "pdf", paste0(name, ".pdf")),
    plot,
    width = width_in,
    height = height_in,
    device = cairo_pdf,
    bg = "white"
  )
  ggsave(
    file.path(analysis_figure_dir, "png", paste0(name, ".png")),
    plot,
    width = width_in,
    height = height_in,
    dpi = dpi,
    bg = "white"
  )
  ggsave(
    file.path(analysis_figure_dir, "tiff", paste0(name, ".tiff")),
    plot,
    width = width_in,
    height = height_in,
    dpi = dpi,
    compression = "lzw",
    bg = "white"
  )
  if (requireNamespace("svglite", quietly = TRUE)) {
    ggsave(
      file.path(analysis_figure_dir, "svg", paste0(name, ".svg")),
      plot,
      width = width_in,
      height = height_in,
      device = svglite::svglite,
      bg = "white"
    )
  }
}

matching_summary <- heatmap_source %>%
  count(broad_class, icat_n_quantified, full_length_quantified, name = "n")

interpreted_preference_summary <- plot_source %>%
  mutate(broad_class = as.character(broad_class)) %>%
  count(broad_class, interpreted_preference, name = "n") %>%
  arrange(factor(broad_class, levels = class_order_top), interpreted_preference)

readr::write_csv(
  heatmap_source %>% arrange(desc(quantified_any), broad_class, protein_label),
  file.path(analysis_table_dir, "Figure6_ICAT_construct_heatmap_topology_filtered_exploratory_source.csv")
)
readr::write_csv(
  plot_source %>% arrange(broad_class, desc(full_length_percentile), desc(icat_n_percentile), protein_label),
  file.path(analysis_table_dir, "Figure6_ICAT_construct_heatmap_topology_filtered_exploratory_plotted_proteins.csv")
)
readr::write_csv(
  matching_summary,
  file.path(analysis_table_dir, "Figure6_ICAT_construct_heatmap_topology_filtered_exploratory_matching_summary.csv")
)
readr::write_csv(
  interpreted_preference_summary,
  file.path(analysis_table_dir, "Figure6_ICAT_construct_heatmap_topology_filtered_exploratory_preference_summary.csv")
)

legend_lines <- c(
  "Figure 6 | Topology-filtered exploratory clustering of ICAT construct enrichment.",
  "The heatmap includes ICAT, conoid outer/bridge/inner landmark proteins, and curated microneme proteins that were quantified in at least one of the ICAT N-term TurboID or full-length ICAT proximity-labeling datasets.",
  "MIC18 (TGME49_289100) is manually curated as a microneme-surface protein and labelled as HOOK.",
  "ICAT is placed as a standalone top row and is not clustered. Remaining rows are ordered by compartment class priority, with proteins clustered within microneme-surface, microneme-internal, conoid-outer, conoid-bridge, and conoid-inner slices using ICAT N-term and full-length ICAT enrichment percentiles. Thin left-side brackets group the two microneme slices and the three conoid positional slices without adding extra text labels. Protein labels are placed on the far right.",
  "Contiguous square tiles indicate enrichment percentile; pale tiles indicate proteins not quantified in that bait dataset.",
  "The adjacent FL-N square uses the same cell size and summarizes bait preference. For proteins quantified in both datasets, it shows full-length ICAT minus ICAT N-term enrichment percentile. For proteins quantified in only one bait dataset, it shows the detected bait as the provisional preference. Red indicates full-length ICAT preference and blue indicates ICAT N-term preference.",
  "Directional preferences driven by a negative raw log2FC in the preferred bait are shown as pale grey hatched squares. For curated microneme-internal proteins, preferences supported by low signal, single-bait-only detection, one-replicate detection, or pseudocount sensitivity are also hatched and are not interpreted as positive spatial preference in live-cell proximity labeling."
)
writeLines(legend_lines, file.path(legend_dir, "Figure6_ICAT_construct_heatmap_topology_filtered_exploratory_legend.txt"))

save_pub_plot(heatmap_plot, "Figure6_ICAT_construct_heatmap_topology_filtered_exploratory")

message("List-driven ICAT construct heatmap completed.")
message("Target list proteins: ", nrow(target_list))
message("Plotted proteins quantified in at least one dataset: ", nrow(plot_source))
message("Quantified in both datasets: ", sum(plot_source$quantified_both))
message("Tables: ", analysis_table_dir)
message("Figures: ", analysis_figure_dir)
