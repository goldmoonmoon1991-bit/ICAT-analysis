#!/usr/bin/env Rscript

script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
script_path <- normalizePath(sub("^--file=", "", script_arg[[1]]), mustWork = TRUE)
code_dir <- dirname(script_path)
fig_dir <- normalizePath(file.path(code_dir, "..", ".."), mustWork = TRUE)
project_root <- normalizePath(file.path(fig_dir, ".."), mustWork = TRUE)
renv_lib <- file.path(project_root, "renv", "library", "macos", "R-4.5", "aarch64-apple-darwin24.4.0")
if (dir.exists(renv_lib)) {
  .libPaths(c(renv_lib, .libPaths()))
}
source(file.path(project_root, "shared", "R", "project_library.R"))
icat_activate_project_library(project_root)

suppressPackageStartupMessages({
  library(circlize)
  library(ComplexHeatmap)
  library(dplyr)
  library(ggplot2)
  library(grid)
  library(patchwork)
  library(readr)
  library(scales)
  library(tidyr)
})

processed_dir <- file.path(fig_dir, "02_processed_data", "interactome")
table_dir <- file.path(fig_dir, "04_results", "tables", "interactome")
report_dir <- file.path(fig_dir, "04_results", "reports", "interactome")
figure_dir <- file.path(fig_dir, "04_results", "figures", "interactome")
legend_dir <- file.path(fig_dir, "04_results", "legends")

analysis_name <- "ICAT_construct_QC_sfig2_compact"
analysis_table_dir <- file.path(table_dir, analysis_name)
analysis_report_dir <- file.path(report_dir, analysis_name)
analysis_figure_dir <- file.path(figure_dir, analysis_name)

dir.create(analysis_table_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(analysis_report_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(analysis_figure_dir, "pdf"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(analysis_figure_dir, "png"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(analysis_figure_dir, "svg"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(analysis_figure_dir, "tiff"), recursive = TRUE, showWarnings = FALSE)
dir.create(legend_dir, recursive = TRUE, showWarnings = FALSE)

full_wide_file <- file.path(processed_dir, "Figure6_interactome_wide_source_data.csv")
n_term_file <- file.path(
  table_dir,
  "ICAT_N_term_TurboID",
  "Figure6_ICAT_N_term_quantified_proteins_annotated.csv"
)

missing_files <- c(full_wide_file, n_term_file)[!file.exists(c(full_wide_file, n_term_file))]
if (length(missing_files)) {
  stop("Missing required input files: ", paste(missing_files, collapse = ", "))
}

theme_set(
  theme_classic(base_size = 4.8, base_family = "Arial") +
    theme(
      axis.line = element_line(linewidth = 0.18, colour = "black"),
      axis.ticks = element_line(linewidth = 0.16, colour = "black"),
      axis.ticks.length = unit(0.7, "mm"),
      axis.text = element_text(size = 4.2, colour = "black"),
      axis.title = element_text(size = 4.8, colour = "black"),
      panel.grid = element_blank(),
      plot.margin = margin(0, 0.2, 0, 0.2)
    )
)

condition_cols <- c(
  "Control" = "#C8CDD0",
  "Rapalog" = "#C94855",
  "Cytosolic" = "#C8CDD0",
  "ICAT N" = "#4F6F99"
)

dataset_specs <- list(
  list(
    dataset_id = "ICAT_FL",
    dataset_label = "ICAT-FL",
    data_file = full_wide_file,
    sample_cols = c(
      "normalized_total_spectra_exp1_control",
      "normalized_total_spectra_exp1_rapa",
      "normalized_total_spectra_exp2_control",
      "normalized_total_spectra_exp2_rapa"
    ),
    sample_display = c("1", "1", "2", "2"),
    sample_name = c("FL exp1 ctrl", "FL exp1 rapa", "FL exp2 ctrl", "FL exp2 rapa"),
    replicate = c("exp1", "exp1", "exp2", "exp2"),
    group = c("Control", "Rapalog", "Control", "Rapalog"),
    colour = c("Control" = condition_cols[["Control"]], "Rapalog" = condition_cols[["Rapalog"]]),
    accent = condition_cols[["Rapalog"]]
  ),
  list(
    dataset_id = "ICAT_N",
    dataset_label = "ICAT-N",
    data_file = n_term_file,
    sample_cols = c("PG1", "PG2", "PG3", "PG4"),
    sample_display = c("1", "1", "2", "2"),
    sample_name = c("N exp1 cyto", "N exp1 bait", "N exp2 cyto", "N exp2 bait"),
    replicate = c("exp1", "exp1", "exp2", "exp2"),
    group = c("Cytosolic", "ICAT N", "Cytosolic", "ICAT N"),
    colour = c("Cytosolic" = condition_cols[["Cytosolic"]], "ICAT N" = condition_cols[["ICAT N"]]),
    accent = condition_cols[["ICAT N"]]
  )
)

read_dataset <- function(spec) {
  data <- readr::read_csv(spec$data_file, show_col_types = FALSE) %>%
    mutate(gene = as.character(gene))
  missing_cols <- spec$sample_cols[!spec$sample_cols %in% names(data)]
  if (length(missing_cols)) {
    stop("Missing sample columns for ", spec$dataset_id, ": ", paste(missing_cols, collapse = ", "))
  }
  data
}

dataset_long <- function(data, spec, ordered_cols) {
  sample_meta <- tibble::tibble(
    sample_col = spec$sample_cols,
    sample_display = spec$sample_display,
    sample_name = spec$sample_name,
    replicate = spec$replicate,
    group = spec$group
  )

  data %>%
    select(gene, all_of(spec$sample_cols)) %>%
    pivot_longer(cols = all_of(spec$sample_cols), names_to = "sample_col", values_to = "normalized_spectra") %>%
    left_join(sample_meta, by = "sample_col") %>%
    mutate(
      dataset_id = spec$dataset_id,
      dataset_label = spec$dataset_label,
      sample_col = factor(sample_col, levels = ordered_cols),
      sample_name = factor(sample_name, levels = sample_meta$sample_name[match(ordered_cols, sample_meta$sample_col)]),
      normalized_spectra = replace_na(normalized_spectra, 0),
      log2_spectra_plus1 = log2(normalized_spectra + 1)
    )
}

make_ordered_qc <- function(data, spec) {
  mat_raw <- data %>%
    select(all_of(spec$sample_cols)) %>%
    mutate(across(everything(), ~ replace_na(.x, 0))) %>%
    as.matrix()
  mat_log <- log2(mat_raw + 1)
  cors <- cor(mat_log, method = "pearson", use = "pairwise.complete.obs")
  hc <- hclust(as.dist(1 - cors), method = "average")
  ordered_cols <- spec$sample_cols[hc$order]
  sample_meta <- tibble::tibble(
    sample_col = spec$sample_cols,
    sample_display = spec$sample_display,
    sample_name = spec$sample_name,
    replicate = spec$replicate,
    group = spec$group
  )
  meta <- sample_meta %>%
    mutate(
      dataset_id = spec$dataset_id,
      dataset_label = spec$dataset_label,
      sample_order = match(sample_col, ordered_cols),
      sample_col = factor(sample_col, levels = ordered_cols),
      sample_name = factor(sample_name, levels = sample_name[match(ordered_cols, sample_col)])
    ) %>%
    arrange(sample_order)

  list(
    mat_log = mat_log,
    cors = cors,
    hc = hc,
    ordered_cols = ordered_cols,
    sample_meta = sample_meta,
    meta = meta,
    long = dataset_long(data, spec, ordered_cols)
  )
}

make_heatmap_grob <- function(qc, spec, show_legend = FALSE) {
  sample_meta <- qc$sample_meta
  cors <- qc$cors
  group_vec <- sample_meta$group
  names(group_vec) <- sample_meta$sample_col
  sample_fills <- unname(spec$colour[sample_meta$group])
  density_list <- lapply(sample_meta$sample_col, function(sample_col) {
    values <- qc$mat_log[, sample_col]
    values[is.finite(values) & values > 0]
  })
  names(density_list) <- sample_meta$sample_col
  protein_counts <- vapply(density_list, length, numeric(1))
  if (identical(spec$dataset_id, "ICAT_FL")) {
    top_anno <- HeatmapAnnotation(
      rapamycin = anno_text(
        ifelse(sample_meta$group == "Rapalog", "+", "-"),
        which = "column",
        rot = 0,
        gp = gpar(fontsize = 4.8, fontface = "bold", col = "black"),
        height = unit(2.2, "mm")
      ),
      condition = group_vec,
      col = list(condition = spec$colour),
      show_annotation_name = FALSE,
      simple_anno_size = unit(1.2, "mm"),
      gap = unit(0, "mm"),
      show_legend = FALSE
    )
  } else {
    top_anno <- HeatmapAnnotation(
      condition = group_vec,
      col = list(condition = spec$colour),
      show_annotation_name = FALSE,
      simple_anno_size = unit(1.2, "mm"),
      show_legend = FALSE
    )
  }
  bottom_anno <- HeatmapAnnotation(
    log2 = anno_density(
      density_list,
      which = "column",
      type = "violin",
      xlim = c(0, 9.2),
      border = FALSE,
      gp = gpar(fill = sample_fills, col = "#303437", lwd = 0.35),
      axis = TRUE,
      axis_param = list(
        side = "left",
        at = c(0, 9),
        labels = c("0", "9"),
        gp = gpar(fontsize = 3.6, lwd = 0.25)
      ),
      height = unit(4.4, "mm")
    ),
    gp = gpar(col = "black", lwd = 0.40),
    border = TRUE,
    show_annotation_name = FALSE,
    gap = unit(0, "mm"),
    show_legend = FALSE
  )
  right_anno <- rowAnnotation(
    prot = anno_barplot(
      protein_counts,
      which = "row",
      border = FALSE,
      bar_width = 0.72,
      gp = gpar(fill = sample_fills, col = "#303437", lwd = 0.35),
      ylim = c(0, 3000),
      axis = TRUE,
      axis_param = list(
        side = "top",
        at = c(0, 3000),
        labels = c("0", "3k"),
        labels_rot = 90,
        gp = gpar(fontsize = 3.4, lwd = 0.25)
      ),
      width = unit(4.6, "mm")
    ),
    gp = gpar(col = "black", lwd = 0.40),
    border = TRUE,
    show_annotation_name = FALSE,
    gap = unit(0, "mm"),
    show_legend = FALSE
  )
  if (identical(spec$dataset_id, "ICAT_FL")) {
    corr_col_fun <- circlize::colorRamp2(
      c(0.80, 0.88, 0.94, 1.00),
      c("#FFFFFF", "#F8D4D2", "#E88986", "#C94855")
    )
    corr_legend_at <- c(0.80, 0.90, 1.00)
    corr_legend_labels <- c("0.8", "0.9", "1")
  } else {
    corr_col_fun <- circlize::colorRamp2(
      c(0.6, 0.8, 0.9, 1),
      c("#FFFFFF", "#D5E1EA", "#86AED4", "#2166AC")
    )
    corr_legend_at <- c(0.60, 0.80, 1.00)
    corr_legend_labels <- c("0.6", "0.8", "1")
  }
  panel_title <- if (identical(spec$dataset_id, "ICAT_FL")) "rapamycin" else NULL

  ht <- Heatmap(
    cors,
    name = "r",
    col = corr_col_fun,
    cluster_rows = qc$hc,
    cluster_columns = qc$hc,
    row_dend_side = "left",
    row_dend_width = unit(2.7, "mm"),
    row_dend_gp = gpar(col = "black", lwd = 0.30),
    column_dend_height = unit(0, "mm"),
    show_column_dend = FALSE,
    top_annotation = top_anno,
    bottom_annotation = bottom_anno,
    right_annotation = right_anno,
    column_title = panel_title,
    column_title_side = "top",
    column_title_gp = gpar(fontsize = 5.4, fontface = "plain"),
    row_title = NULL,
    row_title_side = "left",
    row_title_rot = 90,
    row_title_gp = gpar(fontsize = 5.2, fontface = "plain", col = spec$accent),
    row_names_side = "left",
    row_names_gp = gpar(fontsize = 4.3, fontface = "bold"),
    row_labels = sample_meta$sample_display,
    show_column_names = FALSE,
    column_names_side = "top",
    column_labels = sample_meta$sample_display,
    column_names_rot = 0,
    column_names_gp = gpar(fontsize = 4.3, fontface = "bold"),
    rect_gp = gpar(col = "white", lwd = 0.22),
    border = TRUE,
    border_gp = gpar(col = "black", lwd = 0.40),
    width = unit(13.2, "mm"),
    height = unit(13.2, "mm"),
    heatmap_legend_param = list(
      direction = "vertical",
      title = NULL,
      at = corr_legend_at,
      labels = corr_legend_labels,
      title_gp = gpar(fontsize = 4.4, fontface = "bold"),
      labels_gp = gpar(fontsize = 3.7),
      grid_width = unit(2.0, "mm"),
      grid_height = unit(8, "mm"),
      legend_height = unit(8, "mm")
    )
  )

  grid.grabExpr(
    {
      draw(
      ht,
      heatmap_legend_side = "right",
      show_heatmap_legend = show_legend,
      padding = unit(c(0, 0, 0.6, 4.8), "mm")
      )
      decorate_annotation("log2", {
        grid.rect(gp = gpar(col = "black", fill = NA, lwd = 0.40))
      })
      decorate_annotation("prot", {
        grid.rect(gp = gpar(col = "black", fill = NA, lwd = 0.40))
      })
      grid.roundrect(
        x = unit(1.9, "mm"),
        y = unit(16.2, "mm"),
        width = unit(3.1, "mm"),
        height = unit(12.8, "mm"),
        r = unit(0.8, "mm"),
        gp = gpar(col = spec$accent, fill = NA, lwd = 0.50)
      )
      grid.text(
        spec$dataset_label,
        x = unit(1.9, "mm"),
        y = unit(16.2, "mm"),
        rot = 90,
        gp = gpar(fontsize = 4.0, col = "black")
      )
    }
  )
}

make_violin_plot <- function(qc, spec) {
  data <- qc$long %>%
    filter(normalized_spectra > 0) %>%
    mutate(
      sample_name = factor(sample_name, levels = qc$meta$sample_name),
      group = factor(group, levels = names(spec$colour))
    )

  ggplot(data, aes(sample_name, log2_spectra_plus1, fill = group)) +
    geom_violin(width = 0.86, linewidth = 0.12, colour = "#303437", trim = TRUE, scale = "width") +
    geom_boxplot(width = 0.10, linewidth = 0.10, outlier.shape = NA, fill = "white", colour = "#303437") +
    scale_fill_manual(values = spec$colour, guide = "none") +
    scale_y_continuous(breaks = c(0, 9), expand = expansion(mult = c(0.02, 0.02))) +
    coord_cartesian(ylim = c(0, 9.2)) +
    labs(x = NULL, y = "log2") +
    theme(
      axis.text.x = element_blank(),
      axis.ticks.x = element_blank(),
      axis.title.y = element_text(size = 4.2, margin = margin(r = 0.5)),
      axis.text.y = element_text(size = 3.8),
      plot.margin = margin(0, 0.3, 0, 0.3)
    )
}

make_bar_plot <- function(qc, spec) {
  data <- qc$long %>%
    group_by(dataset_id, dataset_label, sample_name, group) %>%
    summarise(proteins_detected = sum(normalized_spectra > 0, na.rm = TRUE), .groups = "drop") %>%
    mutate(
      sample_name = factor(sample_name, levels = qc$meta$sample_name),
      group = factor(group, levels = names(spec$colour))
    )

  ggplot(data, aes(sample_name, proteins_detected, fill = group)) +
    geom_col(width = 0.72, colour = "#303437", linewidth = 0.12) +
    scale_fill_manual(values = spec$colour, guide = "none") +
    scale_y_continuous(labels = label_number(scale = 1 / 1000, suffix = "k"), breaks = pretty_breaks(n = 2), expand = expansion(mult = c(0, 0.08))) +
    labs(x = NULL, y = "prot.") +
    theme(
      axis.text.x = element_blank(),
      axis.ticks.x = element_blank(),
      axis.title.y = element_text(size = 4.2, margin = margin(r = 0.5)),
      axis.text.y = element_text(size = 3.8),
      plot.margin = margin(0, 0.3, 0, 0.3)
    )
}

make_dataset_panel <- function(data, spec, show_heatmap_legend = FALSE) {
  qc <- make_ordered_qc(data, spec)
  heatmap_plot <- patchwork::wrap_elements(full = make_heatmap_grob(qc, spec, show_legend = show_heatmap_legend))

  cor_table <- as.data.frame(as.table(qc$cors), stringsAsFactors = FALSE) %>%
    transmute(
      dataset_id = spec$dataset_id,
      dataset_label = spec$dataset_label,
      sample_x_col = Var1,
      sample_y_col = Var2,
      pearson_r = Freq
    )

  list(
    panel = heatmap_plot,
    meta = qc$meta,
    sample_metrics = qc$long %>%
      group_by(dataset_id, dataset_label, sample_col, sample_name, group, replicate) %>%
      summarise(
        proteins_detected = sum(normalized_spectra > 0, na.rm = TRUE),
        total_normalized_spectra = sum(normalized_spectra, na.rm = TRUE),
        median_log2_spectra_detected = median(log2_spectra_plus1[normalized_spectra > 0], na.rm = TRUE),
        .groups = "drop"
      ),
    correlations = cor_table,
    sample_order = qc$meta
  )
}

full_data <- read_dataset(dataset_specs[[1]])
n_data <- read_dataset(dataset_specs[[2]])

full_panel <- make_dataset_panel(full_data, dataset_specs[[1]], show_heatmap_legend = TRUE)
n_panel <- make_dataset_panel(n_data, dataset_specs[[2]], show_heatmap_legend = TRUE)

compact_plot <- patchwork::wrap_plots(
  list(full_panel$panel, n_panel$panel),
  ncol = 1,
  heights = c(1, 1)
) &
  theme(plot.margin = margin(0, 0, 0, 0))

all_sample_metrics <- bind_rows(full_panel$sample_metrics, n_panel$sample_metrics)
all_correlations <- bind_rows(full_panel$correlations, n_panel$correlations)
all_sample_order <- bind_rows(full_panel$sample_order, n_panel$sample_order)

sample_lookup <- all_sample_order %>%
  mutate(sample_col = as.character(sample_col)) %>%
  select(dataset_id, sample_col, sample_name, replicate, group, sample_display)

pairwise_diagnostic <- all_correlations %>%
  filter(as.character(sample_x_col) < as.character(sample_y_col)) %>%
  mutate(
    sample_x_col = as.character(sample_x_col),
    sample_y_col = as.character(sample_y_col)
  ) %>%
  left_join(
    sample_lookup %>%
      rename(
        sample_x_col = sample_col,
        sample_x_name = sample_name,
        replicate_x = replicate,
        group_x = group,
        display_x = sample_display
      ),
    by = c("dataset_id", "sample_x_col")
  ) %>%
  left_join(
    sample_lookup %>%
      rename(
        sample_y_col = sample_col,
        sample_y_name = sample_name,
        replicate_y = replicate,
        group_y = group,
        display_y = sample_display
      ),
    by = c("dataset_id", "sample_y_col")
  ) %>%
  mutate(
    pair_class = case_when(
      group_x == group_y & replicate_x != replicate_y ~ "same_condition_between_experiments",
      group_x != group_y & replicate_x == replicate_y ~ "different_condition_within_experiment",
      group_x != group_y & replicate_x != replicate_y ~ "different_condition_between_experiments",
      TRUE ~ "other"
    )
  ) %>%
  arrange(dataset_id, desc(pearson_r))

stability_summary <- all_correlations %>%
  filter(sample_x_col != sample_y_col) %>%
  group_by(dataset_id, dataset_label) %>%
  summarise(
    min_off_diagonal_pearson_r = min(pearson_r, na.rm = TRUE),
    median_off_diagonal_pearson_r = median(pearson_r, na.rm = TRUE),
    max_off_diagonal_pearson_r = max(pearson_r, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  left_join(
    all_sample_metrics %>%
      group_by(dataset_id, dataset_label) %>%
      summarise(
        min_detected_proteins = min(proteins_detected, na.rm = TRUE),
        max_detected_proteins = max(proteins_detected, na.rm = TRUE),
        min_total_normalized_spectra = min(total_normalized_spectra, na.rm = TRUE),
        max_total_normalized_spectra = max(total_normalized_spectra, na.rm = TRUE),
        .groups = "drop"
      ),
    by = c("dataset_id", "dataset_label")
  )

readr::write_csv(all_sample_metrics, file.path(analysis_table_dir, "Figure6_ICAT_construct_QC_sfig2_compact_sample_metrics.csv"))
readr::write_csv(all_correlations, file.path(analysis_table_dir, "Figure6_ICAT_construct_QC_sfig2_compact_sample_correlations.csv"))
readr::write_csv(all_sample_order, file.path(analysis_table_dir, "Figure6_ICAT_construct_QC_sfig2_compact_clustered_sample_order.csv"))
readr::write_csv(stability_summary, file.path(analysis_table_dir, "Figure6_ICAT_construct_QC_sfig2_compact_stability_summary.csv"))
readr::write_csv(pairwise_diagnostic, file.path(analysis_table_dir, "Figure6_ICAT_construct_QC_sfig2_compact_pairwise_diagnostic.csv"))

save_pub_plot <- function(plot, name, width_mm = 42, height_mm = 65, dpi = 600) {
  width_in <- width_mm / 25.4
  height_in <- height_mm / 25.4
  ggsave(file.path(analysis_figure_dir, "pdf", paste0(name, ".pdf")), plot, width = width_in, height = height_in, device = cairo_pdf, bg = "white")
  ggsave(file.path(analysis_figure_dir, "png", paste0(name, ".png")), plot, width = width_in, height = height_in, dpi = dpi, bg = "white")
  ggsave(file.path(analysis_figure_dir, "tiff", paste0(name, ".tiff")), plot, width = width_in, height = height_in, dpi = dpi, compression = "lzw", bg = "white")
  if (requireNamespace("svglite", quietly = TRUE)) {
    ggsave(file.path(analysis_figure_dir, "svg", paste0(name, ".svg")), plot, width = width_in, height = height_in, device = svglite::svglite, bg = "white")
  }
}

figure_name <- "Figure6_ICAT_construct_QC_sfig2_compact_reference_layout_42x65mm"
save_pub_plot(compact_plot, figure_name)

legend_lines <- c(
  "Figure 6 - compact QC | Quality control for ICAT proximity proteomics.",
  "For each construct, sample-level Pearson correlations were calculated from log2(normalized spectra + 1) protein intensities and displayed as a clustered heatmap without cell labels. The full-length ICAT correlation heatmap uses an independent white-to-red Pearson r scale narrowed to 0.8-1.0, whereas the ICAT N-term heatmap uses an independent white-to-blue Pearson r scale from 0.6-1.0.",
  "Thin supporting panels show detected-protein intensity distributions and detected protein counts in the same clustered sample order. The lower violin axis denotes log2(normalized spectra + 1), shown from 0 to 9. The right bar axis denotes detected proteins, shown from 0 to 3,000 proteins.",
  "FL, full-length ICAT; N, ICAT N-term TurboID. Protein count and intensity summaries are shown only as compact QC supports; exact values are provided in the source tables."
)
writeLines(legend_lines, file.path(legend_dir, "Figure6_ICAT_construct_QC_sfig2_compact_legend.txt"))

report_lines <- c(
  "# Figure6 ICAT Construct QC sFig2 Compact Report",
  "",
  "## Purpose",
  "",
  "This compact 34 mm x 65 mm figure preserves the sFig2 QC logic while removing numerical correlation labels and reducing the intensity-distribution and protein-count panels to thin supporting strips.",
  "",
  "## Stability Summary",
  "",
  paste(capture.output(print(stability_summary)), collapse = "\n"),
  "",
  "## Outputs",
  "",
  paste0("- Figure PDF: `", file.path(analysis_figure_dir, "pdf", paste0(figure_name, ".pdf")), "`"),
  paste0("- Figure PNG: `", file.path(analysis_figure_dir, "png", paste0(figure_name, ".png")), "`")
)
writeLines(report_lines, file.path(analysis_report_dir, "Figure6_ICAT_construct_QC_sfig2_compact_report.md"))

message("Compact sFig2-style ICAT construct QC completed.")
message("Tables: ", analysis_table_dir)
message("Figures: ", analysis_figure_dir)
message("Report: ", analysis_report_dir)
