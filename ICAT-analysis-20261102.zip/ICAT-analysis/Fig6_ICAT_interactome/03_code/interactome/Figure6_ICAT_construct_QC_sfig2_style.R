#!/usr/bin/env Rscript

script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
script_path <- normalizePath(sub("^--file=", "", script_arg[[1]]), mustWork = TRUE)
code_dir <- dirname(script_path)
fig_dir <- normalizePath(file.path(code_dir, "..", ".."), mustWork = TRUE)
project_root <- normalizePath(file.path(fig_dir, ".."), mustWork = TRUE)
renv_lib <- file.path(project_root, "renv", "library", "macos", "R-4.5", "aarch64-apple-darwin24.4.0")
if (dir.exists(renv_lib)) {
  .libPaths(c(renv_lib, .libPaths()))
}
source(file.path(project_root, "shared", "R", "project_library.R"))
source(file.path(project_root, "shared", "R", "plot_style.R"))
icat_activate_project_library(project_root)

suppressPackageStartupMessages({
  library(circlize)
  library(ComplexHeatmap)
  library(dplyr)
  library(ggplot2)
  library(grid)
  library(patchwork)
  library(readr)
  library(scales)
  library(stringr)
  library(tidyr)
})

processed_dir <- file.path(fig_dir, "02_processed_data", "interactome")
table_dir <- file.path(fig_dir, "04_results", "tables", "interactome")
report_dir <- file.path(fig_dir, "04_results", "reports", "interactome")
figure_dir <- file.path(fig_dir, "04_results", "figures", "interactome")
legend_dir <- file.path(fig_dir, "04_results", "legends")

analysis_name <- "ICAT_construct_QC_sfig2_style"
analysis_table_dir <- file.path(table_dir, analysis_name)
analysis_report_dir <- file.path(report_dir, analysis_name)
analysis_figure_dir <- file.path(figure_dir, analysis_name)

dir.create(analysis_table_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(analysis_report_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(analysis_figure_dir, "pdf"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(analysis_figure_dir, "png"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(analysis_figure_dir, "svg"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(analysis_figure_dir, "tiff"), recursive = TRUE, showWarnings = FALSE)
dir.create(legend_dir, recursive = TRUE, showWarnings = FALSE)

full_wide_file <- file.path(processed_dir, "Figure6_interactome_wide_source_data.csv")
n_term_file <- file.path(
  table_dir,
  "ICAT_N_term_TurboID",
  "Figure6_ICAT_N_term_quantified_proteins_annotated.csv"
)
required_files <- c(full_wide_file, n_term_file)
missing_files <- required_files[!file.exists(required_files)]
if (length(missing_files)) {
  stop("Missing required input files: ", paste(missing_files, collapse = ", "))
}

theme_set(
  theme_classic(base_size = 6.5, base_family = "Arial") +
    theme(
      axis.line = element_line(linewidth = 0.28, colour = "black"),
      axis.ticks = element_line(linewidth = 0.24, colour = "black"),
      axis.text = element_text(size = 5.6, colour = "black"),
      axis.title = element_text(size = 6.2, colour = "black"),
      panel.grid = element_blank(),
      plot.title = element_text(size = 7.0, face = "bold", hjust = 0),
      plot.margin = margin(0.5, 0.5, 0.5, 0.5)
    )
)

condition_cols <- c(
  "Control" = "#C8CDD0",
  "Rapalog" = "#C94855",
  "Cytosolic" = "#C8CDD0",
  "ICAT N" = "#4F6F99"
)

dataset_specs <- list(
  list(
    dataset_id = "ICAT_FL",
    dataset_label = "Full-length ICAT",
    group_left = "Control",
    group_right = "Rapalog",
    data_file = full_wide_file,
    sample_cols = c(
      "normalized_total_spectra_exp1_control",
      "normalized_total_spectra_exp1_rapa",
      "normalized_total_spectra_exp2_control",
      "normalized_total_spectra_exp2_rapa"
    ),
    sample_display = c("1", "1", "2", "2"),
    sample_name = c("FL exp1 ctrl", "FL exp1 rapa", "FL exp2 ctrl", "FL exp2 rapa"),
    replicate = c("exp1", "exp1", "exp2", "exp2"),
    group = c("Control", "Rapalog", "Control", "Rapalog"),
    colour = c("Control" = condition_cols[["Control"]], "Rapalog" = condition_cols[["Rapalog"]])
  ),
  list(
    dataset_id = "ICAT_N",
    dataset_label = "ICAT N-term",
    group_left = "Cytosolic",
    group_right = "ICAT N",
    data_file = n_term_file,
    sample_cols = c("PG1", "PG2", "PG3", "PG4"),
    sample_display = c("1", "1", "2", "2"),
    sample_name = c("N exp1 cyto", "N exp1 bait", "N exp2 cyto", "N exp2 bait"),
    replicate = c("exp1", "exp1", "exp2", "exp2"),
    group = c("Cytosolic", "ICAT N", "Cytosolic", "ICAT N"),
    colour = c("Cytosolic" = condition_cols[["Cytosolic"]], "ICAT N" = condition_cols[["ICAT N"]])
  )
)

read_dataset <- function(spec) {
  data <- readr::read_csv(spec$data_file, show_col_types = FALSE) %>%
    mutate(gene = as.character(gene))
  missing_cols <- spec$sample_cols[!spec$sample_cols %in% names(data)]
  if (length(missing_cols)) {
    stop("Missing sample columns for ", spec$dataset_id, ": ", paste(missing_cols, collapse = ", "))
  }
  data
}

dataset_long <- function(data, spec, ordered_cols = spec$sample_cols) {
  tibble::tibble(
    sample_col = spec$sample_cols,
    sample_display = spec$sample_display,
    sample_name = spec$sample_name,
    replicate = spec$replicate,
    group = spec$group
  ) %>%
    mutate(
      dataset_id = spec$dataset_id,
      dataset_label = spec$dataset_label,
      sample_col = factor(sample_col, levels = ordered_cols),
      sample_name = factor(sample_name, levels = .$sample_name[match(ordered_cols, .$sample_col)])
    ) %>%
    right_join(
      data %>%
        select(gene, all_of(spec$sample_cols)) %>%
        pivot_longer(
          cols = all_of(spec$sample_cols),
          names_to = "sample_col",
          values_to = "normalized_spectra"
        ),
      by = "sample_col"
    ) %>%
    mutate(
      normalized_spectra = replace_na(normalized_spectra, 0),
      log2_spectra_plus1 = log2(normalized_spectra + 1)
    )
}

make_ordered_qc <- function(data, spec) {
  mat_raw <- data %>%
    select(all_of(spec$sample_cols)) %>%
    mutate(across(everything(), ~ replace_na(.x, 0))) %>%
    as.matrix()
  mat_log <- log2(mat_raw + 1)
  cors <- cor(mat_log, method = "pearson", use = "pairwise.complete.obs")
  hc <- hclust(as.dist(1 - cors), method = "average")
  ordered_cols <- spec$sample_cols[hc$order]

  meta <- tibble::tibble(
    sample_col = spec$sample_cols,
    sample_display = spec$sample_display,
    sample_name = spec$sample_name,
    replicate = spec$replicate,
    group = spec$group
  ) %>%
    mutate(
      dataset_id = spec$dataset_id,
      dataset_label = spec$dataset_label,
      sample_order = match(sample_col, ordered_cols),
      sample_col = factor(sample_col, levels = ordered_cols),
      sample_name = factor(sample_name, levels = sample_name[match(ordered_cols, sample_col)])
    ) %>%
    arrange(sample_order)

  list(
    mat_log = mat_log,
    cors = cors,
    hc = hc,
    ordered_cols = ordered_cols,
    meta = meta,
    long = dataset_long(data, spec, ordered_cols)
  )
}

make_heatmap_grob <- function(qc, spec, show_legend = FALSE) {
  ordered <- qc$ordered_cols
  cors <- qc$cors[ordered, ordered, drop = FALSE]
  colnames(cors) <- qc$meta$sample_display
  rownames(cors) <- qc$meta$sample_display
  group_vec <- qc$meta$group
  names(group_vec) <- qc$meta$sample_display

  top_anno <- HeatmapAnnotation(
    group = group_vec,
    col = list(group = spec$colour),
    show_annotation_name = FALSE,
    annotation_height = unit(2.2, "mm"),
    simple_anno_size = unit(2.2, "mm"),
    show_legend = FALSE
  )

  ht <- Heatmap(
    cors,
    name = "Pearson r",
    col = circlize::colorRamp2(
      c(0.6, 0.8, 0.9, 1),
      c("#F1F3F4", "#BFD2DF", "#5F94C7", "#2166AC")
    ),
    cluster_rows = qc$hc,
    cluster_columns = qc$hc,
    row_dend_side = "left",
    row_dend_width = unit(8, "mm"),
    row_dend_gp = gpar(col = "black", lwd = 0.45),
    column_dend_height = unit(0, "mm"),
    show_column_dend = FALSE,
    top_annotation = top_anno,
    column_title = spec$dataset_label,
    column_title_gp = gpar(fontsize = 7.2, fontface = "bold", col = "#2F3438"),
    column_title_side = "top",
    row_names_side = "left",
    row_names_gp = gpar(fontsize = 6, fontface = "bold"),
    column_names_side = "top",
    column_names_rot = 0,
    column_names_gp = gpar(fontsize = 6, fontface = "bold"),
    cell_fun = function(j, i, x, y, width, height, fill) {
      grid.text(
        sprintf("%.2f", cors[i, j]),
        x,
        y,
        gp = gpar(fontsize = 4.6, col = "#1E2429")
      )
    },
    rect_gp = gpar(col = "white", lwd = 0.45),
    border = TRUE,
    width = unit(28, "mm"),
    height = unit(28, "mm"),
    heatmap_legend_param = list(
      direction = "vertical",
      at = c(0.6, 0.8, 0.9, 1),
      labels = c("0.60", "0.80", "0.90", "1.00"),
      title_gp = gpar(fontsize = 6, fontface = "bold"),
      labels_gp = gpar(fontsize = 5.5),
      grid_width = unit(2.5, "mm"),
      grid_height = unit(18, "mm")
    )
  )

  grid.grabExpr(
    draw(
      ht,
      heatmap_legend_side = "right",
      show_heatmap_legend = show_legend,
      padding = unit(c(1, 1, 1, 1), "mm")
    )
  )
}

make_violin_plot <- function(qc, spec) {
  data <- qc$long %>%
    filter(normalized_spectra > 0) %>%
    mutate(
      sample_name = factor(sample_name, levels = qc$meta$sample_name),
      group = factor(group, levels = names(spec$colour))
    )

  ggplot(data, aes(sample_name, log2_spectra_plus1, fill = group)) +
    geom_violin(width = 0.88, linewidth = 0.22, colour = "#303437", trim = TRUE, scale = "width") +
    geom_boxplot(width = 0.13, linewidth = 0.18, outlier.shape = NA, fill = "white", colour = "#303437") +
    scale_fill_manual(values = spec$colour, guide = "none") +
    scale_y_continuous(limits = c(0, 9.2), breaks = c(0, 3, 6, 9), expand = expansion(mult = c(0.02, 0.04))) +
    labs(x = NULL, y = "log2(normalized\nspectra + 1)") +
    theme(
      axis.text.x = element_blank(),
      axis.ticks.x = element_blank(),
      axis.title.y = element_text(size = 6.0),
      axis.text.y = element_text(size = 5.5),
      plot.margin = margin(0, 1, 0, 1)
    )
}

make_bar_plot <- function(qc, spec) {
  data <- qc$long %>%
    group_by(dataset_id, dataset_label, sample_name, group) %>%
    summarise(
      proteins_detected = sum(normalized_spectra > 0, na.rm = TRUE),
      .groups = "drop"
    ) %>%
    mutate(
      sample_name = factor(sample_name, levels = qc$meta$sample_name),
      group = factor(group, levels = names(spec$colour)),
      label = paste0(number(proteins_detected / 1000, accuracy = 0.1), "k")
    )

  ggplot(data, aes(sample_name, proteins_detected, fill = group)) +
    geom_col(width = 0.72, colour = "#303437", linewidth = 0.22) +
    geom_text(aes(label = label), vjust = -0.35, size = 2.0, colour = "#202529") +
    scale_fill_manual(values = spec$colour, guide = "none") +
    scale_y_continuous(labels = comma, expand = expansion(mult = c(0, 0.18))) +
    labs(x = NULL, y = "proteins (#)") +
    theme(
      axis.text.x = element_text(angle = 45, hjust = 1, vjust = 1, size = 5.4),
      axis.title.y = element_text(size = 6.0),
      axis.text.y = element_text(size = 5.5),
      plot.margin = margin(0, 1, 0, 1)
    )
}

make_dataset_panel <- function(data, spec, show_heatmap_legend = FALSE) {
  qc <- make_ordered_qc(data, spec)
  heatmap_plot <- patchwork::wrap_elements(full = make_heatmap_grob(qc, spec, show_legend = show_heatmap_legend))
  violin_plot <- make_violin_plot(qc, spec)
  bar_plot <- make_bar_plot(qc, spec)

  panel <- heatmap_plot / violin_plot / bar_plot +
    plot_layout(heights = c(1.05, 0.78, 0.62))

  cor_table <- as.data.frame(as.table(qc$cors), stringsAsFactors = FALSE) %>%
    transmute(
      dataset_id = spec$dataset_id,
      dataset_label = spec$dataset_label,
      sample_x_col = Var1,
      sample_y_col = Var2,
      pearson_r = Freq
    )

  list(
    panel = panel,
    meta = qc$meta,
    sample_metrics = qc$long %>%
      group_by(dataset_id, dataset_label, sample_col, sample_name, group, replicate) %>%
      summarise(
        proteins_detected = sum(normalized_spectra > 0, na.rm = TRUE),
        total_normalized_spectra = sum(normalized_spectra, na.rm = TRUE),
        median_log2_spectra_detected = median(log2_spectra_plus1[normalized_spectra > 0], na.rm = TRUE),
        .groups = "drop"
      ),
    correlations = cor_table,
    sample_order = qc$meta
  )
}

full_data <- read_dataset(dataset_specs[[1]])
n_data <- read_dataset(dataset_specs[[2]])

full_panel <- make_dataset_panel(full_data, dataset_specs[[1]], show_heatmap_legend = FALSE)
n_panel <- make_dataset_panel(n_data, dataset_specs[[2]], show_heatmap_legend = TRUE)

sfig2_plot <- (full_panel$panel | n_panel$panel) &
  theme(plot.margin = margin(2, 2, 2, 2))

all_sample_metrics <- bind_rows(full_panel$sample_metrics, n_panel$sample_metrics)
all_correlations <- bind_rows(full_panel$correlations, n_panel$correlations)
all_sample_order <- bind_rows(full_panel$sample_order, n_panel$sample_order)

stability_summary <- all_correlations %>%
  filter(sample_x_col != sample_y_col) %>%
  group_by(dataset_id, dataset_label) %>%
  summarise(
    min_off_diagonal_pearson_r = min(pearson_r, na.rm = TRUE),
    median_off_diagonal_pearson_r = median(pearson_r, na.rm = TRUE),
    max_off_diagonal_pearson_r = max(pearson_r, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  left_join(
    all_sample_metrics %>%
      group_by(dataset_id, dataset_label) %>%
      summarise(
        min_detected_proteins = min(proteins_detected, na.rm = TRUE),
        max_detected_proteins = max(proteins_detected, na.rm = TRUE),
        min_total_normalized_spectra = min(total_normalized_spectra, na.rm = TRUE),
        max_total_normalized_spectra = max(total_normalized_spectra, na.rm = TRUE),
        .groups = "drop"
      ),
    by = c("dataset_id", "dataset_label")
  )

readr::write_csv(all_sample_metrics, file.path(analysis_table_dir, "Figure6_ICAT_construct_QC_sfig2_sample_metrics.csv"))
readr::write_csv(all_correlations, file.path(analysis_table_dir, "Figure6_ICAT_construct_QC_sfig2_sample_correlations.csv"))
readr::write_csv(all_sample_order, file.path(analysis_table_dir, "Figure6_ICAT_construct_QC_sfig2_clustered_sample_order.csv"))
readr::write_csv(stability_summary, file.path(analysis_table_dir, "Figure6_ICAT_construct_QC_sfig2_stability_summary.csv"))

save_pub_plot <- function(plot, name, width_mm = 118, height_mm = 122, dpi = 600) {
  width_in <- width_mm / 25.4
  height_in <- height_mm / 25.4
  ggsave(
    file.path(analysis_figure_dir, "pdf", paste0(name, ".pdf")),
    plot,
    width = width_in,
    height = height_in,
    device = cairo_pdf,
    bg = "white"
  )
  ggsave(
    file.path(analysis_figure_dir, "png", paste0(name, ".png")),
    plot,
    width = width_in,
    height = height_in,
    dpi = dpi,
    bg = "white"
  )
  ggsave(
    file.path(analysis_figure_dir, "tiff", paste0(name, ".tiff")),
    plot,
    width = width_in,
    height = height_in,
    dpi = dpi,
    compression = "lzw",
    bg = "white"
  )
  if (requireNamespace("svglite", quietly = TRUE)) {
    ggsave(
      file.path(analysis_figure_dir, "svg", paste0(name, ".svg")),
      plot,
      width = width_in,
      height = height_in,
      device = svglite::svglite,
      bg = "white"
    )
  }
}

figure_name <- "Figure6_ICAT_construct_QC_sfig2_style"
save_pub_plot(sfig2_plot, figure_name)

legend_lines <- c(
  "Figure 6 - figure supplement | sFig2-style quality control for ICAT proximity proteomics.",
  "For each dataset, the upper panel shows hierarchical clustering of sample-level Pearson correlations calculated from log2(normalized spectra + 1) protein intensities. The middle panel shows the distribution of detected protein intensities in each sample. The lower panel shows the number of proteins detected per sample.",
  "Full-length ICAT samples compare rapalog and control conditions across two experiments. ICAT N-term samples compare ICAT N-term TurboID and cytosolic TurboID across two experiments.",
  "Protein counts above bars are shown in thousands. The same clustered sample order is used for the correlation heatmap, violin plot and protein-count bar plot within each dataset."
)
writeLines(legend_lines, file.path(legend_dir, "Figure6_ICAT_construct_QC_sfig2_style_legend.txt"))

report_lines <- c(
  "# Figure6 ICAT Construct QC sFig2-Style Report",
  "",
  "## Purpose",
  "",
  "This figure follows the quality-control logic of sFig2: sample correlation clustering, intensity distribution and detected protein count are shown together for each proximity proteomics dataset.",
  "",
  "## Stability Summary",
  "",
  paste(capture.output(print(stability_summary)), collapse = "\n"),
  "",
  "## Outputs",
  "",
  paste0("- Figure PDF: `", file.path(analysis_figure_dir, "pdf", paste0(figure_name, ".pdf")), "`"),
  paste0("- Figure PNG: `", file.path(analysis_figure_dir, "png", paste0(figure_name, ".png")), "`"),
  paste0("- Sample metrics: `", file.path(analysis_table_dir, "Figure6_ICAT_construct_QC_sfig2_sample_metrics.csv"), "`"),
  paste0("- Sample correlations: `", file.path(analysis_table_dir, "Figure6_ICAT_construct_QC_sfig2_sample_correlations.csv"), "`")
)
writeLines(report_lines, file.path(analysis_report_dir, "Figure6_ICAT_construct_QC_sfig2_style_report.md"))

message("sFig2-style ICAT construct QC completed.")
message("Tables: ", analysis_table_dir)
message("Figures: ", analysis_figure_dir)
message("Report: ", analysis_report_dir)
