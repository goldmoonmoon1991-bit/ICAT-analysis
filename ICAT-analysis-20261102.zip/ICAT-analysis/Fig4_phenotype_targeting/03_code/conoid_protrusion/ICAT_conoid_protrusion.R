#!/usr/bin/env Rscript

script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
script_path <- normalizePath(sub("^--file=", "", script_arg[[1]]), mustWork = TRUE)
fig_dir <- normalizePath(file.path(dirname(script_path), "..", ".."), mustWork = TRUE)
project_root <- normalizePath(file.path(fig_dir, ".."), mustWork = TRUE)

source(file.path(project_root, "shared", "R", "project_library.R"))
icat_activate_project_library(project_root)

suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(ggplot2)
  library(ragg)
})

source(file.path(project_root, "shared", "R", "plot_style.R"))

input_path <- file.path(
  fig_dir,
  "01_raw_data",
  "conoid protrusion",
  "BC2-mAID_conoid protrusion.csv"
)
figure_dir <- file.path(fig_dir, "04_results", "figures", "conoid_protrusion")
table_dir <- file.path(fig_dir, "04_results", "tables", "conoid_protrusion")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)

condition_palette <- c(vehicle = "#1F77B4", IAA = "#D62728")

format_p_value <- function(p_value) {
  if (is.na(p_value)) return("P = NA")
  if (p_value < 0.001) return("P < 0.001")
  paste0("P = ", formatC(p_value, format = "f", digits = 3))
}

format_p_stars <- function(p_value) {
  dplyr::case_when(
    is.na(p_value) ~ "NA",
    p_value < 0.001 ~ "***",
    p_value < 0.01 ~ "**",
    p_value < 0.05 ~ "*",
    TRUE ~ "ns"
  )
}

raw_text <- paste(readLines(input_path, warn = FALSE), collapse = "\n")
raw_all <- read.csv(
  text = raw_text,
  check.names = FALSE,
  stringsAsFactors = FALSE
)
names(raw_all) <- c("strain", paste0("vehicle_", 1:3), paste0("IAA_", 1:3))

raw <- raw_all %>%
  mutate(source_row = row_number() + 1L) %>%
  filter(source_row != 4L)

if (ncol(raw) != 8L) {
  stop("Expected one strain column, six replicate columns, and one source_row column.")
}

strain_levels <- raw$strain
strain_labels <- c(
  "TIR1" = "TIR1",
  "BC2-mAID-3HA" = "ICAT-mAID\n3HA",
  "mAID-3HA-BC2" = "mAID-3HA\nICAT"
)

conoid_long <- raw %>%
  select(-source_row) %>%
  pivot_longer(
    cols = -strain,
    names_to = "sample",
    values_to = "value"
  ) %>%
  separate(sample, into = c("condition", "replicate"), sep = "_") %>%
  mutate(
    strain = factor(strain, levels = strain_levels),
    condition = factor(condition, levels = c("vehicle", "IAA")),
    replicate = as.integer(replicate),
    value = as.numeric(value)
  ) %>%
  filter(is.finite(value))

summary_df <- conoid_long %>%
  group_by(strain, condition) %>%
  summarise(
    n = n(),
    mean_value = mean(value),
    sd_value = sd(value),
    .groups = "drop"
  ) %>%
  mutate(
    strain = factor(strain, levels = strain_levels),
    strain_index = as.numeric(strain),
    x = strain_index + ifelse(condition == "vehicle", -0.16, 0.16)
  )

stat_results <- conoid_long %>%
  group_by(strain) %>%
  summarise(
    p_value = tryCatch(t.test(value ~ condition)$p.value, error = function(e) NA_real_),
    y_max = max(value, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(
    p_label = format_p_stars(p_value),
    p_text = vapply(p_value, format_p_value, character(1)),
    strain = factor(strain, levels = strain_levels),
    strain_index = as.numeric(strain),
    y_position = pmin(103, y_max + 4.8)
  )

write.csv(
  conoid_long,
  file.path(table_dir, "ICAT_conoid_protrusion_long.csv"),
  row.names = FALSE,
  quote = FALSE
)
write.csv(
  summary_df,
  file.path(table_dir, "ICAT_conoid_protrusion_summary.csv"),
  row.names = FALSE,
  quote = FALSE
)
write.csv(
  stat_results,
  file.path(table_dir, "ICAT_conoid_protrusion_stats.csv"),
  row.names = FALSE,
  quote = FALSE
)

p <- ggplot() +
  geom_point(
    data = conoid_long,
    aes(
      x = as.numeric(strain) + ifelse(condition == "vehicle", -0.16, 0.16),
      y = value,
      color = condition
    ),
    position = position_jitter(width = 0.025, height = 0),
    size = 1.15,
    alpha = 0.85
  ) +
  geom_errorbar(
    data = summary_df,
    aes(
      x = x,
      ymin = mean_value - sd_value,
      ymax = mean_value + sd_value,
      color = condition
    ),
    inherit.aes = FALSE,
    width = 0.12,
    linewidth = max(ICAT_LINE_MM * 1.3, 0.28)
  ) +
  geom_point(
    data = summary_df,
    aes(x = x, y = mean_value, color = condition),
    inherit.aes = FALSE,
    size = 1.65
  ) +
  geom_segment(
    data = stat_results,
    aes(
      x = strain_index - 0.16,
      xend = strain_index + 0.16,
      y = y_position,
      yend = y_position
    ),
    inherit.aes = FALSE,
    linewidth = ICAT_LINE_MM,
    color = "black"
  ) +
  geom_text(
    data = stat_results,
    aes(x = strain_index, y = y_position + 1.8, label = p_label),
    inherit.aes = FALSE,
    family = "Arial",
    size = ICAT_TEXT_SMALL_MM,
    color = "black"
  ) +
  scale_color_manual(values = condition_palette, breaks = names(condition_palette)) +
  scale_x_continuous(
    breaks = seq_along(strain_levels),
    labels = strain_labels[strain_levels],
    expand = expansion(mult = c(0.12, 0.12))
  ) +
  scale_y_continuous(
    breaks = c(0, 50, 100),
    limits = c(0, 108),
    expand = expansion(mult = c(0.01, 0.02))
  ) +
  icat_theme_classic(base_family = "Arial") +
  theme(
    axis.text = element_text(size = ICAT_FONT_SMALL_PT, color = "black"),
    axis.text.x = element_text(size = ICAT_FONT_SMALL_PT, lineheight = 0.9),
    axis.title = element_text(size = ICAT_FONT_BODY_PT),
    axis.ticks.length = unit(1.0, "mm"),
    legend.position = "top",
    legend.justification = "center",
    legend.title = element_blank(),
    legend.direction = "horizontal",
    legend.text = element_text(size = ICAT_FONT_SMALL_PT),
    legend.key.width = unit(3.0, "mm"),
    legend.box.spacing = unit(0, "mm"),
    plot.margin = margin(0.25, 0.45, 0.3, 0.5)
  ) +
  labs(x = NULL, y = "Conoid protrusion (%)")

figure_width_cm <- 4.2
figure_height_cm <- 3.5

ggsave(
  file.path(figure_dir, "ICAT_conoid_protrusion.pdf"),
  p,
  width = figure_width_cm / 2.54,
  height = figure_height_cm / 2.54,
  units = "in",
  device = grDevices::cairo_pdf,
  family = "Arial"
)

ggsave(
  file.path(figure_dir, "ICAT_conoid_protrusion.png"),
  p,
  bg = "transparent",
  width = figure_width_cm / 2.54,
  height = figure_height_cm / 2.54,
  units = "in",
  dpi = 300,
  device = ragg::agg_png
)

if (interactive()) print(p)
