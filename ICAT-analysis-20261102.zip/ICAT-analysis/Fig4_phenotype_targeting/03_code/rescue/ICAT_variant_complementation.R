# ============================================================
# ICAT variant complementation: vehicle versus IAA
# ============================================================
script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
script_path <- normalizePath(sub("^--file=", "", script_arg[[1]]), mustWork = TRUE)
fig_dir <- normalizePath(file.path(dirname(script_path), "..", ".."), mustWork = TRUE)
project_root <- normalizePath(file.path(fig_dir, ".."), mustWork = TRUE)
source(file.path(project_root, "shared", "R", "project_library.R"))
icat_activate_project_library(project_root)

library(ggplot2)
library(dplyr)
library(tidyr)

source(file.path(project_root, "shared", "R", "plot_style.R"))

input_path <- file.path(fig_dir, "01_raw_data", "ICAT_variant_complementation", "ICAT-variants-comp.csv")
figure_dir <- file.path(fig_dir, "04_results", "figures", "rescue")
table_dir <- file.path(fig_dir, "04_results", "tables", "rescue")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)

raw <- read.csv(input_path, check.names = FALSE, stringsAsFactors = FALSE)
if (ncol(raw) < 3) {
  stop("The complementation table needs a variant column plus vehicle/IAA replicate columns.")
}

names(raw)[1] <- "variant"
replicate_count <- (ncol(raw) - 1) / 2
if (replicate_count != floor(replicate_count)) {
  stop("The complementation table must contain the same number of vehicle and IAA replicate columns.")
}
replicate_count <- as.integer(replicate_count)
names(raw)[2:(replicate_count + 1)] <- paste0("vehicle_", seq_len(replicate_count))
names(raw)[(replicate_count + 2):ncol(raw)] <- paste0("IAA_", seq_len(replicate_count))

variant_levels <- raw$variant
variant_labels <- c(
  "ICAT-mAID-3HA" = "ICAT-mAID\n3HA",
  "comp-1" = "comp-1",
  "comp-2" = "comp-2",
  "comp-3" = "comp-3",
  "comp-4" = "comp-4",
  "comp-5" = "comp-5"
)

df_long <- raw %>%
  mutate(variant = factor(variant, levels = variant_levels)) %>%
  pivot_longer(
    cols = -variant,
    names_to = "condition",
    values_to = "value"
  ) %>%
  mutate(
    condition = factor(sub("_.*$", "", condition), levels = c("vehicle", "IAA")),
    value = as.numeric(value)
  ) %>%
  group_by(variant, condition) %>%
  mutate(replicate = row_number()) %>%
  ungroup() %>%
  filter(is.finite(value))

if (nrow(df_long) == 0) {
  stop("The complementation table is empty. Fill at least one measurement before plotting.")
}

df_summary <- df_long %>%
  group_by(variant, condition) %>%
  summarise(
    mean_value = mean(value),
    sd_value = if (n() > 1) sd(value) else NA_real_,
    n = n(),
    .groups = "drop"
  ) %>%
  mutate(
    variant = factor(variant, levels = variant_levels),
    variant_index = as.numeric(variant),
    x = variant_index + ifelse(condition == "vehicle", -0.18, 0.18)
  )

stat_results <- df_long %>%
  group_by(variant) %>%
  summarise(
    p_value = tryCatch(t.test(value ~ condition)$p.value, error = function(e) NA_real_),
    y_max = max(value, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(
    p_label = case_when(
      is.na(p_value) ~ "NA",
      p_value < 0.0001 ~ "****",
      p_value < 0.001 ~ "***",
      p_value < 0.01 ~ "**",
      p_value < 0.05 ~ "*",
      TRUE ~ "ns"
    ),
    variant = factor(variant, levels = variant_levels),
    variant_index = as.numeric(variant)
  )

y_span <- max(df_long$value, na.rm = TRUE) - min(df_long$value, na.rm = TRUE)
stat_results <- stat_results %>%
  mutate(y_position = y_max + 0.12 * max(y_span, 1))

summary_wide <- df_summary %>%
  select(variant, condition, mean_value, x) %>%
  pivot_wider(
    names_from = condition,
    values_from = c(mean_value, x)
  )

write.csv(df_long, file.path(table_dir, "icat_variant_complementation_long.csv"), row.names = FALSE)
write.csv(df_summary, file.path(table_dir, "icat_variant_complementation_summary.csv"), row.names = FALSE)
write.csv(stat_results, file.path(table_dir, "icat_variant_complementation_stats.csv"), row.names = FALSE)

p <- ggplot() +
  geom_segment(
    data = summary_wide,
    aes(
      x = x_vehicle,
      xend = x_IAA,
      y = mean_value_vehicle,
      yend = mean_value_IAA
    ),
    inherit.aes = FALSE,
    color = "#8C8C8C",
    linewidth = ICAT_LINE_MM
  ) +
  geom_point(
    data = df_long,
    aes(
      x = as.numeric(variant) + ifelse(condition == "vehicle", -0.18, 0.18),
      y = value,
      color = condition
    ),
    position = position_jitter(width = 0.03, height = 0),
    size = 1.2,
    alpha = 0.7,
    inherit.aes = FALSE
  ) +
  geom_errorbar(
    data = df_summary,
    aes(
      x = x,
      ymin = mean_value - coalesce(sd_value, 0),
      ymax = mean_value + coalesce(sd_value, 0),
      color = condition
    ),
    inherit.aes = FALSE,
    width = 0.15,
    linewidth = ICAT_LINE_MM
  ) +
  geom_point(
    data = df_summary,
    aes(x = x, y = mean_value, color = condition),
    inherit.aes = FALSE,
    size = 2.0
  ) +
  geom_text(
    data = stat_results,
    aes(x = variant_index, y = y_position, label = p_label),
    inherit.aes = FALSE,
    color = "black",
    family = "Arial",
    size = ICAT_TEXT_SMALL_MM,
    vjust = 0
  ) +
  scale_color_manual(values = c(vehicle = "#1F77B4", IAA = "#D62728")) +
  scale_x_continuous(
    breaks = seq_along(variant_levels),
    labels = variant_labels[variant_levels],
    expand = expansion(mult = c(0.03, 0.03))
  ) +
  scale_y_continuous(
    breaks = c(0, 50, 100, 150),
    limits = c(0, 155),
    expand = expansion(mult = c(0.01, 0.02))
  ) +
  icat_theme_classic(base_family = "Arial") +
  theme(
    axis.text = element_text(size = ICAT_FONT_SMALL_PT, color = "black"),
    axis.title = element_text(size = ICAT_FONT_BODY_PT),
    axis.text.x = element_text(angle = 0, hjust = 0.5, vjust = 1),
    axis.ticks.length = unit(1.0, "mm"),
    legend.position = "top",
    legend.justification = "center",
    legend.title = element_blank(),
    legend.direction = "horizontal",
    legend.text = element_text(size = ICAT_FONT_SMALL_PT),
    legend.key.width = unit(3.0, "mm"),
    legend.box.spacing = unit(0, "mm"),
    plot.margin = margin(0.35, 0.6, 0.25, 0.45)
  ) +
  labs(x = NULL, y = "Plaque number")

figure_width_cm <- 8.2
figure_height_cm <- 4.1

ggsave(
  file.path(figure_dir, "ICAT_variant_complementation.png"),
  plot = p,
  width = figure_width_cm / 2.54,
  height = figure_height_cm / 2.54,
  units = "in",
  dpi = 300,
  device = ragg::agg_png,
  bg = "transparent"
)

ggsave(
  file.path(figure_dir, "ICAT_variant_complementation.pdf"),
  plot = p,
  width = figure_width_cm / 2.54,
  height = figure_height_cm / 2.54,
  units = "in",
  device = grDevices::cairo_pdf,
  family = "Arial"
)

if (interactive()) print(p)
