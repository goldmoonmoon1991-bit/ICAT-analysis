#!/usr/bin/env Rscript

script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
script_path <- normalizePath(sub("^--file=", "", script_arg[[1]]), mustWork = TRUE)
code_dir <- dirname(script_path)
fig_dir <- normalizePath(file.path(code_dir, ".."), mustWork = TRUE)
project_root <- normalizePath(file.path(fig_dir, ".."), mustWork = TRUE)
source(file.path(project_root, "shared", "R", "project_library.R"))
icat_activate_project_library(project_root)

run_r <- function(...) {
  path <- file.path(code_dir, ...)
  status <- system2(file.path(R.home("bin"), "Rscript"), c("--vanilla", shQuote(path)))
  if (status != 0L) stop("Step failed: ", path)
}

run_r("egress", "ICAT_egress.R")
run_r("evacuoles", "ICAT_evacuoles.R")
run_r("conoid_protrusion", "ICAT_conoid_protrusion.R")
run_r("invasion", "Invasion_dynamic.R")
