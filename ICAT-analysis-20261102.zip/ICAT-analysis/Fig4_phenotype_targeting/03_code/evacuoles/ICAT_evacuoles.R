#!/usr/bin/env Rscript

script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
script_path <- normalizePath(sub("^--file=", "", script_arg[[1]]), mustWork = TRUE)
fig_dir <- normalizePath(file.path(dirname(script_path), "..", ".."), mustWork = TRUE)
project_root <- normalizePath(file.path(fig_dir, ".."), mustWork = TRUE)

source(file.path(project_root, "shared", "R", "project_library.R"))
icat_activate_project_library(project_root)

suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(ggplot2)
  library(readxl)
  library(ragg)
})

source(file.path(project_root, "shared", "R", "plot_style.R"))

input_path <- file.path(
  fig_dir, "01_raw_data", "evacuoles", "Evacuoles-3-replicate.xlsx"
)
figure_dir <- file.path(fig_dir, "04_results", "figures", "evacuoles")
table_dir <- file.path(fig_dir, "04_results", "tables", "evacuoles")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)

condition_palette <- c(vehicle = "#1F77B4", IAA = "#D62728")

format_p_value <- function(p_value) {
  if (is.na(p_value)) return("P = NA")
  if (p_value < 0.001) return("P < 0.001")
  paste0("P = ", formatC(p_value, format = "f", digits = 3))
}

format_p_stars <- function(p_value) {
  dplyr::case_when(
    is.na(p_value) ~ "NA",
    p_value < 0.001 ~ "***",
    p_value < 0.01 ~ "**",
    p_value < 0.05 ~ "*",
    TRUE ~ "ns"
  )
}

raw <- read_excel(input_path, sheet = "Sheet1", .name_repair = "minimal")
names(raw)[1] <- "measure"

evacuoles_long <- raw %>%
  pivot_longer(
    cols = -measure,
    names_to = "sample",
    values_to = "value"
  ) %>%
  separate(sample, into = c("condition", "replicate"), sep = "-") %>%
  pivot_wider(names_from = measure, values_from = value) %>%
  transmute(
    condition = factor(condition, levels = c("vehicle", "IAA")),
    replicate = as.integer(replicate),
    host_cells = as.numeric(`host cell (#)`),
    evacuoles = as.numeric(`Evacuoles (#)`),
    percentage = as.numeric(`percentage (%)`)
  )

evacuoles_summary <- evacuoles_long %>%
  group_by(condition) %>%
  summarise(
    n_replicates = n(),
    host_cells_total = sum(host_cells),
    evacuoles_total = sum(evacuoles),
    mean_percent = mean(percentage),
    sd_percent = sd(percentage),
    .groups = "drop"
  )

t_test <- stats::t.test(percentage ~ condition, data = evacuoles_long)
fisher_matrix <- evacuoles_summary %>%
  mutate(non_evacuoles = host_cells_total - evacuoles_total) %>%
  arrange(condition) %>%
  select(evacuoles_total, non_evacuoles) %>%
  as.matrix()
fisher_test <- stats::fisher.test(fisher_matrix)

stats_df <- tibble(
  comparison = "vehicle_vs_IAA",
  replicate_level_test = "two-sided Welch t-test on replicate percentages",
  replicate_level_p = t_test$p.value,
  pooled_count_test = "two-sided Fisher exact test on pooled host-cell counts",
  pooled_count_p = fisher_test$p.value
)

write.csv(
  evacuoles_long,
  file.path(table_dir, "ICAT_evacuoles_long.csv"),
  row.names = FALSE,
  quote = FALSE
)
write.csv(
  evacuoles_summary,
  file.path(table_dir, "ICAT_evacuoles_summary.csv"),
  row.names = FALSE,
  quote = FALSE
)
write.csv(
  stats_df,
  file.path(table_dir, "ICAT_evacuoles_stats.csv"),
  row.names = FALSE,
  quote = FALSE
)

y_max <- max(evacuoles_long$percentage, na.rm = TRUE)
y_bracket <- min(58, y_max + 8)
y_label <- y_bracket + 4
stat_label <- paste(format_p_stars(t_test$p.value), format_p_value(t_test$p.value))

p <- ggplot(evacuoles_long, aes(x = condition, y = percentage, color = condition)) +
  geom_point(
    position = position_jitter(width = 0.06, height = 0),
    size = 1.35,
    alpha = 0.9
  ) +
  geom_errorbar(
    data = evacuoles_summary,
    aes(
      x = condition,
      ymin = mean_percent - sd_percent,
      ymax = mean_percent + sd_percent
    ),
    inherit.aes = FALSE,
    width = 0.13,
    linewidth = max(ICAT_LINE_MM * 1.3, 0.28),
    color = "black"
  ) +
  geom_point(
    data = evacuoles_summary,
    aes(x = condition, y = mean_percent),
    inherit.aes = FALSE,
    shape = 18,
    size = 1.8,
    color = "black"
  ) +
  annotate(
    "segment",
    x = 1,
    xend = 2,
    y = y_bracket,
    yend = y_bracket,
    linewidth = ICAT_LINE_MM,
    color = "black"
  ) +
  annotate(
    "segment",
    x = 1,
    xend = 1,
    y = y_bracket,
    yend = y_bracket - 2,
    linewidth = ICAT_LINE_MM,
    color = "black"
  ) +
  annotate(
    "segment",
    x = 2,
    xend = 2,
    y = y_bracket,
    yend = y_bracket - 2,
    linewidth = ICAT_LINE_MM,
    color = "black"
  ) +
  annotate(
    "text",
    x = 1.5,
    y = y_label,
    label = stat_label,
    size = ICAT_TEXT_SMALL_MM,
    family = "Arial",
    color = "black"
  ) +
  scale_color_manual(values = condition_palette) +
  scale_y_continuous(
    breaks = c(0, 25, 50),
    limits = c(0, 65),
    expand = expansion(mult = c(0.01, 0.02))
  ) +
  icat_theme_classic(base_family = "Arial") +
  theme(
    axis.text = element_text(size = ICAT_FONT_SMALL_PT, color = "black"),
    axis.title = element_text(size = ICAT_FONT_BODY_PT),
    axis.ticks.length = unit(1.0, "mm"),
    legend.position = "none",
    plot.margin = margin(0.5, 0.8, 0.35, 0.55)
  ) +
  labs(x = NULL, y = "Evacuoles (%)")

figure_width_cm <- 3.2
figure_height_cm <- 3.5

ggsave(
  file.path(figure_dir, "ICAT_evacuoles.pdf"),
  p,
  width = figure_width_cm / 2.54,
  height = figure_height_cm / 2.54,
  units = "in",
  device = grDevices::cairo_pdf,
  family = "Arial"
)

ggsave(
  file.path(figure_dir, "ICAT_evacuoles.png"),
  p,
  bg = "transparent",
  width = figure_width_cm / 2.54,
  height = figure_height_cm / 2.54,
  units = "in",
  dpi = 300,
  device = ragg::agg_png
)

if (interactive()) print(p)
