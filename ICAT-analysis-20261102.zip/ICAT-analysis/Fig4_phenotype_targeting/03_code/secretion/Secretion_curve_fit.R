#!/usr/bin/env Rscript

# Descriptive one-phase secretion fit:
# y = 1 - exp(-k * time)
# The plateau is fixed at 100% because the assay is normalized to the vehicle
# endpoint; k should be interpreted as an apparent progression constant.

script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
script_path <- normalizePath(sub("^--file=", "", script_arg[[1]]), mustWork = TRUE)
fig_dir <- normalizePath(file.path(dirname(script_path), "..", ".."), mustWork = TRUE)
project_root <- normalizePath(file.path(fig_dir, ".."), mustWork = TRUE)
source(file.path(project_root, "shared", "R", "project_library.R"))
icat_activate_project_library(project_root)

suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(ggplot2)
  library(ragg)
})

source(file.path(project_root, "shared", "R", "plot_style.R"))

input_path <- file.path(fig_dir, "01_raw_data", "secretion", "secretion_dynamic_template.csv")
figure_dir <- file.path(fig_dir, "04_results", "figures", "secretion")
table_dir <- file.path(fig_dir, "04_results", "tables", "secretion")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)

condition_palette <- c(vehicle = "#1F77B4", IAA = "#D62728")

format_p_value <- function(p_value) {
  if (is.na(p_value)) return("P = NA")
  if (p_value < 0.001) return("P < 0.001")
  paste0("P = ", formatC(p_value, format = "f", digits = 3))
}

format_p_stars <- function(p_value) {
  dplyr::case_when(
    is.na(p_value) ~ "NA",
    p_value < 0.001 ~ "***",
    p_value < 0.01 ~ "**",
    p_value < 0.05 ~ "*",
    TRUE ~ "ns"
  )
}

fit_fixed_plateau <- function(data) {
  fit <- tryCatch(
    nls(
      measurement ~ 1 - exp(-k * time_min),
      data = data,
      start = list(k = 0.1),
      algorithm = "port",
      lower = c(k = 1e-6),
      upper = c(k = 5),
      control = nls.control(maxiter = 200, warnOnly = TRUE)
    ),
    error = function(e) e
  )

  if (inherits(fit, "error")) {
    return(tibble(k_per_min = NA_real_, rss = NA_real_, fit_error = fit$message))
  }

  k_value <- unname(coef(fit)[["k"]])
  tibble(
    k_per_min = k_value,
    t_half_min = log(2) / k_value,
    apparent_initial_rate_percent_per_min = 100 * k_value,
    rss = sum(resid(fit)^2),
    fit_error = NA_character_
  )
}

raw <- read.csv(input_path, check.names = FALSE, stringsAsFactors = FALSE)
required_cols <- c("condition", "time_min", "replicate_1", "replicate_2", "replicate_3")
missing_cols <- setdiff(required_cols, colnames(raw))
if (length(missing_cols) > 0) {
  stop("Missing columns in secretion template: ", paste(missing_cols, collapse = ", "))
}

df_long <- raw %>%
  mutate(
    condition = factor(condition, levels = c("vehicle", "IAA")),
    time_min = as.numeric(time_min)
  ) %>%
  pivot_longer(
    cols = starts_with("replicate_"),
    names_to = "replicate",
    values_to = "measurement"
  ) %>%
  mutate(measurement = as.numeric(measurement)) %>%
  filter(is.finite(measurement))

if (nrow(df_long) == 0) {
  stop("The secretion template is empty. Fill at least one measurement before fitting.")
}

df_summary <- df_long %>%
  group_by(time_min, condition) %>%
  summarise(
    mean_value = mean(measurement),
    sd_value = if (n() > 1) sd(measurement) else NA_real_,
    n = n(),
    .groups = "drop"
  )

condition_fits <- df_long %>%
  group_by(condition) %>%
  group_modify(~ fit_fixed_plateau(.x)) %>%
  ungroup() %>%
  mutate(model = "fixed plateau: y = 1 - exp(-k*time)")

replicate_fits <- df_long %>%
  group_by(condition, replicate) %>%
  group_modify(~ fit_fixed_plateau(.x)) %>%
  ungroup() %>%
  mutate(model = "fixed plateau: y = 1 - exp(-k*time)")

fit_stats <- replicate_fits %>%
  filter(is.finite(k_per_min)) %>%
  group_by(condition) %>%
  summarise(
    n = n(),
    mean_k_per_min = mean(k_per_min),
    sd_k_per_min = sd(k_per_min),
    mean_t_half_min = mean(t_half_min),
    sd_t_half_min = sd(t_half_min),
    mean_initial_rate_percent_per_min = mean(apparent_initial_rate_percent_per_min),
    sd_initial_rate_percent_per_min = sd(apparent_initial_rate_percent_per_min),
    .groups = "drop"
  )

curve_test_data <- replicate_fits %>% filter(is.finite(k_per_min))
curve_test <- tibble(
  test = "two-sided Welch t-test on replicate-level apparent k",
  p_value = tryCatch(t.test(k_per_min ~ condition, data = curve_test_data)$p.value, error = function(e) NA_real_)
) %>%
  mutate(
    p_label = format_p_stars(p_value),
    p_text = format_p_value(p_value)
  )

prediction_grid <- expand.grid(
  condition = factor(c("vehicle", "IAA"), levels = c("vehicle", "IAA")),
  time_min = seq(0, 10, length.out = 200)
) %>%
  left_join(condition_fits, by = "condition") %>%
  mutate(fitted_value = 1 - exp(-k_per_min * time_min))

write.csv(df_long, file.path(table_dir, "secretion_curve_fit_long.csv"), row.names = FALSE, quote = FALSE)
write.csv(df_summary, file.path(table_dir, "secretion_curve_fit_summary.csv"), row.names = FALSE, quote = FALSE)
write.csv(condition_fits, file.path(table_dir, "secretion_curve_fit_condition_parameters.csv"), row.names = FALSE, quote = FALSE)
write.csv(replicate_fits, file.path(table_dir, "secretion_curve_fit_replicate_parameters.csv"), row.names = FALSE, quote = FALSE)
write.csv(fit_stats, file.path(table_dir, "secretion_curve_fit_parameter_summary.csv"), row.names = FALSE, quote = FALSE)
write.csv(curve_test, file.path(table_dir, "secretion_curve_fit_stats.csv"), row.names = FALSE, quote = FALSE)
write.csv(prediction_grid, file.path(table_dir, "secretion_curve_fit_predictions.csv"), row.names = FALSE, quote = FALSE)

label_df <- tibble(
  condition = factor(c("vehicle", "IAA"), levels = c("vehicle", "IAA")),
  label = c("vehicle", "IAA"),
  x_label = c(10.0, 10.0),
  y_label = c(0.82, 0.42)
)

test_label <- curve_test %>%
  mutate(
    x = 2.8,
    y = 0.93,
    label = paste0("k: ", p_label)
  )

p <- ggplot() +
  geom_line(
    data = prediction_grid,
    aes(x = time_min, y = fitted_value, color = condition),
    linewidth = ICAT_LINE_MM * 1.45
  ) +
  geom_errorbar(
    data = df_summary,
    aes(
      x = time_min,
      ymin = mean_value - coalesce(sd_value, 0),
      ymax = mean_value + coalesce(sd_value, 0)
    ),
    width = 0.75,
    linewidth = max(ICAT_LINE_MM * 1.8, 0.45),
    color = "black"
  ) +
  geom_point(
    data = df_summary,
    aes(x = time_min, y = mean_value, color = condition),
    size = 1.45
  ) +
  geom_text(
    data = label_df,
    aes(x = x_label, y = y_label, label = label, color = condition),
    inherit.aes = FALSE,
    family = "Arial",
    size = ICAT_TEXT_SMALL_MM,
    hjust = 1,
    vjust = 0.5
  ) +
  geom_text(
    data = test_label,
    aes(x = x, y = y, label = label),
    inherit.aes = FALSE,
    family = "Arial",
    size = ICAT_TEXT_SMALL_MM,
    color = "black"
  ) +
  scale_color_manual(values = condition_palette) +
  scale_x_continuous(breaks = c(0, 2, 5, 10), limits = c(-0.25, 10.35)) +
  scale_y_continuous(
    breaks = c(0, 0.5, 1.0),
    labels = c("0", "50", "100"),
    limits = c(0, 1.12),
    expand = expansion(mult = c(0.01, 0.02))
  ) +
  icat_theme_classic(base_family = "Arial") +
  theme(
    axis.text = element_text(size = ICAT_FONT_SMALL_PT, color = "black"),
    axis.title = element_text(size = 7),
    axis.title.x = element_text(size = 7, margin = margin(t = 1.2)),
    axis.title.y = element_text(margin = margin(r = 1)),
    axis.ticks.length = unit(1.0, "mm"),
    legend.position = "none",
    plot.margin = margin(0.05, 0.2, 0.2, 2.6)
  ) +
  labs(x = "Time (min)", y = "Secretion (%)")

figure_width_cm <- 3.2
figure_height_cm <- 1.8

ggsave(
  file.path(figure_dir, "Secretion_curve_fit.png"),
  plot = p,
  width = figure_width_cm / 2.54,
  height = figure_height_cm / 2.54,
  units = "in",
  dpi = 300,
  device = ragg::agg_png,
  bg = "transparent"
)

ggsave(
  file.path(figure_dir, "Secretion_curve_fit.pdf"),
  plot = p,
  width = figure_width_cm / 2.54,
  height = figure_height_cm / 2.54,
  units = "in",
  device = grDevices::cairo_pdf,
  family = "Arial"
)

if (interactive()) print(p)
