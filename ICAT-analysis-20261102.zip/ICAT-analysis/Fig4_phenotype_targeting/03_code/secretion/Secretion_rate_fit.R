#!/usr/bin/env Rscript

script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
script_path <- normalizePath(sub("^--file=", "", script_arg[[1]]), mustWork = TRUE)
fig_dir <- normalizePath(file.path(dirname(script_path), "..", ".."), mustWork = TRUE)
project_root <- normalizePath(file.path(fig_dir, ".."), mustWork = TRUE)
source(file.path(project_root, "shared", "R", "project_library.R"))
icat_activate_project_library(project_root)

suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(ggplot2)
  library(ragg)
})

source(file.path(project_root, "shared", "R", "plot_style.R"))

input_path <- file.path(fig_dir, "01_raw_data", "secretion", "secretion_dynamic_template.csv")
figure_dir <- file.path(fig_dir, "04_results", "figures", "secretion")
table_dir <- file.path(fig_dir, "04_results", "tables", "secretion")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)

condition_palette <- c(vehicle = "#1F77B4", IAA = "#D62728")

format_p_value <- function(p_value) {
  if (is.na(p_value)) return("P = NA")
  if (p_value < 0.001) return("P < 0.001")
  paste0("P = ", formatC(p_value, format = "f", digits = 3))
}

format_p_stars <- function(p_value) {
  dplyr::case_when(
    is.na(p_value) ~ "NA",
    p_value < 0.001 ~ "***",
    p_value < 0.01 ~ "**",
    p_value < 0.05 ~ "*",
    TRUE ~ "ns"
  )
}

fit_rate <- function(data, window_label, max_time) {
  data %>%
    filter(time_min <= max_time) %>%
    group_by(condition, replicate) %>%
    summarise(
      rate_fraction_per_min = coef(lm(measurement ~ time_min))[["time_min"]],
      intercept = coef(lm(measurement ~ time_min))[["(Intercept)"]],
      n_timepoints = n(),
      .groups = "drop"
    ) %>%
    mutate(
      window = window_label,
      max_time_min = max_time,
      rate_percent_per_min = 100 * rate_fraction_per_min
    )
}

raw <- read.csv(input_path, check.names = FALSE, stringsAsFactors = FALSE)

df_long <- raw %>%
  mutate(
    condition = factor(condition, levels = c("vehicle", "IAA")),
    time_min = as.numeric(time_min)
  ) %>%
  pivot_longer(
    cols = starts_with("replicate_"),
    names_to = "replicate",
    values_to = "measurement"
  ) %>%
  mutate(measurement = as.numeric(measurement)) %>%
  filter(is.finite(measurement))

rate_slopes <- bind_rows(
  fit_rate(df_long, "initial 0-5 min", 5),
  fit_rate(df_long, "overall 0-10 min", 10)
) %>%
  mutate(
    window = factor(window, levels = c("initial 0-5 min", "overall 0-10 min")),
    condition = factor(condition, levels = c("vehicle", "IAA"))
  )

rate_summary <- rate_slopes %>%
  group_by(window, condition) %>%
  summarise(
    n = n(),
    mean_rate_percent_per_min = mean(rate_percent_per_min),
    sd_rate_percent_per_min = sd(rate_percent_per_min),
    .groups = "drop"
  )

rate_stats <- rate_slopes %>%
  group_by(window) %>%
  group_modify(~ {
    p_value <- tryCatch(
      t.test(rate_percent_per_min ~ condition, data = .x)$p.value,
      error = function(e) NA_real_
    )
    tibble(
      test = "two-sided Welch t-test",
      p_value = p_value,
      p_label = format_p_stars(p_value),
      p_text = format_p_value(p_value)
    )
  }) %>%
  ungroup()

write.csv(
  rate_slopes,
  file.path(table_dir, "secretion_rate_fit_slopes.csv"),
  row.names = FALSE,
  quote = FALSE
)
write.csv(
  rate_summary,
  file.path(table_dir, "secretion_rate_fit_summary.csv"),
  row.names = FALSE,
  quote = FALSE
)
write.csv(
  rate_stats,
  file.path(table_dir, "secretion_rate_fit_stats.csv"),
  row.names = FALSE,
  quote = FALSE
)

anno_df <- rate_slopes %>%
  group_by(window) %>%
  summarise(y = max(rate_percent_per_min, na.rm = TRUE) + 1.8, .groups = "drop") %>%
  left_join(rate_stats, by = "window") %>%
  mutate(x = 1.5)

p <- ggplot(rate_slopes, aes(x = condition, y = rate_percent_per_min, color = condition)) +
  geom_point(
    position = position_jitter(width = 0.06, height = 0),
    size = 1.25,
    alpha = 0.9
  ) +
  geom_errorbar(
    data = rate_summary,
    aes(
      x = condition,
      ymin = mean_rate_percent_per_min - sd_rate_percent_per_min,
      ymax = mean_rate_percent_per_min + sd_rate_percent_per_min
    ),
    inherit.aes = FALSE,
    width = 0.13,
    linewidth = max(ICAT_LINE_MM * 1.3, 0.28),
    color = "black"
  ) +
  geom_point(
    data = rate_summary,
    aes(x = condition, y = mean_rate_percent_per_min),
    inherit.aes = FALSE,
    shape = 18,
    size = 1.75,
    color = "black"
  ) +
  geom_segment(
    data = anno_df,
    aes(x = 1, xend = 2, y = y, yend = y),
    inherit.aes = FALSE,
    linewidth = ICAT_LINE_MM,
    color = "black"
  ) +
  geom_text(
    data = anno_df,
    aes(x = x, y = y + 0.9, label = p_label),
    inherit.aes = FALSE,
    size = ICAT_TEXT_SMALL_MM,
    family = "Arial",
    color = "black"
  ) +
  facet_wrap(~window, nrow = 1) +
  scale_color_manual(values = condition_palette) +
  scale_y_continuous(expand = expansion(mult = c(0.02, 0.14))) +
  icat_theme_classic(base_family = "Arial") +
  theme(
    axis.text = element_text(size = ICAT_FONT_SMALL_PT, color = "black"),
    axis.title = element_text(size = ICAT_FONT_BODY_PT),
    axis.ticks.length = unit(1.0, "mm"),
    strip.background = element_blank(),
    strip.text = element_text(size = ICAT_FONT_SMALL_PT, face = "bold"),
    legend.position = "none",
    plot.margin = margin(0.35, 0.55, 0.35, 0.55)
  ) +
  labs(x = NULL, y = "Secretion rate (% min^-1)")

ggsave(
  file.path(figure_dir, "Secretion_rate_fit.pdf"),
  p,
  width = 6.0 / 2.54,
  height = 3.2 / 2.54,
  units = "in",
  device = grDevices::cairo_pdf,
  family = "Arial"
)

ggsave(
  file.path(figure_dir, "Secretion_rate_fit.png"),
  p,
  width = 6.0 / 2.54,
  height = 3.2 / 2.54,
  units = "in",
  dpi = 300,
  device = ragg::agg_png,
  bg = "transparent"
)

if (interactive()) print(p)
