# ============================================================
# ICAT secretion dynamics heatmap: vehicle versus IAA
# Each tile represents one biological replicate at one time point.
# ============================================================
script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
script_path <- normalizePath(sub("^--file=", "", script_arg[[1]]), mustWork = TRUE)
fig_dir <- normalizePath(file.path(dirname(script_path), "..", ".."), mustWork = TRUE)
project_root <- normalizePath(file.path(fig_dir, ".."), mustWork = TRUE)
source(file.path(project_root, "shared", "R", "project_library.R"))
icat_activate_project_library(project_root)

library(ggplot2)
library(dplyr)
library(tidyr)

source(file.path(project_root, "shared", "R", "plot_style.R"))

input_path <- file.path(fig_dir, "01_raw_data", "secretion", "secretion_dynamic_template.csv")
figure_dir <- file.path(fig_dir, "04_results", "figures", "secretion")
table_dir <- file.path(fig_dir, "04_results", "tables", "secretion")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)

raw <- read.csv(input_path, check.names = FALSE, stringsAsFactors = FALSE)
replicate_cols <- grep("^replicate_[0-9]+$", colnames(raw), value = TRUE)
required_cols <- c("condition", "time_min", "replicate_1", "replicate_2", "replicate_3")
missing_cols <- setdiff(required_cols, colnames(raw))
if (length(missing_cols) > 0) {
  stop("Missing columns in secretion template: ", paste(missing_cols, collapse = ", "))
}
if (length(replicate_cols) == 0) {
  stop("No replicate columns found in secretion template.")
}

df_long <- raw %>%
  mutate(
    condition = factor(condition, levels = c("vehicle", "IAA")),
    time_min = as.numeric(time_min),
    time_label = factor(time_min, levels = c(0, 2, 5, 10))
  ) %>%
  pivot_longer(
    cols = all_of(replicate_cols),
    names_to = "replicate",
    values_to = "measurement"
  ) %>%
  mutate(
    measurement = as.numeric(measurement),
    replicate = factor(replicate, levels = replicate_cols)
  ) %>%
  filter(is.finite(measurement))

if (nrow(df_long) == 0) {
  stop("The secretion template is empty. Fill at least one measurement before plotting.")
}

df_summary <- df_long %>%
  group_by(time_min, condition) %>%
  summarise(
    mean_value = mean(measurement),
    sd_value = if (n() > 1) sd(measurement) else NA_real_,
    .groups = "drop"
  )

write.csv(df_long, file.path(table_dir, "secretion_heatmap_long.csv"), row.names = FALSE)
write.csv(df_summary, file.path(table_dir, "secretion_heatmap_summary.csv"), row.names = FALSE)

fill_limits <- c(0, 1)

p <- ggplot(df_long, aes(x = time_label, y = replicate, fill = measurement)) +
  geom_tile(color = "white", linewidth = ICAT_LINE_MM, width = 0.98, height = 0.96) +
  facet_grid(condition ~ ., switch = "y") +
  scale_fill_gradient2(
    low = "#2C7BB6",
    mid = "#F7F7F7",
    high = "#D7191C",
    midpoint = 0.35,
    limits = fill_limits,
    breaks = c(0, 0.5, 1.0),
    labels = c("0", "50", "100"),
    oob = scales::squish
  ) +
  scale_x_discrete(
    labels = c("0", "2", "5", "10"),
    expand = expansion(add = 0.01)
  ) +
  scale_y_discrete(labels = c(
    "replicate_1" = "R1",
    "replicate_2" = "R2",
    "replicate_3" = "R3",
    "replicate_4" = "R4"
  )) +
  icat_theme_classic(base_family = "Arial") +
  theme(
    axis.text = element_text(size = 5, color = "black"),
    axis.title = element_text(size = ICAT_FONT_BODY_PT),
    axis.title.y = element_blank(),
    axis.ticks.length = unit(1.0, "mm"),
    strip.text.y.left = element_text(size = 5, face = "bold", angle = 0),
    strip.background = element_rect(fill = "grey95", colour = NA),
    strip.placement = "outside",
    panel.spacing.y = unit(0.8, "mm"),
    legend.position = "right",
    legend.title = element_blank(),
    legend.text = element_text(size = 4.8),
    legend.key.height = unit(2.1, "mm"),
    legend.key.width = unit(1.8, "mm"),
    legend.margin = margin(0, 0, 0, 0),
    legend.box.spacing = unit(0, "mm"),
    plot.margin = margin(0.3, 0.8, 0.3, 0.35)
  ) +
  labs(x = "Time (min)", y = "Replicate", fill = "Secretion (%)")

figure_width_cm <- 3.3
figure_height_cm <- 1.8

ggsave(
  file.path(figure_dir, "Secretion_heatmap.png"),
  plot = p,
  width = figure_width_cm / 2.54,
  height = figure_height_cm / 2.54,
  units = "in",
  dpi = 300,
  device = ragg::agg_png,
  bg = "transparent"
)

ggsave(
  file.path(figure_dir, "Secretion_heatmap.pdf"),
  plot = p,
  width = figure_width_cm / 2.54,
  height = figure_height_cm / 2.54,
  units = "in",
  device = grDevices::cairo_pdf,
  family = "Arial"
)

if (interactive()) print(p)
