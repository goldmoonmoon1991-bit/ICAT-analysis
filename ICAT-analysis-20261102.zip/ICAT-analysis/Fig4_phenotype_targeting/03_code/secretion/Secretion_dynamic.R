# ============================================================
# ICAT secretion dynamics: vehicle versus IAA
# Input template: 01_raw_data/secretion/secretion_dynamic_template.csv
# Fill one value per biological replicate in replicate_1 to replicate_3.
# ============================================================
script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
script_path <- normalizePath(sub("^--file=", "", script_arg[[1]]), mustWork = TRUE)
fig_dir <- normalizePath(file.path(dirname(script_path), "..", ".."), mustWork = TRUE)
project_root <- normalizePath(file.path(fig_dir, ".."), mustWork = TRUE)
source(file.path(project_root, "shared", "R", "project_library.R"))
icat_activate_project_library(project_root)

library(ggplot2)
library(dplyr)
library(tidyr)

source(file.path(project_root, "shared", "R", "plot_style.R"))

input_path <- file.path(fig_dir, "01_raw_data", "secretion", "secretion_dynamic_template.csv")
figure_dir <- file.path(fig_dir, "04_results", "figures", "secretion")
table_dir <- file.path(fig_dir, "04_results", "tables", "secretion")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)

raw <- read.csv(input_path, check.names = FALSE, stringsAsFactors = FALSE)
required_cols <- c("condition", "time_min", "replicate_1", "replicate_2", "replicate_3")
missing_cols <- setdiff(required_cols, colnames(raw))
if (length(missing_cols) > 0) {
  stop("Missing columns in secretion template: ", paste(missing_cols, collapse = ", "))
}

df_long <- raw %>%
  mutate(
    condition = factor(condition, levels = c("vehicle", "IAA")),
    time_min = as.numeric(time_min)
  ) %>%
  pivot_longer(
    cols = starts_with("replicate_"),
    names_to = "replicate",
    values_to = "measurement"
  ) %>%
  mutate(measurement = as.numeric(measurement)) %>%
  filter(is.finite(measurement))

if (nrow(df_long) == 0) {
  stop("The secretion template is empty. Fill at least one measurement before plotting.")
}

df_summary <- df_long %>%
  group_by(time_min, condition) %>%
  summarise(
    mean_value = mean(measurement),
    sd_value = if (n() > 1) sd(measurement) else NA_real_,
    n = n(),
    .groups = "drop"
  )

# Welch two-sample t-test at each time point; use biological replicates as n.
stat_results <- df_long %>%
  group_by(time_min) %>%
  group_modify(~ {
    x <- .x %>% filter(condition == "vehicle") %>% pull(measurement)
    y <- .x %>% filter(condition == "IAA") %>% pull(measurement)
    p_value <- if (length(x) >= 2 && length(y) >= 2) {
      tryCatch(t.test(x, y, var.equal = FALSE)$p.value, error = function(e) NA_real_)
    } else {
      NA_real_
    }
    tibble(p_value = p_value)
  }) %>%
  ungroup() %>%
  mutate(
    p_label = case_when(
      is.na(p_value) ~ "NA",
      p_value < 0.0001 ~ "****",
      p_value < 0.001 ~ "***",
      p_value < 0.01 ~ "**",
      p_value < 0.05 ~ "*",
      TRUE ~ "ns"
    )
  )

stat_results <- stat_results %>%
  left_join(
    df_summary %>%
      group_by(time_min) %>%
      summarise(y_max = max(mean_value + coalesce(sd_value, 0), na.rm = TRUE), .groups = "drop"),
    by = "time_min"
  )

y_range <- range(df_long$measurement, na.rm = TRUE)
y_span <- max(diff(y_range), abs(y_range[2]), 1)
y_offset <- 0.14 * y_span
stat_results <- stat_results %>% mutate(y_position = y_max + y_offset)

write.csv(df_long, file.path(table_dir, "secretion_dynamic_long.csv"), row.names = FALSE)
write.csv(df_summary, file.path(table_dir, "secretion_dynamic_summary.csv"), row.names = FALSE)
write.csv(stat_results, file.path(table_dir, "secretion_dynamic_stats.csv"), row.names = FALSE)

p <- ggplot(df_summary, aes(x = time_min, y = mean_value, color = condition, group = condition)) +
  geom_errorbar(
    aes(ymin = mean_value - coalesce(sd_value, 0), ymax = mean_value + coalesce(sd_value, 0)),
    width = 1,
    linewidth = max(ICAT_LINE_MM * 1.8, 0.45),
    color = "black"
  ) +
  geom_line(linewidth = ICAT_LINE_MM) +
  geom_point(size = 1.5) +
  geom_text(
    data = stat_results %>% filter(!is.na(p_value)),
    aes(x = time_min, y = y_position, label = p_label),
    inherit.aes = FALSE,
    color = "black",
    family = "Arial",
    size = ICAT_TEXT_SMALL_MM,
    vjust = 0.3
  ) +
  scale_color_manual(values = c(vehicle = "#1F77B4", IAA = "#D62728")) +
  scale_x_continuous(breaks = c(0, 2, 5, 10), limits = c(-0.35, 10.15)) +
  scale_y_continuous(
    breaks = c(0, 0.5, 1.0),
    labels = c("0", "50", "100"),
    limits = c(0, 1.26),
    expand = expansion(mult = c(0.01, 0.03))
  ) +
  icat_theme_classic(base_family = "Arial") +
  theme(
    axis.text = element_text(size = ICAT_FONT_SMALL_PT, color = "black"),
    axis.title = element_text(size = 7),
    axis.title.x = element_text(size = 7, margin = margin(t = 1.2)),
    axis.title.y = element_text(margin = margin(r = 1)),
    axis.ticks.length = unit(1.0, "mm"),
    legend.position = "none",
    plot.margin = margin(0.05, 0.2, 0.2, 2.6)
  ) +
  labs(x = "Time (min)", y = "Secretion (%)")

figure_width_cm <- 3.2
figure_height_cm <- 1.8

ggsave(
  file.path(figure_dir, "Secretion_dynamic.png"),
  plot = p,
  width = figure_width_cm / 2.54,
  height = figure_height_cm / 2.54,
  units = "in",
  dpi = 300,
  device = ragg::agg_png,
  bg = "transparent"
)

ggsave(
  file.path(figure_dir, "Secretion_dynamic.pdf"),
  plot = p,
  width = figure_width_cm / 2.54,
  height = figure_height_cm / 2.54,
  units = "in",
  device = grDevices::cairo_pdf,
  family = "Arial"
)

if (interactive()) print(p)
