#!/usr/bin/env Rscript

script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
script_path <- normalizePath(sub("^--file=", "", script_arg[[1]]), mustWork = TRUE)
fig_dir <- normalizePath(file.path(dirname(script_path), "..", ".."), mustWork = TRUE)
project_root <- normalizePath(file.path(fig_dir, ".."), mustWork = TRUE)

source(file.path(project_root, "shared", "R", "project_library.R"))
icat_activate_project_library(project_root)

suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(ggplot2)
})
source(file.path(project_root, "shared", "R", "plot_style.R"))

input_path <- file.path(
  fig_dir, "01_raw_data", "plaque", "BC2-mAID-3HA.pzfx"
)
table_dir <- file.path(fig_dir, "04_results", "tables", "plaque")
figure_dir <- file.path(fig_dir, "04_results", "figures", "plaque")
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)

read_prism_table <- function(table_id) {
  txt <- paste(readLines(input_path, warn = FALSE), collapse = "\n")
  table_pat <- paste0("(?s)<Table ID=\"", table_id, "\".*?</Table>")
  table_match <- regexpr(table_pat, txt, perl = TRUE)
  if (table_match[1] == -1) {
    stop("Table not found: ", table_id)
  }
  block <- regmatches(txt, table_match)

  table_title <- sub("(?s).*?<Title>(.*?)</Title>.*", "\\1", block, perl = TRUE)
  row_title <- sub("(?s).*?<RowTitlesColumn.*?<d>(.*?)</d>.*", "\\1", block, perl = TRUE)

  y_blocks <- regmatches(
    block,
    gregexpr("(?s)<YColumn[^>]*>.*?</YColumn>", block, perl = TRUE)
  )[[1]]

  out <- lapply(seq_along(y_blocks), function(i) {
    y_block <- y_blocks[[i]]
    condition <- sub(
      "(?s).*?<TextAlign align=\"Center\">(.*?)</TextAlign>.*",
      "\\1",
      y_block,
      perl = TRUE
    )
    values <- regmatches(y_block, gregexpr("(?s)<d>(.*?)</d>", y_block, perl = TRUE))[[1]]
    values <- sub("(?s).*?<d>(.*?)</d>.*", "\\1", values, perl = TRUE)
    tibble(
      table = table_title,
      strain = row_title,
      condition = condition,
      replicate = seq_along(values),
      value = suppressWarnings(as.numeric(values))
    )
  }) |> bind_rows()

  out
}

plaque_number <- read_prism_table("Table8") |>
  mutate(metric = "plaque number")

plaque_area <- read_prism_table("Table9") |>
  mutate(metric = "plaque area")

plaque_long <- bind_rows(plaque_number, plaque_area) |>
  select(strain, metric, condition, replicate, value) |>
  arrange(metric, condition, replicate)

write.csv(
  plaque_long,
  file.path(table_dir, "BC2-mAID-3HA_plaque_long.csv"),
  row.names = FALSE,
  quote = FALSE
)

write.csv(
  filter(plaque_long, metric == "plaque number"),
  file.path(table_dir, "BC2-mAID-3HA_plaque_number.csv"),
  row.names = FALSE,
  quote = FALSE
)

write.csv(
  filter(plaque_long, metric == "plaque area"),
  file.path(table_dir, "BC2-mAID-3HA_plaque_area.csv"),
  row.names = FALSE,
  quote = FALSE
)

summary_df <- plaque_long |>
  group_by(metric, condition) |>
  summarise(
    n = n(),
    mean = mean(value, na.rm = TRUE),
    sd = sd(value, na.rm = TRUE),
    .groups = "drop"
  )

write.csv(
  summary_df,
  file.path(table_dir, "BC2-mAID-3HA_plaque_summary.csv"),
  row.names = FALSE,
  quote = FALSE
)

metric_levels <- c("plaque number", "plaque area")
condition_levels <- c("vehicle", "IAA")
plaque_long <- plaque_long |>
  mutate(
    metric = factor(metric, levels = metric_levels),
    condition = factor(condition, levels = condition_levels)
  )

summary_df <- summary_df |>
  mutate(
    metric = factor(metric, levels = metric_levels),
    condition = factor(condition, levels = condition_levels)
  )

stats_df <- bind_rows(lapply(split(plaque_long, plaque_long$metric), function(df) {
  p_value <- wilcox.test(value ~ condition, data = df, exact = FALSE)$p.value
  tibble(
    metric = unique(df$metric),
    p_value = p_value,
    test = "two-sided Wilcoxon rank-sum",
    label = case_when(
      p_value < 0.0001 ~ "****",
      p_value < 0.001 ~ "***",
      p_value < 0.01 ~ "**",
      p_value < 0.05 ~ "*",
      TRUE ~ "ns"
    )
  )
}))

write.csv(
  stats_df,
  file.path(table_dir, "BC2-mAID-3HA_plaque_stats.csv"),
  row.names = FALSE,
  quote = FALSE
)

anno_df <- summary_df |>
  group_by(metric) |>
  summarise(
    x = 1.5,
    y = max(mean + sd, na.rm = TRUE) * 1.12,
    .groups = "drop"
  ) |>
  left_join(stats_df, by = "metric")

fig <- plaque_long |>
  mutate(metric = factor(metric, levels = c("plaque number", "plaque area"))) |>
  ggplot(aes(x = condition, y = value, color = condition)) +
  geom_jitter(width = 0.08, size = 1.4, alpha = 0.9) +
  geom_errorbar(
    data = summary_df,
    aes(x = condition, ymin = mean - sd, ymax = mean + sd),
    inherit.aes = FALSE,
    width = 0.12,
    linewidth = ICAT_LINE_MM,
    color = "black"
  ) +
  stat_summary(fun = mean, geom = "point", size = 1.8, shape = 18, color = "black") +
  geom_segment(
    data = anno_df,
    aes(x = 1, xend = 2, y = y, yend = y),
    inherit.aes = FALSE,
    linewidth = ICAT_LINE_MM,
    color = "black"
  ) +
  geom_text(
    data = anno_df,
    aes(x = x, y = y * 1.02, label = label),
    inherit.aes = FALSE,
    family = "Arial",
    size = ICAT_TEXT_SMALL_MM,
    color = "black"
  ) +
  facet_wrap(
    ~metric,
    nrow = 1,
    scales = "free_y",
    labeller = as_labeller(c(
      "plaque number" = "plaque\nnumber",
      "plaque area" = "plaque\narea"
    ))
  ) +
  scale_x_discrete(labels = NULL) +
  scale_color_manual(values = c(vehicle = "#2C7FB8", IAA = "#D7301F")) +
  labs(x = "Treatment", y = NULL) +
  icat_theme_classic(base_family = "Arial") +
  theme(
    axis.text = element_text(size = ICAT_FONT_SMALL_PT, colour = "black"),
    axis.title = element_text(size = ICAT_FONT_BODY_PT),
    axis.ticks.length = unit(1.0, "mm"),
    axis.ticks.x = element_blank(),
    strip.text = element_text(size = ICAT_FONT_SMALL_PT, face = "bold"),
    strip.background = element_blank(),
    legend.position = "none",
    plot.margin = margin(2.2, 1.0, 0.9, 1.0)
  )

ggsave(
  file.path(figure_dir, "BC2-mAID-3HA_plaque_dotplot.pdf"),
  fig,
  width = 3.8 / 2.54,
  height = 2.8 / 2.54,
  device = grDevices::cairo_pdf,
  family = "Arial"
)

ggsave(
  file.path(figure_dir, "BC2-mAID-3HA_plaque_dotplot.png"),
  fig,
  width = 3.8 / 2.54,
  height = 2.8 / 2.54,
  dpi = 300,
  device = grDevices::png
)

message("Saved tables to: ", table_dir)
message("Saved figures to: ", figure_dir)
