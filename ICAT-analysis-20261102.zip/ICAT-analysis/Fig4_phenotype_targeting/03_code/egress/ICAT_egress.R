# ============================================================
# 1. 加载必要的库
# ============================================================
script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
script_path <- normalizePath(sub("^--file=", "", script_arg[[1]]), mustWork = TRUE)
fig_dir <- normalizePath(file.path(dirname(script_path), "..", ".."), mustWork = TRUE)
project_root <- normalizePath(file.path(fig_dir, ".."), mustWork = TRUE)
source(file.path(project_root, "shared", "R", "project_library.R"))
icat_activate_project_library(project_root)

library(ggplot2)   # 核心绘图
library(dplyr)     # 数据处理
library(tidyr)     # 格式转换
library(patchwork) # 拼图工具
library(ragg)      # 高质量 PNG 渲染
library(ggpubr)    # 统计辅助 (如需后续添加显著性标记)

source(file.path(project_root, "shared", "R", "plot_style.R"))
input_path <- file.path(fig_dir, "01_raw_data", "egress", "ICAT_egress.csv")
figure_dir <- file.path(fig_dir, "04_results", "figures", "egress")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)

condition_palette <- c(vehicle = "#1F77B4", IAA = "#D62728")
mean_line_width <- max(ICAT_LINE_MM * 1.4, 0.32)
replicate_line_width <- ICAT_LINE_MM
summary_point_size <- 1.1

# ============================================================
# 2. 数据读取与预处理
# ============================================================
# 读取原始 CSV 数据
df <- read.csv(input_path)

# 统一列名格式：将点 "." 替换为下划线 "_" 方便后续 separate 处理
colnames(df) <- gsub("\\.", "_", colnames(df))

# 自动生成时间轴：如果 CSV 没带 time 列，按行号生成从 0 开始的时间索引
if(!"time" %in% colnames(df)){
  df$time <- 0:(nrow(df)-1)
}

# ============================================================
# 3. 数据转换 (Wide to Long)
# ============================================================
df_long <- df %>%
  # 转换为长表格，保留 time 列
  pivot_longer(
    cols = -time,
    names_to = "group",
    values_to = "value"
  ) %>%
  # 将列名（如 "Control_Rep1"）拆分为 "condition" 和 "replicate"
  separate(group, into = c("condition", "replicate"), sep = "_") %>%
  mutate(
    condition = recode(condition, Etoh = "vehicle", Auxin = "IAA"),
    condition = factor(condition, levels = c("vehicle", "IAA"))
  )

# ============================================================
# 4. 统计计算 (均值与标准差)
# ============================================================
# 用于绘制主图中的平均曲线和阴影面积 (Ribbon)
df_summary <- df_long %>%
  group_by(time, condition) %>%
  summarise(
    mean = mean(value),
    sd = sd(value),
    .groups = "drop"
  )

# ============================================================
# 5. 定义 Egress Time (计算事件触发点)
# ============================================================
threshold <- 50   # 设定阈值，当 Value 达到此值时视为发生 Egress

egress_df <- df_long %>%
  group_by(condition, replicate) %>%
  # 筛选每个样本首次超过阈视的时间点
  filter(value >= threshold) %>%
  summarise(egress_time = min(time), .groups = "drop")

# ============================================================
# 6. 单图压缩：动态曲线 + 每个重复的 egress time
# ============================================================
egress_marks <- egress_df %>%
  mutate(
    ymin = ifelse(condition == "vehicle", 3.5, 9.5),
    ymax = ifelse(condition == "vehicle", 7.5, 13.5)
  )

egress_median <- egress_df %>%
  group_by(condition) %>%
  summarise(
    median_egress = median(egress_time),
    .groups = "drop"
  ) %>%
  mutate(
    label = paste0(median_egress, " s"),
    label_x = median_egress + 3,
    label_y = ifelse(condition == "vehicle", 31, 41),
    label_hjust = 0
  )

format_p_value <- function(p_value) {
  if (is.na(p_value)) return("P = NA")
  if (p_value < 0.001) return("P < 0.001")
  paste0("P = ", formatC(p_value, format = "f", digits = 3))
}

format_p_stars <- function(p_value) {
  dplyr::case_when(
    is.na(p_value) ~ "NA",
    p_value < 0.001 ~ "***",
    p_value < 0.01 ~ "**",
    p_value < 0.05 ~ "*",
    TRUE ~ "ns"
  )
}

egress_t_test <- stats::t.test(egress_time ~ condition, data = egress_df)
median_range <- range(egress_median$median_egress)
stat_annotation <- tibble::tibble(
  x = median_range[[1]],
  xend = median_range[[2]],
  y = 20,
  label_x = mean(median_range),
  label_y = 25,
  label = paste(format_p_stars(egress_t_test$p.value), format_p_value(egress_t_test$p.value))
)

direct_labels <- tibble::tibble(
  condition = factor(c("vehicle", "IAA"), levels = c("vehicle", "IAA")),
  x = c(128, 128),
  y = c(96, 88),
  label = c("vehicle", "IAA")
)

p_compact <- ggplot() +
  geom_hline(
    yintercept = threshold,
    linewidth = ICAT_LINE_MM,
    linetype = "dashed",
    colour = "grey45"
  ) +
  annotate(
    "text",
    x = 4,
    y = threshold + 4,
    label = "50%",
    hjust = 0,
    size = ICAT_TEXT_SMALL_MM,
    colour = "grey30"
  ) +
  geom_line(
    data = df_long,
    aes(
      time,
      value,
      group = interaction(condition, replicate),
      color = condition
    ),
    alpha = 0.22,
    linewidth = replicate_line_width
  ) +
  geom_ribbon(
    data = df_summary,
    aes(time, ymin = pmax(mean - sd, 0), ymax = pmin(mean + sd, 100), fill = condition),
    alpha = 0.14,
    colour = NA
  ) +
  geom_line(
    data = df_summary,
    aes(time, mean, color = condition),
    linewidth = mean_line_width
  ) +
  geom_segment(
    data = egress_median,
    aes(
      x = median_egress,
      xend = median_egress,
      y = 14.5,
      yend = threshold,
      color = condition
    ),
    linewidth = ICAT_LINE_MM,
    linetype = "dotted"
  ) +
  geom_segment(
    data = egress_marks,
    aes(
      x = egress_time,
      xend = egress_time,
      y = ymin,
      yend = ymax,
      color = condition
    ),
    linewidth = max(ICAT_LINE_MM * 2.0, 0.35),
    lineend = "butt"
  ) +
  geom_segment(
    data = stat_annotation,
    aes(x = x, xend = xend, y = y, yend = y),
    inherit.aes = FALSE,
    linewidth = ICAT_LINE_MM,
    colour = "black"
  ) +
  geom_segment(
    data = stat_annotation,
    aes(x = x, xend = x, y = y, yend = y - 2.2),
    inherit.aes = FALSE,
    linewidth = ICAT_LINE_MM,
    colour = "black"
  ) +
  geom_segment(
    data = stat_annotation,
    aes(x = xend, xend = xend, y = y, yend = y - 2.2),
    inherit.aes = FALSE,
    linewidth = ICAT_LINE_MM,
    colour = "black"
  ) +
  geom_text(
    data = stat_annotation,
    aes(x = label_x, y = label_y, label = label),
    inherit.aes = FALSE,
    size = ICAT_TEXT_SMALL_MM,
    colour = "black"
  ) +
  geom_text(
    data = egress_median,
    aes(x = label_x, y = label_y, label = label, color = condition, hjust = label_hjust),
    size = ICAT_TEXT_SMALL_MM
  ) +
  geom_text(
    data = direct_labels,
    aes(x = x, y = y, label = label, color = condition),
    hjust = 0,
    size = ICAT_TEXT_BODY_MM
  ) +
  scale_color_manual(values = condition_palette, breaks = names(condition_palette)) +
  scale_fill_manual(values = condition_palette, breaks = names(condition_palette)) +
  scale_x_continuous(
    breaks = c(0, 50, 100, 150),
    expand = expansion(mult = c(0.01, 0.02))
  ) +
  scale_y_continuous(
    breaks = c(0, 50, 100),
    expand = expansion(mult = c(0.01, 0.02))
  ) +
  coord_cartesian(xlim = c(0, 158), ylim = c(0, 103)) +
  icat_theme_classic(base_family = "Arial") +
  theme(
    axis.text = element_text(size = ICAT_FONT_SMALL_PT, color = "black"),
    axis.title = element_text(size = ICAT_FONT_BODY_PT),
    axis.ticks.length = unit(1.0, "mm"),
    legend.position = "none",
    panel.background = element_rect(fill = "transparent", colour = NA),
    plot.background = element_rect(fill = "transparent", colour = NA),
    plot.margin = margin(0.4, 0.6, 0.4, 0.6)
  ) +
  labs(x = "Time (s)", y = "Egress (%)")

if (interactive()) print(p_compact)

figure_width_cm <- 5.2
figure_height_cm <- 3.5

ggsave(
  file.path(figure_dir, "Figure_panel.pdf"),
  p_compact,
  width = figure_width_cm / 2.54,
  height = figure_height_cm / 2.54,
  units = "in",
  device = grDevices::cairo_pdf,
  family = "Arial"
)

ggsave(
  file.path(figure_dir, "Figure_panel.png"),
  p_compact,
  bg = "transparent",
  device = ragg::agg_png,
  width = figure_width_cm / 2.54,
  height = figure_height_cm / 2.54,
  units = "in",
  dpi = 300
)
