#!/usr/bin/env Rscript

script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
script_path <- normalizePath(sub("^--file=", "", script_arg[[1]]), mustWork = TRUE)
fig_dir <- normalizePath(file.path(dirname(script_path), "..", ".."), mustWork = TRUE)
project_root <- normalizePath(file.path(fig_dir, ".."), mustWork = TRUE)
source(file.path(project_root, "shared", "R", "project_library.R"))
icat_activate_project_library(project_root)

suppressPackageStartupMessages({
  library(grid)
  library(ragg)
})

source(file.path(project_root, "shared", "R", "plot_style.R"))

figure_dir <- file.path(fig_dir, "04_results", "figures", "summary")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)

figure_width_cm <- 5.0
figure_height_cm <- 6.0

col_vehicle <- "#1F77B4"
col_iaa <- "#D62728"
col_icat <- "#159A9C"
col_mic2 <- "#9B7CF5"
col_secreted <- "#B48CF2"
col_grey <- "#9A9A9A"
col_light <- "#F5F5F5"
col_dark <- "#222222"
line_lwd <- ICAT_LINE_PT / ICAT_R_DEVICE_PT_PER_LWD
fs_panel <- ICAT_FONT_TITLE_PT
fs_title <- ICAT_FONT_SMALL_PT
fs_label <- 5.8
fs_small <- 5.2

npc <- function(x) unit(x, "npc")

rot_xy <- function(x, y, cx, cy, angle_deg) {
  angle <- angle_deg * pi / 180
  xr <- cx + (x - cx) * cos(angle) - (y - cy) * sin(angle)
  yr <- cy + (x - cx) * sin(angle) + (y - cy) * cos(angle)
  list(x = xr, y = yr)
}

ellipse_points <- function(cx, cy, rx, ry, angle_deg = 0, n = 120) {
  theta <- seq(0, 2 * pi, length.out = n)
  x <- cx + rx * cos(theta)
  y <- cy + ry * sin(theta)
  rot_xy(x, y, cx, cy, angle_deg)
}

draw_ellipse <- function(cx, cy, rx, ry, angle_deg = 0, fill, col, lwd = line_lwd, alpha = 1) {
  xy <- ellipse_points(cx, cy, rx, ry, angle_deg)
  grid.polygon(
    npc(xy$x), npc(xy$y),
    gp = gpar(fill = adjustcolor(fill, alpha.f = alpha), col = col, lwd = lwd)
  )
}

draw_parasite <- function(cx, cy, fill, angle_deg = -28) {
  theta <- seq(0, 2 * pi, length.out = 160)
  x <- cx + 0.075 * cos(theta) + 0.012 * cos(2 * theta)
  y <- cy + 0.030 * sin(theta) * (1 - 0.15 * cos(theta))
  xy <- rot_xy(x, y, cx, cy, angle_deg)
  grid.polygon(
    npc(xy$x), npc(xy$y),
    gp = gpar(fill = fill, col = adjustcolor(fill, 0.9), lwd = line_lwd)
  )
  head <- rot_xy(cx + 0.070, cy, cx, cy, angle_deg)
  grid.circle(npc(head$x), npc(head$y), r = npc(0.010), gp = gpar(fill = "white", col = NA, alpha = 0.85))
}

draw_micronemes <- function(cx, cy, angle_deg, n = 5, spread = 0.048, active = TRUE) {
  offsets <- seq(-0.5, 0.5, length.out = n) * spread
  for (i in seq_along(offsets)) {
    pos <- rot_xy(cx + 0.045 + i * 0.004, cy + offsets[i], cx, cy, angle_deg)
    draw_ellipse(
      pos$x, pos$y, 0.008, 0.0038, angle_deg + 8,
      fill = if (active) col_mic2 else "#C9C9C9",
      col = if (active) "#7D63C8" else "#B5B5B5",
      lwd = line_lwd * 0.65,
      alpha = if (active) 0.95 else 0.55
    )
  }
}

draw_conoid_route <- function(cx, cy, width = 0.34) {
  grid.curve(
    npc(cx - width / 2), npc(cy + 0.030), npc(cx + width / 2), npc(cy + 0.030),
    curvature = -0.22, angle = 90, ncp = 20,
    gp = gpar(col = "#A0A0A0", lwd = line_lwd * 1.25)
  )
  grid.curve(
    npc(cx - width / 2), npc(cy - 0.030), npc(cx + width / 2), npc(cy - 0.030),
    curvature = -0.22, angle = 90, ncp = 20,
    gp = gpar(col = "#A0A0A0", lwd = line_lwd * 1.25)
  )
}

draw_secretory_arrows <- function(cx, cy, angle_deg, n = 4, color = col_secreted, strong = TRUE) {
  for (i in seq_len(n)) {
    shift <- (i - (n + 1) / 2) * 0.012
    start <- rot_xy(cx + 0.070, cy + shift, cx, cy, angle_deg)
    end <- rot_xy(cx + 0.110, cy + shift, cx, cy, angle_deg)
    grid.segments(
      npc(start$x), npc(start$y), npc(end$x), npc(end$y),
      arrow = arrow(length = unit(1.1, "mm"), type = "closed"),
      gp = gpar(col = adjustcolor(color, alpha.f = if (strong) 0.95 else 0.45), lwd = line_lwd * if (strong) 1.2 else 0.8)
    )
  }
}

draw_icat_domain <- function() {
  y <- 0.875
  grid.text("ICAT", npc(0.50), npc(0.955), gp = gpar(fontfamily = "Arial", fontsize = fs_title, fontface = "bold", col = col_dark))
  grid.roundrect(npc(0.135), npc(y), width = npc(0.120), height = npc(0.050), r = unit(1.3, "mm"),
                 gp = gpar(fill = "white", col = col_vehicle, lwd = line_lwd))
  grid.text("Nter", npc(0.135), npc(y), gp = gpar(fontfamily = "Arial", fontsize = fs_label, col = col_dark))
  x <- seq(0.205, 0.795, length.out = 360)
  yy <- y + 0.020 * sin(seq(0, 24 * pi, length.out = 360))
  grid.lines(npc(x), npc(yy), gp = gpar(col = "#777777", lwd = line_lwd * 1.2))
  grid.roundrect(npc(0.865), npc(y), width = npc(0.120), height = npc(0.050), r = unit(1.3, "mm"),
                 gp = gpar(fill = "white", col = col_iaa, lwd = line_lwd))
  grid.text("Cter", npc(0.865), npc(y), gp = gpar(fontfamily = "Arial", fontsize = fs_label, col = col_dark))
}

draw_state_box <- function(x, y, label, color) {
  grid.roundrect(npc(x), npc(y), width = npc(0.33), height = npc(0.055), r = unit(1.4, "mm"),
                 gp = gpar(fill = adjustcolor(color, alpha.f = 0.08), col = color, lwd = line_lwd))
  grid.text(label, npc(x), npc(y), gp = gpar(fontfamily = "Arial", fontsize = fs_label, fontface = "bold", col = color))
}

draw_top_conoid_model <- function() {
  grid.text("MIC2+ microneme\nsecretion", npc(0.205), npc(0.890),
            gp = gpar(fontfamily = "Arial", fontsize = fs_label, col = col_secreted, lineheight = 0.92))
  grid.segments(npc(0.255), npc(0.812), npc(0.255), npc(0.865),
                arrow = arrow(length = unit(2.2, "mm"), type = "closed"),
                gp = gpar(col = col_secreted, lwd = line_lwd * 1.35))

  grid.lines(npc(c(0.055, 0.365)), npc(c(0.795, 0.802)), gp = gpar(col = "#D2D2D2", lwd = line_lwd))
  grid.lines(npc(c(0.055, 0.365)), npc(c(0.785, 0.790)), gp = gpar(col = "#D2D2D2", lwd = line_lwd))
  grid.text("apical plasma\nmembrane", npc(0.445), npc(0.795), just = "left",
            gp = gpar(fontfamily = "Arial", fontsize = fs_small, col = "#9B9B9B", lineheight = 0.95))

  grid.segments(npc(0.205), npc(0.805), npc(0.205), npc(0.525),
                gp = gpar(col = "#D7DDE3", lwd = line_lwd, lty = 2))
  grid.lines(npc(c(0.085, 0.040, 0.015, 0.060, 0.115)),
             npc(c(0.768, 0.565, 0.555, 0.760, 0.775)),
             gp = gpar(col = "#D0D0D0", lwd = line_lwd))
  grid.lines(npc(c(0.320, 0.372, 0.392, 0.350, 0.300)),
             npc(c(0.768, 0.565, 0.555, 0.758, 0.775)),
             gp = gpar(col = "#D0D0D0", lwd = line_lwd))
  grid.lines(npc(c(0.065, 0.140, 0.210, 0.285, 0.360)),
             npc(c(0.555, 0.545, 0.542, 0.548, 0.560)),
             gp = gpar(col = "#D0D0D0", lwd = line_lwd))

  draw_ellipse(0.238, 0.725, 0.020, 0.050, 0, fill = col_secreted, col = NA, alpha = 0.35)
  draw_ellipse(0.275, 0.625, 0.020, 0.045, 0, fill = col_secreted, col = NA, alpha = 0.35)

  for (y in c(0.720, 0.675, 0.620)) {
    grid.segments(npc(0.292), npc(y), npc(0.338), npc(y + 0.010),
                  gp = gpar(col = "#A5A5A5", lwd = line_lwd * 2.4, lineend = "round"))
    grid.segments(npc(0.334), npc(y + 0.010), npc(0.356), npc(y + 0.014),
                  gp = gpar(col = "#C9C57A", lwd = line_lwd * 2.4, lineend = "round"))
  }
  grid.text("ICAT region", npc(0.360), npc(0.520), just = "left",
            gp = gpar(fontfamily = "Arial", fontsize = fs_label, col = "#666666"))

  grid.text("conoid-proximal", npc(0.650), npc(0.665), just = "centre",
            gp = gpar(fontfamily = "Arial", fontsize = fs_small, col = "#C9C57A"))
  grid.roundrect(npc(0.710), npc(0.625), width = npc(0.300), height = npc(0.035), r = unit(0.2, "mm"),
                 gp = gpar(fill = "white", col = "#555555", lwd = line_lwd))
  grid.rect(npc(0.620), npc(0.625), width = npc(0.120), height = npc(0.035),
            gp = gpar(fill = "#D4D17E", col = NA))
  grid.rect(npc(0.770), npc(0.625), width = npc(0.180), height = npc(0.035),
            gp = gpar(fill = "#A6A6A6", col = NA))
  grid.text("supports MIC2+\nexit", npc(0.710), npc(0.560), just = "centre",
            gp = gpar(fontfamily = "Arial", fontsize = fs_small, col = "#8A8A8A", lineheight = 0.92))
}

draw_secretion_plume <- function(cx, cy, scale = 1, alpha = 0.75) {
  draw_ellipse(cx, cy + 0.112 * scale, 0.046 * scale, 0.082 * scale, 0,
               fill = col_mic2, col = "#9B73F2", lwd = line_lwd, alpha = alpha)
  draw_ellipse(cx, cy + 0.108 * scale, 0.032 * scale, 0.060 * scale, 0,
               fill = "#CDB7FF", col = NA, alpha = 0.65)
  draw_ellipse(cx, cy + 0.072 * scale, 0.020 * scale, 0.034 * scale, 0,
               fill = "#E4D8FF", col = NA, alpha = 0.70)
}

draw_secretion_scale <- function() {
  x0 <- 0.305
  widths <- rep(0.022, 5)
  cols <- c("#E8DAFF", "#D6BFFF", "#C49EFF", "#B27EFF", "#9B6AFF")
  for (i in seq_along(cols)) {
    grid.rect(npc(x0 + (i - 1) * widths[i]), npc(0.078),
              width = npc(widths[i]), height = npc(0.020),
              gp = gpar(fill = cols[i], col = NA))
  }
  grid.segments(npc(0.420), npc(0.078), npc(0.500), npc(0.078),
                arrow = arrow(length = unit(1.5, "mm"), type = "closed"),
                gp = gpar(col = col_dark, lwd = line_lwd))
  grid.text("time / secretion output", npc(0.500), npc(0.035),
            gp = gpar(fontfamily = "Arial", fontsize = fs_small, col = col_dark))
}

draw_panel <- function() {
  grid.newpage()
  grid.rect(gp = gpar(fill = "white", col = NA))
  grid.text("K", npc(0.035), npc(0.965), gp = gpar(fontfamily = "Arial", fontsize = fs_panel, fontface = "bold"))

  draw_top_conoid_model()
  grid.segments(npc(0.500), npc(0.495), npc(0.500), npc(0.455),
                arrow = arrow(length = unit(1.0, "mm"), type = "closed"),
                gp = gpar(col = "#B5B5B5", lwd = line_lwd))

  grid.text("ICAT present", npc(0.295), npc(0.430),
            gp = gpar(fontfamily = "Arial", fontsize = fs_label, col = col_vehicle))
  grid.text("ICAT depleted", npc(0.735), npc(0.430),
            gp = gpar(fontfamily = "Arial", fontsize = fs_label, col = col_iaa))

  draw_secretion_plume(0.335, 0.235, scale = 0.85, alpha = 0.85)
  draw_parasite(0.295, 0.198, col_vehicle, angle_deg = -36)
  draw_micronemes(0.295, 0.198, -36, n = 6, spread = 0.055, active = TRUE)
  grid.circle(npc(0.350), npc(0.237), r = npc(0.010), gp = gpar(fill = col_icat, col = NA))
  grid.text("high", npc(0.295), npc(0.122),
            gp = gpar(fontfamily = "Arial", fontsize = fs_small, col = col_vehicle, fontface = "bold"))

  draw_secretion_plume(0.765, 0.235, scale = 0.40, alpha = 0.72)
  draw_parasite(0.735, 0.198, col_iaa, angle_deg = -36)
  draw_micronemes(0.725, 0.178, -36, n = 4, spread = 0.060, active = FALSE)
  grid.circle(npc(0.790), npc(0.237), r = npc(0.010), gp = gpar(fill = "white", col = col_icat, lwd = line_lwd, lty = 2))
  grid.text("low", npc(0.735), npc(0.122),
            gp = gpar(fontfamily = "Arial", fontsize = fs_small, col = col_iaa, fontface = "bold"))

  draw_secretion_scale()
}

png_path <- file.path(figure_dir, "Fig4K_summary_schematic.png")
pdf_path <- file.path(figure_dir, "Fig4K_summary_schematic.pdf")
svg_path <- file.path(figure_dir, "Fig4K_summary_schematic.svg")

ragg::agg_png(
  png_path,
  width = figure_width_cm / 2.54,
  height = figure_height_cm / 2.54,
  units = "in",
  res = 600,
  bg = "transparent"
)
draw_panel()
dev.off()

grDevices::cairo_pdf(
  pdf_path,
  width = figure_width_cm / 2.54,
  height = figure_height_cm / 2.54,
  family = "Arial"
)
draw_panel()
dev.off()

grDevices::svg(
  svg_path,
  width = figure_width_cm / 2.54,
  height = figure_height_cm / 2.54,
  family = "Arial"
)
draw_panel()
dev.off()

if (interactive()) draw_panel()
