#!/usr/bin/env Rscript

script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
script_path <- normalizePath(sub("^--file=", "", script_arg[[1]]), mustWork = TRUE)
fig_dir <- normalizePath(file.path(dirname(script_path), "..", ".."), mustWork = TRUE)
project_root <- normalizePath(file.path(fig_dir, ".."), mustWork = TRUE)
source(file.path(project_root, "shared", "R", "project_library.R"))
icat_activate_project_library(project_root)
suppressPackageStartupMessages({
  library(grid)
  library(ragg)
  library(svglite)
})
source(file.path(project_root, "shared", "R", "plot_style.R"))

# Keep the observed phenotype distinct from the positioning hypothesis.
figure_dir <- file.path(fig_dir, "04_results", "figures", "summary")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
figure_width_cm <- 5.6
figure_height_cm <- 8.6
col_vehicle <- "#1F77B4"
col_iaa <- "#D62728"
col_microneme <- "#AC83DE"
col_microneme_light <- "#D5BEEE"
col_ts <- "#D3CD85"
col_ts_text <- "#807928"
col_sequence <- "#8F9397"
col_structure <- "#8C9398"
col_dark <- "#25292C"
col_muted <- "#626A70"
line_lwd <- ICAT_LINE_PT / ICAT_R_DEVICE_PT_PER_LWD
npc <- function(x) unit(x, "npc")

label <- function(text, x, y, size = ICAT_FONT_SMALL_PT, col = col_dark,
                  just = "centre", bold = FALSE) {
  grid.text(text, npc(x), npc(y), just = just,
            gp = gpar(fontfamily = "Arial", fontsize = size, col = col,
                      fontface = if (bold) "bold" else "plain", lineheight = 1.05))
}

stroke <- function(x, y, col = col_structure, dashed = FALSE) {
  grid.lines(npc(x), npc(y),
             gp = gpar(col = col, lwd = line_lwd, lty = if (dashed) 2 else 1,
                       lineend = "round", linejoin = "round"))
}

ellipse <- function(x, y, rx, ry, angle = 0, fill = col_microneme_light,
                    outline = NA) {
  theta <- seq(0, 2 * pi, length.out = 100)
  px <- rx * cos(theta)
  py <- ry * sin(theta)
  radians <- angle * pi / 180
  grid.polygon(npc(x + px * cos(radians) - py * sin(radians)),
               npc(y + px * sin(radians) + py * cos(radians)),
               gp = gpar(fill = fill, col = outline, lwd = line_lwd))
}

secretion_arrow <- function(x, y0, y1, width) {
  head_width <- max(width * 2.2, 0.024)
  head_height <- 0.018
  grid.polygon(npc(x + c(-width / 2, width / 2, width / 2,
                         head_width / 2, 0, -head_width / 2, -width / 2)),
               npc(c(y0, y0, y1 - head_height, y1 - head_height,
                     y1, y1 - head_height, y1 - head_height)),
               gp = gpar(fill = col_microneme, col = NA))
}

draw_apical_model <- function() {
  label("Secretion", 0.23, 0.540, col = col_microneme)
  secretion_arrow(0.23, 0.475, 0.515, 0.014)
  stroke(c(0.085, 0.22, 0.35, 0.425), c(0.466, 0.472, 0.472, 0.468))
  stroke(c(0.085, 0.22, 0.35, 0.425), c(0.455, 0.461, 0.461, 0.457))
  label("Apical plasma\nmembrane", 0.52, 0.470, col = col_muted, just = "left")
  stroke(c(0.43, 0.49), c(0.466, 0.466), col = col_muted)

  stroke(c(0.146, 0.088, 0.064), c(0.445, 0.275, 0.258))
  stroke(c(0.171, 0.110, 0.086), c(0.448, 0.279, 0.263))
  stroke(c(0.342, 0.402, 0.427), c(0.445, 0.275, 0.258))
  stroke(c(0.317, 0.378, 0.402), c(0.448, 0.279, 0.263))
  grid.xspline(npc(c(0.064, 0.15, 0.245, 0.34, 0.427)),
                npc(c(0.258, 0.243, 0.237, 0.243, 0.258)),
                shape = c(0, 1, 1, 1, 0), open = TRUE,
                gp = gpar(col = col_structure, lwd = line_lwd))
  ellipse(0.237, 0.396, 0.019, 0.033)
  ellipse(0.268, 0.298, 0.019, 0.033)
  for (y in c(0.402, 0.354, 0.306)) {
    patch_x <- 0.342 + (0.402 - y) * 0.29
    grid.segments(npc(patch_x - 0.029), npc(y), npc(patch_x), npc(y + 0.004),
                  gp = gpar(col = col_sequence, lwd = line_lwd * 2.6,
                            lineend = "round"))
    grid.segments(npc(patch_x), npc(y + 0.004), npc(patch_x + 0.012), npc(y + 0.006),
                  gp = gpar(col = col_ts, lwd = line_lwd * 2.6,
                            lineend = "round"))
  }
  bar_x <- 0.52
  bar_width <- 0.39
  ts_width <- bar_width * 491 / 3168
  grid.rect(npc(bar_x), npc(0.360), npc(ts_width), npc(0.023), just = "left",
            gp = gpar(fill = col_ts, col = NA))
  grid.rect(npc(bar_x + ts_width), npc(0.360), npc(bar_width - ts_width),
            npc(0.023), just = "left", gp = gpar(fill = col_sequence, col = NA))
  grid.rect(npc(bar_x), npc(0.360), npc(bar_width), npc(0.023), just = "left",
            gp = gpar(fill = NA, col = col_muted, lwd = line_lwd))
  label("Conoid-facing", 0.52, 0.409, just = "left", col = col_ts_text)
  stroke(c(bar_x + ts_width / 2, bar_x + ts_width / 2), c(0.376, 0.392),
         col = col_ts_text)
  label("Microneme-facing", 0.735, 0.307, col = col_muted)
  stroke(c(0.78, 0.78), c(0.343, 0.328), col = col_muted)

  stroke(c(0.375, 0.448, 0.785, 0.785),
         c(0.310, 0.250, 0.250, 0.222), col = col_muted)
  label("ICAT\npatch", 0.785, 0.176, size = ICAT_FONT_BODY_PT)
  label("Microneme pathway\norganization", 0.275, 0.176)
  # This question is the bridge to Fig. 5, rather than an established mechanism.
  grid.segments(npc(0.665), npc(0.176), npc(0.525), npc(0.176),
                arrow = arrow(length = unit(1.5, "mm"), type = "closed"),
                gp = gpar(col = col_muted, fill = col_muted,
                          lwd = line_lwd, lty = 2))
  label("?", 0.595, 0.210, col = col_iaa, size = ICAT_FONT_BODY_PT, bold = TRUE)
}

draw_parasite <- function(dx, fill, y_offset = 0) {
  t <- seq(0, 1, length.out = 70)
  bezier <- function(p0, p1, p2, p3) {
    (1 - t)^3 * p0 + 3 * (1 - t)^2 * t * p1 +
      3 * (1 - t) * t^2 * p2 + t^3 * p3
  }
  x <- c(bezier(0.302, 0.379, 0.277, 0.136),
         bezier(0.136, 0.035, 0.245, 0.302)) + dx
  y <- c(bezier(0.273, 0.194, 0.115, 0.122),
         bezier(0.122, 0.151, 0.202, 0.273)) + y_offset
  grid.polygon(npc(x), npc(y), gp = gpar(fill = fill, col = col_structure,
                                       lwd = line_lwd))
  ellipse(0.303 + dx, 0.269 + y_offset, 0.012, 0.004, fill = "#F1EEF5",
          outline = col_structure)
  organelles <- data.frame(x = c(0.280, 0.290, 0.300, 0.310),
                          y = c(0.218, 0.226, 0.232, 0.235),
                          angle = c(-28, -14, 4, 22))
  for (i in seq_len(nrow(organelles))) {
    ellipse(organelles$x[i] + dx, organelles$y[i] + y_offset, 0.0045, 0.016,
            angle = organelles$angle[i], fill = "#D6C3E8")
  }
}

draw_panel <- function() {
  grid.newpage()
  grid.rect(gp = gpar(fill = "white", col = NA))
  label("k", 0.025, 0.973, size = ICAT_FONT_TITLE_PT, just = "left", bold = TRUE)
  label("ICAT present", 0.255, 0.920, size = ICAT_FONT_BODY_PT, col = col_vehicle)
  label("ICAT depleted", 0.750, 0.920, size = ICAT_FONT_BODY_PT, col = col_iaa)
  label("High", 0.302, 0.868, col = col_vehicle)
  label("Low", 0.792, 0.868, col = col_iaa)
  label("Secretion", 0.525, 0.820, col = col_muted)
  draw_parasite(0, adjustcolor(col_vehicle, alpha.f = 0.68), y_offset = 0.50)
  draw_parasite(0.49, adjustcolor(col_iaa, alpha.f = 0.68), y_offset = 0.50)
  secretion_arrow(0.302, 0.777, 0.842, width = 0.025)
  secretion_arrow(0.792, 0.777, 0.812, width = 0.009)

  grid.rect(npc(0.302), npc(0.773), npc(0.075), npc(0.055),
            gp = gpar(fill = NA, col = col_muted, lwd = line_lwd))
  # A single leader avoids crossing the other parasite with a magnification wedge.
  stroke(c(0.2645, 0.060, 0.060, 0.045),
         c(0.8005, 0.8005, 0.595, 0.580), col = col_muted)
  grid.rect(npc(0.50), npc(0.330), npc(0.91), npc(0.500),
            gp = gpar(fill = "white", col = col_muted, lwd = line_lwd))
  draw_apical_model()
}

prefix <- file.path(figure_dir, "Fig4K_summary_revised")
ragg::agg_png(paste0(prefix, ".png"), width = figure_width_cm,
              height = figure_height_cm, units = "cm", res = 600, background = "white")
draw_panel()
invisible(dev.off())
grDevices::cairo_pdf(paste0(prefix, ".pdf"), width = figure_width_cm / 2.54,
                     height = figure_height_cm / 2.54, family = "Arial")
draw_panel()
invisible(dev.off())
svglite::svglite(paste0(prefix, ".svg"), width = figure_width_cm / 2.54,
                 height = figure_height_cm / 2.54, bg = "white")
draw_panel()
invisible(dev.off())
if (interactive()) draw_panel()
