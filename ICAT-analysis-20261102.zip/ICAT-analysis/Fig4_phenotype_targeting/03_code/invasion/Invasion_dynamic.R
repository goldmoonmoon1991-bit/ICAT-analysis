# ============================================================
# Unified ICAT style: invasion dynamics
# ============================================================
script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
script_path <- normalizePath(sub("^--file=", "", script_arg[[1]]), mustWork = TRUE)
fig_dir <- normalizePath(file.path(dirname(script_path), "..", ".."), mustWork = TRUE)
project_root <- normalizePath(file.path(fig_dir, ".."), mustWork = TRUE)
source(file.path(project_root, "shared", "R", "project_library.R"))
icat_activate_project_library(project_root)

library(ggplot2)
library(dplyr)
library(tidyr)
library(stringr)
library(scales)
library(ggpubr)
library(rstatix)

source(file.path(project_root, "shared", "R", "plot_style.R"))
input_path <- file.path(fig_dir, "01_raw_data", "invasion", "Invasion_dynamic.csv")
figure_dir <- file.path(fig_dir, "04_results", "figures", "invasion")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)

# 1. 数据处理
df <- read.csv(input_path, check.names = FALSE)
colnames(df)[1] <- "time_raw"

df_long <- df %>%
  mutate(time = as.numeric(str_extract(time_raw, "\\d+"))) %>%
  select(-time_raw) %>%
  pivot_longer(cols = -time, names_to = "group_rep", values_to = "rate") %>%
  separate(group_rep, into = c("Condition", "Replicate"), sep = "-")

df_summary <- df_long %>%
  group_by(time, Condition) %>%
  summarise(mean_rate = mean(rate), sd_rate = sd(rate), .groups = "drop")

df_long <- df_long %>%
  mutate(
    Condition = factor(Condition, levels = c("vehicle", "IAA"))
  )

df_summary <- df_summary %>%
  mutate(
    Condition = factor(Condition, levels = c("vehicle", "IAA"))
  )

# 2. 统计分析：解决错位的核心步骤
stat_results <- df_long %>%
  group_by(time) %>%
  t_test(rate ~ Condition) %>%
  add_significance() %>%
  add_xy_position(x = "time", step.increase = 0) %>%
  # 手动抬高 Y 轴起始位置，避免星号撞到误差线
  mutate(y.position = y.position + 0.1)

# 3. 绘图
p1 <- ggplot(df_summary, aes(x = time, y = mean_rate, color = Condition, group = Condition)) +
  geom_errorbar(aes(ymin = mean_rate - sd_rate, ymax = mean_rate + sd_rate),
                width = 1.2, linewidth = ICAT_LINE_MM, alpha = 0.9) +
  geom_line(linewidth = ICAT_LINE_MM) +
  geom_point(size = 2.2) +
  stat_pvalue_manual(
    stat_results,
    x = "time",             # 显式指定 x 为 time 变量，防止全部挤到左侧
    label = "p.signif",
    hide.ns = FALSE,
    tip.length = 0,
    remove.bracket = TRUE,
    size = ICAT_TEXT_SMALL_MM,
    vjust = 1
  ) +
  scale_color_manual(values = c("vehicle" = "#1F77B4", "IAA" = "#D62728")) +
  scale_x_continuous(
    breaks = c(2, 5, 10, 30, 60),
    limits = c(0, 61),
    guide = guide_axis(n.dodge = 2)
  ) +
  scale_y_continuous(
    labels = scales::label_number(scale = 100),
    limits = c(0, 1),
    expand = expansion(mult = c(0, 0.1))
  ) +
  icat_theme_classic(base_family = "Arial") +
  theme(
    axis.text = element_text(color = "black", size = ICAT_FONT_SMALL_PT),
    axis.title = element_text(size = ICAT_FONT_BODY_PT),
    axis.ticks.length = unit(1.0, "mm"),
    legend.position = "top",
    legend.justification = "center",
    legend.title = element_blank(),
    legend.direction = "horizontal",
    legend.text = element_text(size = ICAT_FONT_SMALL_PT),
    legend.key.width = unit(3.5, "mm"),
    legend.spacing.x = unit(0.8, "mm"),
    legend.box.spacing = unit(0, "mm"),
    legend.margin = margin(0, 0, 0, 0),
    plot.margin = margin(0.6, 1.2, 0.8, 1.0)
  ) +
  labs(x = "Time (min)", y = "Invasion (%)")

# 4. 保存
ggsave(file.path(figure_dir, "Invasion_Dynamic_Final.png"),
       plot = p1, width = 5 / 2.54, height = 4.1 / 2.54, units = "in", dpi = 300,
       device = ragg::agg_png, bg = "transparent")

ggsave(file.path(figure_dir, "Invasion_Dynamic.pdf"),
       plot = p1,
       width = 5 / 2.54,
       height = 4.1 / 2.54,
       units = "in",
       device = grDevices::cairo_pdf,
       family = "Arial")

if (interactive()) print(p1)
