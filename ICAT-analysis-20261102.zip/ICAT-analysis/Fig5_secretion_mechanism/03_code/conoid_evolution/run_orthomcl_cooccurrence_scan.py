#!/usr/bin/env python3
"""
Scan Toxoplasma gondii ME49 genes for OrthoMCL co-occurrence patterns
similar to ICAT (TGME49_252880).

The script uses public ToxoDB/OrthoMCL WDK service endpoints:
- ToxoDB gene search: ME49 gene list and product annotation
- OrthoMCL sequence search: taxon-specific protein -> orthogroup mapping

Output files are written to the organized OrthoMCL result directory.
"""

from __future__ import annotations

import csv
import json
import math
import time
import urllib.error
import urllib.request
from collections import defaultdict
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "04_results" / "tables" / "conoid_evolution" / "orthomcl_cooccurrence"

TOXODB_GENE_REPORT = (
    "https://toxodb.org/toxo/service/record-types/gene/"
    "searches/GenesByTaxonGene/reports/standard"
)
ORTHOMCL_SEQUENCE_REPORT = (
    "https://orthomcl.org/orthomcl/service/record-types/sequence/"
    "searches/ByTaxonomy/reports/standard"
)

ICAT_GENE_ID = "TGME49_252880"

MODULE_SEED_GENES = {
    "ICAT": "TGME49_252880",
    "ICMAP1": "TGME49_239300",
    "ICMAP2": "TGME49_224700",
    "ICMAP3": "TGME49_500200",
}

# Species groups used for the current conoid/ICMT/ICAT evolutionary table.
# Multiple OrthoMCL taxa are collapsed to a single species-level presence call.
TARGET_SPECIES = [
    ("Babesia bovis", ["bbov"]),
    ("Theileria annulata", ["tann"]),
    ("Plasmodium falciparum", ["pfal"]),
    ("Cryptosporidium parvum", ["cpar"]),
    ("Toxoplasma gondii", ["tgon"]),
    ("Neospora caninum", ["ncan", "nclv"]),
    ("Hammondia hammondi", ["hhhh"]),
    ("Eimeria tenella", ["eten", "etht"]),
    ("Sarcocystis neurona", ["sneu", "snsn"]),
    ("Besnoitia besnoiti", ["bbes"]),
    ("Cystoisospora suis", ["csui"]),
]


def post_json(url: str, payload: dict[str, Any], attempts: int = 3) -> dict[str, Any]:
    body = json.dumps(payload).encode("utf-8")
    request = urllib.request.Request(
        url,
        data=body,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    last_error: Exception | None = None
    for attempt in range(1, attempts + 1):
        try:
            with urllib.request.urlopen(request, timeout=120) as response:
                return json.load(response)
        except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as exc:
            last_error = exc
            if attempt < attempts:
                time.sleep(2 * attempt)
    raise RuntimeError(f"POST failed for {url}: {last_error}")


def get_attr(record: dict[str, Any], name: str, default: Any = "") -> Any:
    return record.get("attributes", {}).get(name, default)


def group_id_from_link(value: Any) -> str:
    if isinstance(value, dict):
        return value.get("displayText", "") or value.get("url", "").rstrip("/").split("/")[-1]
    if isinstance(value, str):
        return value
    return ""


def clean_gene_id(sequence_id: str) -> str:
    return sequence_id.split("|", 1)[1] if "|" in sequence_id else sequence_id


def fetch_toxodb_me49_genes() -> dict[str, dict[str, str]]:
    payload = {
        "searchConfig": {"parameters": {"organism": "Toxoplasma gondii ME49"}},
        "reportConfig": {"attributes": ["primary_key", "organism", "product"]},
    }
    data = post_json(TOXODB_GENE_REPORT, payload)
    genes: dict[str, dict[str, str]] = {}
    for record in data.get("records", []):
        gene_id = get_attr(record, "primary_key")
        if not gene_id:
            continue
        genes[gene_id] = {
            "gene_id": gene_id,
            "product": get_attr(record, "product"),
            "organism": get_attr(record, "organism"),
        }
    return genes


def fetch_orthomcl_taxon_sequences(taxon_abbrev: str) -> list[dict[str, str]]:
    payload = {
        "searchConfig": {"parameters": {"taxon_type_ahead": taxon_abbrev}},
        "reportConfig": {
            "attributes": [
                "primary_key",
                "taxon_name",
                "product",
                "length",
                "group_link",
            ]
        },
    }
    data = post_json(ORTHOMCL_SEQUENCE_REPORT, payload)
    rows: list[dict[str, str]] = []
    for record in data.get("records", []):
        sequence_id = get_attr(record, "primary_key")
        group_id = group_id_from_link(get_attr(record, "group_link"))
        if not sequence_id:
            continue
        rows.append(
            {
                "taxon_abbrev": taxon_abbrev,
                "sequence_id": sequence_id,
                "gene_id": clean_gene_id(sequence_id),
                "orthogroup": group_id,
                "taxon_name": get_attr(record, "taxon_name"),
                "product": get_attr(record, "product"),
                "length": str(get_attr(record, "length")),
            }
        )
    return rows


def jaccard(a: list[int], b: list[int]) -> float:
    inter = sum(1 for x, y in zip(a, b) if x and y)
    union = sum(1 for x, y in zip(a, b) if x or y)
    return inter / union if union else float("nan")


def cosine(a: list[int], b: list[int]) -> float:
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(y * y for y in b))
    return dot / (norm_a * norm_b) if norm_a and norm_b else float("nan")


def product_text(row: dict[str, Any]) -> str:
    return (row.get("toxodb_product") or row.get("orthomcl_product") or "").strip()


def has_informative_annotation(row: dict[str, Any]) -> bool:
    product = product_text(row).lower()
    uninformative = {
        "",
        "unknown",
        "hypothetical protein",
        "conserved hypothetical protein",
        "hypothetical protein, conserved",
    }
    return product not in uninformative


CELL_BIOLOGY_KEYWORDS = [
    "apical",
    "conoid",
    "microneme",
    "rhoptry",
    "dense granule",
    "gra",
    "imc",
    "inner membrane",
    "alveolin",
    "morn",
    "myosin",
    "actin",
    "tubulin",
    "kinesin",
    "dynein",
    "armadillo",
    "ankyrin",
    "wd",
    "coiled",
    "secret",
    "vesicle",
    "membrane",
    "palmitoyl",
    "acyl",
    "calcium",
    "kinase",
    "phosphatase",
    "g protein",
    "rab",
    "small gtpase",
    "isp",
    "isap",
    "glideosome",
]


def has_cell_biology_keyword(row: dict[str, Any]) -> bool:
    product = product_text(row).lower()
    return any(keyword in product for keyword in CELL_BIOLOGY_KEYWORDS)


def pattern_to_vector(pattern: str) -> list[int]:
    return [int(char) for char in pattern]


def vector_to_pattern(vector: list[int]) -> str:
    return "".join(str(x) for x in vector)


def hamming_distance(a: list[int], b: list[int]) -> int:
    return sum(1 for x, y in zip(a, b) if x != y)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)

    species_by_taxon = {
        taxon: species for species, taxa in TARGET_SPECIES for taxon in taxa
    }
    species_names = [species for species, _taxa in TARGET_SPECIES]

    genes = fetch_toxodb_me49_genes()

    all_sequence_rows: list[dict[str, str]] = []
    for _species, taxa in TARGET_SPECIES:
        for taxon in taxa:
            rows = fetch_orthomcl_taxon_sequences(taxon)
            all_sequence_rows.extend(rows)
            time.sleep(0.2)

    with (OUT / "target_taxa.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["species", "orthomcl_taxa"])
        for species, taxa in TARGET_SPECIES:
            writer.writerow([species, ";".join(taxa)])

    with (OUT / "taxon_sequence_orthogroups.csv").open("w", newline="") as handle:
        fields = [
            "taxon_abbrev",
            "species",
            "sequence_id",
            "gene_id",
            "orthogroup",
            "taxon_name",
            "product",
            "length",
        ]
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in all_sequence_rows:
            out = dict(row)
            out["species"] = species_by_taxon[row["taxon_abbrev"]]
            writer.writerow(out)

    # orthogroup -> species -> sequence IDs
    group_species_sequences: dict[str, dict[str, set[str]]] = defaultdict(lambda: defaultdict(set))
    # TGME49 gene -> orthogroup/product from OrthoMCL
    tgon_gene_groups: dict[str, set[str]] = defaultdict(set)
    tgon_orthomcl_product: dict[str, str] = {}

    for row in all_sequence_rows:
        group_id = row["orthogroup"]
        if not group_id:
            continue
        species = species_by_taxon[row["taxon_abbrev"]]
        group_species_sequences[group_id][species].add(row["sequence_id"])
        if row["taxon_abbrev"] == "tgon":
            tgon_gene_groups[row["gene_id"]].add(group_id)
            tgon_orthomcl_product[row["gene_id"]] = row["product"]

    icat_groups = sorted(tgon_gene_groups.get(ICAT_GENE_ID, []))
    if not icat_groups:
        raise RuntimeError(f"Could not find ICAT gene {ICAT_GENE_ID} in OrthoMCL tgon mapping.")

    # If a gene maps to multiple groups, union the species presence calls.
    target_vector = [
        int(any(species in group_species_sequences[group] for group in icat_groups))
        for species in species_names
    ]

    scan_rows: list[dict[str, Any]] = []
    for gene_id, annotation in sorted(genes.items()):
        groups = sorted(tgon_gene_groups.get(gene_id, []))
        vector = [
            int(any(species in group_species_sequences[group] for group in groups))
            for species in species_names
        ]
        distance_to_icat = hamming_distance(vector, target_vector)
        present_species = [species for species, value in zip(species_names, vector) if value]
        shared_present = [
            species for species, x, y in zip(species_names, vector, target_vector) if x and y
        ]
        row = {
            "gene_id": gene_id,
            "orthogroups": ";".join(groups),
            "toxodb_product": annotation.get("product", ""),
            "orthomcl_product": tgon_orthomcl_product.get(gene_id, ""),
            "hamming_to_ICAT": distance_to_icat,
            "jaccard_to_ICAT": f"{jaccard(vector, target_vector):.4f}",
            "cosine_to_ICAT": f"{cosine(vector, target_vector):.4f}",
            "present_species_count": sum(vector),
            "shared_ICAT_present_count": len(shared_present),
            "exact_ICAT_pattern": int(vector == target_vector),
            "species_pattern": "".join(str(x) for x in vector),
            "present_species": ";".join(present_species),
        }
        for species, value in zip(species_names, vector):
            row[species] = value
        scan_rows.append(row)

    sort_key = lambda r: (
        int(r["hamming_to_ICAT"]),
        -float(r["jaccard_to_ICAT"]),
        -float(r["cosine_to_ICAT"]),
        r["gene_id"],
    )
    scan_rows.sort(key=sort_key)

    result_fields = [
        "gene_id",
        "orthogroups",
        "toxodb_product",
        "orthomcl_product",
        "hamming_to_ICAT",
        "jaccard_to_ICAT",
        "cosine_to_ICAT",
        "present_species_count",
        "shared_ICAT_present_count",
        "exact_ICAT_pattern",
        "species_pattern",
        "present_species",
    ] + species_names

    full_scan = OUT / "tgon_gene_orthogroup_cooccurrence_scan.csv"
    with full_scan.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=result_fields)
        writer.writeheader()
        writer.writerows(scan_rows)

    top_hits = OUT / "top_ICAT_like_genes.csv"
    with top_hits.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=result_fields)
        writer.writeheader()
        writer.writerows(scan_rows[:200])

    exact_hits = [r for r in scan_rows if r["exact_ICAT_pattern"] == 1]
    strong_hits = [r for r in scan_rows if int(r["hamming_to_ICAT"]) <= 1]
    annotated_exact_hits = [r for r in exact_hits if has_informative_annotation(r)]
    keyword_exact_hits = [r for r in exact_hits if has_cell_biology_keyword(r)]

    filtered_outputs = {
        "exact_ICAT_pattern_genes": OUT / "exact_ICAT_pattern_genes.csv",
        "exact_ICAT_pattern_annotated_genes": OUT
        / "exact_ICAT_pattern_annotated_genes.csv",
        "exact_ICAT_pattern_cell_biology_keyword_hits": OUT
        / "exact_ICAT_pattern_cell_biology_keyword_hits.csv",
        "priority_ICAT_like_shortlist": OUT / "priority_ICAT_like_shortlist.csv",
    }
    for path, rows in [
        (filtered_outputs["exact_ICAT_pattern_genes"], exact_hits),
        (filtered_outputs["exact_ICAT_pattern_annotated_genes"], annotated_exact_hits),
        (filtered_outputs["exact_ICAT_pattern_cell_biology_keyword_hits"], keyword_exact_hits),
    ]:
        with path.open("w", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=result_fields)
            writer.writeheader()
            writer.writerows(rows)

    priority: list[tuple[int, str, dict[str, Any]]] = []
    for row in exact_hits:
        score = 0
        if row["gene_id"] == ICAT_GENE_ID:
            score -= 100
        if has_cell_biology_keyword(row):
            score -= 10
        if has_informative_annotation(row):
            score -= 3
        low_info = product_text(row).lower()
        if "hypothetical" in low_info or low_info == "unknown":
            score += 1
        priority.append((score, row["gene_id"], row))
    priority.sort()
    with filtered_outputs["priority_ICAT_like_shortlist"].open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=result_fields)
        writer.writeheader()
        writer.writerows([row for _score, _gene_id, row in priority[:100]])

    mapped_genes = sum(1 for _gene, groups in tgon_gene_groups.items() if groups)

    summary = {
        "seed_gene": ICAT_GENE_ID,
        "seed_orthogroups": icat_groups,
        "species_order": species_names,
        "seed_pattern": "".join(str(x) for x in target_vector),
        "seed_present_species": [
            species for species, value in zip(species_names, target_vector) if value
        ],
        "toxodb_me49_gene_count": len(genes),
        "tgon_genes_with_orthomcl_group": mapped_genes,
        "sequence_rows_downloaded": len(all_sequence_rows),
        "orthogroups_in_target_taxa": len(group_species_sequences),
        "exact_ICAT_pattern_gene_count": len(exact_hits),
        "hamming_le_1_gene_count": len(strong_hits),
        "annotated_exact_ICAT_pattern_gene_count": len(annotated_exact_hits),
        "cell_biology_keyword_exact_ICAT_pattern_gene_count": len(keyword_exact_hits),
        "outputs": {
            "full_scan": str(full_scan),
            "top_hits": str(top_hits),
            "target_taxa": str(OUT / "target_taxa.csv"),
            "taxon_sequence_orthogroups": str(OUT / "taxon_sequence_orthogroups.csv"),
            **{name: str(path) for name, path in filtered_outputs.items()},
        },
    }
    (OUT / "cooccurrence_scan_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )

    rows_by_gene = {row["gene_id"]: row for row in scan_rows}
    missing_module_seeds = [
        name for name, gene_id in MODULE_SEED_GENES.items() if gene_id not in rows_by_gene
    ]
    if missing_module_seeds:
        raise RuntimeError(f"Missing module seed genes in scan output: {missing_module_seeds}")

    module_seed_vectors = {
        name: pattern_to_vector(rows_by_gene[gene_id]["species_pattern"])
        for name, gene_id in MODULE_SEED_GENES.items()
    }
    module_seed_rows = []
    for name, gene_id in MODULE_SEED_GENES.items():
        row = rows_by_gene[gene_id]
        module_seed_rows.append(
            {
                "seed_name": name,
                "gene_id": gene_id,
                "orthogroups": row["orthogroups"],
                "product": row["toxodb_product"] or row["orthomcl_product"],
                "species_pattern": row["species_pattern"],
                "present_species": row["present_species"],
            }
        )

    n_seeds = len(module_seed_vectors)
    seed_matrix = list(module_seed_vectors.values())
    module_union = [int(any(v[i] for v in seed_matrix)) for i in range(len(species_names))]
    module_intersection = [
        int(all(v[i] for v in seed_matrix)) for i in range(len(species_names))
    ]
    module_majority = [
        int(sum(v[i] for v in seed_matrix) >= math.ceil(n_seeds / 2))
        for i in range(len(species_names))
    ]

    module_fields = [
        "gene_id",
        "orthogroups",
        "toxodb_product",
        "orthomcl_product",
        "module_mean_jaccard",
        "module_min_jaccard",
        "module_mean_cosine",
        "module_mean_hamming",
        "hamming_to_module_majority",
        "hamming_to_module_union",
        "hamming_to_module_intersection",
        "matches_module_majority",
        "matches_module_union",
        "matches_module_intersection",
        "species_pattern",
        "present_species",
    ] + species_names

    module_rows: list[dict[str, Any]] = []
    for row in scan_rows:
        vector = pattern_to_vector(row["species_pattern"])
        jaccards = [jaccard(vector, seed_vector) for seed_vector in seed_matrix]
        cosines = [cosine(vector, seed_vector) for seed_vector in seed_matrix]
        hammings = [hamming_distance(vector, seed_vector) for seed_vector in seed_matrix]
        module_row = {
            "gene_id": row["gene_id"],
            "orthogroups": row["orthogroups"],
            "toxodb_product": row["toxodb_product"],
            "orthomcl_product": row["orthomcl_product"],
            "module_mean_jaccard": f"{sum(jaccards) / len(jaccards):.4f}",
            "module_min_jaccard": f"{min(jaccards):.4f}",
            "module_mean_cosine": f"{sum(cosines) / len(cosines):.4f}",
            "module_mean_hamming": f"{sum(hammings) / len(hammings):.2f}",
            "hamming_to_module_majority": hamming_distance(vector, module_majority),
            "hamming_to_module_union": hamming_distance(vector, module_union),
            "hamming_to_module_intersection": hamming_distance(
                vector, module_intersection
            ),
            "matches_module_majority": int(vector == module_majority),
            "matches_module_union": int(vector == module_union),
            "matches_module_intersection": int(vector == module_intersection),
            "species_pattern": row["species_pattern"],
            "present_species": row["present_species"],
        }
        for species in species_names:
            module_row[species] = row[species]
        module_rows.append(module_row)

    module_rows.sort(
        key=lambda r: (
            -float(r["module_mean_jaccard"]),
            -float(r["module_min_jaccard"]),
            float(r["module_mean_hamming"]),
            int(r["hamming_to_module_majority"]),
            r["gene_id"],
        )
    )

    module_scan = OUT / "ICAT_ICMAP_module_cooccurrence_scan.csv"
    with module_scan.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=module_fields)
        writer.writeheader()
        writer.writerows(module_rows)

    module_top = OUT / "top_ICAT_ICMAP_module_like_genes.csv"
    with module_top.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=module_fields)
        writer.writeheader()
        writer.writerows(module_rows[:300])

    module_majority_hits = [
        row for row in module_rows if row["matches_module_majority"] == 1
    ]
    module_union_hits = [row for row in module_rows if row["matches_module_union"] == 1]
    module_intersection_hits = [
        row for row in module_rows if row["matches_module_intersection"] == 1
    ]
    for path, rows in [
        (OUT / "exact_ICAT_ICMAP_module_majority_pattern_genes.csv", module_majority_hits),
        (OUT / "exact_ICAT_ICMAP_module_union_pattern_genes.csv", module_union_hits),
        (
            OUT / "exact_ICAT_ICMAP_module_intersection_pattern_genes.csv",
            module_intersection_hits,
        ),
    ]:
        with path.open("w", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=module_fields)
            writer.writeheader()
            writer.writerows(rows)

    module_summary = {
        "module_seed_genes": MODULE_SEED_GENES,
        "module_seed_rows": module_seed_rows,
        "species_order": species_names,
        "module_union_pattern": vector_to_pattern(module_union),
        "module_majority_pattern": vector_to_pattern(module_majority),
        "module_intersection_pattern": vector_to_pattern(module_intersection),
        "module_union_gene_count": len(module_union_hits),
        "module_majority_gene_count": len(module_majority_hits),
        "module_intersection_gene_count": len(module_intersection_hits),
        "top_module_like_genes": str(module_top),
        "full_module_scan": str(module_scan),
    }
    (OUT / "ICAT_ICMAP_module_summary.json").write_text(
        json.dumps(module_summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )

    md_lines = [
        "# ICAT-like orthogroup co-occurrence scan",
        "",
        f"- Seed gene: `{ICAT_GENE_ID}`",
        f"- Seed orthogroup(s): `{';'.join(icat_groups)}`",
        f"- Species order: `{', '.join(species_names)}`",
        f"- Seed pattern: `{summary['seed_pattern']}`",
        f"- Seed present species: `{'; '.join(summary['seed_present_species'])}`",
        f"- ToxoDB ME49 genes scanned: `{len(genes)}`",
        f"- ME49 genes with OrthoMCL group: `{mapped_genes}`",
        f"- OrthoMCL sequence rows downloaded: `{len(all_sequence_rows)}`",
        f"- Orthogroups represented in target taxa: `{len(group_species_sequences)}`",
        f"- Exact ICAT-pattern genes: `{len(exact_hits)}`",
        f"- Genes with Hamming distance <= 1 from ICAT: `{len(strong_hits)}`",
        f"- Exact ICAT-pattern genes with informative annotation: `{len(annotated_exact_hits)}`",
        f"- Exact ICAT-pattern genes with cell-biology keywords: `{len(keyword_exact_hits)}`",
        "",
        "## Priority ICAT-like shortlist",
        "",
        "| rank | gene_id | orthogroups | hamming | jaccard | product | present_species |",
        "|---:|---|---|---:|---:|---|---|",
    ]
    for rank, (_score, _gene_id, row) in enumerate(priority[:25], start=1):
        product = (row["toxodb_product"] or row["orthomcl_product"] or "").replace("|", "/")
        if len(product) > 80:
            product = product[:77] + "..."
        md_lines.append(
            f"| {rank} | `{row['gene_id']}` | `{row['orthogroups']}` | "
            f"{row['hamming_to_ICAT']} | {row['jaccard_to_ICAT']} | "
            f"{product} | {row['present_species']} |"
        )
    md_lines.extend(
        [
            "",
            "## Interpretation notes",
            "",
            "- This scan is orthogroup-based. It tests phyletic co-occurrence, not direct functional interaction.",
            "- Multiple strains are collapsed to species-level presence for Neospora, Eimeria, and Sarcocystis.",
            "- Genes without an OrthoMCL group are retained in the full output with an all-zero pattern.",
            "- Strong candidates should be filtered further by localization, expression, domain architecture, and proximity/phenotype data.",
            "",
            "## ICAT + ICMAP module scan",
            "",
            "Seed genes:",
            "",
        ]
    )
    for seed in module_seed_rows:
        md_lines.append(
            f"- `{seed['seed_name']}`: `{seed['gene_id']}`, "
            f"`{seed['species_pattern']}`, {seed['product']}"
        )
    md_lines.extend(
        [
            "",
            f"- Union pattern: `{vector_to_pattern(module_union)}`",
            f"- Majority pattern: `{vector_to_pattern(module_majority)}`",
            f"- Intersection pattern: `{vector_to_pattern(module_intersection)}`",
            f"- Exact union-pattern genes: `{len(module_union_hits)}`",
            f"- Exact majority-pattern genes: `{len(module_majority_hits)}`",
            f"- Exact intersection-pattern genes: `{len(module_intersection_hits)}`",
            "",
            "Top module-like genes are ranked by mean Jaccard similarity to ICAT, ICMAP1, ICMAP2, and ICMAP3.",
        ]
    )
    (OUT / "cooccurrence_scan_summary.md").write_text(
        "\n".join(md_lines) + "\n", encoding="utf-8"
    )

    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
