#!/usr/bin/env Rscript

script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
if (length(script_arg) == 0L) {
  stop("This script must be run with Rscript so that --file is available.")
}
script_path <- normalizePath(sub("^--file=", "", script_arg[[1]]), mustWork = TRUE)
fig_dir <- normalizePath(file.path(dirname(script_path), "..", ".."), mustWork = TRUE)
project_root <- normalizePath(file.path(fig_dir, ".."), mustWork = TRUE)
source(file.path(project_root, "shared", "R", "project_library.R"))
icat_activate_project_library(project_root)

library(dplyr)
library(tidyr)
library(ggplot2)
library(patchwork)

table_dir <- file.path(fig_dir, "04_results", "tables", "conoid_evolution", "toxoplasma_reference_modules")
report_dir <- file.path(fig_dir, "04_results", "reports", "conoid_evolution", "toxoplasma_reference_modules")
figure_dir <- file.path(fig_dir, "04_results", "figures", "conoid_evolution", "toxoplasma_reference_modules", "conservation")
pdf_dir <- file.path(figure_dir, "PDF")
png_dir <- file.path(figure_dir, "PNG")
svg_dir <- file.path(figure_dir, "SVG")
dir.create(report_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(pdf_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(png_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(svg_dir, recursive = TRUE, showWarnings = FALSE)
font_cache <- file.path(tempdir(), "icat-fontconfig-cache")
dir.create(font_cache, recursive = TRUE, showWarnings = FALSE)
Sys.setenv(XDG_CACHE_HOME = font_cache)

species_scores_path <- file.path(table_dir, "toxoplasma_reference_module_species_scores.csv")
protein_scores_path <- file.path(table_dir, "toxoplasma_reference_protein_conservation_long.csv")
representative_scores_path <- file.path(table_dir, "toxoplasma_reference_module_representative_scores_for_fig.csv")
structure_matrix_path <- file.path(
  fig_dir,
  "02_processed_data",
  "conoid_evolution",
  "物种与结构矩阵",
  "apicomplexa_structure_guided_matrix_v2.csv"
)
stopifnot(
  file.exists(species_scores_path),
  file.exists(protein_scores_path),
  file.exists(representative_scores_path),
  file.exists(structure_matrix_path)
)

TEXT <- "#24282A"
MUTED <- "#68747A"
GRID <- "#DCE3E5"
PANEL <- "#FFFFFF"
LOW <- "#F6F7F4"
ABSENT <- "#E9EEEE"
SCAFFOLD <- "#7D8C94"
ICMT <- "#1F6370"
ICAT <- "#B44575"
FONT_7PT <- 7 / 2.845276

module_cols <- c(
  `Conoid scaffold` = SCAFFOLD,
  ICMTs = ICMT,
  ICAT = ICAT
)

supp_module_cols <- c(
  `Conoid scaffold` = "#B7D7A8",
  ICMTs = "#2E8B57",
  ICAT = "#9B4A97"
)

clade_cols <- c(
  Coccidia = "#E6A600",
  Piroplasmida = "#56B4E9",
  Haemosporidia = "#D96B00"
)

supp_clade_cols <- c(
  Coccidia = unname(clade_cols["Coccidia"]),
  `Haemosporidia/Cryptosporidia` = unname(clade_cols["Haemosporidia"]),
  Piroplasmida = unname(clade_cols["Piroplasmida"])
)

abbr_map <- c(
  `Toxoplasma gondii` = "Tg",
  `Neospora caninum` = "Nc",
  `Hammondia hammondi` = "Hh",
  `Besnoitia besnoiti` = "Be",
  `Sarcocystis neurona` = "Sn",
  `Cystoisospora suis` = "Cs",
  `Eimeria tenella` = "Et",
  `Plasmodium falciparum` = "Pf",
  `Cryptosporidium parvum` = "Cp",
  `Babesia bovis` = "Bbo",
  `Theileria annulata` = "Ta",
  Ciliates = "Cil",
  Perkinsus = "Per",
  `Chromera velia` = "Cv"
)

species_display_map <- c(
  `Toxoplasma gondii` = "T. gondii",
  `Neospora caninum` = "N. caninum",
  `Hammondia hammondi` = "H. hammondi",
  `Besnoitia besnoiti` = "B. besnoiti",
  `Sarcocystis neurona` = "S. neurona",
  `Cystoisospora suis` = "C. suis",
  `Eimeria tenella` = "E. tenella",
  `Plasmodium falciparum` = "P. falciparum",
  `Cryptosporidium parvum` = "C. parvum",
  `Babesia bovis` = "B. bovis",
  `Theileria annulata` = "T. annulata"
)

species_long_raw <- read.csv(species_scores_path, stringsAsFactors = FALSE, check.names = FALSE)
protein_long_raw <- read.csv(protein_scores_path, stringsAsFactors = FALSE, check.names = FALSE)
representative_scores_raw <- read.csv(representative_scores_path, stringsAsFactors = FALSE, check.names = FALSE)
structure_matrix_raw <- read.csv(structure_matrix_path, stringsAsFactors = FALSE, check.names = FALSE)

if (!"protein_plot_id" %in% colnames(protein_long_raw)) {
  protein_long_raw$protein_plot_id <- paste(protein_long_raw$module, protein_long_raw$gene_id, sep = "__")
}
if (!"source_row" %in% colnames(protein_long_raw)) {
  protein_long_raw$source_row <- NA_integer_
}

if (!"module_model_score" %in% colnames(species_long_raw)) {
  species_long_raw$module_model_score <- species_long_raw$module_conservation_fraction
}
if (!"strict_conservation_fraction" %in% colnames(species_long_raw)) {
  species_long_raw$strict_conservation_fraction <- species_long_raw$module_conservation_fraction
}

species_wide_core <- species_long_raw %>%
  mutate(
    module_id = case_when(
      module == "Conoid scaffold" ~ "conoid_scaffold_ortholog_fraction",
      module == "ICMT/ICMAP system" ~ "icmt_score",
      module == "ICAT structure" ~ "icat_score",
      TRUE ~ module
    ),
    strict_score = strict_conservation_fraction
  ) %>%
  select(species, module_id, strict_score) %>%
  pivot_wider(names_from = module_id, values_from = strict_score) %>%
  left_join(
    structure_matrix_raw %>%
      transmute(
        species,
        source_clade = clade,
        morphology_state = model,
        morphology_score = `conoid score`,
        morphology_gate = morphology_score / 2
      ),
    by = "species"
  ) %>%
  mutate(
    morphology_score = coalesce(morphology_score, 0),
    morphology_gate = coalesce(morphology_gate, 0),
    conoid_scaffold_score = conoid_scaffold_ortholog_fraction * morphology_gate,
    label_short = unname(abbr_map[species]),
    data_class = "protein conservation"
  )

outgroup_context <- representative_scores_raw %>%
  filter(representative_label %in% c("Ciliates", "Perkinsids", "Chromerids")) %>%
  transmute(
    species = display_species,
    conoid_scaffold_ortholog_fraction = conoid_scaffold_score,
    source_clade = representative_label,
    morphology_state = case_when(
      representative_label == "Ciliates" ~ "outgroup context",
      representative_label == "Perkinsids" ~ "open/asymmetric conoid context",
      representative_label == "Chromerids" ~ "closed/symmetric conoid context",
      TRUE ~ "evolutionary context"
    ),
    morphology_score = NA_real_,
    morphology_gate = NA_real_,
    conoid_scaffold_score = conoid_scaffold_score,
    icmt_score = icmt_icmap_score,
    icat_score = icat_score,
    label_short = unname(abbr_map[display_species]),
    data_class = "evolutionary context"
  )

species_wide <- bind_rows(species_wide_core, outgroup_context) %>%
  mutate(
    label_short = ifelse(is.na(label_short), species, label_short),
    derived_score = rowMeans(cbind(icmt_score, icat_score), na.rm = TRUE),
    morphology_gated_conoid_scaffold_index = conoid_scaffold_score
  )

simple_to_complex_order <- c("Cil", "Per", "Bbo", "Ta", "Pf", "Cp", "Cv", "Et", "Sn", "Cs", "Tg", "Nc", "Hh", "Be")
tree_root_x <- 0.38
tree_min_x <- 0.72
tree_max_x <- 2.34

leaf_df <- species_wide %>%
  mutate(
    label_rank = match(label_short, simple_to_complex_order),
    label_rank = ifelse(is.na(label_rank), 99L, label_rank)
  ) %>%
  arrange(label_rank, conoid_scaffold_score, derived_score, label_short) %>%
  mutate(
    y = rev(seq_len(n())),
    tree_x = tree_min_x + conoid_scaffold_score * (tree_max_x - tree_min_x),
    score_label = sprintf("%.2f", conoid_scaffold_score),
    derived_label = sprintf("%.2f", derived_score),
    label_fontface = ifelse(data_class == "evolutionary context", "italic", "bold")
  )

tree_groups <- leaf_df %>%
  group_by(conoid_scaffold_score) %>%
  summarise(
    tree_x = mean(tree_x),
    y_min = min(y),
    y_max = max(y),
    y_mid = mean(range(y)),
    labels = paste(label_short, collapse = "/"),
    .groups = "drop"
  )

complexity_tree_segments <- bind_rows(
  tibble::tibble(
    x = tree_root_x,
    xend = tree_root_x,
    y = min(leaf_df$y),
    yend = max(leaf_df$y),
    segment_type = "backbone"
  ),
  tree_groups %>%
    transmute(
      x = tree_root_x,
      xend = tree_x,
      y = y_mid,
      yend = y_mid,
      segment_type = "branch"
    ),
  tree_groups %>%
    filter(y_max > y_min) %>%
    transmute(
      x = tree_x,
      xend = tree_x,
      y = y_min,
      yend = y_max,
      segment_type = "score group"
    )
)

correlation_source_all <- species_wide %>%
  mutate(
    included_in_correlation = data_class == "protein conservation",
    plot_clade = case_when(
      grepl("Coccidia", source_clade, ignore.case = TRUE) ~ "Coccidia",
      grepl("Piroplasmida", source_clade, ignore.case = TRUE) ~ "Piroplasmida",
      grepl("Haemosporida", source_clade, ignore.case = TRUE) ~ "Haemosporidia",
      grepl("Cryptosporidia", source_clade, ignore.case = TRUE) ~ "Haemosporidia",
      TRUE ~ NA_character_
    ),
    plot_alpha = case_when(
      label_short == "Et" ~ 0.46,
      TRUE ~ 0.88
    ),
    plot_note = case_when(
      label_short == "Et" ~ "Coccidia fill with reduced alpha to mark low-confidence ICAT evidence.",
      grepl("Cryptosporidia", source_clade, ignore.case = TRUE) ~ "Cryptosporidia retained in source_clade; displayed with the reduced/non-coccidian orange group in the requested three-colour scheme.",
      TRUE ~ "Standard clade fill."
    )
  ) %>%
  select(
    species,
    label_short,
    data_class,
    included_in_correlation,
    source_clade,
    morphology_state,
    morphology_score,
    morphology_gate,
    conoid_scaffold_ortholog_fraction,
    morphology_gated_conoid_scaffold_index,
    conoid_scaffold_score,
    icmt_score,
    icat_score,
    derived_score,
    plot_clade,
    plot_alpha,
    plot_note
  )
correlation_source <- correlation_source_all %>%
  filter(included_in_correlation)
correlation_context <- correlation_source_all %>%
  filter(!included_in_correlation)

rho_scaffold_icmt <- suppressWarnings(cor(correlation_source$conoid_scaffold_score, correlation_source$icmt_score, method = "spearman"))
rho_scaffold_icat <- suppressWarnings(cor(correlation_source$conoid_scaffold_score, correlation_source$icat_score, method = "spearman"))
rho_scaffold_derived <- suppressWarnings(cor(correlation_source$conoid_scaffold_score, correlation_source$derived_score, method = "spearman"))
spearman_scaffold_derived <- suppressWarnings(cor.test(correlation_source$conoid_scaffold_score, correlation_source$derived_score, method = "spearman", exact = FALSE))
pearson_scaffold_derived <- suppressWarnings(cor.test(correlation_source$conoid_scaffold_score, correlation_source$derived_score, method = "pearson"))
lm_scaffold_derived <- lm(derived_score ~ conoid_scaffold_score, data = correlation_source)
lm_summary <- summary(lm_scaffold_derived)

correlation_points <- correlation_source %>%
  group_by(conoid_scaffold_score, derived_score) %>%
  arrange(label_short, .by_group = TRUE) %>%
  mutate(
    n_at_coordinate = n(),
    coordinate_rank = row_number(),
    offset_index = coordinate_rank - (n_at_coordinate + 1) / 2,
    point_x = conoid_scaffold_score + ifelse(n_at_coordinate > 1, offset_index * 0.018, 0),
    point_y = derived_score + ifelse(n_at_coordinate > 1, ifelse(coordinate_rank %% 2 == 1, 0.012, -0.012), 0),
    callout_dx = case_when(
      label_short == "Bbo" ~ -0.012,
      label_short == "Ta" ~ 0.030,
      label_short == "Pf" ~ 0.055,
      label_short == "Cp" ~ 0.055,
      label_short == "Et" ~ 0.045,
      label_short == "Sn" ~ -0.075,
      label_short == "Cs" ~ -0.085,
      label_short == "Be" ~ -0.070,
      label_short == "Tg" ~ 0.055,
      label_short == "Nc" ~ 0.065,
      label_short == "Hh" ~ 0.070,
      TRUE ~ 0.025
    ),
    callout_dy = case_when(
      label_short == "Bbo" ~ 0.055,
      label_short == "Ta" ~ -0.055,
      label_short == "Pf" ~ 0.045,
      label_short == "Cp" ~ 0.050,
      label_short == "Et" ~ 0.035,
      label_short == "Sn" ~ 0.050,
      label_short == "Cs" ~ -0.065,
      label_short == "Be" ~ 0.080,
      label_short == "Tg" ~ -0.060,
      label_short == "Nc" ~ 0.070,
      label_short == "Hh" ~ -0.090,
      TRUE ~ 0.030
    ),
    label_x = point_x + callout_dx,
    label_y = point_y + callout_dy,
    callout_side = ifelse(callout_dx < 0, -1, 1),
    label_hjust = ifelse(callout_side < 0, 1, 0),
    callout_start_x = point_x + callout_side * 0.026,
    callout_start_y = point_y,
    callout_elbow_x = point_x + callout_side * pmin(0.060, pmax(0.035, abs(callout_dx) * 0.48)),
    callout_elbow_y = point_y,
    callout_end_x = label_x - callout_side * 0.012,
    callout_end_y = label_y
  ) %>%
  ungroup()

correlation_callout_segments <- bind_rows(
  correlation_points %>%
    transmute(
      species,
      segment_part = "horizontal stub",
      x = callout_start_x,
      y = callout_start_y,
      xend = callout_elbow_x,
      yend = callout_elbow_y
    ),
  correlation_points %>%
    transmute(
      species,
      segment_part = "label leader",
      x = callout_elbow_x,
      y = callout_elbow_y,
      xend = callout_end_x,
      yend = callout_end_y
    )
)

correlation_context_grouped <- correlation_context %>%
  group_by(conoid_scaffold_score, derived_score) %>%
  summarise(
    label_group = paste(label_short, collapse = "/"),
    n_species = n(),
    .groups = "drop"
  ) %>%
  mutate(
    label_x = case_when(
      label_group == "Per" ~ conoid_scaffold_score - 0.035,
      TRUE ~ conoid_scaffold_score + 0.020
    ),
    label_y = case_when(
      label_group == "Per" ~ derived_score + 0.115,
      TRUE ~ derived_score + 0.055
    ),
    label_hjust = ifelse(label_group == "Per", 1, 0)
  )

correlation_stats <- data.frame(
  comparison = c("Morphology-gated conoid scaffold index vs derived-module score", "Morphology-gated conoid scaffold index vs derived-module score", "Morphology-gated conoid scaffold index predicts derived-module score"),
  method = c("Spearman rank correlation", "Pearson correlation", "Linear model"),
  estimate = c(unname(spearman_scaffold_derived$estimate), unname(pearson_scaffold_derived$estimate), unname(coef(lm_scaffold_derived)[["conoid_scaffold_score"]])),
  p_value = c(spearman_scaffold_derived$p.value, pearson_scaffold_derived$p.value, lm_summary$coefficients["conoid_scaffold_score", "Pr(>|t|)"]),
  r_squared = c(NA_real_, NA_real_, lm_summary$r.squared),
  n_species = nrow(correlation_source),
  outgroups_excluded_from_stats = nrow(correlation_context)
)

barcode_start_x <- 2.96
barcode_step_x <- 0.100
barcode_square_size <- 1.72

protein_order <- protein_long_raw %>%
  filter(include_in_score == 1) %>%
  distinct(module, protein_plot_id, gene_id, protein, display_name, source_row) %>%
  mutate(
    module_tree = case_when(
      module == "Conoid scaffold" ~ "Conoid scaffold",
      module == "ICMT/ICMAP system" ~ "ICMTs",
      module == "ICAT structure" ~ "ICAT",
      TRUE ~ module
    ),
    module_tree = factor(module_tree, levels = names(module_cols)),
    protein_index_within_module = ave(seq_along(protein), module_tree, FUN = seq_along)
  ) %>%
  arrange(module_tree, source_row, protein_index_within_module, gene_id) %>%
  mutate(
    protein_order = row_number(),
    x = barcode_start_x + (protein_order - 1) * barcode_step_x
  )

barcode_df <- protein_long_raw %>%
  filter(include_in_score == 1) %>%
  mutate(
    label_short = unname(abbr_map[species]),
    module_tree = case_when(
      module == "Conoid scaffold" ~ "Conoid scaffold",
      module == "ICMT/ICMAP system" ~ "ICMTs",
      module == "ICAT structure" ~ "ICAT",
      TRUE ~ module
    ),
    module_tree = factor(module_tree, levels = names(module_cols))
  ) %>%
  left_join(
    protein_order %>% select(module, protein_plot_id, gene_id, module_tree, protein_order, x),
    by = c("module", "protein_plot_id", "gene_id", "module_tree")
  ) %>%
  left_join(leaf_df %>% select(species, label_short, y, conoid_scaffold_score, icmt_score, icat_score, derived_score), by = c("species", "label_short")) %>%
  mutate(
    protein_score = ifelse(orthogroup_present > 0, 1, 0),
    alpha_score = 1,
    fill_col = ifelse(protein_score == 0, ABSENT, unname(module_cols[as.character(module_tree)]))
  )

module_bands <- protein_order %>%
  group_by(module_tree) %>%
  summarise(
    n_proteins = n(),
    xmin = min(x) - barcode_step_x * 0.52,
    xmax = max(x) + barcode_step_x * 0.52,
    xmid = mean(c(xmin, xmax)),
    .groups = "drop"
  ) %>%
  mutate(
    y = max(leaf_df$y) + 0.62,
    label = case_when(
      module_tree == "Conoid scaffold" ~ paste0("Conoid (", n_proteins, ")"),
      module_tree == "ICMTs" ~ paste0("ICMTs (", n_proteins, ")"),
      module_tree == "ICAT" ~ "ICAT",
      TRUE ~ as.character(module_tree)
    ),
    fill_col = unname(module_cols[as.character(module_tree)])
  )

species_axis_df <- leaf_df %>%
  arrange(label_rank, conoid_scaffold_score, derived_score, label_short) %>%
  mutate(species_x = row_number())

module_axis_df <- tibble::tibble(
  module_tree = factor(c("Conoid scaffold", "ICMTs", "ICAT"), levels = names(module_cols)),
  module_label = c("Conoid", "ICMTs", "ICAT"),
  glyph_y = c(3.16, 2.04, 0.92)
)

module_section_lookup <- protein_order %>%
  group_by(module_tree) %>%
  arrange(source_row, protein_index_within_module, gene_id, .by_group = TRUE) %>%
  mutate(
    section_index = row_number(),
    n_sections = n()
  ) %>%
  ungroup() %>%
  select(module, protein_plot_id, gene_id, module_tree, section_index, n_sections)

strict_section_hits <- barcode_df %>%
  left_join(
    module_section_lookup,
    by = c("module", "protein_plot_id", "gene_id", "module_tree")
  ) %>%
  group_by(species, label_short, module_tree, section_index, n_sections) %>%
  summarise(section_score = mean(protein_score, na.rm = TRUE), .groups = "drop")

section_score_df <- tidyr::crossing(
  species_axis_df %>% select(species, label_short, species_x, data_class),
  module_section_lookup %>% distinct(module_tree, section_index, n_sections)
) %>%
  left_join(
    strict_section_hits,
    by = c("species", "label_short", "module_tree", "section_index", "n_sections")
  ) %>%
  mutate(
    module_tree = factor(module_tree, levels = names(module_cols)),
    section_score = ifelse(is.na(section_score), 0, section_score)
  ) %>%
  left_join(module_axis_df, by = "module_tree") %>%
  mutate(
    fill_col = ifelse(section_score > 0, unname(module_cols[as.character(module_tree)]), ABSENT),
    alpha_score = 1,
    start_angle = pi / 2 - 2 * pi * (section_index - 1) / n_sections,
    end_angle = pi / 2 - 2 * pi * section_index / n_sections,
    group_id = paste(label_short, module_tree, section_index, sep = "_")
  )

make_sector_polygons <- function(section_df, radius_x = 0.42, radius_y = 0.15, n_points = 14) {
  pieces <- lapply(seq_len(nrow(section_df)), function(i) {
    row <- section_df[i, , drop = FALSE]
    theta <- seq(row$start_angle, row$end_angle, length.out = n_points)
    data.frame(
      group_id = row$group_id,
      fill_col = row$fill_col,
      alpha_score = row$alpha_score,
      x = c(row$species_x, row$species_x + radius_x * cos(theta), row$species_x),
      y = c(row$glyph_y, row$glyph_y + radius_y * sin(theta), row$glyph_y)
    )
  })
  do.call(rbind, pieces)
}

make_circle_outlines <- function(circle_df, radius_x = 0.42, radius_y = 0.15, n_points = 64) {
  theta <- seq(0, 2 * pi, length.out = n_points)
  pieces <- lapply(seq_len(nrow(circle_df)), function(i) {
    row <- circle_df[i, , drop = FALSE]
    data.frame(
      group_id = paste(row$label_short, row$module_tree, sep = "_"),
      x = row$species_x + radius_x * cos(theta),
      y = row$glyph_y + radius_y * sin(theta)
    )
  })
  do.call(rbind, pieces)
}

section_polygon_df <- make_sector_polygons(section_score_df)
circle_outline_df <- make_circle_outlines(
  section_score_df %>%
    distinct(label_short, module_tree, species_x, glyph_y)
)
section_glyph_source <- section_score_df %>%
  left_join(
    module_section_lookup,
    by = c("module_tree", "section_index", "n_sections")
  ) %>%
  mutate(
    strict_presence = as.integer(section_score > 0)
  ) %>%
  select(
    species, label_short, data_class, species_x,
    module_tree, section_index, n_sections,
    module, protein_plot_id, gene_id,
    strict_presence
  )

tree_base_y <- 4.20
tree_scale_y <- 0.66
tree_tip_df <- species_axis_df %>%
  mutate(tree_tip_y = tree_base_y + conoid_scaffold_score * tree_scale_y)

tree_plot <- ggplot() +
  annotate(
    "rect",
    xmin = 0.25,
    xmax = max(species_axis_df$species_x) + 0.45,
    ymin = 0.32,
    ymax = tree_base_y + tree_scale_y + 0.58,
    fill = LOW,
    color = GRID,
    linewidth = 0.22
  ) +
  geom_text(
    data = module_axis_df,
    aes(x = 0.38, y = glyph_y, label = module_label, color = module_tree),
    hjust = 1,
    fontface = "bold",
    size = 2.15
  ) +
  geom_polygon(
    data = section_polygon_df,
    aes(x = x, y = y, group = group_id, fill = fill_col, alpha = alpha_score),
    color = "white",
    linewidth = 0.08
  ) +
  geom_path(
    data = circle_outline_df,
    aes(x = x, y = y, group = group_id),
    color = "#3C4447",
    linewidth = 0.18,
    alpha = 0.85
  ) +
  geom_segment(
    aes(x = 1, xend = max(species_axis_df$species_x), y = tree_base_y, yend = tree_base_y),
    color = SCAFFOLD,
    linewidth = 0.45,
    lineend = "round"
  ) +
  geom_segment(
    data = tree_tip_df,
    aes(x = species_x, xend = species_x, y = tree_base_y, yend = tree_tip_y),
    color = SCAFFOLD,
    linewidth = 0.42,
    lineend = "round"
  ) +
  geom_point(
    data = tree_tip_df,
    aes(x = species_x, y = tree_tip_y, shape = data_class),
    fill = "white",
    color = SCAFFOLD,
    stroke = 0.46,
    size = 1.45
  ) +
  geom_text(
    data = tree_tip_df,
    aes(x = species_x, y = tree_base_y - 0.55, label = label_short, fontface = label_fontface),
    hjust = 0.5,
    vjust = 1,
    color = TEXT,
    size = 1.95
  ) +
  annotate(
    "segment",
    x = 1,
    xend = max(species_axis_df$species_x),
    y = tree_base_y + tree_scale_y + 0.31,
    yend = tree_base_y + tree_scale_y + 0.31,
    color = MUTED,
    linewidth = 0.33,
    arrow = grid::arrow(length = grid::unit(0.085, "cm"))
  ) +
  annotate(
    "label",
    x = mean(range(species_axis_df$species_x)),
    y = tree_base_y + tree_scale_y + 0.52,
    label = "Conoid complexity",
    color = TEXT,
    fill = PANEL,
    linewidth = 0,
    fontface = "bold",
    size = 1.95
  ) +
  scale_alpha_identity() +
  scale_fill_identity() +
  scale_color_manual(values = module_cols, guide = "none") +
  scale_shape_manual(values = c(`protein conservation` = 21, `evolutionary context` = 24), guide = "none") +
  coord_cartesian(
    xlim = c(-0.74, max(species_axis_df$species_x) + 0.48),
    ylim = c(0.30, tree_base_y + tree_scale_y + 0.72),
    clip = "off"
  ) +
  labs(title = NULL, subtitle = NULL) +
  theme_void(base_family = "Arial", base_size = 7.0) +
  theme(
    plot.background = element_rect(fill = PANEL, color = NA),
    panel.background = element_rect(fill = PANEL, color = NA),
    legend.position = "none",
    plot.margin = margin(0.8, 0.8, 0.8, 0.8)
  )

model_strip <- ggplot() +
  coord_cartesian(xlim = c(0, 10), ylim = c(0, 1.45), expand = FALSE) +
  theme_void(base_family = "Arial") +
  annotate("text", x = 0.15, y = 1.08, hjust = 0, label = "Interpretation", size = 2.60, fontface = "bold", color = TEXT) +
  annotate("text", x = 0.15, y = 0.62, hjust = 0, label = "High-scaffold branches concentrate strict ICMT/ICMAP and ICAT OrthoMCL hits.", size = 2.23, color = MUTED) +
  annotate("text", x = 0.15, y = 0.27, hjust = 0, label = "Each section is binary: filled = strict hit; pale = no strict hit.", size = 2.04, color = MUTED)

combined_plot <- tree_plot

supp_species_order <- leaf_df %>%
  filter(data_class == "protein conservation") %>%
  left_join(
    correlation_source_all %>%
      select(species, plot_clade),
    by = "species"
  ) %>%
  arrange(label_rank, conoid_scaffold_score, derived_score, label_short) %>%
  mutate(
    barcode_y = rev(seq_len(n())),
    species_label = ifelse(!is.na(unname(species_display_map[species])), unname(species_display_map[species]), species),
    clade_display = case_when(
      plot_clade == "Coccidia" ~ "Coccidia",
      plot_clade == "Piroplasmida" ~ "Piroplasmida",
      plot_clade == "Haemosporidia" ~ "Haemosporidia/Cryptosporidia",
      TRUE ~ "Other"
    ),
    clade_fill_col = unname(supp_clade_cols[clade_display])
  )

supp_module_offsets <- protein_order %>%
  arrange(module_tree, source_row, protein_order) %>%
  count(module_tree, name = "n_proteins") %>%
  mutate(module_start = cumsum(lag(n_proteins + 0.30, default = 0)) + 1)

supp_protein_presence_order <- barcode_df %>%
  semi_join(supp_species_order, by = "species") %>%
  group_by(module, protein_plot_id, gene_id, module_tree) %>%
  summarise(
    n_species = n(),
    n_present = sum(protein_score > 0, na.rm = TRUE),
    presence_fraction = n_present / n_species,
    .groups = "drop"
  )

supp_protein_order <- protein_order %>%
  left_join(
    supp_protein_presence_order,
    by = c("module", "protein_plot_id", "gene_id", "module_tree")
  ) %>%
  mutate(
    n_species = coalesce(n_species, 0L),
    n_present = coalesce(n_present, 0L),
    presence_fraction = coalesce(presence_fraction, 0),
    protein_sort_key = ifelse(
      as.character(module_tree) %in% c("Conoid scaffold", "ICMTs"),
      -presence_fraction,
      protein_order
    )
  ) %>%
  arrange(module_tree, protein_sort_key, source_row, protein_order) %>%
  group_by(module_tree) %>%
  mutate(protein_index_supp = row_number()) %>%
  ungroup() %>%
  left_join(supp_module_offsets, by = "module_tree") %>%
  mutate(
    x_supp = module_start + protein_index_supp - 1,
    protein_label = case_when(
      !is.na(display_name) & display_name != "" ~ display_name,
      !is.na(protein) & protein != "" ~ protein,
      !is.na(gene_id) & gene_id != "" ~ gene_id,
      TRUE ~ protein_plot_id
    )
  )

supp_barcode_df <- barcode_df %>%
  semi_join(supp_species_order, by = "species") %>%
  left_join(
    supp_species_order %>%
      select(species, label_short, barcode_y, species_label, source_clade, plot_clade, clade_display, clade_fill_col),
    by = c("species", "label_short")
  ) %>%
  left_join(
    supp_protein_order %>%
      select(module, protein_plot_id, gene_id, module_tree, x_supp, protein_label),
    by = c("module", "protein_plot_id", "gene_id", "module_tree")
  ) %>%
  mutate(
    strict_presence = as.integer(protein_score > 0),
    presence_label = factor(ifelse(strict_presence == 1, "Present", "Absent"), levels = c("Present", "Absent")),
    fill_col = ifelse(strict_presence == 1, unname(supp_module_cols[as.character(module_tree)]), ABSENT)
  )

supp_col_counts <- supp_barcode_df %>%
  group_by(module_tree, x_supp, protein_label) %>%
  summarise(n_present = sum(strict_presence, na.rm = TRUE), .groups = "drop") %>%
  mutate(
    bar_height = n_present / max(supp_species_order$barcode_y) * 1.10,
    fill_col = unname(supp_module_cols[as.character(module_tree)])
  )

supp_row_counts <- supp_barcode_df %>%
  group_by(species, species_label, barcode_y, clade_display, clade_fill_col) %>%
  summarise(n_present = sum(strict_presence, na.rm = TRUE), .groups = "drop") %>%
  mutate(bar_width = n_present / max(n_present, na.rm = TRUE) * 1.15)

supp_col_percentages <- supp_barcode_df %>%
  group_by(module_tree, x_supp, protein_label) %>%
  summarise(
    n_species = n(),
    n_present = sum(strict_presence, na.rm = TRUE),
    presence_fraction = n_present / n_species,
    .groups = "drop"
  ) %>%
  mutate(
    bar_height = presence_fraction * 1.10,
    fill_col = unname(supp_module_cols[as.character(module_tree)])
  )

supp_row_module_percentages <- supp_barcode_df %>%
  group_by(species, species_label, barcode_y, clade_display, clade_fill_col, module_tree) %>%
  summarise(
    n_proteins = n(),
    n_present = sum(strict_presence, na.rm = TRUE),
    module_presence_fraction = n_present / n_proteins,
    .groups = "drop"
  ) %>%
  mutate(
    module_tree = factor(module_tree, levels = names(supp_module_cols)),
    module_y_offset = case_when(
      module_tree == "Conoid scaffold" ~ 0.24,
      module_tree == "ICMTs" ~ 0.00,
      module_tree == "ICAT" ~ -0.24,
      TRUE ~ 0.00
    ),
    bar_width = module_presence_fraction * 1.15,
    fill_col = unname(supp_module_cols[as.character(module_tree)])
  )

supp_row_module_summary <- supp_row_module_percentages %>%
  select(
    species, species_label, clade_display, module_tree,
    n_present, n_proteins, module_presence_fraction
  ) %>%
  tidyr::pivot_wider(
    names_from = module_tree,
    values_from = c(n_present, n_proteins, module_presence_fraction),
    names_sep = "__"
  ) %>%
  mutate(
    equal_weight_module_presence_fraction = rowMeans(
      cbind(
        `module_presence_fraction__Conoid scaffold`,
        `module_presence_fraction__ICMTs`,
        module_presence_fraction__ICAT
      ),
      na.rm = TRUE
    )
  )

supp_module_bands <- supp_protein_order %>%
  group_by(module_tree) %>%
  summarise(
    n_proteins = n(),
    xmin = min(x_supp) - 0.45,
    xmax = max(x_supp) + 0.45,
    xmid = mean(c(xmin, xmax)),
    .groups = "drop"
  ) %>%
  mutate(
    ymin = max(supp_species_order$barcode_y) + 2.86,
    ymax = max(supp_species_order$barcode_y) + 3.03,
    label = case_when(
      module_tree == "Conoid scaffold" ~ paste0("Conoid scaffold (", n_proteins, ")"),
      module_tree == "ICMTs" ~ paste0("ICMT/ICMAP (", n_proteins, ")"),
      module_tree == "ICAT" ~ "ICAT (1)",
      TRUE ~ as.character(module_tree)
    ),
    fill_col = unname(supp_module_cols[as.character(module_tree)])
  )

supp_lineage_legend <- tibble::tibble(
  label = c("Coccidia", "Haemosporidia /\nCryptosporidia", "Piroplasmida"),
  fill_col = unname(supp_clade_cols),
  x = c(4.20, 11.00, 20.00),
  y = -5.80
)

supp_presence_legend <- tibble::tibble(
  label = c("Present", "Absent"),
  fill_col = c(supp_module_cols[["Conoid scaffold"]], ABSENT),
  x = c(7.10, 11.20),
  y = -6.92
)

supp_module_legend <- tibble::tibble(
  label = c("Conoid scaffold", "ICMT/ICMAP", "ICAT"),
  fill_col = unname(supp_module_cols),
  x = c(4.20, 11.00, 18.20),
  y = -4.92
)

supp_barcode_plot <- ggplot() +
  annotate(
    "rect",
    xmin = min(supp_protein_order$x_supp) - 0.52,
    xmax = max(supp_protein_order$x_supp) + 0.58,
    ymin = 0.52,
    ymax = max(supp_species_order$barcode_y) + 1.05,
    fill = LOW,
    color = GRID,
    linewidth = 0.20
  ) +
  geom_rect(
    data = supp_col_counts,
    aes(
      xmin = x_supp - 0.38,
      xmax = x_supp + 0.38,
      ymin = max(supp_species_order$barcode_y) + 1.34,
      ymax = max(supp_species_order$barcode_y) + 1.34 + bar_height,
      fill = fill_col
    ),
    inherit.aes = FALSE,
    color = NA,
    alpha = 0.92
  ) +
  annotate(
    "text",
    x = min(supp_protein_order$x_supp) - 0.52,
    y = max(supp_species_order$barcode_y) + 2.02,
    label = "protein hits",
    hjust = 1,
    color = TEXT,
    size = FONT_7PT
  ) +
  geom_rect(
    data = supp_row_counts,
    aes(
      xmin = min(supp_protein_order$x_supp) - 6.00,
      xmax = min(supp_protein_order$x_supp) - 6.00 + bar_width,
      ymin = barcode_y - 0.36,
      ymax = barcode_y + 0.36,
      fill = clade_fill_col
    ),
    inherit.aes = FALSE,
    color = NA,
    alpha = 0.88
  ) +
  annotate(
    "text",
    x = min(supp_protein_order$x_supp) - 6.00,
    y = max(supp_species_order$barcode_y) + 1.02,
    label = "total hits",
    hjust = 0,
    color = TEXT,
    size = FONT_7PT
  ) +
  geom_point(
    data = supp_barcode_df,
    aes(x = x_supp, y = barcode_y, fill = fill_col),
    shape = 22,
    size = 3.95,
    color = "white",
    stroke = 0.06
  ) +
  geom_rect(
    data = supp_module_bands,
    aes(xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax, fill = fill_col),
    color = NA
  ) +
  geom_text(
    data = supp_module_bands,
    aes(x = xmid, y = ymax + 0.24, label = label),
    color = TEXT,
    fontface = "bold",
    size = FONT_7PT
  ) +
  geom_point(
    data = supp_species_order,
    aes(x = min(supp_protein_order$x_supp) - 0.72, y = barcode_y, fill = clade_fill_col),
    inherit.aes = FALSE,
    shape = 21,
    color = TEXT,
    stroke = 0.24,
    size = 2.40
  ) +
  geom_text(
    data = supp_species_order,
    aes(x = min(supp_protein_order$x_supp) - 1.02, y = barcode_y, label = species_label),
    hjust = 1,
    color = TEXT,
    size = FONT_7PT
  ) +
  geom_text(
    data = supp_protein_order,
    aes(x = x_supp, y = 0.26, label = protein_label),
    angle = 90,
    hjust = 1,
    vjust = 0.5,
    color = TEXT,
    size = FONT_7PT
  ) +
  annotate(
    "text",
    x = min(supp_protein_order$x_supp) - 1.02,
    y = max(supp_species_order$barcode_y) + 1.02,
    label = "species",
    hjust = 1,
    color = TEXT,
    size = FONT_7PT
  ) +
  annotate("text", x = 1.00, y = -4.92, label = "Module", hjust = 0, color = TEXT, fontface = "bold", size = FONT_7PT) +
  geom_point(
    data = supp_module_legend,
    aes(x = x, y = y, fill = fill_col),
    inherit.aes = FALSE,
    shape = 22,
    color = "white",
    stroke = 0.06,
    size = 3.95
  ) +
  geom_text(
    data = supp_module_legend,
    aes(x = x + 0.42, y = y, label = label),
    inherit.aes = FALSE,
    hjust = 0,
    color = TEXT,
    size = FONT_7PT
  ) +
  annotate("text", x = 1.00, y = -5.80, label = "Lineage", hjust = 0, color = TEXT, fontface = "bold", size = FONT_7PT) +
  geom_point(
    data = supp_lineage_legend,
    aes(x = x, y = y, fill = fill_col),
    inherit.aes = FALSE,
    shape = 21,
    color = TEXT,
    stroke = 0.24,
    size = 2.40
  ) +
  geom_text(
    data = supp_lineage_legend,
    aes(x = x + 0.42, y = y, label = label),
    inherit.aes = FALSE,
    hjust = 0,
    color = TEXT,
    size = FONT_7PT,
    lineheight = 0.85
  ) +
  annotate("text", x = 1.00, y = -6.92, label = "Strict OrthoMCL", hjust = 0, color = TEXT, fontface = "bold", size = FONT_7PT) +
  geom_point(
    data = supp_presence_legend,
    aes(x = x, y = y, fill = fill_col),
    inherit.aes = FALSE,
    shape = 22,
    color = "white",
    stroke = 0.06,
    size = 3.95
  ) +
  geom_text(
    data = supp_presence_legend,
    aes(x = x + 0.42, y = y, label = label),
    inherit.aes = FALSE,
    hjust = 0,
    color = TEXT,
    size = FONT_7PT
  ) +
  scale_fill_identity() +
  coord_cartesian(
    xlim = c(min(supp_protein_order$x_supp) - 6.25, max(supp_protein_order$x_supp) + 1.10),
    ylim = c(-7.55, max(supp_species_order$barcode_y) + 3.45),
    clip = "off"
  ) +
  labs(title = NULL, subtitle = NULL) +
  theme_void(base_family = "Arial", base_size = 7.0) +
  theme(
    plot.background = element_rect(fill = PANEL, color = NA),
    panel.background = element_rect(fill = PANEL, color = NA),
    plot.margin = margin(1.2, 1.2, 46, 1.2)
  )

supp_weak_icat_df <- supp_barcode_df %>%
  filter(species == "Eimeria tenella", module_tree == "ICAT")

supp_barcode_percent_plot <- ggplot() +
  annotate(
    "rect",
    xmin = min(supp_protein_order$x_supp) - 0.52,
    xmax = max(supp_protein_order$x_supp) + 0.58,
    ymin = 0.52,
    ymax = max(supp_species_order$barcode_y) + 1.05,
    fill = LOW,
    color = GRID,
    linewidth = 0.20
  ) +
  geom_rect(
    data = supp_col_percentages,
    aes(
      xmin = x_supp - 0.38,
      xmax = x_supp + 0.38,
      ymin = max(supp_species_order$barcode_y) + 1.34,
      ymax = max(supp_species_order$barcode_y) + 1.34 + bar_height,
      fill = fill_col
    ),
    inherit.aes = FALSE,
    color = NA,
    alpha = 0.92
  ) +
  annotate(
    "segment",
    x = max(supp_protein_order$x_supp) + 0.77,
    xend = max(supp_protein_order$x_supp) + 0.77,
    y = max(supp_species_order$barcode_y) + 1.34,
    yend = max(supp_species_order$barcode_y) + 2.44,
    color = MUTED,
    linewidth = 0.20
  ) +
  annotate("text", x = max(supp_protein_order$x_supp) + 0.92, y = max(supp_species_order$barcode_y) + 1.34, label = "0", hjust = 0, color = TEXT, size = FONT_7PT) +
  annotate("text", x = max(supp_protein_order$x_supp) + 0.92, y = max(supp_species_order$barcode_y) + 2.44, label = "100%", hjust = 0, color = TEXT, size = FONT_7PT) +
  annotate(
    "text",
    x = min(supp_protein_order$x_supp) - 0.52,
    y = max(supp_species_order$barcode_y) + 2.02,
    label = "species %",
    hjust = 1,
    color = TEXT,
    size = FONT_7PT
  ) +
  geom_rect(
    data = supp_row_module_percentages,
    aes(
      xmin = min(supp_protein_order$x_supp) - 6.00,
      xmax = min(supp_protein_order$x_supp) - 6.00 + bar_width,
      ymin = barcode_y + module_y_offset - 0.09,
      ymax = barcode_y + module_y_offset + 0.09,
      fill = fill_col
    ),
    inherit.aes = FALSE,
    color = NA,
    alpha = 0.92
  ) +
  annotate(
    "segment",
    x = min(supp_protein_order$x_supp) - 6.00,
    xend = min(supp_protein_order$x_supp) - 4.85,
    y = max(supp_species_order$barcode_y) + 0.72,
    yend = max(supp_species_order$barcode_y) + 0.72,
    color = MUTED,
    linewidth = 0.20
  ) +
  annotate("text", x = min(supp_protein_order$x_supp) - 6.00, y = max(supp_species_order$barcode_y) + 1.16, label = "module\n%", hjust = 0, color = TEXT, size = FONT_7PT, lineheight = 0.78) +
  annotate("text", x = min(supp_protein_order$x_supp) - 6.00, y = max(supp_species_order$barcode_y) + 0.46, label = "0", hjust = 0, color = TEXT, size = FONT_7PT) +
  annotate("text", x = min(supp_protein_order$x_supp) - 4.85, y = max(supp_species_order$barcode_y) + 0.46, label = "100%", hjust = 1, color = TEXT, size = FONT_7PT) +
  geom_point(
    data = supp_barcode_df,
    aes(x = x_supp, y = barcode_y, fill = fill_col),
    shape = 22,
    size = 3.95,
    color = "white",
    stroke = 0.06
  ) +
  geom_point(
    data = supp_weak_icat_df,
    aes(x = x_supp, y = barcode_y),
    inherit.aes = FALSE,
    shape = 4,
    color = supp_module_cols[["ICAT"]],
    stroke = 0.45,
    size = 2.45
  ) +
  geom_rect(
    data = supp_module_bands,
    aes(xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax, fill = fill_col),
    color = NA
  ) +
  geom_text(
    data = supp_module_bands,
    aes(x = xmid, y = ymax + 0.24, label = label),
    color = TEXT,
    fontface = "bold",
    size = FONT_7PT
  ) +
  geom_point(
    data = supp_species_order,
    aes(x = min(supp_protein_order$x_supp) - 0.72, y = barcode_y, fill = clade_fill_col),
    inherit.aes = FALSE,
    shape = 21,
    color = TEXT,
    stroke = 0.24,
    size = 2.40
  ) +
  geom_text(
    data = supp_species_order,
    aes(x = min(supp_protein_order$x_supp) - 1.02, y = barcode_y, label = species_label),
    hjust = 1,
    color = TEXT,
    size = FONT_7PT
  ) +
  geom_text(
    data = supp_protein_order,
    aes(x = x_supp, y = 0.26, label = protein_label),
    angle = 90,
    hjust = 1,
    vjust = 0.5,
    color = TEXT,
    size = FONT_7PT
  ) +
  annotate(
    "text",
    x = min(supp_protein_order$x_supp) - 1.02,
    y = max(supp_species_order$barcode_y) + 1.02,
    label = "taxa",
    hjust = 1,
    color = TEXT,
    size = FONT_7PT
  ) +
  annotate("text", x = 1.00, y = -4.92, label = "Module", hjust = 0, color = TEXT, fontface = "bold", size = FONT_7PT) +
  geom_point(
    data = supp_module_legend,
    aes(x = x, y = y, fill = fill_col),
    inherit.aes = FALSE,
    shape = 22,
    color = "white",
    stroke = 0.06,
    size = 3.95
  ) +
  geom_text(
    data = supp_module_legend,
    aes(x = x + 0.42, y = y, label = label),
    inherit.aes = FALSE,
    hjust = 0,
    color = TEXT,
    size = FONT_7PT
  ) +
  annotate("text", x = 1.00, y = -5.80, label = "Lineage", hjust = 0, color = TEXT, fontface = "bold", size = FONT_7PT) +
  geom_point(
    data = supp_lineage_legend,
    aes(x = x, y = y, fill = fill_col),
    inherit.aes = FALSE,
    shape = 21,
    color = TEXT,
    stroke = 0.24,
    size = 2.40
  ) +
  geom_text(
    data = supp_lineage_legend,
    aes(x = x + 0.42, y = y, label = label),
    inherit.aes = FALSE,
    hjust = 0,
    color = TEXT,
    size = FONT_7PT,
    lineheight = 0.85
  ) +
  annotate("text", x = 1.00, y = -6.92, label = "Strict OrthoMCL", hjust = 0, color = TEXT, fontface = "bold", size = FONT_7PT) +
  geom_point(
    data = supp_presence_legend,
    aes(x = x, y = y, fill = fill_col),
    inherit.aes = FALSE,
    shape = 22,
    color = "white",
    stroke = 0.06,
    size = 3.95
  ) +
  geom_text(
    data = supp_presence_legend,
    aes(x = x + 0.42, y = y, label = label),
    inherit.aes = FALSE,
    hjust = 0,
    color = TEXT,
    size = FONT_7PT
  ) +
  annotate("text", x = 1.00, y = -7.84, label = "Weak ICAT call", hjust = 0, color = TEXT, fontface = "bold", size = FONT_7PT) +
  annotate(
    "point",
    x = 7.65,
    y = -7.84,
    shape = 4,
    color = supp_module_cols[["ICAT"]],
    stroke = 0.45,
    size = 2.45
  ) +
  annotate("text", x = 8.06, y = -7.84, label = "weak E. tenella homolog, not scored as strict present", hjust = 0, color = TEXT, size = FONT_7PT) +
  scale_fill_identity() +
  coord_cartesian(
    xlim = c(min(supp_protein_order$x_supp) - 6.25, max(supp_protein_order$x_supp) + 1.70),
    ylim = c(-8.48, max(supp_species_order$barcode_y) + 3.45),
    clip = "off"
  ) +
  labs(title = NULL, subtitle = NULL) +
  theme_void(base_family = "Arial", base_size = 7.0) +
  theme(
    plot.background = element_rect(fill = PANEL, color = NA),
    panel.background = element_rect(fill = PANEL, color = NA),
    plot.margin = margin(1.2, 1.2, 52, 1.2)
  )

correlation_plot <- ggplot(correlation_source, aes(x = conoid_scaffold_score, y = derived_score)) +
  annotate("rect", xmin = -0.035, xmax = 1.04, ymin = -0.04, ymax = 1.17, fill = LOW, color = GRID, linewidth = 0.25) +
  geom_smooth(
    method = "lm",
    formula = y ~ x,
    se = TRUE,
    color = SCAFFOLD,
    fill = "#CED9DD",
    linewidth = 0.55,
    alpha = 0.32
  ) +
  geom_segment(
    data = correlation_callout_segments,
    aes(x = x, y = y, xend = xend, yend = yend),
    inherit.aes = FALSE,
    color = "#8C989D",
    linewidth = 0.22,
    alpha = 0.76,
    lineend = "round"
  ) +
  geom_point(
    data = correlation_points,
    aes(x = point_x, y = point_y, fill = plot_clade, alpha = plot_alpha),
    inherit.aes = FALSE,
    shape = 21,
    color = TEXT,
    stroke = 0.30,
    size = 2.65,
    alpha = 0.86
  ) +
  geom_text(
    data = correlation_points,
    aes(x = label_x, y = label_y, label = label_short, hjust = label_hjust),
    inherit.aes = FALSE,
    color = TEXT,
    size = 1.60,
    lineheight = 0.85
  ) +
  annotate(
    "text",
    x = 1.055,
    y = 0.125,
    hjust = 1,
    label = sprintf("rho = %.2f; r = %.2f; R2 = %.2f", unname(spearman_scaffold_derived$estimate), unname(pearson_scaffold_derived$estimate), lm_summary$r.squared),
    color = TEXT,
    size = 1.45,
    lineheight = 0.90
  ) +
  scale_fill_manual(
    values = clade_cols,
    breaks = names(clade_cols),
    name = NULL,
    guide = guide_legend(
      override.aes = list(alpha = 0.88, size = 2.4, shape = 21, color = TEXT),
      keyheight = grid::unit(0.20, "cm"),
      keywidth = grid::unit(0.20, "cm")
    )
  ) +
  scale_alpha_identity() +
  coord_cartesian(xlim = c(-0.10, 1.15), ylim = c(-0.08, 1.20), clip = "off") +
  scale_x_continuous(breaks = c(0, 0.50, 1.00)) +
  scale_y_continuous(breaks = c(0, 0.50, 1.00)) +
  labs(
    title = NULL,
    subtitle = NULL,
    x = "Conoid complexity",
    y = "ICMT and ICAT conservation"
  ) +
  theme_classic(base_family = "Arial", base_size = 6.0) +
  theme(
    plot.background = element_rect(fill = PANEL, color = NA),
    panel.background = element_rect(fill = PANEL, color = NA),
    legend.position = c(0.18, 0.90),
    legend.justification = c(0, 1),
    legend.background = element_blank(),
    legend.key = element_blank(),
    legend.text = element_text(color = TEXT, size = 4.9),
    axis.line = element_line(linewidth = 0.35, color = TEXT),
    axis.ticks = element_line(linewidth = 0.35, color = TEXT),
    axis.title = element_text(color = TEXT, size = 5.9),
    axis.text = element_text(color = MUTED, size = 5.3),
    plot.margin = margin(3, 4, 3, 4)
  )

save_figure <- function(plot, stem, width_cm, height_cm) {
  ggsave(file.path(png_dir, paste0(stem, ".png")), plot = plot, width = width_cm / 2.54, height = height_cm / 2.54, units = "in", dpi = 600, device = ragg::agg_png, bg = "white")
  ggsave(file.path(pdf_dir, paste0(stem, ".pdf")), plot = plot, width = width_cm / 2.54, height = height_cm / 2.54, units = "in", device = grDevices::cairo_pdf, family = "Arial")
  ggsave(file.path(svg_dir, paste0(stem, ".svg")), plot = plot, width = width_cm / 2.54, height = height_cm / 2.54, units = "in", device = grDevices::svg, bg = "white")
}

stem <- "Fig5_conoid_scaffold_score_tree_protein_barcode_NatureMicrobiology_style"
save_figure(combined_plot, stem, width_cm = 6.5, height_cm = 6.5)
cor_stem <- "Fig5_conoid_scaffold_vs_derived_module_correlation_NatureMicrobiology_style"
save_figure(correlation_plot, cor_stem, width_cm = 6.0, height_cm = 6.0)
supp_barcode_stem <- "Fig5S_strict_protein_barcode_by_structure_NatureMicrobiology_style"
save_figure(supp_barcode_plot, supp_barcode_stem, width_cm = 16.0, height_cm = 12.0)
supp_barcode_percent_stem <- "Fig5S_strict_protein_barcode_by_structure_percentage_NatureMicrobiology_style"
save_figure(supp_barcode_percent_plot, supp_barcode_percent_stem, width_cm = 16.0, height_cm = 12.0)

correlation_source_export <- correlation_source_all %>%
  left_join(
    correlation_points %>%
      select(
        species,
        point_x,
        point_y,
        label_x,
        label_y,
        callout_dx,
        callout_dy,
        callout_start_x,
        callout_start_y,
        callout_elbow_x,
        callout_elbow_y,
        callout_end_x,
        callout_end_y,
        n_at_coordinate,
        coordinate_rank
      ),
    by = "species"
  )

write.csv(leaf_df, file.path(table_dir, "conoid_scaffold_score_tree_species_order.csv"), row.names = FALSE)
write.csv(barcode_df, file.path(table_dir, "conoid_scaffold_score_tree_protein_barcode_source.csv"), row.names = FALSE)
write.csv(supp_barcode_df, file.path(table_dir, "strict_protein_barcode_by_structure_source.csv"), row.names = FALSE)
write.csv(supp_col_percentages, file.path(table_dir, "strict_protein_barcode_by_structure_column_percentages.csv"), row.names = FALSE)
write.csv(supp_row_module_percentages, file.path(table_dir, "strict_protein_barcode_by_structure_row_module_percentages_long.csv"), row.names = FALSE)
write.csv(supp_row_module_summary, file.path(table_dir, "strict_protein_barcode_by_structure_row_module_percentages_wide.csv"), row.names = FALSE)
write.csv(section_glyph_source, file.path(table_dir, "conoid_scaffold_score_tree_section_glyph_source.csv"), row.names = FALSE)
write.csv(correlation_source_export, file.path(table_dir, "conoid_scaffold_vs_derived_module_correlation_source.csv"), row.names = FALSE)
write.csv(correlation_stats, file.path(table_dir, "conoid_scaffold_vs_derived_module_correlation_stats.csv"), row.names = FALSE)
write.csv(
  data.frame(
    metric = c("rho_scaffold_ICMTs", "rho_scaffold_ICAT", "rho_scaffold_derived"),
    spearman_rho = c(rho_scaffold_icmt, rho_scaffold_icat, rho_scaffold_derived)
  ),
  file.path(table_dir, "conoid_scaffold_score_tree_correlations.csv"),
  row.names = FALSE
)

report <- c(
  "# Morphology-gated conoid scaffold index with protein-count section glyphs",
  "",
  "## Figure contract",
  "",
  "- Core claim: a morphology-gated conoid complexity axis places assembled/high-scaffold species in columns enriched for ICMT/ICMAP and ICAT protein signals.",
  "- Evidence chain: the top ladder axis is ordered and branch-scaled by a morphology-gated scaffold index; the lower section-glyph rows summarize strict reference-protein conservation after the order is fixed.",
  "- Archetype: Nature-style tree plus protein-composition section glyphs.",
  "",
  "## Quantitative readouts",
  "",
  sprintf("- Spearman rho, morphology-gated conoid scaffold index versus ICMT/ICMAP score: %.2f.", rho_scaffold_icmt),
  sprintf("- Spearman rho, morphology-gated conoid scaffold index versus ICAT strict score: %.2f.", rho_scaffold_icat),
  sprintf("- Spearman rho, morphology-gated conoid scaffold index versus mean derived-module score: %.2f.", rho_scaffold_derived),
  sprintf("- Pearson r, morphology-gated conoid scaffold index versus mean derived-module score: %.2f.", unname(pearson_scaffold_derived$estimate)),
  sprintf("- Linear-model R2, morphology-gated conoid scaffold index predicting mean derived-module score: %.2f.", lm_summary$r.squared),
  "",
  "## Interpretation boundary",
  "",
  "For the main figure, the plain-language axis labels are Conoid complexity and ICMT and ICAT conservation. The first retains the morphology weighting; the second is the equal-weight mean of ICMT protein retention and the binary ICAT call.",
  "This ladder axis is a structure-complexity summary, not a formal species phylogeny.",
  "For target species, the x-axis index is calculated as `Tg conoid-scaffold ortholog fraction x morphology gate`, where morphology gate = 0 for no obvious mature conoid, 0.5 for reduced/molecularly retained conoid and 1 for highly developed conoid.",
  "The ungated `conoid_scaffold_ortholog_fraction` is retained in source tables as the molecular scaffold-retention audit column.",
  "In the companion correlation plot, each target species is shown as one fixed-size circle. Fill color encodes the requested clade grouping: Coccidia, Piroplasmida or Haemosporidia. Eimeria tenella remains in the Coccidia group but is drawn with reduced opacity to mark low-confidence ICAT evidence. Small deterministic offsets separate species with identical coordinates; species labels use fixed elbow callout leaders with a short horizontal stub plus an angled leader segment.",
  "Cryptosporidium parvum is retained as Cryptosporidia in `source_clade`; in this three-colour display it uses the same orange reduced/non-coccidian colour family as the Haemosporidia display group.",
  "Each circular glyph is split by the actual number of reference proteins in that structure: 19 Conoid scaffold proteins, 10 ICMT/ICMAP proteins and 1 ICAT protein.",
  "The supplementary protein barcode expands the same strict binary calls at one square per reference protein, grouped by Conoid scaffold, ICMT/ICMAP and ICAT modules.",
  "Within the Conoid scaffold and ICMT/ICMAP blocks of the supplementary barcode, protein columns are ordered by descending species-level strict presence percentage; ties retain the curated input order.",
  "A companion percentage-barcode version keeps the same strict binary matrix but changes marginal bar plots to percentages: top bars show the percentage of target species with each protein present; left bars show within-species module fractions separately for Conoid scaffold, ICMT/ICMAP and ICAT.",
  "The three left-side module fractions are not multiplied. The exported wide summary includes an equal-weight module mean only as an optional audit column, because multiplying modules would collapse biologically informative scaffold-only states to zero when a derived module is absent.",
  "Each section is a strict binary OrthoMCL readout: filled = at least one strict orthogroup hit for that Toxoplasma reference protein; pale = no strict hit. Weak candidate calls, low-similarity homologs and morphology-informed overrides are not used for the section glyphs.",
  "In the percentage barcode, the Eimeria tenella ICAT low-confidence candidate is marked with a small purple cross over the pale ICAT square. It is annotated as weak evidence but is not counted as strict present.",
  "Because the column order and branch heights are determined from the morphology-gated scaffold index alone, enrichment of ICMT/ICMAP and ICAT signals in high-index columns is an overlaid association rather than circular clustering.",
  "Ciliates, Perkinsus and Chromera are retained as evolutionary context columns on the complexity axis. Their section glyphs are not morphology-proxy filled and remain pale unless a strict per-protein OrthoMCL hit is present in the source table.",
  "The companion correlation plot quantifies morphology-gated conoid scaffold index versus mean strict ICMT/ICAT fraction using protein-conservation species only. It supports a scaffold-complexity-driven model, but correlation alone should be described as consistent with rather than definitive proof of causality.",
  "",
  "## Outputs",
  "",
  paste0("- `", stem, ".pdf`"),
  paste0("- `", stem, ".png`"),
  paste0("- `", stem, ".svg`"),
  paste0("- `", cor_stem, ".pdf`"),
  paste0("- `", cor_stem, ".png`"),
  paste0("- `", cor_stem, ".svg`"),
  paste0("- `", supp_barcode_stem, ".pdf`"),
  paste0("- `", supp_barcode_stem, ".png`"),
  paste0("- `", supp_barcode_stem, ".svg`"),
  paste0("- `", supp_barcode_percent_stem, ".pdf`"),
  paste0("- `", supp_barcode_percent_stem, ".png`"),
  paste0("- `", supp_barcode_percent_stem, ".svg`"),
  "- `conoid_scaffold_score_tree_species_order.csv`",
  "- `conoid_scaffold_score_tree_protein_barcode_source.csv`",
  "- `strict_protein_barcode_by_structure_source.csv`",
  "- `strict_protein_barcode_by_structure_column_percentages.csv`",
  "- `strict_protein_barcode_by_structure_row_module_percentages_long.csv`",
  "- `strict_protein_barcode_by_structure_row_module_percentages_wide.csv`",
  "- `conoid_scaffold_score_tree_section_glyph_source.csv`",
  "- `conoid_scaffold_score_tree_correlations.csv`",
  "- `conoid_scaffold_vs_derived_module_correlation_source.csv`",
  "- `conoid_scaffold_vs_derived_module_correlation_stats.csv`"
)
writeLines(report, file.path(report_dir, "conoid_scaffold_score_tree_protein_barcode_NatureMicrobiology_style.md"))

message("Wrote conoid scaffold score-derived structural tree with protein-count section glyphs to: ", figure_dir)
