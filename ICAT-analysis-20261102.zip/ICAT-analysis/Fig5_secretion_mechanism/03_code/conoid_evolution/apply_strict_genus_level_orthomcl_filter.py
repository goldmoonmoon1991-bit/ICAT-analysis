#!/usr/bin/env python3
"""
Apply Alveolates-only OrthoMCL distribution filtering.

This script re-checks the full member list of each OrthoMCL group in an
input candidate table. It then:

1. Collapses homolog detection to genus level.
2. Recomputes the binary pattern across the target genera.
3. Marks groups/genes that contain homologs outside Alveolates (ALVE).
4. Applies a tolerant ICAT/ICMAP pattern rule within the target genera.

Default input:
  04_results/tables/conoid_evolution/orthomcl_cooccurrence/ICAT_ICMAP_module_cooccurrence_scan.csv

The pass rule implemented here is:
  an orthogroup passes only if non-alveolate eukaryotic members are no more
  than 10% of all eukaryotic members and the target-genus pattern is
  compatible with 00001111111.

Pattern tolerance:
  the first four expected-zero positions may contain at most one 1;
  the last seven expected-one positions may contain at most two 0s.
"""

from __future__ import annotations

import csv
import json
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "04_results" / "tables" / "conoid_evolution" / "orthomcl_cooccurrence"
DEFAULT_INPUT = OUT / "ICAT_ICMAP_module_cooccurrence_scan.csv"
CACHE_DIR = OUT / "orthomcl_group_member_cache"
ORTHOMCL_SEQUENCE_BY_ACCESSION = (
    "https://orthomcl.org/orthomcl/service/record-types/sequence/"
    "searches/ByAccession/reports/standard"
)

TARGET_LABELS = [
    "Babesia bovis",
    "Theileria annulata",
    "Plasmodium falciparum",
    "Cryptosporidium parvum",
    "Toxoplasma gondii",
    "Neospora caninum",
    "Hammondia hammondi",
    "Eimeria tenella",
    "Sarcocystis neurona",
    "Besnoitia besnoiti",
    "Cystoisospora suis",
]
TARGET_GENERA = [name.split()[0] for name in TARGET_LABELS]
TARGET_GENERA_SET = set(TARGET_GENERA)
EXPECTED_ICAT_ICMAP_PATTERN = "00001111111"
MAX_FRONT_ZERO_VIOLATIONS = 1
MAX_BACK_ONE_VIOLATIONS = 2
MAX_NON_ALVEOLATE_EUKA_FRACTION = 0.10

# Curated genus-level allowlists for auditing OrthoMCL members.
APICOMPLEXA_GENERA = sorted(
    {
        *TARGET_GENERA_SET,
        "Adelina",
        "Ascogregarina",
        "Babesia",
        "Besnoitia",
        "Calyptospora",
        "Cardiosporidium",
        "Caryospora",
        "Cryptosporidium",
        "Cyclospora",
        "Cystoisospora",
        "Cytauxzoon",
        "Eimeria",
        "Frenkelia",
        "Gregarina",
        "Haemoproteus",
        "Hammondia",
        "Hepatocystis",
        "Hepatozoon",
        "Isospora",
        "Klossia",
        "Lankesterella",
        "Lecudina",
        "Leucocytozoon",
        "Monocystis",
        "Neospora",
        "Plasmodium",
        "Porospora",
        "Sarcocystis",
        "Schellackia",
        "Theileria",
        "Toxoplasma",
    }
)
APICOMPLEXA_GENERA_SET = set(APICOMPLEXA_GENERA)

ALVEOLATE_GENERA = sorted(
    {
        *APICOMPLEXA_GENERA_SET,
        # Chromerid / colpodellid relatives commonly used as apicomplexan outgroups.
        "Chromera",
        "Vitrella",
        "Colpodella",
        "Voromonas",
        # Ciliates.
        "Blepharisma",
        "Euplotes",
        "Ichthyophthirius",
        "Oxytricha",
        "Paramecium",
        "Stentor",
        "Stylonychia",
        "Tetrahymena",
        # Dinoflagellates and perkinsids.
        "Alexandrium",
        "Amphidinium",
        "Breviolum",
        "Cladocopium",
        "Durusdinium",
        "Effrenium",
        "Fugacium",
        "Gerakladium",
        "Hematodinium",
        "Karlodinium",
        "Karenia",
        "Lingulodinium",
        "Oxyrrhis",
        "Perkinsus",
        "Polarella",
        "Prorocentrum",
        "Symbiodinium",
    }
)
ALVEOLATE_GENERA_SET = set(ALVEOLATE_GENERA)

# OrthoMCL full member lists can include bacterial/archaeal hits. These are
# excluded from the EUKA denominator for the ALVE/EUKA ratio rule.
NON_EUKARYOTE_GENERA = sorted(
    {
        "Acidobacterium",
        "Acidianus",
        "Agrobacterium",
        "Aquifex",
        "Archaeoglobus",
        "Bacillus",
        "Bacteroides",
        "Bradyrhizobium",
        "Calditerrivibrio",
        "Caldimicrobium",
        "Caldivirga",
        "Campylobacter",
        "Chitinivibrio",
        "Chlamydia",
        "Chlorobaculum",
        "Chloroflexus",
        "Clostridium",
        "Coxiella",
        "Dehalococcoides",
        "Deinococcus",
        "Desulfurococcus",
        "Desulfurispirillum",
        "Dictyoglomus",
        "Escherichia",
        "Francisella",
        "Fusobacterium",
        "Gemmatimonas",
        "Geobacter",
        "Gloeobacter",
        "Halobacterium",
        "Haloquadratum",
        "Helicobacter",
        "Hyperthermus",
        "Ignicoccus",
        "Korarchaeum",
        "Leptospira",
        "Listeria",
        "Methanocaldococcus",
        "Methanococcus",
        "Methanopyrus",
        "Methanosarcina",
        "Methanothermobacter",
        "Metallosphaera",
        "Mycobacterium",
        "Nanoarchaeum",
        "Neisseria",
        "Nitrosopumilus",
        "Picrophilus",
        "Pseudomonas",
        "Pyrobaculum",
        "Pyrodictium",
        "Pyrolobus",
        "Ralstonia",
        "Rhodopirellula",
        "Rickettsia",
        "Shigella",
        "Staphylothermus",
        "Streptomyces",
        "Sulfolobus",
        "Synechocystis",
        "Thermobaculum",
        "Thermococcus",
        "Thermodesulfovibrio",
        "Thermofilum",
        "Thermosphaera",
        "Thermotoga",
        "Treponema",
        "Verrucomicrobium",
        "Vibrio",
        "Wolinella",
        "Yersinia",
    }
)
NON_EUKARYOTE_GENERA_SET = set(NON_EUKARYOTE_GENERA)


def post_json(url: str, payload: dict[str, Any], attempts: int = 3) -> dict[str, Any]:
    body = json.dumps(payload).encode("utf-8")
    request = urllib.request.Request(
        url,
        data=body,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    last_error: Exception | None = None
    for attempt in range(1, attempts + 1):
        try:
            with urllib.request.urlopen(request, timeout=180) as response:
                return json.load(response)
        except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as exc:
            last_error = exc
            if attempt < attempts:
                time.sleep(2 * attempt)
    raise RuntimeError(f"POST failed for {url}: {last_error}")


def genus_from_taxon_name(taxon_name: str) -> str:
    text = (taxon_name or "").replace("<i>", "").replace("</i>", "").strip()
    return text.split()[0] if text else ""


def fetch_group_members(group_id: str) -> list[dict[str, str]]:
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    cache_file = CACHE_DIR / f"{urllib.parse.quote(group_id, safe='')}.json"
    if cache_file.exists():
        return json.loads(cache_file.read_text(encoding="utf-8"))

    payload = {
        "searchConfig": {"parameters": {"accession": group_id}},
        "reportConfig": {
            "attributes": ["primary_key", "taxon_name", "product", "group_link"]
        },
    }
    data = post_json(ORTHOMCL_SEQUENCE_BY_ACCESSION, payload)
    members: list[dict[str, str]] = []
    for record in data.get("records", []):
        attrs = record.get("attributes", {})
        sequence_id = attrs.get("primary_key", "")
        taxon_name = attrs.get("taxon_name", "")
        product = attrs.get("product", "")
        members.append(
            {
                "orthogroup": group_id,
                "sequence_id": sequence_id,
                "taxon_name": taxon_name,
                "genus": genus_from_taxon_name(taxon_name),
                "product": product,
            }
        )
    cache_file.write_text(json.dumps(members, indent=2), encoding="utf-8")
    return members


def prefetch_group_members(group_ids: list[str], max_workers: int = 24) -> None:
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    missing = []
    for group_id in sorted(set(group_ids)):
        cache_file = CACHE_DIR / f"{urllib.parse.quote(group_id, safe='')}.json"
        if not cache_file.exists():
            missing.append(group_id)
    if not missing:
        return
    print(
        f"Fetching {len(missing)} OrthoMCL group member lists with {max_workers} workers...",
        flush=True,
    )
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(fetch_group_members, group_id): group_id for group_id in missing}
        completed = 0
        for future in as_completed(futures):
            group_id = futures[future]
            try:
                future.result()
            except Exception as exc:
                raise RuntimeError(f"Failed to fetch members for {group_id}: {exc}") from exc
            completed += 1
            if completed % 25 == 0 or completed == len(missing):
                print(f"  fetched {completed}/{len(missing)}", flush=True)


def parse_orthogroups(value: str) -> list[str]:
    return [part for part in (value or "").split(";") if part]


def pattern_for_genera(genera: set[str]) -> str:
    return "".join("1" if genus in genera else "0" for genus in TARGET_GENERA)


def tolerant_pattern_metrics(pattern: str) -> dict[str, Any]:
    front_zero_violations = sum(1 for char in pattern[:4] if char == "1")
    back_one_violations = sum(1 for char in pattern[4:] if char == "0")
    tolerant_pass = (
        front_zero_violations <= MAX_FRONT_ZERO_VIOLATIONS
        and back_one_violations <= MAX_BACK_ONE_VIOLATIONS
    )
    return {
        "expected_pattern": EXPECTED_ICAT_ICMAP_PATTERN,
        "front_zero_violations": front_zero_violations,
        "back_one_violations": back_one_violations,
        "tolerant_pattern_pass": int(tolerant_pass),
    }


def summarize_members(groups: list[str]) -> dict[str, Any]:
    all_members: list[dict[str, str]] = []
    for group_id in groups:
        all_members.extend(fetch_group_members(group_id))

    member_genera = {m["genus"] for m in all_members if m.get("genus")}
    target_present = member_genera & TARGET_GENERA_SET
    eukaryote_members = [
        m
        for m in all_members
        if m.get("genus") and m["genus"] not in NON_EUKARYOTE_GENERA_SET
    ]
    non_eukaryote_members = [
        m
        for m in all_members
        if m.get("genus") and m["genus"] in NON_EUKARYOTE_GENERA_SET
    ]
    non_alveolate_euka_members = [
        m
        for m in eukaryote_members
        if m.get("genus") and m["genus"] not in ALVEOLATE_GENERA_SET
    ]
    eukaryote_member_count = len(eukaryote_members)
    non_alveolate_euka_member_count = len(non_alveolate_euka_members)
    non_alveolate_euka_fraction = (
        non_alveolate_euka_member_count / eukaryote_member_count
        if eukaryote_member_count
        else 0.0
    )
    non_alveolate_euka_genera = sorted(
        {m["genus"] for m in non_alveolate_euka_members if m.get("genus")}
    )
    non_eukaryote_genera = sorted(
        {m["genus"] for m in non_eukaryote_members if m.get("genus")}
    )
    other_alveolate_genera = sorted(
        (member_genera & ALVEOLATE_GENERA_SET) - TARGET_GENERA_SET
    )
    non_alveolate_euka_taxa = sorted(
        {m["taxon_name"] for m in non_alveolate_euka_members if m.get("taxon_name")}
    )
    non_eukaryote_taxa = sorted(
        {m["taxon_name"] for m in non_eukaryote_members if m.get("taxon_name")}
    )
    target_pattern = pattern_for_genera(target_present)
    pattern_metrics = tolerant_pattern_metrics(target_pattern)
    alveolates_only = non_alveolate_euka_fraction <= MAX_NON_ALVEOLATE_EUKA_FRACTION
    return {
        "member_count": len(all_members),
        "member_genera": sorted(member_genera),
        "target_present_genera": sorted(target_present),
        "other_alveolate_genera": other_alveolate_genera,
        "eukaryote_member_count": eukaryote_member_count,
        "non_alveolate_euka_member_count": non_alveolate_euka_member_count,
        "non_alveolate_euka_fraction": non_alveolate_euka_fraction,
        "non_alveolate_euka_genera": non_alveolate_euka_genera,
        "non_alveolate_euka_taxa": non_alveolate_euka_taxa,
        "non_eukaryote_member_count": len(non_eukaryote_members),
        "non_eukaryote_genera": non_eukaryote_genera,
        "non_eukaryote_taxa": non_eukaryote_taxa,
        "target_genus_pattern": target_pattern,
        "alveolates_only": int(alveolates_only),
        **pattern_metrics,
        "alveolates_only_tolerant_pass": int(
            alveolates_only and pattern_metrics["tolerant_pattern_pass"]
        ),
    }


def main() -> None:
    input_path = DEFAULT_INPUT
    rows = list(csv.DictReader(input_path.open()))
    if not rows:
        raise RuntimeError(f"No rows in {input_path}")
    candidate_rows = [
        (index, row)
        for index, row in enumerate(rows, start=1)
        if tolerant_pattern_metrics(row.get("species_pattern", ""))["tolerant_pattern_pass"]
    ]
    all_group_ids = sorted(
        {
            group_id
            for _index, row in candidate_rows
            for group_id in parse_orthogroups(row.get("orthogroups", ""))
        }
    )
    prefetch_group_members(all_group_ids)

    module_summary_path = OUT / "ICAT_ICMAP_module_summary.json"
    module_summary = json.loads(module_summary_path.read_text(encoding="utf-8"))
    majority_pattern = module_summary["module_majority_pattern"]
    union_pattern = module_summary["module_union_pattern"]
    intersection_pattern = module_summary["module_intersection_pattern"]

    annotated_rows: list[dict[str, Any]] = []
    group_member_rows: list[dict[str, str]] = []
    for index, row in candidate_rows:
        groups = parse_orthogroups(row.get("orthogroups", ""))
        summary = summarize_members(groups)
        for group_id in groups:
            group_member_rows.extend(fetch_group_members(group_id))

        target_pattern = summary["target_genus_pattern"]
        annotated = {
            "rank_in_input": str(index),
            **row,
            "target_genus_pattern": target_pattern,
            "expected_icat_icmap_pattern": summary["expected_pattern"],
            "front_zero_violations": str(summary["front_zero_violations"]),
            "back_one_violations": str(summary["back_one_violations"]),
            "tolerant_pattern_pass": str(summary["tolerant_pattern_pass"]),
            "alveolates_only": str(summary["alveolates_only"]),
            "alveolates_only_tolerant_pass": str(
                summary["alveolates_only_tolerant_pass"]
            ),
            "present_target_genera": ";".join(summary["target_present_genera"]),
            "other_alveolate_genera": ";".join(summary["other_alveolate_genera"]),
            "member_count": str(summary["member_count"]),
            "member_genera": ";".join(summary["member_genera"]),
            "eukaryote_member_count": str(summary["eukaryote_member_count"]),
            "non_alveolate_euka_member_count": str(
                summary["non_alveolate_euka_member_count"]
            ),
            "non_alveolate_euka_fraction": (
                f"{summary['non_alveolate_euka_fraction']:.4f}"
            ),
            "max_non_alveolate_euka_fraction": (
                f"{MAX_NON_ALVEOLATE_EUKA_FRACTION:.4f}"
            ),
            "non_alveolate_euka_genera": ";".join(
                summary["non_alveolate_euka_genera"]
            ),
            "non_alveolate_euka_taxa": ";".join(summary["non_alveolate_euka_taxa"]),
            "non_eukaryote_member_count": str(summary["non_eukaryote_member_count"]),
            "non_eukaryote_genera": ";".join(summary["non_eukaryote_genera"]),
            "non_eukaryote_taxa": ";".join(summary["non_eukaryote_taxa"]),
            "matches_module_majority_exact": str(int(target_pattern == majority_pattern)),
            "matches_module_union_exact": str(int(target_pattern == union_pattern)),
            "matches_module_intersection_exact": str(
                int(target_pattern == intersection_pattern)
            ),
            "matches_original_species_pattern_exact": str(
                int(target_pattern == row.get("species_pattern", ""))
            ),
        }
        annotated_rows.append(annotated)

    base = input_path.stem
    annotated_path = OUT / f"{base}_alveolates_tolerant.csv"
    fieldnames = list(annotated_rows[0].keys())
    with annotated_path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(annotated_rows)

    alveolates_only_rows = [r for r in annotated_rows if r["alveolates_only"] == "1"]
    alveolates_only_path = OUT / f"{base}_alveolates_only.csv"
    with alveolates_only_path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(alveolates_only_rows)

    tolerant_pattern_rows = [
        r for r in annotated_rows if r["tolerant_pattern_pass"] == "1"
    ]
    tolerant_pattern_path = OUT / f"{base}_tolerant_pattern.csv"
    with tolerant_pattern_path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(tolerant_pattern_rows)

    pass_rows = [
        r for r in annotated_rows if r["alveolates_only_tolerant_pass"] == "1"
    ]
    pass_path = OUT / f"{base}_alveolates_only_tolerant_pass.csv"
    with pass_path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(pass_rows)

    pass_clean_fields = [
        "rank_in_input",
        "gene_id",
        "orthogroups",
        "toxodb_product",
        "orthomcl_product",
        "target_genus_pattern",
        "front_zero_violations",
        "back_one_violations",
        "present_target_genera",
        "other_alveolate_genera",
        "member_count",
        "eukaryote_member_count",
        "non_alveolate_euka_member_count",
        "non_alveolate_euka_fraction",
        "module_mean_jaccard",
        "module_min_jaccard",
        "module_mean_cosine",
    ]
    pass_clean_path = OUT / f"{base}_alveolates_only_tolerant_pass_clean.csv"
    with pass_clean_path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=pass_clean_fields)
        writer.writeheader()
        for row in pass_rows:
            writer.writerow({field: row.get(field, "") for field in pass_clean_fields})

    pass_clean_md_path = OUT / f"{base}_alveolates_only_tolerant_pass_clean.md"
    md_fields = [
        "rank_in_input",
        "gene_id",
        "target_genus_pattern",
        "front_zero_violations",
        "back_one_violations",
        "non_alveolate_euka_fraction",
        "other_alveolate_genera",
        "toxodb_product",
    ]

    def md_cell(value: str) -> str:
        return (value or "").replace("|", "\\|")

    clean_lines = [
        "# Alveolates-only tolerant-pass shortlist",
        "",
        f"- Rows: `{len(pass_rows)}`",
        f"- Expected pattern: `{EXPECTED_ICAT_ICMAP_PATTERN}`",
        f"- ALVE/EUKA ratio rule: non-ALVE EUKA members <= `{MAX_NON_ALVEOLATE_EUKA_FRACTION:.0%}` of all EUKA members.",
        f"- Tolerance: first four 0 positions <= `{MAX_FRONT_ZERO_VIOLATIONS}` unexpected 1; last seven 1 positions <= `{MAX_BACK_ONE_VIOLATIONS}` missing 1.",
        "",
        "|" + "|".join(md_fields) + "|",
        "|" + "|".join(["---"] * len(md_fields)) + "|",
    ]
    for row in pass_rows:
        clean_lines.append("|" + "|".join(md_cell(row.get(field, "")) for field in md_fields) + "|")
    pass_clean_md_path.write_text("\n".join(clean_lines) + "\n", encoding="utf-8")

    members_path = OUT / f"{base}_alveolates_tolerant_group_members.csv"
    member_fields = ["orthogroup", "sequence_id", "taxon_name", "genus", "product"]
    seen_members = set()
    with members_path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=member_fields)
        writer.writeheader()
        for member in group_member_rows:
            key = (member["orthogroup"], member["sequence_id"])
            if key in seen_members:
                continue
            seen_members.add(key)
            writer.writerow(member)

    pattern_counts = Counter(r["target_genus_pattern"] for r in annotated_rows)
    non_alveolate_euka_genus_counts = Counter()
    non_eukaryote_genus_counts = Counter()
    other_alveolate_genus_counts = Counter()
    for row in annotated_rows:
        for genus in row["non_alveolate_euka_genera"].split(";"):
            if genus:
                non_alveolate_euka_genus_counts[genus] += 1
        for genus in row["non_eukaryote_genera"].split(";"):
            if genus:
                non_eukaryote_genus_counts[genus] += 1
        for genus in row["other_alveolate_genera"].split(";"):
            if genus:
                other_alveolate_genus_counts[genus] += 1

    summary = {
        "input": str(input_path),
        "input_rows": len(rows),
        "pattern_prefiltered_rows_audited": len(annotated_rows),
        "target_labels": TARGET_LABELS,
        "target_genera": TARGET_GENERA,
        "apicomplexa_genera_allowlist": APICOMPLEXA_GENERA,
        "alveolate_genera_allowlist": ALVEOLATE_GENERA,
        "non_eukaryote_genera_excluded_from_euka_denominator": NON_EUKARYOTE_GENERA,
        "expected_icat_icmap_pattern": EXPECTED_ICAT_ICMAP_PATTERN,
        "tolerance": {
            "first_four_expected_zero_max_ones": MAX_FRONT_ZERO_VIOLATIONS,
            "last_seven_expected_one_max_zeros": MAX_BACK_ONE_VIOLATIONS,
            "non_alveolate_euka_fraction_max": MAX_NON_ALVEOLATE_EUKA_FRACTION,
        },
        "module_majority_pattern": majority_pattern,
        "module_union_pattern": union_pattern,
        "module_intersection_pattern": intersection_pattern,
        "alveolates_only_count": len(alveolates_only_rows),
        "tolerant_pattern_count": len(candidate_rows),
        "alveolates_only_tolerant_pass_count": len(pass_rows),
        "target_genus_pattern_counts": dict(pattern_counts),
        "non_alveolate_euka_genus_counts": dict(
            non_alveolate_euka_genus_counts.most_common()
        ),
        "non_eukaryote_genus_counts": dict(non_eukaryote_genus_counts.most_common()),
        "other_alveolate_genus_counts": dict(
            other_alveolate_genus_counts.most_common()
        ),
        "outputs": {
            "annotated": str(annotated_path),
            "alveolates_only": str(alveolates_only_path),
            "tolerant_pattern": str(tolerant_pattern_path),
            "alveolates_only_tolerant_pass": str(pass_path),
            "alveolates_only_tolerant_pass_clean": str(pass_clean_path),
            "alveolates_only_tolerant_pass_clean_md": str(pass_clean_md_path),
            "group_members": str(members_path),
            "cache_dir": str(CACHE_DIR),
        },
    }
    summary_path = OUT / f"{base}_alveolates_tolerant_summary.json"
    summary_path.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")

    md_path = OUT / f"{base}_alveolates_tolerant_summary.md"
    lines = [
        "# Alveolates-only tolerant OrthoMCL filter",
        "",
        f"- Input: `{input_path}`",
        f"- Input rows: `{len(rows)}`",
        f"- Pattern-prefiltered rows audited with full OrthoMCL members: `{len(annotated_rows)}`",
        f"- Target genera: `{', '.join(TARGET_GENERA)}`",
        f"- Expected ICAT/ICMAP pattern: `{EXPECTED_ICAT_ICMAP_PATTERN}`",
        f"- ALVE/EUKA ratio rule: non-ALVE EUKA members must be <= `{MAX_NON_ALVEOLATE_EUKA_FRACTION:.0%}` of all EUKA members.",
        (
            "- Tolerance: first four expected-zero positions allow at most "
            f"`{MAX_FRONT_ZERO_VIOLATIONS}` one; last seven expected-one "
            f"positions allow at most `{MAX_BACK_ONE_VIOLATIONS}` zeros."
        ),
        f"- Module majority pattern from seed scan: `{majority_pattern}`",
        f"- Alveolates-only rows: `{len(alveolates_only_rows)}`",
        f"- Tolerant-pattern rows: `{len(tolerant_pattern_rows)}`",
        f"- Alveolates-only + tolerant-pattern rows: `{len(pass_rows)}`",
        "",
        "## Output files",
        "",
        f"- Annotated table: `{annotated_path}`",
        f"- Alveolates-only rows: `{alveolates_only_path}`",
        f"- Tolerant-pattern rows: `{tolerant_pattern_path}`",
        f"- Alveolates-only + tolerant-pattern rows: `{pass_path}`",
        f"- Clean shortlist CSV: `{pass_clean_path}`",
        f"- Clean shortlist Markdown: `{pass_clean_md_path}`",
        f"- Group member audit table: `{members_path}`",
        "",
        "## Notes",
        "",
        "- Pattern calls are recomputed at genus level across the 11 target genera.",
        "- A row fails `alveolates_only` if non-ALVE eukaryotic OrthoMCL group members are >10% of all eukaryotic group members.",
        "- Alveolate genera outside the 11 target genera are tracked in `other_alveolate_genera` but are not treated as exclusion by themselves.",
        "- Bacterial/archaeal genera are tracked in `non_eukaryote_genera` and excluded from the EUKA denominator.",
        "- Same-genus non-listed strains/species are accepted as presence for the listed genus.",
        "- Chromera and Vitrella are accepted by this rule because they are alveolate relatives within ALVE.",
    ]
    md_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
