#!/usr/bin/env python3
"""Audit the cell-level MIC2/Tubulin width-ratio shift after ICAT depletion."""

from __future__ import annotations

import csv
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
CACHE = ROOT / "04_results" / "reports" / "conoid_evolution" / ".cache" / "matplotlib"
CACHE.mkdir(parents=True, exist_ok=True)
os.environ.setdefault("MPLCONFIGDIR", str(CACHE))
os.environ.setdefault("XDG_CACHE_HOME", str(CACHE))

import matplotlib as mpl

mpl.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


PROJECT_ROOT = ROOT.parent
INPUT_DIR = PROJECT_ROOT / "Fig1_intro_spatial" / "01_raw_data" / "quantification"
OUTPUT_DIR = ROOT / "04_results" / "reports" / "conoid_evolution" / "ICATkd_width_ratio_audit"


def read_ratios(name: str) -> np.ndarray:
    values: list[float] = []
    with (INPUT_DIR / f"{name}.csv").open(newline="") as handle:
        for row in csv.reader(handle):
            if len(row) < 4:
                continue
            try:
                values.append(float(row[3]))
            except ValueError:
                continue
    return np.asarray(values, dtype=float)


def cliffs_delta(x: np.ndarray, y: np.ndarray) -> float:
    comparisons = np.sign(x[:, None] - y[None, :])
    return float(comparisons.mean())


def bootstrap_mean_difference(
    mutant: np.ndarray, control: np.ndarray, iterations: int = 20_000
) -> tuple[float, float]:
    rng = np.random.default_rng(20260706)
    chunk = 1_000
    diffs: list[np.ndarray] = []
    remaining = iterations
    while remaining:
        n = min(chunk, remaining)
        mutant_means = rng.choice(mutant, size=(n, len(mutant)), replace=True).mean(axis=1)
        control_means = rng.choice(control, size=(n, len(control)), replace=True).mean(axis=1)
        diffs.append(mutant_means - control_means)
        remaining -= n
    all_diffs = np.concatenate(diffs)
    low, high = np.quantile(all_diffs, [0.025, 0.975])
    return float(low), float(high)


def summarize(name: str, values: np.ndarray) -> dict[str, float | int | str]:
    return {
        "group": name,
        "n_cells": len(values),
        "mean": float(values.mean()),
        "median": float(np.median(values)),
        "sd": float(values.std(ddof=1)),
        "q1": float(np.quantile(values, 0.25)),
        "q3": float(np.quantile(values, 0.75)),
        "min": float(values.min()),
        "max": float(values.max()),
        "replicate_metadata_present": "no",
    }


def write_outputs(wt: np.ndarray, icat: np.ndarray) -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    rows = [summarize("WT", wt), summarize("ICATkd", icat)]
    mean_diff = float(icat.mean() - wt.mean())
    median_diff = float(np.median(icat) - np.median(wt))
    fold_change = float(icat.mean() / wt.mean())
    delta = cliffs_delta(icat, wt)
    ci_low, ci_high = bootstrap_mean_difference(icat, wt)
    wt_q95 = float(np.quantile(wt, 0.95))
    mutant_above_wt_q95 = float((icat > wt_q95).mean())

    with (OUTPUT_DIR / "ICATkd_vs_WT_width_ratio_summary.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

    with (OUTPUT_DIR / "ICATkd_vs_WT_width_ratio_effects.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["metric", "value"])
        writer.writerows(
            [
                ["mean_difference_ICATkd_minus_WT", mean_diff],
                ["cell_level_bootstrap_95CI_low", ci_low],
                ["cell_level_bootstrap_95CI_high", ci_high],
                ["median_difference_ICATkd_minus_WT", median_diff],
                ["mean_fold_change_ICATkd_over_WT", fold_change],
                ["cliffs_delta_ICATkd_vs_WT", delta],
                ["WT_95th_percentile", wt_q95],
                ["fraction_ICATkd_above_WT_95th_percentile", mutant_above_wt_q95],
            ]
        )

    report = f"""# Cell-level audit of MIC2/Tubulin width ratio after ICAT depletion

## Result

- WT: n = {len(wt)} cells, mean = {wt.mean():.3f}, median = {np.median(wt):.3f}, SD = {wt.std(ddof=1):.3f}.
- ICATkd: n = {len(icat)} cells, mean = {icat.mean():.3f}, median = {np.median(icat):.3f}, SD = {icat.std(ddof=1):.3f}.
- Mean shift (ICATkd - WT): {mean_diff:.3f}; cell-level bootstrap 95% interval {ci_low:.3f} to {ci_high:.3f}.
- Mean fold change: {fold_change:.2f}x.
- Cliff's delta: {delta:.3f}.
- {mutant_above_wt_q95:.1%} of ICATkd cells exceed the WT 95th percentile ({wt_q95:.3f}).

The existing measurements show a large expansion of the MIC2-positive width relative to the Tubulin-defined conoid reference after ICAT depletion. This is directionally consistent with loss of microneme spatial restriction and strengthens the terminal-positioning model.

## Statistical boundary

The source workbook contains only group, MIC2 width, Tubulin width, and ratio. It has no biological-replicate, acquisition-date, field, clone, or treatment-batch identifiers. Consequently:

- the values above are cell-level descriptive statistics;
- the bootstrap interval treats cells as the resampling unit and is exploratory, not a biological-replicate confidence interval;
- no cell-level P value should be presented as definitive inferential evidence;
- the effect must be reproduced with at least three independently identified biological replicates and analyzed with replicate-aware statistics.

## Mechanistic interpretation

This width ratio reports lateral spread relative to the conoid reference. It supports altered spatial restriction, but by itself does not distinguish:

1. failed terminal capture/positioning;
2. increased number or accumulation of micronemes near the apex;
3. altered conoid geometry;
4. indirect imaging or segmentation effects.

Pair this readout with conoid dimensions, total/apical MIC2 abundance, same-cell angular position, and live arrival/dwell measurements before claiming a specific transport mechanism.
"""
    (OUTPUT_DIR / "ICATkd_vs_WT_width_ratio_audit.md").write_text(report)

    mpl.rcParams.update({"font.family": "DejaVu Sans", "pdf.fonttype": 42, "svg.fonttype": "none"})
    fig, axes = plt.subplots(1, 2, figsize=(8.4, 3.8), gridspec_kw={"width_ratios": [1.05, 1]})
    colors = ["#4E777D", "#B04472"]
    rng = np.random.default_rng(41)
    for idx, (label, values, color) in enumerate(zip(["WT", "ICATkd"], [wt, icat], colors), start=1):
        jitter = rng.uniform(-0.16, 0.16, len(values))
        axes[0].scatter(np.full(len(values), idx) + jitter, values, s=16, color=color, alpha=0.68, edgecolor="none")
        axes[0].plot([idx - 0.20, idx + 0.20], [np.median(values)] * 2, color="#222222", lw=2.2)
        q1, q3 = np.quantile(values, [0.25, 0.75])
        axes[0].plot([idx, idx], [q1, q3], color="#222222", lw=1.4)
    axes[0].set_xticks([1, 2], ["WT", "ICATkd"])
    axes[0].set_ylabel("MIC2 width / Tubulin width")
    axes[0].set_title("Cell-level distributions", loc="left", fontsize=10, weight="bold")
    axes[0].grid(axis="y", color="#E4E8EA", lw=0.8)

    for label, values, color in zip(["WT", "ICATkd"], [wt, icat], colors):
        ordered = np.sort(values)
        axes[1].step(ordered, np.arange(1, len(values) + 1) / len(values), where="post", label=label, color=color, lw=2)
    axes[1].set_xlabel("MIC2 width / Tubulin width")
    axes[1].set_ylabel("Cumulative fraction")
    axes[1].set_title("Distribution shift", loc="left", fontsize=10, weight="bold")
    axes[1].legend(frameon=False)
    axes[1].grid(color="#E4E8EA", lw=0.8)

    fig.suptitle("ICAT depletion broadens the MIC2-positive domain", x=0.08, ha="left", fontsize=13, weight="bold")
    fig.text(0.08, 0.01, "Descriptive cell-level audit; source workbook lacks biological-replicate identifiers.", fontsize=8, color="#626A70")
    fig.tight_layout(rect=(0.04, 0.06, 0.99, 0.92))
    for suffix in ("png", "pdf", "svg"):
        fig.savefig(OUTPUT_DIR / f"ICATkd_vs_WT_width_ratio_audit.{suffix}", dpi=300 if suffix == "png" else None, bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    wt = read_ratios("WT")
    icat = read_ratios("ICATkd")
    write_outputs(wt, icat)


if __name__ == "__main__":
    main()
