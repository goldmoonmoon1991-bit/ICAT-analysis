#!/usr/bin/env Rscript

script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
if (length(script_arg) == 0L) {
  stop("This script must be run with Rscript so that --file is available.")
}
script_path <- normalizePath(sub("^--file=", "", script_arg[[1]]), mustWork = TRUE)
fig_dir <- normalizePath(file.path(dirname(script_path), "..", ".."), mustWork = TRUE)
project_root <- normalizePath(file.path(fig_dir, ".."), mustWork = TRUE)
source(file.path(project_root, "shared", "R", "project_library.R"))
icat_activate_project_library(project_root)

library(dplyr)
library(tidyr)
library(ggplot2)
library(patchwork)

table_dir <- file.path(
  fig_dir,
  "04_results",
  "tables",
  "conoid_evolution",
  "toxoplasma_reference_modules"
)
report_dir <- file.path(
  fig_dir,
  "04_results",
  "reports",
  "conoid_evolution",
  "toxoplasma_reference_modules"
)
figure_dir <- file.path(
  fig_dir,
  "04_results",
  "figures",
  "conoid_evolution",
  "toxoplasma_reference_modules",
  "conservation"
)
pdf_dir <- file.path(figure_dir, "PDF")
png_dir <- file.path(figure_dir, "PNG")
svg_dir <- file.path(figure_dir, "SVG")
dir.create(report_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(pdf_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(png_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(svg_dir, recursive = TRUE, showWarnings = FALSE)
font_cache <- file.path(tempdir(), "icat-fontconfig-cache")
dir.create(font_cache, recursive = TRUE, showWarnings = FALSE)
Sys.setenv(XDG_CACHE_HOME = font_cache)

representative_path <- file.path(table_dir, "toxoplasma_reference_module_representative_scores_for_fig.csv")
species_scores_path <- file.path(table_dir, "toxoplasma_reference_module_species_scores.csv")
stopifnot(file.exists(representative_path), file.exists(species_scores_path))

TEXT <- "#24282A"
MUTED <- "#68747A"
GRID <- "#DCE3E5"
PAPER <- "#F7F8F4"
PANEL <- "#FFFFFF"
CF <- "#7D8C94"
ICMT <- "#1F6370"
ICAT <- "#B44575"
AMBER <- "#D99A2B"
LOW <- "#F1F3F1"

module_cols <- c(
  `Conoid scaffold` = CF,
  `ICMT/ICMAP system` = ICMT,
  `ICAT structure` = ICAT
)

representative_order <- c(
  "Ciliates",
  "Perkinsus",
  "Chromera velia",
  "Toxoplasma gondii",
  "Cryptosporidium",
  "Plasmodium"
)

rep_scores <- read.csv(representative_path, stringsAsFactors = FALSE, check.names = FALSE) %>%
  mutate(
    conoid_scaffold_score = coalesce(conoid_scaffold_score, cf_score),
    icmt_icmap_score = coalesce(icmt_icmap_score, icmt_score),
    icat_score = coalesce(icat_score, icat_icmap_asymmetry_score),
    conoid_scaffold_complexity_score = coalesce(conoid_scaffold_complexity_score, conoid_molecular_conservation_score),
    display_species = factor(display_species, levels = representative_order),
    y_index = as.numeric(display_species),
    state = case_when(
      display_species == "Toxoplasma gondii" ~ "partitioned",
      display_species %in% c("Cryptosporidium", "Plasmodium") ~ "reduced",
      display_species == "Chromera velia" ~ "closed",
      display_species == "Perkinsus" ~ "open",
      TRUE ~ "outgroup"
    ),
    state = factor(state, levels = c("outgroup", "open", "closed", "partitioned", "reduced")),
    coupling_index = sqrt(pmax(icmt_icmap_score, 0) * pmax(icat_score, 0))
  )

rep_long <- rep_scores %>%
  select(
    display_species,
    conoid_scaffold_score,
    icmt_icmap_score,
    icat_score,
    conoid_scaffold_complexity_score
  ) %>%
  pivot_longer(
    cols = c(conoid_scaffold_score, icmt_icmap_score, icat_score),
    names_to = "module_id",
    values_to = "score"
  ) %>%
  mutate(
    module = recode(
      module_id,
      conoid_scaffold_score = "Conoid scaffold",
      icmt_icmap_score = "ICMT/ICMAP system",
      icat_score = "ICAT structure"
    ),
    module = factor(module, levels = names(module_cols)),
    display_species = factor(display_species, levels = representative_order)
  )

species_long <- read.csv(species_scores_path, stringsAsFactors = FALSE, check.names = FALSE)
if (!"module_model_score" %in% colnames(species_long)) {
  species_long$module_model_score <- species_long$module_conservation_fraction
}
if (!"strict_conservation_fraction" %in% colnames(species_long)) {
  species_long$strict_conservation_fraction <- species_long$module_conservation_fraction
}
if (!"evidence_class" %in% colnames(species_long)) {
  species_long$evidence_class <- "strict orthogroup conservation"
}
if (!"evidence_note" %in% colnames(species_long)) {
  species_long$evidence_note <- "No model override applied."
}
species_wide <- species_long %>%
  select(
    species,
    module,
    module_conservation_fraction,
    strict_conservation_fraction,
    module_model_score,
    evidence_class,
    evidence_note
  ) %>%
  mutate(
    module_id = case_when(
      module == "Conoid scaffold" ~ "conoid_scaffold_score",
      module == "ICMT/ICMAP system" ~ "icmt_icmap_score",
      module == "ICAT structure" ~ "icat_score",
      TRUE ~ module
    )
  ) %>%
  select(species, module_id, module_model_score) %>%
  pivot_wider(names_from = module_id, values_from = module_model_score) %>%
  left_join(
    species_long %>%
      filter(module == "ICAT structure") %>%
      transmute(
        species,
        icat_strict_score = strict_conservation_fraction,
        icat_model_score = module_model_score,
        icat_evidence_class = evidence_class,
        icat_evidence_note = evidence_note
      ),
    by = "species"
  ) %>%
  mutate(
    conoid_scaffold_complexity_score = conoid_scaffold_score,
    derived_specialization_score = rowMeans(select(., icmt_icmap_score, icat_score), na.rm = TRUE),
    coupling_index = sqrt(pmax(icmt_icmap_score, 0) * pmax(icat_score, 0)),
    lineage_group = case_when(
      species %in% c("Toxoplasma gondii", "Neospora caninum", "Hammondia hammondi", "Besnoitia besnoiti", "Sarcocystis neurona", "Cystoisospora suis", "Eimeria tenella") ~ "coccidian-like",
      species %in% c("Babesia bovis", "Theileria annulata", "Plasmodium falciparum") ~ "haemo/piroplasmid",
      species == "Cryptosporidium parvum" ~ "reduced apicomplexan",
      TRUE ~ "other"
    ),
    label_short = recode(
      species,
      `Toxoplasma gondii` = "Tg",
      `Neospora caninum` = "Nc",
      `Hammondia hammondi` = "Hh",
      `Besnoitia besnoiti` = "Bb",
      `Sarcocystis neurona` = "Sn",
      `Cystoisospora suis` = "Cs",
      `Eimeria tenella` = "Et",
      `Babesia bovis` = "Bbo",
      `Theileria annulata` = "Ta",
      `Plasmodium falciparum` = "Pf",
      `Cryptosporidium parvum` = "Cp",
      .default = species
    )
  )

spearman_rho <- suppressWarnings(cor(species_wide$icmt_icmap_score, species_wide$icat_score, method = "spearman"))
pearson_r <- suppressWarnings(cor(species_wide$icmt_icmap_score, species_wide$icat_score, method = "pearson"))

coupling_labels <- tibble::tribble(
  ~x, ~y, ~label_x, ~label_y, ~label,
  1.00, 1.00, 0.50, 1.08, "Tg/Nc/Hh/Sn/Be/Cs",
  1.00, 0.25, 0.76, 0.27, "Et\nweak ICAT",
  0.50, 0.00, 0.25, -0.06, "Pf/Bbo/Ta",
  0.00, 0.00, -0.06, -0.06, "Cp"
)

base_theme <- theme_classic(base_family = "Arial", base_size = 7) +
  theme(
    plot.background = element_rect(fill = PANEL, color = NA),
    panel.background = element_rect(fill = PANEL, color = NA),
    axis.line = element_line(linewidth = 0.35, color = TEXT),
    axis.ticks = element_line(linewidth = 0.30, color = TEXT),
    axis.text = element_text(color = TEXT, size = 6.7),
    axis.title = element_text(color = TEXT, size = 7.0),
    plot.title = element_text(color = TEXT, face = "bold", size = 9.0, margin = margin(b = 2)),
    plot.subtitle = element_text(color = MUTED, size = 6.5, margin = margin(b = 5)),
    legend.position = "none",
    plot.margin = margin(5, 6, 5, 6)
  )

state_cols <- c(
  outgroup = "#B8C1C5",
  open = "#31A354",
  closed = "#63A878",
  partitioned = "#E0002A",
  reduced = "#9AA4AA"
)

complexity_plot <- ggplot(rep_scores, aes(y = display_species)) +
  geom_segment(
    aes(x = 0, xend = conoid_scaffold_complexity_score, yend = display_species),
    linewidth = 1.45,
    color = "#C8D0D3",
    lineend = "round"
  ) +
  geom_point(
    aes(x = conoid_scaffold_complexity_score, fill = state),
    shape = 21,
    size = 3.2,
    color = "white",
    stroke = 0.55
  ) +
  geom_text(
    aes(x = pmin(conoid_scaffold_complexity_score + 0.055, 1.03), label = sprintf("%.2f", conoid_scaffold_complexity_score)),
    hjust = 0,
    size = 2.35,
    color = TEXT
  ) +
  scale_fill_manual(values = state_cols) +
  scale_x_continuous(
    limits = c(0, 1.10),
    breaks = c(0, 0.5, 1),
    labels = c("0", "0.5", "1"),
    expand = c(0, 0)
  ) +
  scale_y_discrete(limits = rev(representative_order)) +
  labs(
    title = "Conoid scaffold complexity",
    subtitle = "Scaffold conservation is treated as the complexity driver",
    x = "conoid scaffold conservation score",
    y = NULL
  ) +
  base_theme +
  theme(
    axis.text.y = element_text(face = "bold", size = 7.0),
    panel.grid.major.x = element_line(color = GRID, linewidth = 0.25),
    axis.line.y = element_blank(),
    axis.ticks.y = element_blank()
  )

coupling_plot <- ggplot(species_wide, aes(x = icmt_icmap_score, y = icat_score)) +
  annotate("rect", xmin = 0.72, xmax = 1.02, ymin = 0.72, ymax = 1.02, fill = "#F7DCE8", color = NA) +
  geom_abline(slope = 1, intercept = 0, linetype = "dashed", linewidth = 0.32, color = "#AEB8BC") +
  geom_point(
    aes(size = conoid_scaffold_score, fill = lineage_group),
    shape = 21,
    color = TEXT,
    stroke = 0.35,
    alpha = 0.95
  ) +
  geom_segment(
    data = coupling_labels,
    aes(x = x, y = y, xend = label_x, yend = label_y),
    inherit.aes = FALSE,
    color = "#BAC4C8",
    linewidth = 0.22
  ) +
  geom_text(
    data = coupling_labels,
    aes(x = label_x, y = label_y, label = label),
    inherit.aes = FALSE,
    size = 2.25,
    color = TEXT,
    hjust = 0,
    vjust = 0.5
  ) +
  annotate(
    "text",
    x = 0.03,
    y = 0.96,
    hjust = 0,
    vjust = 1,
    label = sprintf("Spearman rho = %.2f\nPearson r = %.2f", spearman_rho, pearson_r),
    size = 2.35,
    color = MUTED,
    lineheight = 0.92
  ) +
  scale_fill_manual(
    values = c(
      `coccidian-like` = "#E6C0D3",
      `haemo/piroplasmid` = "#BCD7DC",
      `reduced apicomplexan` = "#D9DDDD",
      other = "#ECECEC"
    )
  ) +
  scale_size_continuous(range = c(2.7, 6.2), limits = c(0, 1)) +
  scale_x_continuous(limits = c(-0.09, 1.10), breaks = c(0, 0.5, 1), labels = c("0", "0.5", "1")) +
  scale_y_continuous(limits = c(-0.09, 1.12), breaks = c(0, 0.5, 1), labels = c("0", "0.5", "1")) +
  coord_equal(clip = "off") +
  labs(
    title = "Derived-module association",
    subtitle = "Target species; size = scaffold",
    x = "ICMT/ICMAP system score",
    y = "ICAT structure score"
  ) +
  base_theme +
  theme(
    panel.grid.major = element_line(color = GRID, linewidth = 0.25),
    axis.line = element_line(linewidth = 0.35, color = TEXT)
  )

barcode_plot <- ggplot(rep_long, aes(x = display_species, y = module)) +
  geom_tile(aes(fill = module), alpha = 0.08, color = "white", linewidth = 0.8, width = 0.86, height = 0.78) +
  geom_point(aes(size = score, fill = module), shape = 21, color = "white", stroke = 0.45, alpha = 0.98) +
  geom_text(
    aes(label = ifelse(score == 0, "0", ifelse(score == 1, "1", sprintf("%.2f", score))), color = score > 0.58),
    size = 2.15,
    fontface = "bold"
  ) +
  geom_line(
    data = rep_scores,
    aes(x = display_species, y = coupling_index * 2.3 + 0.52, group = 1),
    inherit.aes = FALSE,
    color = AMBER,
    linewidth = 0.85,
    alpha = 0.88
  ) +
  geom_point(
    data = rep_scores,
    aes(x = display_species, y = coupling_index * 2.3 + 0.52),
    inherit.aes = FALSE,
    color = AMBER,
    fill = PANEL,
    shape = 21,
    stroke = 0.65,
    size = 2.0
  ) +
  scale_fill_manual(values = module_cols, name = NULL) +
  scale_color_manual(values = c(`TRUE` = "white", `FALSE` = TEXT), guide = "none") +
  scale_size_continuous(range = c(2.8, 9.0), limits = c(0, 1), guide = "none") +
  scale_x_discrete(position = "top") +
  scale_y_discrete(limits = rev(names(module_cols))) +
  labs(
    title = "Module barcode across representative taxa",
    subtitle = "Bubble area encodes conservation fraction; amber line marks coupled ICMT/ICMAP x ICAT signal",
    x = NULL,
    y = NULL
  ) +
  base_theme +
  theme(
    axis.line = element_blank(),
    axis.ticks = element_blank(),
    axis.text.x = element_text(angle = 28, hjust = 0, vjust = 0, size = 6.5),
    axis.text.y = element_text(face = "bold", size = 6.8),
    panel.grid = element_blank(),
    plot.margin = margin(4, 6, 5, 6)
  )

legend_plot <- ggplot() +
  coord_cartesian(xlim = c(0, 10), ylim = c(0, 1), expand = FALSE) +
  theme_void(base_family = "Arial") +
  annotate("rect", xmin = 0.0, xmax = 10.0, ymin = 0.06, ymax = 0.94, fill = PAPER, color = GRID, linewidth = 0.25) +
  annotate("point", x = 0.55, y = 0.50, color = CF, size = 3.8) +
  annotate("text", x = 0.86, y = 0.50, hjust = 0, label = "Conoid scaffold", size = 2.35, color = TEXT) +
  annotate("point", x = 2.75, y = 0.50, color = ICMT, size = 3.8) +
  annotate("text", x = 3.06, y = 0.50, hjust = 0, label = "ICMT/ICMAP system", size = 2.35, color = TEXT) +
  annotate("point", x = 5.10, y = 0.50, color = ICAT, size = 3.8) +
  annotate("text", x = 5.41, y = 0.50, hjust = 0, label = "ICAT structure", size = 2.35, color = TEXT) +
  annotate("segment", x = 8.00, xend = 8.58, y = 0.50, yend = 0.50, color = AMBER, linewidth = 0.85) +
  annotate("point", x = 8.58, y = 0.50, color = AMBER, fill = PANEL, shape = 21, size = 2.2, stroke = 0.65) +
  annotate("text", x = 8.78, y = 0.50, hjust = 0, label = "coupling index", size = 2.35, color = TEXT)

combined_plot <- (
  complexity_plot | coupling_plot
) /
  (barcode_plot / legend_plot + plot_layout(heights = c(1, 0.17))) +
  plot_layout(heights = c(1.0, 0.96), widths = c(0.9, 1.1)) +
  plot_annotation(
    title = "Conoid scaffold complexity enables derived ICMT and ICAT modules",
    subtitle = "Nature Microbiology-style summary of scaffold-driven conoid evolution.",
    caption = "Protein-conservation/model scores; Et ICAT is retained as weak low-similarity candidate evidence, not full ICAT presence.",
    theme = theme(
      plot.background = element_rect(fill = PANEL, color = NA),
      plot.title = element_text(family = "Arial", face = "bold", size = 13.0, color = TEXT, margin = margin(b = 2)),
      plot.subtitle = element_text(family = "Arial", size = 7.7, color = MUTED, margin = margin(b = 7)),
      plot.caption = element_text(family = "Arial", size = 6.1, color = MUTED, hjust = 0, margin = margin(t = 5)),
      plot.margin = margin(7, 7, 7, 7)
    )
  )

save_figure <- function(plot, stem, width_cm, height_cm) {
  ggsave(
    file.path(png_dir, paste0(stem, ".png")),
    plot = plot,
    width = width_cm / 2.54,
    height = height_cm / 2.54,
    units = "in",
    dpi = 600,
    device = ragg::agg_png,
    bg = "white"
  )
  ggsave(
    file.path(pdf_dir, paste0(stem, ".pdf")),
    plot = plot,
    width = width_cm / 2.54,
    height = height_cm / 2.54,
    units = "in",
    device = grDevices::cairo_pdf,
    family = "Arial"
  )
  ggsave(
    file.path(svg_dir, paste0(stem, ".svg")),
    plot = plot,
    width = width_cm / 2.54,
    height = height_cm / 2.54,
    units = "in",
    device = grDevices::svg,
    bg = "white"
  )
}

stem <- "Fig5_conoid_complexity_ICMT_ICAT_coupling_NatureMicrobiology_style"
save_figure(combined_plot, stem, width_cm = 18.3, height_cm = 13.2)

write.csv(
  rep_scores,
  file.path(table_dir, "conoid_complexity_icmt_icat_coupling_representative_source.csv"),
  row.names = FALSE
)
write.csv(
  species_wide,
  file.path(table_dir, "conoid_complexity_icmt_icat_coupling_species_source.csv"),
  row.names = FALSE
)

report <- c(
  "# Conoid scaffold complexity and derived-module figure",
  "",
  "## Figure contract",
  "",
  "- Core claim: conoid scaffold complexity is the driver; elaborated scaffold architecture creates the structural space in which ICMT/ICMAP and ICAT modules can emerge.",
  "- Evidence chain: representative taxa show scaffold-complexity gradients, target species show ICMT/ICMAP versus ICAT association, and the module barcode shows the stepwise emergence of derived modules.",
  "- Archetype: Nature Microbiology-style asymmetric mixed-modality quantitative summary.",
  "",
  "## Key quantitative readout",
  "",
  sprintf("- Spearman rho between ICMT/ICMAP score and ICAT score across target species: %.2f.", spearman_rho),
  sprintf("- Pearson r between ICMT/ICMAP score and ICAT score across target species: %.2f.", pearson_r),
  "",
  "## Interpretation boundary",
  "",
  "The values are protein-conservation fractions, not direct ultrastructural measurements.",
  "This figure should be read together with morphology: reduced/remodeled taxa can retain partial scaffold or ICMT/ICMAP protein signals while lacking the ICAT structure.",
  "Eimeria tenella is treated as a low-similarity ICAT-like candidate: strict ICAT conservation remains 0, while the model score is set to 0.25 for visualization and hypothesis-building.",
  "",
  "## Outputs",
  "",
  paste0("- `", stem, ".pdf`"),
  paste0("- `", stem, ".png`"),
  paste0("- `", stem, ".svg`"),
  "- `conoid_complexity_icmt_icat_coupling_representative_source.csv`",
  "- `conoid_complexity_icmt_icat_coupling_species_source.csv`"
)
writeLines(report, file.path(report_dir, "conoid_complexity_icmt_icat_coupling_NatureMicrobiology_style.md"))

message("Wrote Nature Microbiology-style conoid complexity/coupling figure to: ", figure_dir)
