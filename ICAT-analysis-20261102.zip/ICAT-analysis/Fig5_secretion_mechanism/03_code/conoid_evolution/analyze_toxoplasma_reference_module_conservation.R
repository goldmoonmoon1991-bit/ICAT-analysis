#!/usr/bin/env Rscript

script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
if (length(script_arg) == 0L) {
  stop("This script must be run with Rscript so that --file is available.")
}
script_path <- normalizePath(sub("^--file=", "", script_arg[[1]]), mustWork = TRUE)
fig_dir <- normalizePath(file.path(dirname(script_path), "..", ".."), mustWork = TRUE)
project_root <- normalizePath(file.path(fig_dir, ".."), mustWork = TRUE)
source(file.path(project_root, "shared", "R", "project_library.R"))
icat_activate_project_library(project_root)

library(dplyr)
library(tidyr)
library(ggplot2)
library(patchwork)
library(readxl)

raw_nsmb_path <- file.path(
  fig_dir,
  "01_raw_data",
  "conoid_evolution",
  "NSMB_2026_conoid_structure",
  "41594_2025_1728_MOESM3_ESM.xlsx"
)

processed_dir <- file.path(
  fig_dir,
  "02_processed_data",
  "conoid_evolution",
  "toxoplasma_reference_modules"
)

target_scan_path <- file.path(
  fig_dir,
  "04_results",
  "tables",
  "conoid_evolution",
  "orthomcl_cooccurrence",
  "tgon_gene_orthogroup_cooccurrence_scan.csv"
)

broad_scan_path <- file.path(
  fig_dir,
  "04_results",
  "tables",
  "conoid_evolution",
  "orthomcl_cooccurrence",
  "ICAT_ICMAP_module_cooccurrence_scan_alveolates_tolerant.csv"
)

context_matrix_path <- file.path(
  processed_dir,
  "toxoplasma_reference_module_matrix_draft.csv"
)

output_root <- file.path(fig_dir, "04_results")
table_dir <- file.path(output_root, "tables", "conoid_evolution", "toxoplasma_reference_modules")
report_dir <- file.path(output_root, "reports", "conoid_evolution", "toxoplasma_reference_modules")
figure_dir <- file.path(output_root, "figures", "conoid_evolution", "toxoplasma_reference_modules", "conservation")
pdf_dir <- file.path(figure_dir, "PDF")
png_dir <- file.path(figure_dir, "PNG")
svg_dir <- file.path(figure_dir, "SVG")
dir.create(processed_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(report_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(pdf_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(png_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(svg_dir, recursive = TRUE, showWarnings = FALSE)
font_cache <- file.path(tempdir(), "icat-fontconfig-cache")
dir.create(font_cache, recursive = TRUE, showWarnings = FALSE)
Sys.setenv(XDG_CACHE_HOME = font_cache)

stopifnot(file.exists(raw_nsmb_path), file.exists(target_scan_path), file.exists(broad_scan_path))

squish <- function(x) {
  x <- as.character(x)
  x[is.na(x)] <- ""
  gsub("\\s+", " ", trimws(x))
}

nsmb_species <- c(
  "Haemoproteus",
  "Plasmodium falciparum",
  "Babesia bovis",
  "Theileria annulata",
  "Hammondia hammondi",
  "Cryptosporidium parvum",
  "Eimeria tenella",
  "Neospora caninum",
  "Gregarina niphandrodes",
  "Porospora cf. gigantea A"
)

parse_nsmb_conservation <- function(path) {
  raw <- readxl::read_excel(path, sheet = "A | Conservation", col_names = FALSE, .name_repair = "minimal")
  dat <- raw[5:(nrow(raw) - 1L), 1:13]
  colnames(dat) <- c("entry_no", "protein", "gene_id", nsmb_species)
  dat %>%
    mutate(
      entry_no = suppressWarnings(as.integer(squish(entry_no))),
      protein = squish(protein),
      gene_id = squish(gene_id)
    ) %>%
    filter(grepl("^TGME49_", gene_id), nzchar(protein)) %>%
    mutate(
      across(all_of(nsmb_species), ~ as.integer(squish(.x) == "+")),
      nsmb_source = "NSMB 2026 Table 1 / Supplementary Table 1 Tab A"
    ) %>%
    distinct(protein, gene_id, .keep_all = TRUE) %>%
    arrange(entry_no)
}

nsmb_all <- parse_nsmb_conservation(raw_nsmb_path)

module_levels <- c("Conoid scaffold", "ICMT/ICMAP system", "ICAT structure")

module_sheet_specs <- tibble::tribble(
  ~source_sheet, ~module,
  "Conoid_list", "Conoid scaffold",
  "ICMT-list", "ICMT/ICMAP system",
  "ICAT-list", "ICAT structure"
)

read_module_sheet <- function(path, source_sheet, module_name) {
  readxl::read_excel(path, sheet = source_sheet) %>%
    transmute(
      module = module_name,
      source_sheet = source_sheet,
      source_row = row_number(),
      gene_id = squish(GeneID),
      spatial_class = squish(Spatial_class),
      cryoem_name = squish(CryoEM_name),
      label = squish(Label)
    ) %>%
    filter(grepl("^TGME49_", gene_id)) %>%
    mutate(
      protein = case_when(
        nzchar(label) ~ label,
        nzchar(cryoem_name) ~ cryoem_name,
        TRUE ~ gene_id
      ),
      display_name = protein,
      include_in_score = 1L,
      source_basis = paste0("NSMB workbook curated module tab: ", source_sheet),
      notes = sprintf(
        "Module assigned from %s; Spatial_class=%s; CryoEM_name=%s.",
        source_sheet,
        ifelse(nzchar(spatial_class), spatial_class, "not annotated"),
        ifelse(nzchar(cryoem_name), cryoem_name, "not annotated")
      )
    )
}

module_reference_raw <- bind_rows(lapply(seq_len(nrow(module_sheet_specs)), function(i) {
  read_module_sheet(
    raw_nsmb_path,
    module_sheet_specs$source_sheet[[i]],
    module_sheet_specs$module[[i]]
  )
})) %>%
  mutate(module = factor(module, levels = module_levels)) %>%
  arrange(module, source_row, protein)

duplicate_module_gene_ids <- module_reference_raw %>%
  count(gene_id, name = "n_module_rows") %>%
  filter(n_module_rows > 1L) %>%
  left_join(
    module_reference_raw %>%
      group_by(gene_id) %>%
      summarise(
        modules = paste(unique(as.character(module)), collapse = "; "),
        labels = paste(unique(protein), collapse = "; "),
        .groups = "drop"
      ),
    by = "gene_id"
  )

reference_list <- module_reference_raw %>%
  distinct(module, gene_id, .keep_all = TRUE) %>%
  left_join(
    nsmb_all %>%
      select(
        gene_id,
        nsmb_entry_no = entry_no,
        nsmb_tabA_protein = protein,
        nsmb_source
      ),
    by = "gene_id"
  ) %>%
  mutate(
    module = factor(module, levels = module_levels),
    scoring_status = ifelse(include_in_score == 1L & nzchar(gene_id), "included", "pending_id"),
    protein_plot_id = paste(as.character(module), gene_id, sep = "__"),
    source_basis = ifelse(
      !is.na(nsmb_source) & nzchar(nsmb_source),
      paste(source_basis, nsmb_source, sep = "; conservation cross-check: "),
      source_basis
    ),
    notes = ifelse(
      !is.na(nsmb_tabA_protein) & nzchar(nsmb_tabA_protein) & nsmb_tabA_protein != protein,
      paste0(notes, " NSMB Tab A label=", nsmb_tabA_protein, "."),
      notes
    )
  ) %>%
  arrange(module, source_row, protein)

assigned_lookup <- reference_list %>%
  transmute(
    gene_id,
    assigned_module = as.character(module),
    source_sheet,
    module_tab_label = protein
  )

nsmb_clean <- nsmb_all %>%
  left_join(assigned_lookup, by = "gene_id") %>%
  mutate(
    include_in_three_module_score = as.integer(!is.na(assigned_module)),
    scoring_note = case_when(
      include_in_three_module_score == 1L ~ paste0(
        "Included through curated workbook tab `",
        source_sheet,
        "` as `",
        module_tab_label,
        "`."
      ),
      TRUE ~ "NSMB conoid-associated protein not used in the three-module Fig5 score."
    )
  )

target_scan <- read.csv(target_scan_path, stringsAsFactors = FALSE, check.names = FALSE)
broad_scan <- read.csv(broad_scan_path, stringsAsFactors = FALSE, check.names = FALSE)

target_species <- c(
  "Babesia bovis",
  "Theileria annulata",
  "Plasmodium falciparum",
  "Cryptosporidium parvum",
  "Toxoplasma gondii",
  "Neospora caninum",
  "Hammondia hammondi",
  "Eimeria tenella",
  "Sarcocystis neurona",
  "Besnoitia besnoiti",
  "Cystoisospora suis"
)

target_cols <- intersect(target_species, colnames(target_scan))

protein_wide <- reference_list %>%
  left_join(
    target_scan %>%
      select(
        gene_id,
        orthogroups,
        toxodb_product,
        orthomcl_product,
        species_pattern,
        present_species,
        all_of(target_cols)
      ),
    by = "gene_id"
  ) %>%
  left_join(
    broad_scan %>%
      select(
        gene_id,
        broad_member_genera = member_genera,
        other_alveolate_genera,
        broad_member_count = member_count,
        non_alveolate_euka_fraction
      ),
    by = "gene_id"
  ) %>%
  mutate(
    row_found_in_target_scan = !is.na(orthogroups),
    row_found_in_broad_scan = !is.na(broad_member_genera),
    across(all_of(target_cols), ~ as.integer(coalesce(.x, 0L)))
  )

protein_long <- protein_wide %>%
  select(
    module,
    protein,
    display_name,
    protein_plot_id,
    gene_id,
    source_sheet,
    source_row,
    spatial_class,
    cryoem_name,
    label,
    include_in_score,
    scoring_status,
    source_basis,
    notes,
    row_found_in_target_scan,
    row_found_in_broad_scan,
    all_of(target_cols)
  ) %>%
  pivot_longer(
    cols = all_of(target_cols),
    names_to = "species",
    values_to = "orthogroup_present"
  ) %>%
  mutate(
    orthogroup_present = as.integer(orthogroup_present),
    module = factor(module, levels = module_levels)
  )

module_species_scores <- protein_long %>%
  filter(include_in_score == 1L, !is.na(orthogroup_present)) %>%
  group_by(module, species) %>%
  summarise(
    n_reference_proteins = n(),
    n_present = sum(orthogroup_present == 1L),
    module_conservation_fraction = n_present / n_reference_proteins,
    .groups = "drop"
  ) %>%
  mutate(
    module = as.character(module),
    species = factor(species, levels = target_species)
  ) %>%
  arrange(module, species)

icat_candidate_overrides <- tibble::tibble(
  species = "Eimeria tenella",
  module = "ICAT structure",
  strict_conservation_fraction = 0,
  model_score_override = 0.25,
  evidence_class = "low-similarity ICAT-like candidate",
  evidence_note = "User-curated update: Eimeria tenella has a low-similarity ICAT homolog candidate. It is not scored as a high-confidence strict orthogroup hit, but is retained as weak evidence in the model score."
)

module_species_scores <- module_species_scores %>%
  left_join(
    icat_candidate_overrides %>%
      select(species, module, model_score_override, evidence_class, evidence_note),
    by = c("species", "module")
  ) %>%
  mutate(
    strict_conservation_fraction = module_conservation_fraction,
    module_model_score = coalesce(model_score_override, module_conservation_fraction),
    evidence_class = coalesce(evidence_class, "strict orthogroup conservation"),
    evidence_note = coalesce(evidence_note, "No model override applied.")
  )

module_summary <- module_species_scores %>%
  group_by(module) %>%
  summarise(
    n_reference_proteins = max(n_reference_proteins),
    mean_presence_across_target_species = mean(module_conservation_fraction),
    mean_model_score_across_target_species = mean(module_model_score),
    min_species_fraction = min(module_conservation_fraction),
    max_species_fraction = max(module_conservation_fraction),
    min_model_score = min(module_model_score),
    max_model_score = max(module_model_score),
    .groups = "drop"
  )

reference_nsmb_presence <- reference_list %>%
  left_join(
    nsmb_all %>%
      select(gene_id, all_of(nsmb_species)),
    by = "gene_id"
  ) %>%
  mutate(across(all_of(nsmb_species), ~ as.integer(coalesce(.x, 0L))))

nsmb_scored_long <- reference_nsmb_presence %>%
  select(module, protein, gene_id, all_of(nsmb_species)) %>%
  pivot_longer(
    cols = all_of(nsmb_species),
    names_to = "species",
    values_to = "nsmb_blast_hit"
  ) %>%
  mutate(
    module = factor(module, levels = module_levels)
  )

nsmb_module_species_scores <- nsmb_scored_long %>%
  group_by(module, species) %>%
  summarise(
    n_reference_proteins = n(),
    n_present = sum(nsmb_blast_hit == 1L),
    module_conservation_fraction = n_present / n_reference_proteins,
    evidence_source = "NSMB Supplementary Table 1 Tab A BLAST conservation",
    .groups = "drop"
  )

genus_present <- function(genera_string, genus_pattern) {
  if (is.na(genera_string) || !nzchar(genera_string)) {
    return(NA_integer_)
  }
  as.integer(grepl(genus_pattern, genera_string, ignore.case = TRUE))
}

representative_genus <- tibble::tribble(
  ~representative_label, ~query_type, ~query_value, ~display_species,
  "Ciliates", "genus_regex", "Paramecium|Tetrahymena", "Ciliates",
  "Perkinsids", "genus_regex", "Perkinsus", "Perkinsus",
  "Chromerids", "genus_regex", "Chromera", "Chromera velia",
  "Toxoplasma", "species_column", "Toxoplasma gondii", "Toxoplasma gondii",
  "Cryptosporidium", "species_column", "Cryptosporidium parvum", "Cryptosporidium",
  "Plasmodium", "species_column", "Plasmodium falciparum", "Plasmodium"
)

context_proxy_scores <- if (file.exists(context_matrix_path)) {
  read.csv(context_matrix_path, stringsAsFactors = FALSE, check.names = FALSE) %>%
    filter(representative_group %in% c("Ciliates", "Perkinsids", "Chromerids")) %>%
    select(
      representative_label = representative_group,
      display_species,
      conoid_scaffold_score = cf_score,
      icmt_icmap_score = icmt_score,
      icat_score,
      context_evidence_status = evidence_status,
      context_notes = notes
    ) %>%
    pivot_longer(
      cols = c(conoid_scaffold_score, icmt_icmap_score, icat_score),
      names_to = "module_score_name",
      values_to = "context_proxy_score"
    ) %>%
    mutate(
      module = case_when(
        module_score_name == "conoid_scaffold_score" ~ "Conoid scaffold",
        module_score_name == "icmt_icmap_score" ~ "ICMT/ICMAP system",
        module_score_name == "icat_score" ~ "ICAT structure",
        TRUE ~ module_score_name
      )
    ) %>%
    select(
      representative_label,
      display_species,
      module,
      context_proxy_score,
      context_evidence_status,
      context_notes
    )
} else {
  tibble::tibble(
    representative_label = character(),
    display_species = character(),
    module = character(),
    context_proxy_score = numeric(),
    context_evidence_status = character(),
    context_notes = character()
  )
}

representative_scores <- bind_rows(lapply(seq_len(nrow(representative_genus)), function(i) {
  row <- representative_genus[i, ]
  query_type <- row$query_type[[1]]
  query_value <- row$query_value[[1]]
  representative_label <- row$representative_label[[1]]
  display_species <- row$display_species[[1]]

  if (query_type == "species_column") {
    module_species_scores %>%
      filter(as.character(species) == query_value) %>%
      transmute(
        representative_label = representative_label,
        display_species = display_species,
        module,
        n_reference_proteins,
        n_present,
        strict_n_present = n_present,
        conservation_fraction = module_model_score,
        strict_conservation_fraction,
        context_proxy_score = NA_real_,
        evidence_class,
        evidence_note,
        context_evidence_status = NA_character_,
        context_notes = NA_character_,
        evidence_level = "target species OrthoMCL column"
      )
  } else {
    protein_wide %>%
      filter(include_in_score == 1L, row_found_in_broad_scan) %>%
      mutate(
        genus_present = vapply(
          broad_member_genera,
          genus_present,
          integer(1),
          genus_pattern = query_value
        )
      ) %>%
      group_by(module) %>%
      summarise(
        n_reference_proteins = n(),
        n_present = sum(genus_present == 1L, na.rm = TRUE),
        strict_conservation_fraction = mean(genus_present, na.rm = TRUE),
        .groups = "drop"
      ) %>%
      left_join(
        context_proxy_scores %>%
          filter(representative_label == !!representative_label, display_species == !!display_species),
        by = "module"
      ) %>%
      mutate(
        representative_label = representative_label,
        display_species = display_species,
        strict_n_present = n_present,
        conservation_fraction = coalesce(context_proxy_score, strict_conservation_fraction),
        evidence_class = ifelse(
          !is.na(context_proxy_score),
          "morphology-informed context proxy",
          "strict broad OrthoMCL genus membership"
        ),
        evidence_note = ifelse(
          !is.na(context_proxy_score),
          paste0(
            "Context row uses structure-informed proxy score for display; strict broad OrthoMCL genus fraction = ",
            sprintf("%.2f", strict_conservation_fraction),
            "."
          ),
          "No morphology proxy override applied."
        ),
        evidence_level = ifelse(
          !is.na(context_proxy_score),
          "morphology-informed outgroup context; strict broad OrthoMCL fraction retained",
          "broad OrthoMCL genus membership"
        )
      ) %>%
      select(
        representative_label,
        display_species,
        module,
        n_reference_proteins,
        n_present,
        strict_n_present,
        conservation_fraction,
        strict_conservation_fraction,
        context_proxy_score,
        evidence_class,
        evidence_note,
        context_evidence_status,
        context_notes,
        evidence_level
      )
  }
}))

representative_wide <- representative_scores %>%
  select(representative_label, display_species, module, conservation_fraction) %>%
  mutate(
    module_score_name = case_when(
      module == "Conoid scaffold" ~ "conoid_scaffold_score",
      module == "ICMT/ICMAP system" ~ "icmt_icmap_score",
      module == "ICAT structure" ~ "icat_score",
      TRUE ~ module
    )
  ) %>%
  select(-module) %>%
  pivot_wider(names_from = module_score_name, values_from = conservation_fraction)

for (needed_col in c("conoid_scaffold_score", "icmt_icmap_score", "icat_score")) {
  if (!needed_col %in% colnames(representative_wide)) {
    representative_wide[[needed_col]] <- NA_real_
  }
}
representative_wide <- representative_wide %>%
  mutate(
    conoid_scaffold_complexity_score = conoid_scaffold_score,
    derived_specialization_score = rowMeans(
      select(., icmt_icmap_score, icat_score),
      na.rm = TRUE
    ),
    conoid_molecular_conservation_score = conoid_scaffold_complexity_score,
    cf_score = conoid_scaffold_score,
    icmt_score = icmt_icmap_score,
    icat_icmap_asymmetry_score = icat_score
  )

module_tab_counts <- reference_list %>%
  count(module, source_sheet, name = "n_reference_proteins") %>%
  mutate(module = as.character(module)) %>%
  arrange(factor(module, levels = module_levels))

write.csv(nsmb_clean, file.path(processed_dir, "nsmb_conoid_protein_gene_ids_clean.csv"), row.names = FALSE)
write.csv(reference_list, file.path(processed_dir, "toxoplasma_reference_protein_list_v2_from_nsmb.csv"), row.names = FALSE)
write.csv(reference_list, file.path(processed_dir, "toxoplasma_reference_protein_list_from_module_tabs.csv"), row.names = FALSE)
write.csv(module_tab_counts, file.path(processed_dir, "toxoplasma_reference_module_tab_counts.csv"), row.names = FALSE)
write.csv(duplicate_module_gene_ids, file.path(processed_dir, "toxoplasma_reference_module_tab_duplicate_gene_ids.csv"), row.names = FALSE)
write.csv(nsmb_clean, file.path(table_dir, "nsmb_conoid_protein_gene_ids_clean.csv"), row.names = FALSE)
write.csv(reference_list, file.path(table_dir, "toxoplasma_reference_protein_list_v2_from_nsmb.csv"), row.names = FALSE)
write.csv(reference_list, file.path(table_dir, "toxoplasma_reference_protein_list_from_module_tabs.csv"), row.names = FALSE)
write.csv(module_tab_counts, file.path(table_dir, "toxoplasma_reference_module_tab_counts.csv"), row.names = FALSE)
write.csv(duplicate_module_gene_ids, file.path(table_dir, "toxoplasma_reference_module_tab_duplicate_gene_ids.csv"), row.names = FALSE)
write.csv(protein_wide, file.path(table_dir, "toxoplasma_reference_protein_conservation_wide.csv"), row.names = FALSE)
write.csv(protein_long, file.path(table_dir, "toxoplasma_reference_protein_conservation_long.csv"), row.names = FALSE)
write.csv(module_species_scores, file.path(table_dir, "toxoplasma_reference_module_species_scores.csv"), row.names = FALSE)
write.csv(module_summary, file.path(table_dir, "toxoplasma_reference_module_conservation_summary.csv"), row.names = FALSE)
write.csv(icat_candidate_overrides, file.path(table_dir, "icat_candidate_homolog_model_overrides.csv"), row.names = FALSE)
write.csv(nsmb_scored_long, file.path(table_dir, "nsmb_tabA_three_module_conservation_long.csv"), row.names = FALSE)
write.csv(nsmb_module_species_scores, file.path(table_dir, "nsmb_tabA_three_module_species_scores.csv"), row.names = FALSE)
write.csv(representative_scores, file.path(table_dir, "toxoplasma_reference_module_representative_scores_long.csv"), row.names = FALSE)
write.csv(representative_wide, file.path(table_dir, "toxoplasma_reference_module_representative_scores_for_fig.csv"), row.names = FALSE)

TEXT <- "#232629"
MUTED <- "#66737B"
CF <- "#7D8C94"
ICMT <- "#1F6370"
ICAT <- "#B44575"
ABSENT <- "#F3F5F6"

species_order <- rev(target_species)
protein_order <- reference_list %>%
  filter(include_in_score == 1L) %>%
  mutate(module = factor(module, levels = module_levels)) %>%
  arrange(module, source_row, nsmb_entry_no, protein) %>%
  pull(protein_plot_id)

protein_axis_labels <- reference_list %>%
  filter(include_in_score == 1L) %>%
  arrange(module, source_row, nsmb_entry_no, protein) %>%
  distinct(protein_plot_id, .keep_all = TRUE) %>%
  transmute(protein_plot_id, label = display_name) %>%
  tibble::deframe()

heatmap_df <- protein_long %>%
  filter(include_in_score == 1L) %>%
  mutate(
    species = factor(species, levels = species_order),
    protein_plot_id = factor(protein_plot_id, levels = protein_order),
    module = factor(module, levels = module_levels),
    fill_group = case_when(
      orthogroup_present == 0L ~ "Absent",
      module == "Conoid scaffold" ~ "Conoid scaffold",
      module == "ICMT/ICMAP system" ~ "ICMT/ICMAP system",
      module == "ICAT structure" ~ "ICAT structure",
      TRUE ~ "Absent"
    )
  )

score_df <- module_species_scores %>%
  mutate(
    species = factor(as.character(species), levels = species_order),
    module = factor(module, levels = module_levels),
    plotted_fraction = module_model_score,
    module_offset = case_when(
      module == "Conoid scaffold" ~ -0.22,
      module == "ICMT/ICMAP system" ~ 0,
      module == "ICAT structure" ~ 0.22,
      TRUE ~ 0
    ),
    y_position = as.numeric(species) + module_offset
  )

heatmap_plot <- ggplot(heatmap_df, aes(x = protein_plot_id, y = species, fill = fill_group)) +
  geom_tile(color = "white", linewidth = 0.30, width = 0.92, height = 0.78) +
  facet_grid(. ~ module, scales = "free_x", space = "free_x") +
  scale_fill_manual(
    values = c(
      `Absent` = ABSENT,
      `Conoid scaffold` = CF,
      `ICMT/ICMAP system` = ICMT,
      `ICAT structure` = ICAT
    ),
    breaks = c("Conoid scaffold", "ICMT/ICMAP system", "ICAT structure", "Absent"),
    name = NULL
  ) +
  scale_x_discrete(labels = protein_axis_labels) +
  labs(
    title = "Toxoplasma reference proteins: orthogroup conservation",
    subtitle = "Gene IDs are parsed from the curated Conoid_list, ICMT-list and ICAT-list workbook tabs.",
    x = NULL,
    y = NULL
  ) +
  theme_minimal(base_family = "Arial", base_size = 7) +
  theme(
    panel.grid = element_blank(),
    axis.text.x = element_text(angle = 45, hjust = 1, vjust = 1, color = TEXT, size = 5.8),
    axis.text.y = element_text(color = TEXT, size = 6.8),
    strip.text = element_text(face = "bold", color = TEXT, size = 7.0),
    plot.title = element_text(face = "bold", color = TEXT, size = 10.0),
    plot.subtitle = element_text(color = MUTED, size = 6.8),
    legend.position = "bottom",
    legend.text = element_text(size = 6.1),
    plot.margin = margin(5, 6, 5, 5)
  )

score_plot <- ggplot(score_df, aes(x = plotted_fraction, y = y_position, color = module)) +
  geom_segment(aes(x = 0, xend = plotted_fraction, yend = y_position), linewidth = 0.8, alpha = 0.72) +
  geom_point(size = 2.1) +
  geom_point(
    data = score_df %>% filter(!is.na(model_score_override)),
    shape = 21,
    fill = "white",
    stroke = 0.55,
    size = 2.6
  ) +
  scale_x_continuous(limits = c(0, 1), breaks = c(0, 0.5, 1), labels = c("0", "0.5", "1")) +
  scale_y_continuous(
    breaks = seq_along(species_order),
    labels = species_order,
    expand = expansion(add = c(0.45, 0.45))
  ) +
  scale_color_manual(
    values = c(
      `Conoid scaffold` = CF,
      `ICMT/ICMAP system` = ICMT,
      `ICAT structure` = ICAT
    ),
    name = NULL
  ) +
  labs(
    title = "Module-level conservation fraction",
    x = "fraction of reference proteins present",
    y = NULL
  ) +
  theme_minimal(base_family = "Arial", base_size = 7) +
  theme(
    panel.grid.major.y = element_blank(),
    panel.grid.minor = element_blank(),
    axis.text = element_text(color = TEXT),
    axis.title.x = element_text(color = TEXT, size = 6.8),
    plot.title = element_text(face = "bold", color = TEXT, size = 8.8),
    legend.position = "bottom",
    legend.text = element_text(size = 6.1),
    plot.margin = margin(5, 5, 5, 5)
  )

combined_plot <- heatmap_plot / score_plot + plot_layout(heights = c(1, 0.62))

save_figure <- function(plot, stem, width_cm, height_cm) {
  ggsave(
    file.path(png_dir, paste0(stem, ".png")),
    plot = plot,
    width = width_cm / 2.54,
    height = height_cm / 2.54,
    units = "in",
    dpi = 600,
    device = ragg::agg_png,
    bg = "white"
  )
  ggsave(
    file.path(pdf_dir, paste0(stem, ".pdf")),
    plot = plot,
    width = width_cm / 2.54,
    height = height_cm / 2.54,
    units = "in",
    device = grDevices::cairo_pdf,
    family = "Arial"
  )
  svg_device <- if (requireNamespace("svglite", quietly = TRUE)) {
    svglite::svglite
  } else {
    grDevices::svg
  }
  ggsave(
    file.path(svg_dir, paste0(stem, ".svg")),
    plot = plot,
    width = width_cm / 2.54,
    height = height_cm / 2.54,
    units = "in",
    device = svg_device,
    bg = "white"
  )
}

save_figure(
  combined_plot,
  "Fig5_toxoplasma_reference_module_conservation_audit",
  width_cm = 20.0,
  height_cm = 14.0
)

summary_lines <- module_species_scores %>%
  filter(as.character(species) %in% c("Toxoplasma gondii", "Eimeria tenella", "Cryptosporidium parvum", "Plasmodium falciparum")) %>%
  arrange(species, module) %>%
  mutate(line = sprintf(
    "- `%s` / `%s`: %.2f (%d/%d)",
    species,
    module,
    module_conservation_fraction,
    n_present,
    n_reference_proteins
  )) %>%
  pull(line)

nsmb_summary_lines <- nsmb_module_species_scores %>%
  filter(species %in% c("Plasmodium falciparum", "Cryptosporidium parvum", "Eimeria tenella", "Neospora caninum", "Gregarina niphandrodes")) %>%
  arrange(species, module) %>%
  mutate(line = sprintf(
    "- `%s` / `%s`: %.2f (%d/%d)",
    species,
    module,
    module_conservation_fraction,
    n_present,
    n_reference_proteins
  )) %>%
  pull(line)

unscored_lines <- nsmb_clean %>%
  filter(include_in_three_module_score == 0L) %>%
  mutate(line = sprintf("- `%s` (`%s`): %s", protein, gene_id, scoring_note)) %>%
  pull(line)

missing_target_scan_lines <- protein_wide %>%
  filter(include_in_score == 1L, !row_found_in_target_scan) %>%
  mutate(line = sprintf("- `%s` / `%s` (`%s`)", module, protein, gene_id)) %>%
  pull(line)
if (length(missing_target_scan_lines) == 0L) {
  missing_target_scan_lines <- "- None; every curated module-tab GeneID is present in the local target-species OrthoMCL scan."
}

duplicate_gene_lines <- duplicate_module_gene_ids %>%
  mutate(line = sprintf("- `%s`: %s; label(s): %s", gene_id, modules, labels)) %>%
  pull(line)
if (length(duplicate_gene_lines) == 0L) {
  duplicate_gene_lines <- "- None; no GeneID is assigned to more than one module tab."
}

report <- c(
  "# Toxoplasma reference module conservation analysis",
  "",
  "This analysis replaces the earlier placeholder 0-1 scores with an auditable protein-conservation workflow.",
  "Gene IDs for all three modules are parsed from the first three curated workbook tabs: `Conoid_list`, `ICMT-list` and `ICAT-list`.",
  "The former hard-coded scaffold/ICMT lists and manually appended ICAT row are no longer used for Fig5 module scoring.",
  "Scoring is GeneID-first: `GeneID` is the statistical key, while `Label` and `CryoEM_name` are used only for display and audit.",
  "",
  "## Figure contract",
  "",
  "- Core claim: conoid scaffold complexity is the evolutionary driver; a more elaborate scaffold enables derived ICMT/ICMAP structures and, in this study, the ICAT structure.",
  "- Evidence chain: the curated module tabs define the Conoid scaffold, ICMT/ICMAP system and ICAT structure reference sets; local OrthoMCL species columns provide target-species presence/absence; NSMB Tab A is retained as an independent BLAST-conservation audit where available.",
  "- Archetype: quantitative audit grid supporting a schematic-led evolutionary summary.",
  "",
  "## Scored modules",
  "",
  "- `Conoid scaffold`: all valid GeneIDs in `Conoid_list`; this is the conoid-complexity driver axis.",
  "- `ICMT/ICMAP system`: all valid GeneIDs in `ICMT-list`; ICMAPs are treated as ICMT structural proteins.",
  "- `ICAT structure`: all valid GeneIDs in `ICAT-list`; currently this is the one-protein ICAT marker from this study.",
  "",
  "## Module-tab counts",
  "",
  sprintf(
    "- `%s` from `%s`: %d reference proteins",
    module_tab_counts$module,
    module_tab_counts$source_sheet,
    module_tab_counts$n_reference_proteins
  ),
  "",
  "## GeneID audit",
  "",
  "### Missing from target-species OrthoMCL scan",
  "",
  missing_target_scan_lines,
  "",
  "### GeneIDs assigned to more than one module tab",
  "",
  duplicate_gene_lines,
  "",
  "## Target-species OrthoMCL fractions",
  "",
  summary_lines,
  "",
  "## NSMB Supplementary Table 1 Tab A BLAST fractions",
  "",
  nsmb_summary_lines,
  "",
  "## NSMB proteins not used in the three-module score",
  "",
  unscored_lines,
  "",
  "## Interpretation boundary",
  "",
  "These values are protein-conservation fractions, not direct structural-complexity measurements.",
  "The conoid scaffold score is interpreted as the main complexity axis; ICMT/ICMAP and ICAT are downstream or derived specialization modules, not equal drivers of scaffold complexity.",
  "Reference proteins missing from the local target-species OrthoMCL scan are retained in the denominator, scored as absent, and flagged in `toxoplasma_reference_protein_conservation_wide.csv`.",
  "Broadly conserved microtubule or ring proteins can remain detectable in reduced lineages, so final structural interpretation should combine conservation with morphology.",
  "Ciliates, Perkinsids and Chromerids in `toxoplasma_reference_module_representative_scores_for_fig.csv` are morphology-informed context/proxy rows. Their strict broad OrthoMCL genus-membership fractions are retained in `strict_conservation_fraction`, but their display scores use the structure-informed context matrix and are excluded from formal correlation statistics.",
  "This separation is important for Perkinsus: its open-sided conoid-like morphology is represented as context, even though the current Tg reference scaffold orthogroups do not recover Perkinsus genus-level hits.",
  "NSMB Tab A entries that are not present in the curated three module tabs remain in `nsmb_conoid_protein_gene_ids_clean.csv` for audit, but are not included in Fig5 module scoring.",
  "",
  "## Outputs",
  "",
  "- `nsmb_conoid_protein_gene_ids_clean.csv`",
  "- `toxoplasma_reference_protein_list_v2_from_nsmb.csv`",
  "- `toxoplasma_reference_protein_list_from_module_tabs.csv`",
  "- `toxoplasma_reference_module_tab_counts.csv`",
  "- `toxoplasma_reference_module_tab_duplicate_gene_ids.csv`",
  "- `toxoplasma_reference_protein_conservation_wide.csv`",
  "- `toxoplasma_reference_protein_conservation_long.csv`",
  "- `toxoplasma_reference_module_species_scores.csv`",
  "- `nsmb_tabA_three_module_species_scores.csv`",
  "- `toxoplasma_reference_module_representative_scores_for_fig.csv`",
  "- `Fig5_toxoplasma_reference_module_conservation_audit.*`"
)
writeLines(report, file.path(report_dir, "toxoplasma_reference_module_conservation.md"))

message("Wrote Toxoplasma reference module conservation analysis to: ", table_dir)
