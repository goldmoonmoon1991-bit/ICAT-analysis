# =========数据合并=========
script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
script_path <- normalizePath(sub("^--file=", "", script_arg[[1]]), mustWork = TRUE)
fig_dir <- normalizePath(file.path(dirname(script_path), "..", ".."), mustWork = TRUE)
project_root <- normalizePath(file.path(fig_dir, ".."), mustWork = TRUE)
source(file.path(project_root, "shared", "R", "project_library.R"))
icat_activate_project_library(project_root)

library(tools)
source(file.path(project_root, "shared", "R", "plot_style.R"))
raw_root <- file.path(fig_dir, "01_raw_data", "2D_motility")
processed_root <- file.path(fig_dir, "02_processed_data", "2D_motility")
figure_dir <- file.path(fig_dir, "04_results", "figures", "2D_motility")
table_dir <- file.path(fig_dir, "04_results", "tables", "2D_motility")
report_dir <- file.path(fig_dir, "04_results", "reports", "2D_motility")
for (path in c(processed_root, figure_dir, table_dir, report_dir)) {
  dir.create(path, recursive = TRUE, showWarnings = FALSE)
}
date_dirs <- list.dirs(raw_root, recursive = FALSE, full.names = TRUE)

merge_one_condition <- function(cond_dir, output_file) {
  files <- list.files(cond_dir, pattern = "\\.csv$", full.names = TRUE)

  if (length(files) == 0) return(NULL)

  data_list <- lapply(files, function(f) {
    df <- suppressWarnings(read.csv(f, row.names = 1, check.names = FALSE, stringsAsFactors = FALSE))
    df <- df[, !is.na(colnames(df)) & colnames(df) != "", drop = FALSE]
    df$original_rowname <- rownames(df)
    df$file_id <- file_path_sans_ext(basename(f))
    df
  })

  merged_data <- do.call(rbind, data_list)
  merged_data <- merged_data[, c("file_id", "original_rowname",
                                 setdiff(colnames(merged_data), c("file_id", "original_rowname"))),
                             drop = FALSE]

  write.csv(merged_data, output_file, row.names = FALSE, quote = FALSE)
  message("Saved: ", output_file)
}

for (date_dir in date_dirs) {
  processed_date_dir <- file.path(processed_root, basename(date_dir))
  dir.create(processed_date_dir, recursive = TRUE, showWarnings = FALSE)
  if (dir.exists(file.path(date_dir, "IAA"))) {
    merge_one_condition(file.path(date_dir, "IAA"), file.path(processed_date_dir, "IAA_merged.csv"))
  }
  if (dir.exists(file.path(date_dir, "vehicle"))) {
    merge_one_condition(file.path(date_dir, "vehicle"), file.path(processed_date_dir, "vehicle_merged.csv"))
  }
}

message("All done.")


# =========作图与统计=========

library(dplyr)
library(tidyr)
library(ggplot2)
library(patchwork)
library(scales)

# =========================================================
# 图形结论和统计边界
# =========================================================
# 结论：ICAT depletion 后，2D motility composition 从 helical/productive motility
# 转向 non-motile/no-move enriched state。
# 注意：这里的 flow 是 composition shift，不代表同一细胞的真实轨迹转换。

root_dir <- processed_root
keep_dates <- c("20260213", "20260218", "20260227", "20260305")
n_date_reps <- length(keep_dates)
condition_order <- c("vehicle", "IAA")
motility_cols <- c("twirl", "circle", "helix", "no move")
motility_order <- c("no move", "circle", "twirl", "helix")
motility_labels <- c(
  "helix" = "Helical",
  "circle" = "Circular",
  "twirl" = "Twirling",
  "no move" = "Non-motile"
)
motility_colors <- c(
  "helix" = "#C9332B",
  "circle" = "#4D8EAE",
  "twirl" = "#D7A349",
  "no move" = "#9A9A9A"
)
direction_colors <- c(
  "increase" = "#B33A3A",
  "decrease" = "#2D6F8E",
  "stable" = "#6F6F6F"
)

format_p <- function(p) {
  ifelse(is.na(p), "NA", ifelse(p < 0.001, "<0.001", sprintf("%.3f", p)))
}

sig_from_p <- function(p) {
  dplyr::case_when(
    is.na(p) ~ "NA",
    p < 0.001 ~ "***",
    p < 0.01 ~ "**",
    p < 0.05 ~ "*",
    TRUE ~ "ns"
  )
}

save_figure <- function(plot, stem, output_dir, width_cm, height_cm) {
  png_dir <- file.path(output_dir, "PNG")
  pdf_dir <- file.path(output_dir, "PDF")
  svg_dir <- file.path(output_dir, "SVG")
  dir.create(png_dir, recursive = TRUE, showWarnings = FALSE)
  dir.create(pdf_dir, recursive = TRUE, showWarnings = FALSE)
  dir.create(svg_dir, recursive = TRUE, showWarnings = FALSE)

  ggsave(
    file.path(png_dir, paste0(stem, ".png")),
    plot = plot,
    width = width_cm / 2.54,
    height = height_cm / 2.54,
    units = "in",
    dpi = 600,
    device = ragg::agg_png,
    bg = "transparent"
  )
  ggsave(
    file.path(pdf_dir, paste0(stem, ".pdf")),
    plot = plot,
    width = width_cm / 2.54,
    height = height_cm / 2.54,
    units = "in",
    device = grDevices::cairo_pdf,
    family = "Arial"
  )
  ggsave(
    file.path(svg_dir, paste0(stem, ".svg")),
    plot = plot,
    width = width_cm / 2.54,
    height = height_cm / 2.54,
    units = "in",
    device = grDevices::svg,
    bg = "transparent"
  )
}

merged_files <- list.files(
  path = root_dir,
  pattern = "^(IAA|vehicle)_merged\\.csv$",
  recursive = TRUE,
  full.names = TRUE
)

if (length(merged_files) == 0) {
  stop("No merged csv files found.")
}

all_data <- lapply(merged_files, function(f) {
  df <- suppressWarnings(read.csv(f, check.names = FALSE, stringsAsFactors = FALSE))
  df$date <- basename(dirname(f))
  df$condition <- sub("_merged\\.csv$", "", basename(f))
  df
}) %>%
  bind_rows() %>%
  filter(date %in% keep_dates)

if (!"file_id" %in% colnames(all_data)) {
  stop("Column 'file_id' not found.")
}

motility_cols <- intersect(motility_cols, colnames(all_data))
if (length(motility_cols) == 0) {
  stop("No expected motility columns found.")
}

all_data[motility_cols] <- lapply(all_data[motility_cols], function(x) {
  x <- suppressWarnings(as.numeric(x))
  x[is.na(x)] <- 0
  x
})

# =========================================================
# 汇总：file-level、date-level 和 pooled count
# =========================================================
file_counts <- all_data %>%
  group_by(date, condition, file_id) %>%
  summarise(
    across(all_of(motility_cols), ~ sum(.x, na.rm = TRUE)),
    .groups = "drop"
  ) %>%
  mutate(
    total = rowSums(across(all_of(motility_cols)), na.rm = TRUE),
    condition = factor(condition, levels = condition_order)
  ) %>%
  filter(total > 0)

file_summary <- file_counts %>%
  mutate(across(all_of(motility_cols), ~ 100 * .x / total))

write.csv(
  file_summary,
  file.path(table_dir, sprintf("file_level_percentage_4types_%dreps.csv", n_date_reps)),
  row.names = FALSE,
  quote = FALSE
)

date_summary <- file_summary %>%
  group_by(date, condition) %>%
  summarise(
    across(all_of(motility_cols), ~ mean(.x, na.rm = TRUE)),
    n_files = n(),
    .groups = "drop"
  ) %>%
  mutate(
    condition = factor(condition, levels = condition_order),
    date = factor(date, levels = keep_dates)
  )

write.csv(
  date_summary,
  file.path(table_dir, sprintf("date_level_mean_percentage_4types_%dreps.csv", n_date_reps)),
  row.names = FALSE,
  quote = FALSE
)

date_counts <- file_counts %>%
  group_by(date, condition) %>%
  summarise(
    across(all_of(motility_cols), ~ sum(.x, na.rm = TRUE)),
    total = sum(total),
    n_files = n(),
    .groups = "drop"
  )

pooled_counts <- all_data %>%
  group_by(condition) %>%
  summarise(across(all_of(motility_cols), ~ sum(.x, na.rm = TRUE)), .groups = "drop") %>%
  mutate(condition = factor(condition, levels = condition_order)) %>%
  arrange(condition)

count_matrix <- as.matrix(pooled_counts[, motility_cols])
rownames(count_matrix) <- as.character(pooled_counts$condition)

stacked_data <- date_summary %>%
  group_by(condition) %>%
  summarise(across(all_of(motility_cols), ~ mean(.x, na.rm = TRUE)), .groups = "drop") %>%
  pivot_longer(
    cols = all_of(motility_cols),
    names_to = "motility_type",
    values_to = "percentage"
  ) %>%
  mutate(
    condition = factor(condition, levels = condition_order),
    motility_type = factor(motility_type, levels = motility_order)
  )

stacked_check <- stacked_data %>%
  group_by(condition) %>%
  summarise(total_pct = sum(percentage), .groups = "drop")

write.csv(
  stacked_check,
  file.path(table_dir, "sanity_check_stacked_total_pct.csv"),
  row.names = FALSE,
  quote = FALSE
)

dot_data <- date_summary %>%
  pivot_longer(
    cols = all_of(motility_cols),
    names_to = "motility_type",
    values_to = "percentage"
  ) %>%
  mutate(
    condition = factor(condition, levels = condition_order),
    motility_type = factor(motility_type, levels = motility_order),
    date = factor(date, levels = keep_dates)
  )

# =========================================================
# 统计：pooled count global test、post-hoc proportion test、date-level paired test
# =========================================================
global_chisq <- chisq.test(count_matrix)
min_expected <- min(global_chisq$expected)
global_test_res <- if (min_expected < 5) {
  fisher.test(count_matrix, simulate.p.value = TRUE, B = 100000)
} else {
  global_chisq
}

global_test_table <- data.frame(
  test = ifelse(min_expected < 5, "Fisher exact test with simulated p-value", "Pearson chi-squared test"),
  statistic = ifelse(is.null(global_test_res$statistic), NA_real_, unname(global_test_res$statistic)),
  df = ifelse(is.null(global_test_res$parameter), NA_real_, unname(global_test_res$parameter)),
  p_value = global_test_res$p.value,
  min_expected_count = min_expected,
  stringsAsFactors = FALSE
)

write.csv(
  global_test_table,
  file.path(table_dir, "statistical_global_composition_test.csv"),
  row.names = FALSE
)

total_v <- sum(count_matrix["vehicle", ])
total_iaa <- sum(count_matrix["IAA", ])

post_hoc_df <- lapply(colnames(count_matrix), function(type) {
  count_v <- count_matrix["vehicle", type]
  count_iaa <- count_matrix["IAA", type]
  res <- suppressWarnings(prop.test(x = c(count_v, count_iaa), n = c(total_v, total_iaa)))
  data.frame(
    motility_type = type,
    vehicle_count = count_v,
    IAA_count = count_iaa,
    vehicle_total = total_v,
    IAA_total = total_iaa,
    vehicle_fraction = count_v / total_v,
    IAA_fraction = count_iaa / total_iaa,
    delta_fraction = (count_iaa / total_iaa) - (count_v / total_v),
    delta_percentage_points = 100 * ((count_iaa / total_iaa) - (count_v / total_v)),
    p_raw = res$p.value,
    stringsAsFactors = FALSE
  )
}) %>%
  bind_rows() %>%
  mutate(
    p_adj_BH = p.adjust(p_raw, method = "BH"),
    p_adj_bonferroni = p.adjust(p_raw, method = "bonferroni"),
    significance_BH = sig_from_p(p_adj_BH),
    direction = case_when(
      delta_percentage_points > 0 ~ "increase",
      delta_percentage_points < 0 ~ "decrease",
      TRUE ~ "stable"
    ),
    motility_type = factor(motility_type, levels = motility_order)
  ) %>%
  arrange(motility_type)

write.csv(
  post_hoc_df,
  file.path(table_dir, "statistical_post_hoc_proportion_tests.csv"),
  row.names = FALSE
)

# 兼容旧文件名，避免其他文档或入口还引用旧表。
write.csv(
  post_hoc_df,
  file.path(table_dir, "statistical_post_hoc_results_FIXED.csv"),
  row.names = FALSE
)

paired_wide <- dot_data %>%
  select(date, condition, motility_type, percentage) %>%
  pivot_wider(names_from = condition, values_from = percentage) %>%
  mutate(delta_percentage_points = IAA - vehicle)

paired_stats <- paired_wide %>%
  group_by(motility_type) %>%
  summarise(
    n_date_replicates = sum(!is.na(vehicle) & !is.na(IAA)),
    mean_vehicle_percentage = mean(vehicle, na.rm = TRUE),
    mean_IAA_percentage = mean(IAA, na.rm = TRUE),
    mean_delta_percentage_points = mean(delta_percentage_points, na.rm = TRUE),
    median_delta_percentage_points = median(delta_percentage_points, na.rm = TRUE),
    sd_delta_percentage_points = sd(delta_percentage_points, na.rm = TRUE),
    paired_t_p_raw = ifelse(
      n_date_replicates >= 2 && sd(delta_percentage_points, na.rm = TRUE) > 0,
      tryCatch(t.test(IAA, vehicle, paired = TRUE)$p.value, error = function(e) NA_real_),
      NA_real_
    ),
    wilcoxon_p_raw = ifelse(
      n_date_replicates >= 2 && any(delta_percentage_points != 0, na.rm = TRUE),
      tryCatch(wilcox.test(IAA, vehicle, paired = TRUE, exact = FALSE)$p.value, error = function(e) NA_real_),
      NA_real_
    ),
    .groups = "drop"
  ) %>%
  mutate(
    paired_t_p_adj_BH = p.adjust(paired_t_p_raw, method = "BH"),
    wilcoxon_p_adj_BH = p.adjust(wilcoxon_p_raw, method = "BH"),
    paired_t_significance_BH = sig_from_p(paired_t_p_adj_BH),
    wilcoxon_significance_BH = sig_from_p(wilcoxon_p_adj_BH),
    motility_type = factor(motility_type, levels = motility_order)
  ) %>%
  arrange(motility_type)

write.csv(
  paired_wide,
  file.path(table_dir, "date_level_paired_motility_delta_long.csv"),
  row.names = FALSE
)
write.csv(
  paired_stats,
  file.path(table_dir, "date_level_paired_motility_tests.csv"),
  row.names = FALSE
)

flow_change_summary <- stacked_data %>%
  select(condition, motility_type, percentage) %>%
  pivot_wider(names_from = condition, values_from = percentage) %>%
  mutate(
    delta_percentage_points = IAA - vehicle,
    direction = case_when(
      delta_percentage_points > 0 ~ "increase",
      delta_percentage_points < 0 ~ "decrease",
      TRUE ~ "stable"
    )
  ) %>%
  left_join(
    post_hoc_df %>%
      select(motility_type, pooled_delta_percentage_points = delta_percentage_points, p_adj_BH, significance_BH),
    by = "motility_type"
  ) %>%
  left_join(
    paired_stats %>%
      select(motility_type, paired_mean_delta_percentage_points = mean_delta_percentage_points, paired_t_p_adj_BH, paired_t_significance_BH),
    by = "motility_type"
  ) %>%
  arrange(motility_type)

write.csv(
  flow_change_summary,
  file.path(table_dir, "motility_flow_change_summary.csv"),
  row.names = FALSE
)

# =========================================================
# 可视化：composition flow + date-level paired evidence
# =========================================================
flow_rects <- stacked_data %>%
  arrange(condition, motility_type) %>%
  group_by(condition) %>%
  mutate(
    ymin = lag(cumsum(percentage), default = 0),
    ymax = cumsum(percentage),
    ymid = (ymin + ymax) / 2,
    x = as.numeric(condition),
    xmin = x - 0.16,
    xmax = x + 0.16
  ) %>%
  ungroup()

flow_polygons <- flow_rects %>%
  select(condition, motility_type, ymin, ymax) %>%
  pivot_wider(names_from = condition, values_from = c(ymin, ymax)) %>%
  group_by(motility_type) %>%
  summarise(
    x = list(c(1.16, 1.16, 1.84, 1.84)),
    y = list(c(ymin_vehicle, ymax_vehicle, ymax_IAA, ymin_IAA)),
    .groups = "drop"
  ) %>%
  tidyr::unnest(cols = c(x, y)) %>%
  left_join(
    flow_change_summary %>% select(motility_type, delta_percentage_points, direction),
    by = "motility_type"
  )

flow_labels_left <- flow_rects %>%
  filter(condition == "vehicle") %>%
  mutate(
    label = ifelse(percentage >= 10, paste0(motility_labels[as.character(motility_type)], "\n", sprintf("%.1f%%", percentage)), ""),
    text_color = ifelse(motility_type %in% c("helix", "twirl"), "white", "black"),
    x = 1
  )

flow_labels_right <- flow_rects %>%
  filter(condition == "IAA") %>%
  left_join(
    flow_change_summary %>% select(motility_type, delta_percentage_points, p_adj_BH, significance_BH, direction),
    by = "motility_type"
  ) %>%
  mutate(
    label = paste0(
      motility_labels[as.character(motility_type)], " ",
      sprintf("%.1f%%", percentage), "\n",
      sprintf("%+.1f pp", delta_percentage_points),
      "; q ", format_p(p_adj_BH)
    ),
    x = xmax + 0.06
  )

flow_plot <- ggplot() +
  geom_polygon(
    data = flow_polygons,
    aes(x = x, y = y, group = motility_type, fill = motility_type),
    alpha = 0.38,
    color = NA
  ) +
  geom_rect(
    data = flow_rects,
    aes(xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax, fill = motility_type),
    color = "black",
    linewidth = ICAT_LINE_MM
  ) +
  geom_text(
    data = flow_labels_left,
    aes(x = x, y = ymid, label = label, color = text_color),
    hjust = 0.5,
    size = ICAT_TEXT_SMALL_MM * 0.70,
    lineheight = 0.92,
    fontface = "bold"
  ) +
  geom_text(
    data = flow_labels_right,
    aes(x = x, y = ymid, label = label, color = direction),
    hjust = 0,
    size = ICAT_TEXT_SMALL_MM * 0.72,
    lineheight = 0.92,
    fontface = "bold"
  ) +
  annotate(
    "text",
    x = c(1, 2),
    y = 103,
    label = c("vehicle", "IAA"),
    size = ICAT_TEXT_BODY_MM,
    fontface = "bold"
  ) +
  scale_fill_manual(values = motility_colors, labels = motility_labels, drop = FALSE) +
  scale_color_manual(values = c(direction_colors, "white" = "white", "black" = "black"), drop = FALSE) +
  scale_x_continuous(limits = c(0.66, 3.18), breaks = NULL, expand = expansion(mult = c(0, 0))) +
  scale_y_continuous(
    limits = c(0, 106),
    breaks = c(0, 25, 50, 75, 100),
    labels = function(x) paste0(x, "%"),
    expand = expansion(mult = c(0, 0))
  ) +
  icat_theme_classic(base_family = "Arial") +
  theme(
    legend.position = "none",
    axis.title.x = element_blank(),
    axis.text.x = element_blank(),
    axis.ticks.x = element_blank(),
    axis.line.x = element_blank(),
    axis.title.y = element_text(size = ICAT_FONT_SMALL_PT),
    axis.text.y = element_text(size = ICAT_FONT_SMALL_PT, color = "black"),
    plot.title = element_blank(),
    plot.subtitle = element_blank(),
    plot.margin = margin(1.0, 1.2, 0.8, 1.2)
  ) +
  labs(
    title = NULL,
    subtitle = NULL,
    y = "Motility composition"
  )

replicate_stats_labels <- paired_stats %>%
  mutate(
    label = paste0(
      sprintf("mean %+.1f pp", mean_delta_percentage_points),
      "\npaired q ", format_p(paired_t_p_adj_BH)
    )
  )

replicate_plot <- ggplot(
  dot_data,
  aes(x = condition, y = percentage, group = date)
) +
  geom_line(color = "#9A9A9A", linewidth = ICAT_LINE_MM * 1.5, alpha = 0.85) +
  geom_point(aes(color = motility_type), size = 1.65, alpha = 0.95, stroke = 0) +
  geom_text(
    data = replicate_stats_labels,
    aes(x = 1.5, y = Inf, label = label),
    inherit.aes = FALSE,
    vjust = 1.15,
    size = ICAT_TEXT_SMALL_MM * 0.70,
    lineheight = 0.9,
    color = "#2B2B2B"
  ) +
  facet_wrap(~motility_type, nrow = 1, scales = "free_y", labeller = as_labeller(motility_labels)) +
  scale_color_manual(values = motility_colors, labels = motility_labels, drop = FALSE) +
  scale_y_continuous(labels = function(x) paste0(x, "%"), breaks = pretty_breaks(n = 3)) +
  icat_theme_classic(base_family = "Arial") +
  theme(
    legend.position = "none",
    axis.title.x = element_blank(),
    axis.text.x = element_text(size = ICAT_FONT_SMALL_PT, color = "black"),
    axis.text.y = element_text(size = ICAT_FONT_SMALL_PT, color = "black"),
    axis.title.y = element_text(size = ICAT_FONT_SMALL_PT),
    strip.text = element_text(size = ICAT_FONT_SMALL_PT, face = "bold"),
    plot.title = element_text(size = ICAT_FONT_TITLE_PT, face = "bold"),
    plot.margin = margin(0.8, 1.2, 0.8, 1.2)
  ) +
  labs(
    title = "Date-level paired changes",
    y = "Replicate mean"
  )

delta_plot_data <- flow_change_summary %>%
  mutate(
    motility_type = factor(motility_type, levels = rev(motility_order)),
    label = paste0(
      sprintf("%+.1f pp", delta_percentage_points),
      "\nq ", format_p(p_adj_BH)
    ),
    label_x = ifelse(delta_percentage_points >= 0, delta_percentage_points, -0.6),
    label_hjust = ifelse(delta_percentage_points >= 0, -0.05, 1.05)
  )

delta_plot <- ggplot(
  delta_plot_data,
  aes(x = delta_percentage_points, y = motility_type, fill = direction)
) +
  geom_vline(xintercept = 0, linewidth = ICAT_LINE_MM, color = "black") +
  geom_col(width = 0.56, color = "black", linewidth = ICAT_LINE_MM) +
  geom_text(
    aes(x = label_x, label = label, hjust = label_hjust),
    size = ICAT_TEXT_SMALL_MM * 0.78,
    lineheight = 0.9,
    fontface = "bold"
  ) +
  scale_fill_manual(values = direction_colors, drop = FALSE) +
  scale_y_discrete(labels = motility_labels) +
  scale_x_continuous(
    breaks = pretty_breaks(n = 5),
    labels = function(x) paste0(x, " pp"),
    expand = expansion(mult = c(0.18, 0.26))
  ) +
  icat_theme_classic(base_family = "Arial") +
  theme(
    legend.position = "none",
    axis.title.y = element_blank(),
    axis.text.y = element_text(size = ICAT_FONT_SMALL_PT, color = "black"),
    axis.text.x = element_text(size = ICAT_FONT_SMALL_PT, color = "black"),
    axis.title.x = element_text(size = ICAT_FONT_SMALL_PT),
    plot.title = element_text(size = ICAT_FONT_TITLE_PT, face = "bold"),
    plot.margin = margin(0.8, 1.2, 0.8, 1.2)
  ) +
  labs(
    title = "Direction and size of change",
    x = "IAA - vehicle"
  )

combined_plot <- flow_plot / (delta_plot | replicate_plot) +
  plot_layout(heights = c(1.18, 1), widths = c(0.85, 1.55)) +
  plot_annotation(
    title = "ICAT depletion shifts motility away from helical movement",
    theme = theme(
      plot.title = element_text(
        family = "Arial",
        size = ICAT_FONT_TITLE_PT,
        face = "bold",
        hjust = 0
      )
    )
  )

# 主图用 flow + delta，突出运动类型占比的方向和变化大小；replicate plot 单独作为审计图。
main_flow_delta_plot <- (flow_plot | delta_plot) + plot_layout(widths = c(1.45, 1))
legacy_plot <- flow_plot | replicate_plot

save_figure(flow_plot, sprintf("Fig5_2D_motility_composition_flow_%dreps", n_date_reps), figure_dir, width_cm = 10.2, height_cm = 4.6)
save_figure(delta_plot, sprintf("Fig5_2D_motility_delta_bar_%dreps", n_date_reps), figure_dir, width_cm = 5.6, height_cm = 4.0)
save_figure(replicate_plot, sprintf("Fig5_2D_motility_paired_replicates_%dreps", n_date_reps), figure_dir, width_cm = 12.4, height_cm = 4.2)
save_figure(main_flow_delta_plot, sprintf("Fig5_2D_motility_flow_plus_stats_%dreps", n_date_reps), figure_dir, width_cm = 15.0, height_cm = 4.8)
save_figure(combined_plot, sprintf("Fig5_2D_motility_flow_plus_replicate_audit_%dreps", n_date_reps), figure_dir, width_cm = 18.0, height_cm = 9.6)
save_figure(legacy_plot, sprintf("stacked_bar_plus_dotplot_4types_%dreps", n_date_reps), figure_dir, width_cm = 15.0, height_cm = 5.2)

report_lines <- c(
  "# 2D motility composition-flow analysis",
  "",
  "## Figure claim",
  "",
  paste(
    "ICAT depletion shifts the 2D motility composition away from helical movement",
    "and toward non-motile behavior."
  ),
  "",
  "## Data structure",
  "",
  sprintf("- Date-level biological replicates included: %s.", paste(keep_dates, collapse = ", ")),
  sprintf("- Number of date-level replicates: %d.", n_date_reps),
  sprintf("- Pooled vehicle events: %d.", total_v),
  sprintf("- Pooled IAA events: %d.", total_iaa),
  "",
  "## Global composition test",
  "",
  sprintf(
    "- %s: p = %s; minimum expected count = %.2f.",
    global_test_table$test[[1]],
    format_p(global_test_table$p_value[[1]]),
    global_test_table$min_expected_count[[1]]
  ),
  "",
  "## Class-wise pooled proportion changes",
  "",
  paste(
    apply(
      post_hoc_df %>%
        mutate(
          line = sprintf(
            "- %s: vehicle %.1f%%, IAA %.1f%%, delta %+.1f percentage points, BH-adjusted q = %s (%s).",
            motility_labels[as.character(motility_type)],
            100 * vehicle_fraction,
            100 * IAA_fraction,
            delta_percentage_points,
            format_p(p_adj_BH),
            significance_BH
          )
        ) %>%
        pull(line) %>%
        as.matrix(),
      1,
      identity
    ),
    collapse = "\n"
  ),
  "",
  "## Date-level paired test",
  "",
  paste(
    apply(
      paired_stats %>%
        mutate(
          line = sprintf(
            "- %s: mean paired delta %+.1f percentage points, paired t-test BH q = %s (%s); Wilcoxon BH q = %s (%s).",
            motility_labels[as.character(motility_type)],
            mean_delta_percentage_points,
            format_p(paired_t_p_adj_BH),
            paired_t_significance_BH,
            format_p(wilcoxon_p_adj_BH),
            wilcoxon_significance_BH
          )
        ) %>%
        pull(line) %>%
        as.matrix(),
      1,
      identity
    ),
    collapse = "\n"
  ),
  "",
  "## Interpretation boundary",
  "",
  paste(
    "The composition-flow ribbons summarize changes in aggregate motility-state",
    "fractions between conditions. They should be described as a population",
    "composition shift, not as direct single-cell state transitions."
  ),
  "",
  "Generated figure outputs are saved as PDF, PNG, and SVG in the 2D_motility figure folder."
)

writeLines(report_lines, file.path(report_dir, "2D_motility_composition_flow_report.md"))

message("统计完成：已输出 pooled composition test、post-hoc proportion tests 和 date-level paired tests。")
