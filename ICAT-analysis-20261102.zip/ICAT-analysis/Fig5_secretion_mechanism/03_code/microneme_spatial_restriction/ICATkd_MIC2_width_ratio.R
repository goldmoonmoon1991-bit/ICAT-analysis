#!/usr/bin/env Rscript

# Cell-level Microneme confinement index (MCI) audit for Fig. 5C.
script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
script_path <- normalizePath(sub("^--file=", "", script_arg[[1]]), mustWork = TRUE)
fig_dir <- normalizePath(file.path(dirname(script_path), "..", ".."), mustWork = TRUE)
project_root <- normalizePath(file.path(fig_dir, ".."), mustWork = TRUE)
source(file.path(project_root, "shared", "R", "project_library.R"))
icat_activate_project_library(project_root)

library(ggplot2)
library(dplyr)
library(scales)
library(tidyr)
library(patchwork)

source(file.path(project_root, "shared", "R", "plot_style.R"))

input_dir <- file.path(fig_dir, "01_raw_data", "microneme_spatial_restriction", "width_ratio")
class_dir <- file.path(fig_dir, "01_raw_data", "microneme_spatial_restriction", "position_classes")
output_root <- Sys.getenv("ICAT_MCI_OUTPUT_ROOT", unset = fig_dir)
table_dir <- file.path(output_root, "04_results", "tables", "microneme_spatial_restriction", "width_ratio")
class_table_dir <- file.path(output_root, "04_results", "tables", "microneme_spatial_restriction", "position_classes")
report_dir <- file.path(output_root, "04_results", "reports", "microneme_spatial_restriction", "width_ratio")
figure_dir <- file.path(output_root, "04_results", "figures", "microneme_spatial_restriction", "width_ratio")
class_figure_dir <- file.path(output_root, "04_results", "figures", "microneme_spatial_restriction", "position_classes")
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(class_table_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(report_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(class_figure_dir, recursive = TRUE, showWarnings = FALSE)

position_class_input <- Sys.getenv(
  "ICAT_POSITION_CLASS_INPUT",
  unset = file.path(class_dir, "microneme_position_class_template.csv")
)

position_class_columns <- c(
  "condition", "cell_id", "source_label", "MIC2_width", "Tubulin_width",
  "confinement_index", "source_image", "class_I", "class_II", "class_III",
  "notes"
)

read_mci_from_width_file <- function(file_name, condition) {
  path <- file.path(input_dir, file_name)
  df <- read.csv(
    path,
    header = FALSE,
    col.names = c("source_label", "MIC2_width", "Tubulin_width", "raw_ratio"),
    check.names = FALSE
  )
  df$condition <- condition
  df$source_file <- file_name
  df
}

read_mci_from_width_files <- function() {
  bind_rows(
    read_mci_from_width_file("iKD_vehicle.csv", "iKD-vehicle"),
    read_mci_from_width_file("iKD_IAA.csv", "iKD-IAA")
  ) %>%
    mutate(
      condition = factor(condition, levels = c("iKD-vehicle", "iKD-IAA")),
      cell_id = ave(raw_ratio, condition, FUN = seq_along),
      confinement_index = raw_ratio
    )
}

make_annotation_template <- function(mci_df) {
  mci_df %>%
    transmute(
      condition = as.character(condition),
      cell_id = cell_id,
      source_label = source_label,
      MIC2_width = MIC2_width,
      Tubulin_width = Tubulin_width,
      confinement_index = confinement_index,
      source_image = "",
      class_I = NA_integer_,
      class_II = NA_integer_,
      class_III = NA_integer_,
      notes = ""
    )
}

class_pattern <- function(i, ii, iii) {
  classes <- c("I", "II", "III")[c(i, ii, iii)]
  if (length(classes) == 0) "none" else paste(classes, collapse = "+")
}

dominant_class <- function(i, ii, iii) {
  counts <- c(I = i, II = ii, III = iii)
  if (all(is.na(counts)) || sum(counts, na.rm = TRUE) == 0) {
    return("none")
  }
  paste(names(counts)[counts == max(counts, na.rm = TRUE)], collapse = "+")
}

validate_binary_class <- function(values, column) {
  filled <- values[!is.na(values)]
  invalid <- setdiff(unique(filled), c(0L, 1L))
  if (length(invalid)) {
    stop(column, " must contain only 0, 1, or blank values.")
  }
}

ensure_position_class_template <- function(path, mci_df) {
  template <- make_annotation_template(mci_df)
  if (!file.exists(path)) {
    write.csv(template, path, row.names = FALSE, na = "")
    return(invisible(TRUE))
  }

  existing <- read.csv(path, check.names = FALSE, stringsAsFactors = FALSE)
  old_template <- c(
    "condition", "cell_id", "source_image", "n_class_I", "n_class_II",
    "n_class_III", "n_total_micronemes", "notes"
  )
  if (identical(names(existing), old_template) && nrow(existing) == 0) {
    write.csv(template, path, row.names = FALSE, na = "")
    return(invisible(TRUE))
  }

  missing <- setdiff(position_class_columns, names(existing))
  if (length(missing)) {
    stop("Position-class annotation table is missing column(s): ", paste(missing, collapse = ", "))
  }
  if (nrow(existing) == 0) {
    write.csv(template, path, row.names = FALSE, na = "")
    return(invisible(TRUE))
  }
  invisible(FALSE)
}

read_position_classes <- function(path, fallback_mci_df) {
  ensure_position_class_template(path, fallback_mci_df)
  raw <- read.csv(
    path,
    check.names = FALSE,
    stringsAsFactors = FALSE,
    na.strings = c("", "NA")
  )
  raw <- raw[, position_class_columns]
  if (nrow(raw) == 0) {
    return(raw)
  }
  raw <- raw %>%
    mutate(
      condition = factor(condition, levels = c("iKD-vehicle", "iKD-IAA")),
      cell_id = as.integer(cell_id),
      MIC2_width = as.numeric(MIC2_width),
      Tubulin_width = as.numeric(Tubulin_width),
      confinement_index = as.numeric(confinement_index),
      # 如果后续只修改了 MIC2/Tubulin 宽度而忘记填 MCI，这里会自动补算。
      confinement_index = ifelse(
        is.na(confinement_index) & !is.na(MIC2_width) & !is.na(Tubulin_width) & Tubulin_width > 0,
        MIC2_width / Tubulin_width,
        confinement_index
      ),
      class_I = as.integer(class_I),
      class_II = as.integer(class_II),
      class_III = as.integer(class_III)
    )
  validate_binary_class(raw$class_I, "class_I")
  validate_binary_class(raw$class_II, "class_II")
  validate_binary_class(raw$class_III, "class_III")
  if (any(is.na(raw$condition))) {
    stop("condition must be iKD-vehicle or iKD-IAA.")
  }
  duplicated_cells <- raw %>%
    count(condition, cell_id, name = "n_rows") %>%
    filter(n_rows > 1)
  if (nrow(duplicated_cells) > 0) {
    stop("Duplicate condition/cell_id rows found in position-class table.")
  }
  raw
}

mci_from_width_files <- read_mci_from_width_files()
position_classes <- read_position_classes(position_class_input, mci_from_width_files)

# 正式绘图优先使用整合后的 position-class CSV。
# 只要该表中有 confinement_index，MCI 主图、统计和 MCI-class 整合图都会从这里直接重建。
mci_from_position_classes <- position_classes %>%
  filter(!is.na(confinement_index)) %>%
  transmute(
    source_label = source_label,
    MIC2_width = MIC2_width,
    Tubulin_width = Tubulin_width,
    raw_ratio = confinement_index,
    condition = condition,
    source_file = basename(position_class_input),
    cell_id = cell_id,
    confinement_index = confinement_index
  )

uses_position_class_mci <- nrow(mci_from_position_classes) > 0
df <- if (uses_position_class_mci) {
  mci_from_position_classes
} else {
  mci_from_width_files
}

mci_source_note <- if (uses_position_class_mci) {
  sprintf("MCI values were read directly from `%s`.", basename(position_class_input))
} else {
  "MCI values were read from the legacy width-ratio raw CSV files because the position-class table contained no MCI values."
}

vehicle <- df$confinement_index[df$condition == "iKD-vehicle"]
iaa <- df$confinement_index[df$condition == "iKD-IAA"]

cliffs_delta <- function(x, y) {
  mean(sign(outer(x, y, "-")))
}

bootstrap_mean_difference <- function(mutant, control, iterations = 20000, seed = 20260706) {
  set.seed(seed)
  diffs <- replicate(
    iterations,
    mean(sample(mutant, length(mutant), replace = TRUE)) -
      mean(sample(control, length(control), replace = TRUE))
  )
  as.numeric(quantile(diffs, probs = c(0.025, 0.975), names = FALSE))
}

summary_table <- df %>%
  group_by(condition) %>%
  summarise(
    n_cells = n(),
    mean = mean(confinement_index),
    median = median(confinement_index),
    sd = sd(confinement_index),
    q1 = quantile(confinement_index, 0.25),
    q3 = quantile(confinement_index, 0.75),
    min = min(confinement_index),
    max = max(confinement_index),
    replicate_metadata_present = "no",
    .groups = "drop"
  )

mean_diff <- mean(iaa) - mean(vehicle)
median_diff <- median(iaa) - median(vehicle)
fold_change <- mean(iaa) / mean(vehicle)
delta <- cliffs_delta(iaa, vehicle)
ci <- bootstrap_mean_difference(iaa, vehicle)
vehicle_q95 <- as.numeric(quantile(vehicle, 0.95, names = FALSE))
iaa_above_vehicle_q95 <- mean(iaa > vehicle_q95)

effects_table <- tibble::tibble(
  metric = c(
    "mean_difference_iKD_IAA_minus_iKD_vehicle",
    "cell_level_bootstrap_95CI_low",
    "cell_level_bootstrap_95CI_high",
    "median_difference_iKD_IAA_minus_iKD_vehicle",
    "mean_fold_change_iKD_IAA_over_iKD_vehicle",
    "cliffs_delta_iKD_IAA_vs_iKD_vehicle",
    "iKD_vehicle_95th_percentile",
    "fraction_iKD_IAA_above_iKD_vehicle_95th_percentile"
  ),
  value = c(
    mean_diff,
    ci[[1]],
    ci[[2]],
    median_diff,
    fold_change,
    delta,
    vehicle_q95,
    iaa_above_vehicle_q95
  )
)

write.csv(df, file.path(table_dir, "ICATkd_MCI_long.csv"), row.names = FALSE)
write.csv(summary_table, file.path(table_dir, "ICATkd_MCI_summary.csv"), row.names = FALSE)
write.csv(effects_table, file.path(table_dir, "ICATkd_MCI_effects.csv"), row.names = FALSE)

has_position_class_data <- nrow(position_classes) > 0 &&
  any(!is.na(position_classes$class_I) | !is.na(position_classes$class_II) | !is.na(position_classes$class_III))

if (has_position_class_data) {
  position_classes <- position_classes %>%
    mutate(
      has_class_I = class_I == 1L,
      has_class_II = class_II == 1L,
      has_class_III = class_III == 1L,
      class_richness = has_class_I + has_class_II + has_class_III,
      class_pattern = mapply(class_pattern, has_class_I, has_class_II, has_class_III),
      dominant_class = mapply(dominant_class, class_I, class_II, class_III)
    )

  scored_position_classes <- position_classes %>%
    filter(!is.na(class_I) | !is.na(class_II) | !is.na(class_III))

  mci_key <- df %>%
    distinct(condition, cell_id)

  unmatched_position_classes <- scored_position_classes %>%
    anti_join(mci_key, by = c("condition", "cell_id"))

  mci_with_classes <- df %>%
    select(condition, cell_id, source_file, raw_ratio, confinement_index) %>%
    left_join(
      position_classes %>%
        select(
          condition, cell_id, source_image, class_I, class_II, class_III,
          has_class_I, has_class_II, has_class_III, class_richness,
          class_pattern, dominant_class, notes
        ),
      by = c("condition", "cell_id")
    )

  matched_position_classes <- mci_with_classes %>%
    filter(!is.na(class_I) | !is.na(class_II) | !is.na(class_III))

  class_positive_summary <- scored_position_classes %>%
    group_by(condition) %>%
    summarise(
      n_cells_with_position_data = n(),
      fraction_has_class_I = mean(has_class_I),
      fraction_has_class_II = mean(has_class_II),
      fraction_has_class_III = mean(has_class_III),
      mean_class_richness = mean(class_richness),
      .groups = "drop"
    )

  mci_by_class_pattern <- matched_position_classes %>%
    filter(!is.na(class_pattern)) %>%
    group_by(condition, class_pattern, class_richness, dominant_class) %>%
    summarise(
      n_cells = n(),
      mean_confinement_index = mean(confinement_index),
      median_confinement_index = median(confinement_index),
      sd_confinement_index = ifelse(n() > 1, sd(confinement_index), NA_real_),
      .groups = "drop"
    )

  mci_classIII_quadrant <- matched_position_classes %>%
    mutate(
      class_III_state = factor(ifelse(has_class_III, "III+", "III-"), levels = c("III-", "III+")),
      class_III_y = ifelse(has_class_III, 1, 0),
      mci_state = factor(
        ifelse(confinement_index > vehicle_q95, "High MCI", "Low MCI"),
        levels = c("Low MCI", "High MCI")
      ),
      quadrant = factor(
        paste(mci_state, class_III_state, sep = " / "),
        levels = c("Low MCI / III+", "High MCI / III-", "Low MCI / III-", "High MCI / III+")
      )
    )

  mci_classIII_quadrant_summary <- mci_classIII_quadrant %>%
    count(condition, mci_state, class_III_state, quadrant, name = "n_cells") %>%
    group_by(condition) %>%
    mutate(fraction_within_condition = n_cells / sum(n_cells)) %>%
    ungroup()

  write.csv(position_classes, file.path(class_table_dir, "microneme_position_class_long.csv"), row.names = FALSE)
  write.csv(scored_position_classes, file.path(class_table_dir, "microneme_position_class_scored.csv"), row.names = FALSE)
  write.csv(matched_position_classes, file.path(class_table_dir, "microneme_position_class_MCI_matched.csv"), row.names = FALSE)
  write.csv(class_positive_summary, file.path(class_table_dir, "microneme_position_class_positive_summary.csv"), row.names = FALSE)
  write.csv(mci_by_class_pattern, file.path(class_table_dir, "MCI_by_position_class_pattern.csv"), row.names = FALSE)
  write.csv(mci_classIII_quadrant_summary, file.path(class_table_dir, "MCI_ClassIII_quadrant_summary.csv"), row.names = FALSE)
  write.csv(unmatched_position_classes, file.path(class_table_dir, "microneme_position_class_unmatched_to_MCI.csv"), row.names = FALSE)
} else {
  position_classes <- NULL
  scored_position_classes <- NULL
  mci_with_classes <- NULL
  matched_position_classes <- NULL
  unmatched_position_classes <- NULL
  mci_classIII_quadrant <- NULL
  mci_classIII_quadrant_summary <- NULL
}

condition_colors <- c("iKD-vehicle" = "#2F7DB7", "iKD-IAA" = "#D73027")
condition_short_labels <- c("iKD-vehicle" = "vehicle", "iKD-IAA" = "IAA")
class_colors <- c("Class I" = "#8DB3C7", "Class II" = "#B589C9", "Class III" = "#E05A9D")
richness_colors <- c("0" = "#D8D8D8", "1" = "#9ABBD0", "2" = "#C89CCF", "3" = "#D95F8D")

main_plot <- ggplot(df, aes(x = condition, y = confinement_index, color = condition)) +
  geom_jitter(width = 0.13, height = 0, size = 1.35, alpha = 0.62, stroke = 0) +
  geom_crossbar(
    data = summary_table,
    aes(x = condition, y = median, ymin = median, ymax = median),
    inherit.aes = FALSE,
    width = 0.45,
    linewidth = ICAT_LINE_MM * 2.2,
    color = "black"
  ) +
  stat_summary(
    fun.data = function(x) {
      data.frame(y = median(x), ymin = quantile(x, 0.25), ymax = quantile(x, 0.75))
    },
    geom = "errorbar",
    width = 0.12,
    linewidth = ICAT_LINE_MM * 1.4,
    color = "black"
  ) +
  annotate(
    "text",
    x = 1.5,
    y = max(df$confinement_index) * 1.04,
    label = sprintf("%.2fx higher", fold_change),
    size = ICAT_TEXT_SMALL_MM,
    fontface = "bold",
    color = "#2B2B2B"
  ) +
  scale_color_manual(values = condition_colors) +
  scale_y_continuous(
    limits = c(0, max(df$confinement_index) * 1.12),
    breaks = pretty_breaks(n = 4),
    expand = expansion(mult = c(0, 0.02))
  ) +
  icat_theme_classic(base_family = "Arial") +
  theme(
    legend.position = "none",
    axis.title.x = element_blank(),
    axis.text.x = element_text(size = ICAT_FONT_SMALL_PT, color = "black"),
    axis.text.y = element_text(size = ICAT_FONT_SMALL_PT, color = "black"),
    plot.title = element_text(size = ICAT_FONT_TITLE_PT, face = "bold"),
    plot.margin = margin(1.2, 1.2, 1.0, 1.0)
  ) +
  labs(
    title = "Microneme confinement index\nafter ICAT depletion",
    y = "Microneme confinement index"
  )

make_smoothed_cdf <- function(condition_df, x_limits = c(0, 1), n = 512) {
  values <- condition_df$confinement_index
  density_fit <- density(
    values,
    from = x_limits[[1]],
    to = x_limits[[2]],
    n = n,
    adjust = 1.05,
    na.rm = TRUE
  )
  dx <- c(0, diff(density_fit$x))
  cumulative <- cumsum(density_fit$y * dx)
  cumulative <- cumulative / max(cumulative, na.rm = TRUE)
  data.frame(
    condition = condition_df$condition[[1]],
    confinement_index = density_fit$x,
    cumulative_fraction = cumulative
  )
}

ecdf_smooth_df <- df %>%
  split(.$condition) %>%
  lapply(make_smoothed_cdf, x_limits = c(0, 1)) %>%
  bind_rows() %>%
  mutate(condition = factor(condition, levels = c("iKD-vehicle", "iKD-IAA")))

ecdf_plot <- ggplot(ecdf_smooth_df, aes(x = confinement_index, y = cumulative_fraction, color = condition)) +
  geom_line(linewidth = ICAT_LINE_MM * 1.45, lineend = "round") +
  scale_color_manual(values = condition_colors) +
  scale_x_continuous(limits = c(0, 1), breaks = seq(0, 1, by = 0.25), expand = expansion(mult = c(0, 0))) +
  scale_y_continuous(labels = label_number(accuracy = 0.5), limits = c(0, 1), breaks = c(0, 0.5, 1)) +
  icat_theme_classic(base_family = "Arial") +
  theme(
    legend.position = c(0.58, 0.22),
    legend.direction = "horizontal",
    legend.background = element_rect(fill = scales::alpha("white", 0.78), color = NA),
    legend.title = element_blank(),
    legend.text = element_text(size = 4.8),
    legend.key.width = unit(3.4, "mm"),
    legend.key.height = unit(1.6, "mm"),
    legend.spacing.x = unit(0.9, "mm"),
    axis.text = element_text(size = 5.2, color = "black"),
    axis.title = element_text(size = 5.6, color = "black"),
    plot.title = element_blank(),
    plot.margin = margin(0.7, 2.2, 0.7, 0.7)
  ) +
  labs(
    x = "MCI",
    y = "Cumulative fraction"
  )

save_figure <- function(plot, stem, output_dir, width_cm, height_cm) {
  png_dir <- file.path(output_dir, "PNG")
  pdf_dir <- file.path(output_dir, "PDF")
  svg_dir <- file.path(output_dir, "SVG")
  dir.create(png_dir, recursive = TRUE, showWarnings = FALSE)
  dir.create(pdf_dir, recursive = TRUE, showWarnings = FALSE)
  dir.create(svg_dir, recursive = TRUE, showWarnings = FALSE)

  ggsave(
    file.path(png_dir, paste0(stem, ".png")),
    plot = plot,
    width = width_cm / 2.54,
    height = height_cm / 2.54,
    units = "in",
    dpi = 600,
    device = ragg::agg_png,
    bg = "transparent"
  )
  ggsave(
    file.path(pdf_dir, paste0(stem, ".pdf")),
    plot = plot,
    width = width_cm / 2.54,
    height = height_cm / 2.54,
    units = "in",
    device = grDevices::cairo_pdf,
    family = "Arial"
  )
  ggsave(
    file.path(svg_dir, paste0(stem, ".svg")),
    plot = plot,
    width = width_cm / 2.54,
    height = height_cm / 2.54,
    units = "in",
    device = grDevices::svg,
    bg = "transparent"
  )
}

save_figure(main_plot, "Fig5C_ICATkd_MCI", figure_dir, width_cm = 5.6, height_cm = 4.4)
save_figure(ecdf_plot, "ICATkd_MCI_ecdf_audit", figure_dir, width_cm = 4.5, height_cm = 2.8)

class_report_lines <- c(
  "## Position-class integration",
  "",
  "position-class data pending: the merged annotation table is present, but no cell-level Class I/II/III values have been entered yet.",
  "",
  "Annotation fields: condition, cell_id, source_label, MIC2_width, Tubulin_width, confinement_index, source_image, class_I, class_II, class_III, notes.",
  "Enter class_I/class_II/class_III as 0, 1, or blank. Class I/II/III are non-mutually exclusive at the cell level.",
  "Class III marks MIC2+ micronemes apical to the conoid, corresponding to the final apical-exit/fusion step of secretion."
)

if (has_position_class_data) {
  # 分类比例使用全部已填写 Class I/II/III 的细胞；不要求这些细胞必须有 MCI 数值。
  # 这样新增的 "no MIC2+ signal within conoid" 细胞也会进入 Class I/II/III 总数。
  class_positive_long <- scored_position_classes %>%
    select(condition, has_class_I, has_class_II, has_class_III) %>%
    pivot_longer(
      cols = starts_with("has_class_"),
      names_to = "microneme_class",
      values_to = "has_class"
    ) %>%
    mutate(
      microneme_class = recode(
        microneme_class,
        "has_class_I" = "Class I",
        "has_class_II" = "Class II",
        "has_class_III" = "Class III"
      )
    ) %>%
    group_by(condition, microneme_class) %>%
    summarise(
      fraction_positive = mean(has_class),
      n_cells = n(),
      .groups = "drop"
    )

  class_positive_plot <- ggplot(
    class_positive_long,
    aes(x = microneme_class, y = fraction_positive, fill = microneme_class)
  ) +
    geom_col(width = 0.62, color = "black", linewidth = ICAT_LINE_MM) +
    facet_wrap(~condition, nrow = 1) +
    scale_fill_manual(values = class_colors) +
    scale_y_continuous(labels = percent_format(accuracy = 1), limits = c(0, 1), expand = expansion(mult = c(0, 0.04))) +
    icat_theme_classic(base_family = "Arial") +
    theme(
      legend.position = "none",
      axis.title.x = element_blank(),
      axis.text.x = element_text(size = ICAT_FONT_SMALL_PT, color = "black", angle = 35, hjust = 1),
      axis.text.y = element_text(size = ICAT_FONT_SMALL_PT, color = "black"),
      strip.text = element_text(size = ICAT_FONT_SMALL_PT, face = "bold"),
      plot.title = element_text(size = ICAT_FONT_TITLE_PT, face = "bold"),
      plot.margin = margin(1.2, 1.2, 1.0, 1.0)
    ) +
    labs(
      title = "Position-class positive cells",
      y = "Cells with class (%)"
    )

  richness_df <- matched_position_classes %>%
    filter(!is.na(class_richness)) %>%
    mutate(class_richness = factor(class_richness, levels = 0:3))

  mci_by_richness_plot <- ggplot(
    richness_df,
    aes(x = class_richness, y = confinement_index, color = class_richness)
  ) +
    geom_jitter(width = 0.13, height = 0, size = 1.25, alpha = 0.65, stroke = 0) +
    stat_summary(fun = median, geom = "crossbar", width = 0.50, linewidth = ICAT_LINE_MM * 1.8, color = "black") +
    facet_wrap(~condition, nrow = 1) +
    scale_color_manual(values = richness_colors, drop = FALSE) +
    scale_y_continuous(breaks = pretty_breaks(n = 4), expand = expansion(mult = c(0.02, 0.07))) +
    icat_theme_classic(base_family = "Arial") +
    theme(
      legend.position = "none",
      axis.text.x = element_text(size = ICAT_FONT_SMALL_PT, color = "black"),
      axis.text.y = element_text(size = ICAT_FONT_SMALL_PT, color = "black"),
      strip.text = element_text(size = ICAT_FONT_SMALL_PT, face = "bold"),
      plot.title = element_text(size = ICAT_FONT_TITLE_PT, face = "bold"),
      plot.margin = margin(1.2, 1.2, 1.0, 1.0)
    ) +
    labs(
      title = "MCI by position-class richness",
      x = "Number of classes per cell",
      y = "Microneme confinement index"
  )

  # Class pattern 展示全部分类细胞的非互斥组合；MCI 相关图仍只使用 matched cells。
  class_pattern_df <- scored_position_classes %>%
    filter(!is.na(class_pattern)) %>%
    count(condition, class_pattern, name = "n_cells") %>%
    group_by(condition) %>%
    mutate(fraction = n_cells / sum(n_cells)) %>%
    ungroup()

  pattern_colors <- c(
    "I" = "#C7D8E6",
    "I+II" = "#A9C6D8",
    "I+III" = "#D7A9C8",
    "II" = "#C9B1D9",
    "II+III" = "#D989B5",
    "III" = "#E9A0BF",
    "I+II+III" = "#C83F7A",
    "none" = "#E0E0E0"
  )

  class_pattern_plot <- ggplot(
    class_pattern_df,
    aes(x = condition, y = fraction, fill = class_pattern)
  ) +
    geom_col(width = 0.62, color = "black", linewidth = ICAT_LINE_MM) +
    geom_text(
      aes(label = ifelse(fraction >= 0.12, as.character(n_cells), "")),
      position = position_stack(vjust = 0.5),
      size = ICAT_TEXT_SMALL_MM * 0.78,
      color = "white",
      fontface = "bold"
    ) +
    scale_fill_manual(values = pattern_colors, drop = FALSE) +
    scale_x_discrete(labels = condition_short_labels) +
    scale_y_continuous(labels = percent_format(accuracy = 1), expand = expansion(mult = c(0, 0.03))) +
    icat_theme_classic(base_family = "Arial") +
    theme(
      legend.position = "right",
      legend.title = element_blank(),
      legend.text = element_text(size = ICAT_FONT_SMALL_PT),
      axis.title.x = element_blank(),
      axis.text.x = element_text(size = ICAT_FONT_SMALL_PT, color = "black"),
      axis.text.y = element_text(size = ICAT_FONT_SMALL_PT, color = "black"),
      plot.title = element_text(size = ICAT_FONT_TITLE_PT, face = "bold"),
      plot.margin = margin(1.2, 1.2, 1.0, 1.0)
    ) +
    labs(
      title = "Class patterns",
      y = "Scored cells (%)"
    )

  classIII_mci_df <- matched_position_classes %>%
    mutate(
      class_III_status = factor(
        ifelse(has_class_III, "III+", "III-"),
        levels = c("III-", "III+")
      )
    )

  classIII_status_colors <- c("III-" = "#8FA8B8", "III+" = "#C83F7A")

  mci_by_classIII_plot <- ggplot(
    classIII_mci_df,
    aes(x = class_III_status, y = confinement_index, color = class_III_status)
  ) +
    geom_jitter(width = 0.13, height = 0, size = 1.15, alpha = 0.62, stroke = 0) +
    stat_summary(fun = median, geom = "crossbar", width = 0.48, linewidth = ICAT_LINE_MM * 1.8, color = "black") +
    facet_wrap(~condition, nrow = 1, labeller = labeller(condition = condition_short_labels)) +
    scale_color_manual(values = classIII_status_colors, drop = FALSE) +
    scale_y_continuous(breaks = pretty_breaks(n = 4), expand = expansion(mult = c(0.02, 0.07))) +
    icat_theme_classic(base_family = "Arial") +
    theme(
      legend.position = "none",
      axis.title.x = element_blank(),
      axis.text.x = element_text(size = ICAT_FONT_SMALL_PT, color = "black"),
      axis.text.y = element_text(size = ICAT_FONT_SMALL_PT, color = "black"),
      strip.text = element_text(size = ICAT_FONT_SMALL_PT, face = "bold"),
      plot.title = element_text(size = ICAT_FONT_TITLE_PT, face = "bold"),
      plot.margin = margin(1.2, 1.2, 1.0, 1.0)
    ) +
    labs(
      title = "MCI by III state",
      y = "MCI"
    )

  mci_min <- min(mci_classIII_quadrant$confinement_index, na.rm = TRUE)
  mci_max <- max(mci_classIII_quadrant$confinement_index, na.rm = TRUE)
  mci_range <- mci_max - mci_min
  low_mci_mid <- mean(c(mci_min, vehicle_q95))
  high_mci_mid <- mean(c(vehicle_q95, mci_max))
  low_count_y <- mci_min + 0.14 * mci_range
  high_count_y <- mci_max - 0.16 * mci_range

  quadrant_count_labels <- mci_classIII_quadrant %>%
    count(mci_state, class_III_state, name = "n_cells") %>%
    complete(
      mci_state = factor(c("Low MCI", "High MCI"), levels = c("Low MCI", "High MCI")),
      class_III_state = factor(c("III-", "III+"), levels = c("III-", "III+")),
      fill = list(n_cells = 0)
    ) %>%
    mutate(
      x = ifelse(class_III_state == "III+", 1.24, -0.24),
      y = ifelse(mci_state == "Low MCI", low_count_y, high_count_y),
      hjust = ifelse(class_III_state == "III+", 1, 0),
      label = paste0("n = ", n_cells)
    )

  # 四象限图：横坐标为 Class III 状态，纵坐标为 MCI。
  # 阈值线使用 iKD-vehicle matched cells 的 95th percentile，方便后续修改 high-MCI 定义。
  quadrant_plot <- ggplot(
    mci_classIII_quadrant,
    aes(x = class_III_y, y = confinement_index)
  ) +
    annotate(
      "rect",
      xmin = 0.5, xmax = Inf, ymin = -Inf, ymax = vehicle_q95,
      fill = "#F5E4EC", alpha = 0.85
    ) +
    annotate(
      "rect",
      xmin = -Inf, xmax = 0.5, ymin = vehicle_q95, ymax = Inf,
      fill = "#E7F0F4", alpha = 0.85
    ) +
    geom_vline(xintercept = 0.5, linetype = "dashed", linewidth = ICAT_LINE_MM, color = "#555555") +
    geom_hline(yintercept = vehicle_q95, linetype = "dashed", linewidth = ICAT_LINE_MM, color = "#555555") +
    geom_point(
      aes(color = condition),
      position = position_jitter(width = 0.08, height = 0, seed = 20260715),
      size = 0.95,
      alpha = 0.72,
      stroke = 0
    ) +
    geom_text(
      data = quadrant_count_labels,
      aes(x = x, y = y, label = label, hjust = hjust),
      inherit.aes = FALSE,
      size = ICAT_TEXT_SMALL_MM * 0.66,
      fontface = "bold",
      color = "#2B2B2B"
    ) +
    annotate(
      "text",
      x = 0.78,
      y = low_mci_mid,
      label = "Low MCI\nIII+",
      size = ICAT_TEXT_SMALL_MM * 0.72,
      fontface = "bold",
      color = "#A83265"
    ) +
    annotate(
      "text",
      x = 0.22,
      y = high_mci_mid,
      label = "High MCI\nIII-",
      size = ICAT_TEXT_SMALL_MM * 0.72,
      fontface = "bold",
      color = "#4D6C7A"
    ) +
    scale_color_manual(values = condition_colors) +
    scale_x_continuous(
      breaks = c(0, 1),
      labels = c("III-", "III+"),
      limits = c(-0.32, 1.32),
      expand = expansion(mult = c(0, 0))
    ) +
    scale_y_continuous(breaks = pretty_breaks(n = 4), expand = expansion(mult = c(0.04, 0.07))) +
    icat_theme_classic(base_family = "Arial") +
    theme(
      legend.position = "none",
      axis.text.x = element_text(size = ICAT_FONT_SMALL_PT, color = "black"),
      axis.text.y = element_text(size = ICAT_FONT_SMALL_PT, color = "black"),
      axis.title.x = element_text(size = ICAT_FONT_SMALL_PT),
      axis.title.y = element_text(size = ICAT_FONT_SMALL_PT),
      plot.margin = margin(0.6, 0.8, 0.5, 0.5)
    ) +
    labs(
      x = "Class III state",
      y = "MCI"
    )

  # MCI-Class III 概率图：比四象限更直接展示“随着 MCI 增大，Class III+ 比例如何变化”。
  # 主图显示 pooled matched cells 的低/中/高 MCI 三分位比例点，阴影线为探索性 logistic trend。
  classIII_probability_cells <- mci_classIII_quadrant %>%
    mutate(has_class_III = class_III_state == "III+")

  mci_bin_breaks <- quantile(
    classIII_probability_cells$confinement_index,
    probs = c(0, 1 / 3, 2 / 3, 1),
    na.rm = TRUE,
    names = FALSE
  )
  mci_bin_breaks[[1]] <- mci_bin_breaks[[1]] - .Machine$double.eps
  mci_bin_labels <- c("Low", "Mid", "High")

  exact_binom_ci <- function(success, total, index) {
    if (is.na(total) || total == 0) {
      return(NA_real_)
    }
    binom.test(success, total)$conf.int[[index]]
  }

  classIII_fraction_by_mci_bin <- classIII_probability_cells %>%
    mutate(
      mci_bin = cut(
        confinement_index,
        breaks = mci_bin_breaks,
        labels = mci_bin_labels,
        include.lowest = TRUE,
        ordered_result = TRUE
      )
    ) %>%
    group_by(mci_bin) %>%
    summarise(
      mci_min = min(confinement_index),
      mci_max = max(confinement_index),
      mci_median = median(confinement_index),
      n_cells = n(),
      n_class_III = sum(has_class_III),
      fraction_class_III = mean(has_class_III),
      .groups = "drop"
    ) %>%
    mutate(
      ci_low = mapply(exact_binom_ci, n_class_III, n_cells, MoreArgs = list(index = 1)),
      ci_high = mapply(exact_binom_ci, n_class_III, n_cells, MoreArgs = list(index = 2)),
      bin_label = sprintf("%s\n%.2f-%.2f", mci_bin, mci_min, mci_max),
      plot_label = sprintf("%s\n%d/%d", percent(fraction_class_III, accuracy = 1), n_class_III, n_cells)
    )

  classIII_fraction_by_mci_bin_condition <- classIII_probability_cells %>%
    mutate(
      mci_bin = cut(
        confinement_index,
        breaks = mci_bin_breaks,
        labels = mci_bin_labels,
        include.lowest = TRUE,
        ordered_result = TRUE
      )
    ) %>%
    group_by(condition, mci_bin) %>%
    summarise(
      n_cells = n(),
      n_class_III = sum(has_class_III),
      fraction_class_III = mean(has_class_III),
      .groups = "drop"
    ) %>%
    mutate(
      ci_low = mapply(exact_binom_ci, n_class_III, n_cells, MoreArgs = list(index = 1)),
      ci_high = mapply(exact_binom_ci, n_class_III, n_cells, MoreArgs = list(index = 2))
    )

  classIII_probability_fit <- glm(
    has_class_III ~ confinement_index,
    family = binomial(),
    data = classIII_probability_cells
  )
  # pooled single-cell MCI 圆圈：显示所有 matched cells 在同一条概率曲线附近的分布。
  # y 值复用当前 logistic 模型的预测概率；圆圈只作为低透明度背景层，不改变统计结果。
  classIII_probability_cells_plot <- classIII_probability_cells %>%
    mutate(
      predicted_probability = predict(
        classIII_probability_fit,
        newdata = classIII_probability_cells,
        type = "response"
      )
    )
  probability_curve_df <- data.frame(
    confinement_index = seq(
      min(classIII_probability_cells$confinement_index, na.rm = TRUE),
      max(classIII_probability_cells$confinement_index, na.rm = TRUE),
      length.out = 180
    )
  )
  probability_curve_prediction <- predict(
    classIII_probability_fit,
    newdata = probability_curve_df,
    type = "link",
    se.fit = TRUE
  )
  probability_curve_df <- probability_curve_df %>%
    mutate(
      probability = plogis(probability_curve_prediction$fit),
      ci_low = plogis(probability_curve_prediction$fit - 1.96 * probability_curve_prediction$se.fit),
      ci_high = plogis(probability_curve_prediction$fit + 1.96 * probability_curve_prediction$se.fit)
    )

  classIII_probability_coef <- summary(classIII_probability_fit)$coefficients
  classIII_probability_trend <- data.frame(
    model = "Class III positivity ~ MCI",
    term = "MCI, per 0.1 unit increase",
    log_odds = classIII_probability_coef["confinement_index", "Estimate"] * 0.1,
    se = classIII_probability_coef["confinement_index", "Std. Error"] * 0.1,
    odds_ratio = exp(classIII_probability_coef["confinement_index", "Estimate"] * 0.1),
    ci_low = exp((classIII_probability_coef["confinement_index", "Estimate"] - 1.96 * classIII_probability_coef["confinement_index", "Std. Error"]) * 0.1),
    ci_high = exp((classIII_probability_coef["confinement_index", "Estimate"] + 1.96 * classIII_probability_coef["confinement_index", "Std. Error"]) * 0.1),
    exploratory_p_value = classIII_probability_coef["confinement_index", "Pr(>|z|)"],
    n_cells = nrow(classIII_probability_cells)
  )

  write.csv(classIII_fraction_by_mci_bin, file.path(class_table_dir, "MCI_ClassIII_fraction_by_MCI_bin.csv"), row.names = FALSE)
  write.csv(classIII_fraction_by_mci_bin_condition, file.path(class_table_dir, "MCI_ClassIII_fraction_by_MCI_bin_by_condition.csv"), row.names = FALSE)
  write.csv(classIII_probability_trend, file.path(class_table_dir, "MCI_ClassIII_probability_trend.csv"), row.names = FALSE)

  classIII_probability_plot <- ggplot() +
    geom_ribbon(
      data = probability_curve_df,
      aes(x = confinement_index, ymin = ci_low, ymax = ci_high),
      fill = "#C83F7A",
      alpha = 0.14
    ) +
    geom_point(
      data = classIII_probability_cells_plot,
      aes(x = confinement_index, y = predicted_probability, color = condition),
      position = position_jitter(width = 0.003, height = 0.018, seed = 20260715),
      size = 0.6,
      alpha = 0.2,
      stroke = 0
    ) +
    geom_line(
      data = probability_curve_df,
      aes(x = confinement_index, y = probability),
      color = "#A83265",
      linewidth = ICAT_LINE_MM * 1.4
    ) +
    geom_errorbar(
      data = classIII_fraction_by_mci_bin,
      aes(x = mci_median, ymin = ci_low, ymax = ci_high),
      width = 0.018,
      linewidth = ICAT_LINE_MM * 0.9,
      color = "#2B2B2B"
    ) +
    geom_point(
      data = classIII_fraction_by_mci_bin,
      aes(x = mci_median, y = fraction_class_III),
      size = 1.45,
      shape = 21,
      stroke = ICAT_LINE_MM,
      fill = "white",
      color = "#2B2B2B"
    ) +
    geom_text(
      data = classIII_fraction_by_mci_bin,
      aes(x = mci_median, y = pmin(ci_high + 0.09, 1.05), label = plot_label),
      size = ICAT_TEXT_SMALL_MM * 0.56,
      lineheight = 0.82,
      fontface = "bold",
      color = "#2B2B2B"
    ) +
    scale_color_manual(values = condition_colors) +
    scale_x_continuous(breaks = pretty_breaks(n = 4), expand = expansion(mult = c(0.03, 0.05))) +
    scale_y_continuous(
      labels = percent_format(accuracy = 1),
      limits = c(0, 1.08),
      expand = expansion(mult = c(0, 0))
    ) +
    icat_theme_classic(base_family = "Arial") +
    theme(
      legend.position = "none",
      axis.text.x = element_text(size = 7.2, color = "black"),
      axis.text.y = element_text(size = 7.2, color = "black"),
      axis.title.x = element_text(size = 7.6),
      axis.title.y = element_text(size = 7.6),
      plot.margin = margin(0.55, 0.55, 0.45, 0.55)
    ) +
    labs(
      x = "MCI",
      y = "Class III+ cells (%)"
    )

  linked_classIII_plot <- (class_pattern_plot | mci_by_classIII_plot) +
    plot_layout(widths = c(0.95, 1.45)) +
    plot_annotation(
      title = "MCI and Class III in matched cells",
      theme = theme(
        plot.title = element_text(
          family = "Arial",
          size = ICAT_FONT_TITLE_PT,
          face = "bold",
          hjust = 0
        )
      )
    )

  barcode_df <- matched_position_classes %>%
    group_by(condition) %>%
    arrange(confinement_index, .by_group = TRUE) %>%
    mutate(cell_rank = row_number()) %>%
    ungroup()

  make_mci_density <- function(condition_df, global_y_range) {
    condition_df <- condition_df[!is.na(condition_df$confinement_index), , drop = FALSE]
    if (nrow(condition_df) < 2) {
      return(data.frame())
    }
    density_fit <- density(
      condition_df$confinement_index,
      from = global_y_range[[1]],
      to = global_y_range[[2]],
      n = 160
    )
    data.frame(
      condition = condition_df$condition[[1]],
      y = density_fit$x,
      density_scaled = density_fit$y / max(density_fit$y, na.rm = TRUE),
      density = density_fit$y
    )
  }

  # 纵轴分布趋势：两个 condition 的 MCI density 重叠放在整张 barcode 图最右侧。
  # 该分布 panel 使用同一 y 轴尺度，便于直接比较 vehicle 与 IAA 的 MCI 分布位移。
  mci_y_range <- range(barcode_df$confinement_index, na.rm = TRUE)
  barcode_density_df <- barcode_df %>%
    split(.$condition) %>%
    lapply(make_mci_density, global_y_range = mci_y_range) %>%
    bind_rows() %>%
    mutate(condition = factor(condition, levels = c("iKD-vehicle", "iKD-IAA")))

  # 使用 free_x + space = "free_x"：不同 condition 宽度按细胞数分配，
  # 既保持每个 cell-rank 的物理间隔一致，也减少两组之间的无效空白。
  barcode_x_max <- max(barcode_df$cell_rank, na.rm = TRUE)
  barcode_x_breaks <- seq(0, ceiling(barcode_x_max / 25) * 25, by = 25)
  # 坐标轴字号和两组之间的留白集中放在这里，便于后续微调。
  barcode_axis_text_pt <- 7.2
  barcode_axis_title_pt <- 7.6
  barcode_strip_text_pt <- 7.2
  barcode_panel_gap_cm <- 0.06

  barcode_long <- barcode_df %>%
    select(condition, cell_rank, class_I, class_II, class_III) %>%
    pivot_longer(
      cols = starts_with("class_"),
      names_to = "microneme_class",
      values_to = "present"
    ) %>%
    mutate(
      microneme_class = recode(
        microneme_class,
        "class_I" = "Class I",
        "class_II" = "Class II",
        "class_III" = "Class III"
      ),
      microneme_class = factor(microneme_class, levels = c("Class III", "Class II", "Class I")),
      present = factor(present, levels = c(0, 1), labels = c("absent", "present"))
    )

  barcode_mci_plot <- ggplot(
    barcode_df,
    aes(x = cell_rank, y = confinement_index, color = condition)
  ) +
    geom_point(size = 1.05, alpha = 0.75, stroke = 0) +
    geom_line(linewidth = ICAT_LINE_MM * 0.8, alpha = 0.45) +
    facet_grid(. ~ condition, scales = "free_x", space = "free_x") +
    scale_color_manual(values = condition_colors) +
    scale_x_continuous(
      breaks = barcode_x_breaks,
      expand = expansion(mult = c(0.015, 0.025))
    ) +
    scale_y_continuous(breaks = pretty_breaks(n = 4), expand = expansion(mult = c(0.04, 0.08))) +
    icat_theme_classic(base_family = "Arial") +
    theme(
      legend.position = "none",
      axis.title.x = element_blank(),
      axis.text.x = element_blank(),
      axis.ticks.x = element_blank(),
      axis.text.y = element_text(size = barcode_axis_text_pt, color = "black"),
      axis.title.y = element_text(size = barcode_axis_title_pt),
      strip.text = element_text(size = barcode_axis_text_pt, face = "bold"),
      panel.spacing.x = grid::unit(barcode_panel_gap_cm, "cm"),
      plot.title = element_text(size = 6.5, face = "bold"),
      plot.margin = margin(0.45, 0.55, 0.10, 0.35)
    ) +
    labs(
      title = "Matched-cell MCI rank",
      y = "MCI"
    )

  # 右侧 MCI density 是辅助趋势，不作为主阅读区域；
  # 如需再次调整宽窄，可修改下面的 density_panel_width 和 plot_layout(widths)。
  density_panel_width <- 0.11

  barcode_density_overlay_plot <- ggplot(
    barcode_density_df,
    aes(x = density_scaled, y = y, color = condition, fill = condition)
  ) +
    geom_ribbon(
      aes(xmin = 0, xmax = density_scaled),
      alpha = 0.18,
      color = NA
    ) +
    geom_path(linewidth = ICAT_LINE_MM * 1.35, alpha = 0.95) +
    geom_vline(xintercept = 0, linewidth = ICAT_LINE_MM, color = "#555555") +
    scale_color_manual(values = condition_colors) +
    scale_fill_manual(values = condition_colors) +
    scale_x_continuous(limits = c(0, 1.08), breaks = NULL, expand = expansion(mult = c(0, 0.04))) +
    scale_y_continuous(limits = mci_y_range, breaks = pretty_breaks(n = 4), expand = expansion(mult = c(0.04, 0.08))) +
    icat_theme_classic(base_family = "Arial") +
    theme(
      legend.position = "none",
      axis.title = element_blank(),
      axis.text.x = element_blank(),
      axis.text.y = element_blank(),
      axis.ticks.x = element_blank(),
      axis.ticks.y = element_blank(),
      axis.line.y = element_blank(),
      axis.line.x = element_blank(),
      plot.title = element_text(size = 5.2, face = "bold", hjust = 0.5, lineheight = 0.82),
      plot.margin = margin(0.45, 0.25, 0.10, 0)
    ) +
    labs(title = "MCI\ndens.")

  barcode_strip_plot <- ggplot(
    barcode_long,
    aes(x = cell_rank, y = microneme_class, fill = present)
  ) +
    geom_tile(color = "white", linewidth = ICAT_LINE_MM * 0.45) +
    facet_grid(. ~ condition, scales = "free_x", space = "free_x") +
    scale_fill_manual(values = c("absent" = "#ECECEC", "present" = "#C83F7A"), drop = FALSE) +
    scale_x_continuous(
      breaks = barcode_x_breaks,
      expand = expansion(mult = c(0.015, 0.025))
    ) +
    scale_y_discrete(limits = c("Class III", "Class II", "Class I")) +
    icat_theme_classic(base_family = "Arial") +
    theme(
      legend.position = "none",
      legend.title = element_blank(),
      legend.text = element_text(size = ICAT_FONT_SMALL_PT),
      axis.title = element_blank(),
      axis.text.x = element_text(size = barcode_axis_text_pt, color = "black"),
      axis.text.y = element_text(size = barcode_strip_text_pt, color = "black"),
      axis.line = element_blank(),
      axis.ticks = element_blank(),
      strip.text = element_blank(),
      panel.spacing.x = grid::unit(barcode_panel_gap_cm, "cm"),
      plot.margin = margin(0, 0.55, 0.25, 0.35)
    )

  barcode_density_spacer_plot <- ggplot() +
    theme_void() +
    theme(plot.margin = margin(0, 0.25, 0.25, 0))

  # 用显式 top/bottom row 控制 patchwork 宽度，确保重叠 density 只作为最右侧窄 panel。
  barcode_top_row <- (barcode_mci_plot | barcode_density_overlay_plot) +
    plot_layout(widths = c(1, density_panel_width))
  barcode_bottom_row <- (barcode_strip_plot | barcode_density_spacer_plot) +
    plot_layout(widths = c(1, density_panel_width))

  barcode_plot <- barcode_top_row / barcode_bottom_row +
    plot_layout(heights = c(1.35, 0.72)) +
    plot_annotation(
      title = NULL,
      theme = theme(
        plot.title = element_text(
          family = "Arial",
          size = 6.5,
          face = "bold",
          hjust = 0
        )
      )
    )

save_figure(class_positive_plot, "Fig5_position_class_positive_cells", class_figure_dir, width_cm = 8.2, height_cm = 4.5)
save_figure(mci_by_richness_plot, "Fig5_MCI_by_position_class_richness", class_figure_dir, width_cm = 8.2, height_cm = 4.5)
save_figure(linked_classIII_plot, "Fig5_MCI_ClassIII_linked", class_figure_dir, width_cm = 12.4, height_cm = 4.8)
save_figure(barcode_plot, "Fig5_MCI_position_class_cell_barcode", class_figure_dir, width_cm = 9.5, height_cm = 3.7)
# 四象限主图 panel 的导出尺寸；如需调整该图大小，优先修改这里的 width_cm 和 height_cm。
save_figure(quadrant_plot, "Fig5_MCI_ClassIII_quadrant", class_figure_dir, width_cm = 4.0, height_cm = 3.6)
save_figure(classIII_probability_plot, "Fig5_MCI_ClassIII_probability_curve", class_figure_dir, width_cm = 4.2, height_cm = 3.6)

  integrated_plot <- class_positive_plot / mci_by_richness_plot +
    plot_layout(heights = c(1, 1.08)) +
    plot_annotation(
      title = "Microneme position classes and confinement",
      theme = theme(
        plot.title = element_text(
          family = "Arial",
          size = ICAT_FONT_TITLE_PT,
          face = "bold",
          hjust = 0
        )
      )
    )

  save_figure(integrated_plot, "Fig5_MCI_position_class_integrated", class_figure_dir, width_cm = 8.6, height_cm = 8.4)

  class_report_lines <- c(
    "## Position-class integration",
    "",
    sprintf("Position-class data were read from `%s`.", basename(position_class_input)),
    sprintf("Rows in position-class table: %d.", nrow(position_classes)),
    sprintf("Scored cells with Class I/II/III data: %d.", nrow(scored_position_classes)),
    sprintf("Cells matched to MCI measurements: %d.", nrow(matched_position_classes)),
    sprintf("Position-class rows not matched to an MCI cell: %d.", nrow(unmatched_position_classes)),
    "Class I/II/III are non-mutually exclusive at the cell level; a single cell may contain micronemes in more than one class.",
    "Class III marks MIC2+ micronemes apical to the conoid, corresponding to the final apical-exit/fusion step of secretion.",
    "Class-positive and class-pattern summaries use all scored cells. MCI-linked plots use only cells matched to MCI measurements; unmatched position-class rows are exported separately for audit.",
    "",
    "Generated outputs:",
    "- `microneme_position_class_long.csv`",
    "- `microneme_position_class_scored.csv`",
    "- `microneme_position_class_MCI_matched.csv`",
    "- `microneme_position_class_unmatched_to_MCI.csv`",
    "- `microneme_position_class_positive_summary.csv`",
    "- `MCI_by_position_class_pattern.csv`",
    "- `MCI_ClassIII_quadrant_summary.csv`",
    "- `MCI_ClassIII_fraction_by_MCI_bin.csv`",
    "- `MCI_ClassIII_fraction_by_MCI_bin_by_condition.csv`",
    "- `MCI_ClassIII_probability_trend.csv`",
    "- `Fig5_position_class_positive_cells.*`",
    "- `Fig5_MCI_by_position_class_richness.*`",
    "- `Fig5_MCI_ClassIII_linked.*`",
    "- `Fig5_MCI_position_class_cell_barcode.*`",
    "- `Fig5_MCI_ClassIII_quadrant.*`",
    "- `Fig5_MCI_ClassIII_probability_curve.*`",
    "- `Fig5_MCI_position_class_integrated.*`"
  )
}

report <- c(
  "# Cell-level audit of Microneme confinement index after ICAT depletion",
  "",
  "Definition: Microneme confinement index (MCI) = MIC2-positive width / Tubulin-defined conoid width.",
  mci_source_note,
  "",
  "## Result",
  "",
  sprintf(
    "- iKD-vehicle: n = %d cells, mean MCI = %.3f, median = %.3f, SD = %.3f.",
    length(vehicle), mean(vehicle), median(vehicle), sd(vehicle)
  ),
  sprintf(
    "- iKD-IAA: n = %d cells, mean MCI = %.3f, median = %.3f, SD = %.3f.",
    length(iaa), mean(iaa), median(iaa), sd(iaa)
  ),
  sprintf(
    "- Mean MCI shift (iKD-IAA - iKD-vehicle): %.3f; cell-level bootstrap 95%% interval %.3f to %.3f.",
    mean_diff, ci[[1]], ci[[2]]
  ),
  sprintf("- Mean fold change: %.2fx.", fold_change),
  sprintf("- Cliff's delta: %.3f.", delta),
  sprintf(
    "- %.1f%% of iKD-IAA cells exceed the iKD-vehicle 95th percentile (%.3f).",
    100 * iaa_above_vehicle_q95, vehicle_q95
  ),
  "",
  paste(
    "ICAT depletion increases the Microneme confinement index, indicating",
    "expansion of the MIC2-positive domain relative to the Tubulin-defined",
    "conoid reference. This is consistent with reduced microneme confinement",
    "and lower productive secretion efficiency."
  ),
  "",
  "## Statistical boundary",
  "",
  paste(
    "The MCI source tables contain only group labels, MIC2 width, Tubulin width,",
    "and ratio. They do not include biological-replicate, acquisition-date,",
    "field, clone, or treatment-batch identifiers. Consequently:"
  ),
  "",
  "- the values above are cell-level descriptive statistics;",
  "- the bootstrap interval treats cells as the resampling unit and is exploratory;",
  "- no cell-level P value should be presented as definitive inferential evidence;",
  "- the effect should be reproduced with independently identified biological replicates before definitive inference.",
  "",
  "## Mechanistic interpretation",
  "",
  paste(
    "MCI reports lateral spread relative to the conoid reference. It supports",
    "loss of microneme confinement, but by itself does not distinguish failed",
    "terminal positioning, increased local microneme accumulation, altered",
    "conoid geometry, or imaging/segmentation effects."
  ),
  "",
  class_report_lines
)
writeLines(report, file.path(report_dir, "ICATkd_MCI_audit.md"))

if (interactive()) {
  print(main_plot)
  print(ecdf_plot)
}
