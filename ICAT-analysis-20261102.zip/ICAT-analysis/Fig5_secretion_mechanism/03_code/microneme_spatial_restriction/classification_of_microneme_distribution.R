#!/usr/bin/env Rscript

# Fig. 5 microneme position-class prevalence flow.
script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
script_path <- normalizePath(sub("^--file=", "", script_arg[[1]]), mustWork = TRUE)
fig_dir <- normalizePath(file.path(dirname(script_path), "..", ".."), mustWork = TRUE)
project_root <- normalizePath(file.path(fig_dir, ".."), mustWork = TRUE)
source(file.path(project_root, "shared", "R", "project_library.R"))
icat_activate_project_library(project_root)

library(readxl)
library(ggplot2)
library(dplyr)
library(tidyr)
library(scales)
library(patchwork)
library(grid)

source(file.path(project_root, "shared", "R", "plot_style.R"))

input_path <- file.path(
  fig_dir,
  "01_raw_data", "microneme_spatial_restriction",
  "classification of microneme", "classification of microneme.xlsx"
)
output_root <- Sys.getenv("ICAT_MICRONEME_CLASS_OUTPUT_ROOT", unset = fig_dir)
table_dir <- file.path(output_root, "04_results", "tables", "microneme_spatial_restriction", "classification_of_microneme")
figure_dir <- file.path(output_root, "04_results", "figures", "microneme_spatial_restriction", "classification_of_microneme")
report_dir <- file.path(output_root, "04_results", "reports", "microneme_spatial_restriction", "classification_of_microneme")
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(report_dir, recursive = TRUE, showWarnings = FALSE)

if (!file.exists(input_path)) {
  stop("Input workbook not found: ", input_path)
}

class_levels <- c("Class I", "Class II", "Class III")
class_labels <- c(
  "Class I" = "I radial",
  "Class II" = "II inner",
  "Class III" = "III docked"
)
condition_levels <- c("iKD-vehicle", "iKD-IAA")
condition_labels <- c("iKD-vehicle" = "vehicle", "iKD-IAA" = "IAA")

raw_sheet <- read_excel(input_path, sheet = "raw", col_names = FALSE, .name_repair = "minimal")

extract_condition <- function(raw, condition, total_col, class_cols) {
  count_rows <- 4:6
  tibble(
    replicate = seq_along(count_rows),
    condition = condition,
    n_total = as.numeric(unlist(raw[count_rows, total_col], use.names = FALSE)),
    `Class III` = as.numeric(unlist(raw[count_rows, class_cols[["Class III"]]], use.names = FALSE)),
    `Class II` = as.numeric(unlist(raw[count_rows, class_cols[["Class II"]]], use.names = FALSE)),
    `Class I` = as.numeric(unlist(raw[count_rows, class_cols[["Class I"]]], use.names = FALSE))
  ) %>%
    pivot_longer(
      cols = all_of(class_levels),
      names_to = "microneme_class",
      values_to = "n_positive"
    ) %>%
    mutate(
      condition = factor(condition, levels = condition_levels),
      microneme_class = factor(microneme_class, levels = class_levels),
      class_label = recode(as.character(microneme_class), !!!class_labels),
      prevalence_percent = 100 * n_positive / n_total
    )
}

# Excel raw sheet layout:
# vehicle columns = total, III/docked, II/inner-conoid, I/radial;
# IAA columns use the same structure on the right side of the sheet.
class_long <- bind_rows(
  extract_condition(
    raw_sheet,
    condition = "iKD-vehicle",
    total_col = 2,
    class_cols = c("Class III" = 3, "Class II" = 4, "Class I" = 5)
  ),
  extract_condition(
    raw_sheet,
    condition = "iKD-IAA",
    total_col = 7,
    class_cols = c("Class III" = 8, "Class II" = 9, "Class I" = 10)
  )
)

summary_table <- class_long %>%
  group_by(condition, microneme_class, class_label) %>%
  summarise(
    n_replicates = n(),
    total_cells = sum(n_total),
    total_positive = sum(n_positive),
    pooled_prevalence_percent = 100 * total_positive / total_cells,
    mean_prevalence_percent = mean(prevalence_percent),
    median_prevalence_percent = median(prevalence_percent),
    sd_prevalence_percent = sd(prevalence_percent),
    min_prevalence_percent = min(prevalence_percent),
    max_prevalence_percent = max(prevalence_percent),
    .groups = "drop"
  )

effect_table <- summary_table %>%
  select(condition, microneme_class, class_label, mean_prevalence_percent, pooled_prevalence_percent) %>%
  pivot_wider(
    names_from = condition,
    values_from = c(mean_prevalence_percent, pooled_prevalence_percent)
  ) %>%
  mutate(
    mean_shift_IAA_minus_vehicle = `mean_prevalence_percent_iKD-IAA` - `mean_prevalence_percent_iKD-vehicle`,
    pooled_shift_IAA_minus_vehicle = `pooled_prevalence_percent_iKD-IAA` - `pooled_prevalence_percent_iKD-vehicle`
  )

format_significance <- function(q_value) {
  dplyr::case_when(
    is.na(q_value) ~ "NA",
    q_value < 0.001 ~ "***",
    q_value < 0.01 ~ "**",
    q_value < 0.05 ~ "*",
    TRUE ~ "ns"
  )
}

paired_stats <- class_long %>%
  select(replicate, microneme_class, class_label, condition, prevalence_percent) %>%
  pivot_wider(names_from = condition, values_from = prevalence_percent) %>%
  group_by(microneme_class, class_label) %>%
  summarise(
    n_pairs = n(),
    mean_difference_IAA_minus_vehicle = mean(`iKD-IAA` - `iKD-vehicle`),
    paired_t_p_value = t.test(`iKD-IAA`, `iKD-vehicle`, paired = TRUE)$p.value,
    paired_wilcoxon_p_value = suppressWarnings(
      wilcox.test(`iKD-IAA`, `iKD-vehicle`, paired = TRUE, exact = FALSE)$p.value
    ),
    .groups = "drop"
  ) %>%
  mutate(
    paired_t_BH_q_value = p.adjust(paired_t_p_value, method = "BH"),
    significance = format_significance(paired_t_BH_q_value)
  )

effect_table <- effect_table %>%
  left_join(paired_stats, by = c("microneme_class", "class_label"))

write.csv(class_long, file.path(table_dir, "microneme_classification_long.csv"), row.names = FALSE)
write.csv(summary_table, file.path(table_dir, "microneme_classification_summary.csv"), row.names = FALSE)
write.csv(effect_table, file.path(table_dir, "microneme_classification_vehicle_to_IAA_effects.csv"), row.names = FALSE)
write.csv(paired_stats, file.path(table_dir, "microneme_classification_paired_statistics.csv"), row.names = FALSE)

save_figure <- function(plot, stem, output_dir, width_cm, height_cm) {
  png_dir <- file.path(output_dir, "PNG")
  pdf_dir <- file.path(output_dir, "PDF")
  svg_dir <- file.path(output_dir, "SVG")
  dir.create(png_dir, recursive = TRUE, showWarnings = FALSE)
  dir.create(pdf_dir, recursive = TRUE, showWarnings = FALSE)
  dir.create(svg_dir, recursive = TRUE, showWarnings = FALSE)

  ggsave(
    file.path(png_dir, paste0(stem, ".png")),
    plot = plot,
    width = width_cm / 2.54,
    height = height_cm / 2.54,
    units = "in",
    dpi = 600,
    device = ragg::agg_png,
    bg = "transparent"
  )
  ggsave(
    file.path(pdf_dir, paste0(stem, ".pdf")),
    plot = plot,
    width = width_cm / 2.54,
    height = height_cm / 2.54,
    units = "in",
    device = grDevices::cairo_pdf,
    family = "Arial"
  )
  ggsave(
    file.path(svg_dir, paste0(stem, ".svg")),
    plot = plot,
    width = width_cm / 2.54,
    height = height_cm / 2.54,
    units = "in",
    device = grDevices::svg,
    bg = "transparent"
  )
}

class_colors <- c(
  "Class I" = "#8FA8B8",
  "Class II" = "#C8A56A",
  "Class III" = "#C83F7A"
)
condition_colors <- c("iKD-vehicle" = "#2F7DB7", "iKD-IAA" = "#D73027")

flow_means <- summary_table %>%
  select(condition, microneme_class, class_label, mean_prevalence_percent) %>%
  mutate(condition_x = as.numeric(condition))

flow_segments <- flow_means %>%
  select(condition, microneme_class, class_label, mean_prevalence_percent) %>%
  pivot_wider(names_from = condition, values_from = mean_prevalence_percent) %>%
  mutate(
    x = 1,
    xend = 2,
    y = `iKD-vehicle`,
    yend = `iKD-IAA`,
    label_y = `iKD-IAA`,
    delta_label = sprintf("%+.1f pp", `iKD-IAA` - `iKD-vehicle`)
  )

# 三类 microneme 是非互斥读数，因此这里用 independent prevalence flow，
# 不使用 stacked bar；每条线表示该 class 从 vehicle 到 IAA 的阳性率变化。
flow_plot <- ggplot() +
  geom_line(
    data = class_long,
    aes(
      x = as.numeric(condition),
      y = prevalence_percent,
      group = interaction(microneme_class, replicate),
      color = microneme_class
    ),
    linewidth = ICAT_LINE_MM * 1.2,
    alpha = 0.28
  ) +
  geom_segment(
    data = flow_segments,
    aes(x = x, xend = xend, y = y, yend = yend, color = microneme_class),
    linewidth = ICAT_LINE_MM * 4.5,
    lineend = "round",
    arrow = arrow(length = unit(0.10, "cm"), type = "closed")
  ) +
  geom_point(
    data = flow_means,
    aes(x = condition_x, y = mean_prevalence_percent, fill = microneme_class),
    shape = 21,
    size = 2.2,
    stroke = ICAT_LINE_MM * 1.8,
    color = "black"
  ) +
  geom_point(
    data = class_long,
    aes(x = as.numeric(condition), y = prevalence_percent, color = microneme_class),
    size = 1.2,
    alpha = 0.55,
    stroke = 0
  ) +
  geom_text(
    data = flow_segments,
    aes(x = 2.08, y = label_y, label = paste(class_label, delta_label), color = microneme_class),
    hjust = 0,
    size = ICAT_TEXT_SMALL_MM * 0.88,
    fontface = "bold"
  ) +
  scale_color_manual(values = class_colors, guide = "none") +
  scale_fill_manual(values = class_colors, guide = "none") +
  scale_x_continuous(
    breaks = c(1, 2),
    labels = c("vehicle", "IAA"),
    limits = c(0.86, 2.55),
    expand = expansion(mult = c(0, 0))
  ) +
  scale_y_continuous(
    labels = label_percent(scale = 1, accuracy = 1),
    limits = c(0, 105),
    breaks = seq(0, 100, 25),
    expand = expansion(mult = c(0, 0.03))
  ) +
  icat_theme_classic(base_family = "Arial") +
  theme(
    axis.title.x = element_blank(),
    axis.text = element_text(size = ICAT_FONT_SMALL_PT, color = "black"),
    axis.title.y = element_text(size = ICAT_FONT_SMALL_PT),
    plot.title = element_text(size = ICAT_FONT_TITLE_PT, face = "bold"),
    plot.subtitle = element_text(size = ICAT_FONT_SMALL_PT, color = "#3A3A3A"),
    plot.margin = margin(1.2, 4.8, 1.0, 1.0)
  ) +
  labs(
    title = "Microneme position-class flow",
    subtitle = "Non-exclusive class prevalence across replicates",
    y = "Cells with class (%)"
  ) +
  coord_cartesian(clip = "off")

compact_labels <- effect_table %>%
  transmute(
    microneme_class,
    class_short = recode(
      as.character(microneme_class),
      "Class I" = "I",
      "Class II" = "II",
      "Class III" = "III"
    ),
    label = paste0(class_short, " ", significance),
    label_y = `mean_prevalence_percent_iKD-IAA`
  )

# 4 x 3.5 cm compact panel：只保留三类从 vehicle 到 IAA 的趋势和统计标注。
# 如果后续需要调整小图尺寸，请修改下方 save_figure(compact_trend_plot, ...) 的 width_cm/height_cm。
compact_trend_plot <- ggplot() +
  geom_line(
    data = class_long,
    aes(
      x = as.numeric(condition),
      y = prevalence_percent,
      group = interaction(microneme_class, replicate),
      color = microneme_class
    ),
    linewidth = ICAT_LINE_MM * 0.85,
    alpha = 0.24
  ) +
  geom_segment(
    data = flow_segments,
    aes(x = x, xend = xend, y = y, yend = yend, color = microneme_class),
    linewidth = ICAT_LINE_MM * 3.5,
    lineend = "round"
  ) +
  geom_point(
    data = flow_means,
    aes(x = condition_x, y = mean_prevalence_percent, fill = microneme_class),
    shape = 21,
    size = 1.35,
    stroke = ICAT_LINE_MM * 1.3,
    color = "black"
  ) +
  geom_text(
    data = compact_labels,
    aes(x = 2.12, y = label_y, label = label, color = microneme_class),
    inherit.aes = FALSE,
    hjust = 0,
    size = ICAT_TEXT_SMALL_MM * 0.78,
    fontface = "bold"
  ) +
  scale_color_manual(values = class_colors, guide = "none") +
  scale_fill_manual(values = class_colors, guide = "none") +
  scale_x_continuous(
    breaks = c(1, 2),
    labels = c("veh", "IAA"),
    limits = c(0.92, 2.36),
    expand = expansion(mult = c(0, 0))
  ) +
  scale_y_continuous(
    labels = label_percent(scale = 1, accuracy = 1),
    limits = c(0, 105),
    breaks = c(0, 50, 100),
    expand = expansion(mult = c(0, 0.02))
  ) +
  icat_theme_classic(base_family = "Arial") +
  theme(
    axis.title.x = element_blank(),
    axis.text.x = element_text(size = ICAT_FONT_SMALL_PT, color = "black"),
    axis.text.y = element_text(size = ICAT_FONT_SMALL_PT, color = "black"),
    axis.title.y = element_text(size = ICAT_FONT_SMALL_PT),
    plot.margin = margin(0.5, 2.6, 0.5, 0.4)
  ) +
  labs(y = "Cells (%)") +
  coord_cartesian(clip = "off")

dot_plot <- ggplot(
  class_long,
  aes(x = microneme_class, y = prevalence_percent, color = condition)
) +
  geom_point(
    position = position_dodge(width = 0.45),
    size = 1.45,
    alpha = 0.75,
    stroke = 0
  ) +
  stat_summary(
    aes(group = condition),
    fun = mean,
    geom = "crossbar",
    position = position_dodge(width = 0.45),
    width = 0.32,
    linewidth = ICAT_LINE_MM * 1.6,
    color = "black"
  ) +
  scale_color_manual(values = condition_colors, labels = condition_labels) +
  scale_x_discrete(labels = class_labels) +
  scale_y_continuous(
    labels = label_percent(scale = 1, accuracy = 1),
    limits = c(0, 105),
    breaks = seq(0, 100, 25),
    expand = expansion(mult = c(0, 0.03))
  ) +
  icat_theme_classic(base_family = "Arial") +
  theme(
    legend.position = "top",
    legend.title = element_blank(),
    legend.text = element_text(size = ICAT_FONT_SMALL_PT),
    axis.title.x = element_blank(),
    axis.text.x = element_text(size = ICAT_FONT_SMALL_PT, color = "black", angle = 25, hjust = 1),
    axis.text.y = element_text(size = ICAT_FONT_SMALL_PT, color = "black"),
    axis.title.y = element_text(size = ICAT_FONT_SMALL_PT),
    plot.title = element_text(size = ICAT_FONT_TITLE_PT, face = "bold"),
    plot.margin = margin(1.2, 1.2, 1.0, 1.0)
  ) +
  labs(
    title = "Replicate prevalence",
    y = "Cells with class (%)"
  )

combined_plot <- flow_plot / dot_plot +
  plot_layout(heights = c(1.25, 1)) +
  plot_annotation(
    title = "Microneme class distribution shifts after ICAT depletion",
    theme = theme(
      plot.title = element_text(
        family = "Arial",
        size = ICAT_FONT_TITLE_PT,
        face = "bold",
        hjust = 0
      )
    )
  )

save_figure(flow_plot, "Fig5_microneme_class_prevalence_flow", figure_dir, width_cm = 8.4, height_cm = 5.1)
save_figure(dot_plot, "Fig5_microneme_class_prevalence_dotplot", figure_dir, width_cm = 7.0, height_cm = 4.6)
save_figure(combined_plot, "Fig5_microneme_class_distribution_integrated", figure_dir, width_cm = 8.6, height_cm = 8.4)
save_figure(compact_trend_plot, "Fig5_microneme_class_compact_trend", figure_dir, width_cm = 4.0, height_cm = 3.5)

report <- c(
  "# Microneme position-class distribution",
  "",
  "Input: `classification of microneme.xlsx`, sheet `raw`.",
  "",
  "The three classes are non-exclusive cell-level prevalence readouts, so the figure uses independent class-wise flows rather than a stacked composition that would imply mutual exclusivity.",
  "",
  "## Mean prevalence shift",
  "",
  apply(
    effect_table,
    1,
    function(row) {
      sprintf(
        "- %s: vehicle %.1f%%, IAA %.1f%%, shift %+.1f percentage points.",
        row[["class_label"]],
        as.numeric(row[["mean_prevalence_percent_iKD-vehicle"]]),
        as.numeric(row[["mean_prevalence_percent_iKD-IAA"]]),
        as.numeric(row[["mean_shift_IAA_minus_vehicle"]])
      )
    }
  ),
  "",
  "## Paired statistics",
  "",
  "Primary display statistic: replicate-level paired t-test with Benjamini-Hochberg correction across the three classes. Paired Wilcoxon values are retained as a small-n sensitivity check.",
  "",
  apply(
    paired_stats,
    1,
    function(row) {
      sprintf(
        "- %s: paired t-test P = %.4g, BH q = %.4g (%s); paired Wilcoxon P = %.4g.",
        row[["class_label"]],
        as.numeric(row[["paired_t_p_value"]]),
        as.numeric(row[["paired_t_BH_q_value"]]),
        row[["significance"]],
        as.numeric(row[["paired_wilcoxon_p_value"]])
      )
    }
  ),
  "",
  "Generated outputs:",
  "- `microneme_classification_long.csv`",
  "- `microneme_classification_summary.csv`",
  "- `microneme_classification_vehicle_to_IAA_effects.csv`",
  "- `microneme_classification_paired_statistics.csv`",
  "- `Fig5_microneme_class_prevalence_flow.*`",
  "- `Fig5_microneme_class_prevalence_dotplot.*`",
  "- `Fig5_microneme_class_compact_trend.*`",
  "- `Fig5_microneme_class_distribution_integrated.*`"
)
writeLines(report, file.path(report_dir, "microneme_classification_distribution_report.md"))

if (interactive()) {
  print(flow_plot)
  print(dot_plot)
  print(compact_trend_plot)
  print(combined_plot)
}
