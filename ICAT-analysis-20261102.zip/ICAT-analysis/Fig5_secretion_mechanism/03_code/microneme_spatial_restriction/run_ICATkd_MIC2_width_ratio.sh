#!/usr/bin/env bash
set -euo pipefail

# 这个 shell wrapper 方便用 bash 启动 R 分析。
# 请不要直接 bash 运行 .R 文件；.R 文件需要交给 Rscript 解释。
script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
Rscript --vanilla "${script_dir}/ICATkd_MIC2_width_ratio.R" "$@"
