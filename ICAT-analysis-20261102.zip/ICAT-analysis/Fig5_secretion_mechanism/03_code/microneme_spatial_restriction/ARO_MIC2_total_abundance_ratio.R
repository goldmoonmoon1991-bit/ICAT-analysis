#!/usr/bin/env Rscript

# Quantify total ARO and MIC2 abundance from vehicle and IAA raw band intensities.
# Fill the CSV template with raw integrated densities from three biological repeats.
# Aldolase is intentionally not used for normalization in this analysis.

script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
script_path <- normalizePath(sub("^--file=", "", script_arg[[1]]), mustWork = TRUE)
fig_dir <- normalizePath(file.path(dirname(script_path), "..", ".."), mustWork = TRUE)
project_root <- normalizePath(file.path(fig_dir, ".."), mustWork = TRUE)
source(file.path(project_root, "shared", "R", "project_library.R"))
icat_activate_project_library(project_root)

library(ggplot2)

source(file.path(project_root, "shared", "R", "plot_style.R"))

input_path <- file.path(
  fig_dir,
  "01_raw_data", "microneme_spatial_restriction",
  "total_protein_abundance", "ARO_MIC2_total_abundance_template.csv"
)
input_path <- Sys.getenv("ICAT_TOTAL_PROTEIN_INPUT", unset = input_path)

output_root <- Sys.getenv("ICAT_TOTAL_PROTEIN_OUTPUT_ROOT", unset = fig_dir)
table_dir <- file.path(output_root, "04_results", "tables", "microneme_spatial_restriction", "total_protein_abundance")
figure_dir <- file.path(output_root, "04_results", "figures", "microneme_spatial_restriction", "total_protein_abundance")
report_dir <- file.path(output_root, "04_results", "reports", "microneme_spatial_restriction", "total_protein_abundance")
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(figure_dir, "PDF"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(figure_dir, "PNG"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(figure_dir, "SVG"), recursive = TRUE, showWarnings = FALSE)
dir.create(report_dir, recursive = TRUE, showWarnings = FALSE)

if (!file.exists(input_path)) {
  stop("Input template not found: ", input_path)
}

raw <- read.csv(input_path, stringsAsFactors = FALSE, check.names = FALSE)
required_cols <- c("replicate", "protein", "vehicle_intensity", "IAA_intensity")
missing_cols <- setdiff(required_cols, names(raw))
if (length(missing_cols)) {
  stop("Missing required columns in template: ", paste(missing_cols, collapse = ", "))
}

raw$protein <- factor(raw$protein, levels = c("ARO", "MIC2"))
raw$replicate <- as.integer(raw$replicate)
raw$vehicle_intensity <- suppressWarnings(as.numeric(raw$vehicle_intensity))
raw$IAA_intensity <- suppressWarnings(as.numeric(raw$IAA_intensity))
raw$IAA_vehicle_ratio <- raw$IAA_intensity / raw$vehicle_intensity

valid <- raw[
  !is.na(raw$protein) &
    !is.na(raw$replicate) &
    is.finite(raw$vehicle_intensity) &
    is.finite(raw$IAA_intensity) &
    raw$vehicle_intensity > 0,
]

write.csv(
  raw,
  file.path(table_dir, "ARO_MIC2_total_abundance_ratio_long.csv"),
  row.names = FALSE
)

if (!nrow(valid)) {
  writeLines(
    c(
      "# ARO/MIC2 total protein abundance ratio",
      "",
      "Status: pending raw band-intensity values.",
      "",
      "Fill `vehicle_intensity` and `IAA_intensity` in the raw-data template.",
      "The script computes `IAA_vehicle_ratio = IAA_intensity / vehicle_intensity`.",
      "Aldolase is intentionally not used for normalization.",
      "",
      "Expected biological repeats: three per protein."
    ),
    file.path(report_dir, "ARO_MIC2_total_abundance_ratio_report.md")
  )
  message("Template is present but no complete numeric rows were found: ", input_path)
  quit(status = 0)
}

summary_table <- do.call(rbind, lapply(split(valid, valid$protein), function(df) {
  ratios <- df$IAA_vehicle_ratio
  paired_p_value <- if (length(ratios) >= 3 && stats::sd(df$IAA_intensity - df$vehicle_intensity) > 0) {
    stats::t.test(df$IAA_intensity, df$vehicle_intensity, paired = TRUE)$p.value
  } else {
    NA_real_
  }
  data.frame(
    protein = as.character(df$protein[[1]]),
    n_replicates = length(ratios),
    mean_vehicle_intensity = mean(df$vehicle_intensity),
    sd_vehicle_intensity = if (nrow(df) > 1) stats::sd(df$vehicle_intensity) else NA_real_,
    mean_IAA_intensity = mean(df$IAA_intensity),
    sd_IAA_intensity = if (nrow(df) > 1) stats::sd(df$IAA_intensity) else NA_real_,
    mean_IAA_vehicle_ratio = mean(ratios),
    sd_IAA_vehicle_ratio = if (length(ratios) > 1) stats::sd(ratios) else NA_real_,
    median_IAA_vehicle_ratio = stats::median(ratios),
    min_IAA_vehicle_ratio = min(ratios),
    max_IAA_vehicle_ratio = max(ratios),
    paired_t_p_value_vehicle_vs_IAA = paired_p_value,
    stringsAsFactors = FALSE
  )
}))

summary_table$BH_q_value_vehicle_vs_IAA <- p.adjust(summary_table$paired_t_p_value_vehicle_vs_IAA, method = "BH")

write.csv(
  summary_table,
  file.path(table_dir, "ARO_MIC2_total_abundance_summary.csv"),
  row.names = FALSE
)

plot_df <- rbind(
  data.frame(
    protein = valid$protein,
    replicate = valid$replicate,
    condition = "vehicle",
    intensity = valid$vehicle_intensity,
    stringsAsFactors = FALSE
  ),
  data.frame(
    protein = valid$protein,
    replicate = valid$replicate,
    condition = "IAA",
    intensity = valid$IAA_intensity,
    stringsAsFactors = FALSE
  )
)
plot_df$protein <- factor(plot_df$protein, levels = c("ARO", "MIC2"))
plot_df$condition <- factor(plot_df$condition, levels = c("vehicle", "IAA"))
summary_table$protein <- factor(summary_table$protein, levels = c("ARO", "MIC2"))

write.csv(
  plot_df,
  file.path(table_dir, "ARO_MIC2_total_abundance_vehicle_IAA_long.csv"),
  row.names = FALSE
)

condition_summary <- aggregate(intensity ~ protein + condition, plot_df, function(x) c(mean = mean(x), sd = stats::sd(x)))
condition_summary <- data.frame(
  protein = condition_summary$protein,
  condition = condition_summary$condition,
  mean_intensity = condition_summary$intensity[, "mean"],
  sd_intensity = condition_summary$intensity[, "sd"],
  stringsAsFactors = FALSE
)
condition_summary$protein <- factor(condition_summary$protein, levels = c("ARO", "MIC2"))
condition_summary$condition <- factor(condition_summary$condition, levels = c("vehicle", "IAA"))

stat_labels <- do.call(rbind, lapply(split(plot_df, plot_df$protein), function(df) {
  protein_name <- as.character(df$protein[[1]])
  protein_summary <- summary_table[summary_table$protein == protein_name, ]
  y_max <- max(df$intensity, na.rm = TRUE)
  y_min <- min(df$intensity, na.rm = TRUE)
  y_pad <- max((y_max - y_min) * 0.18, y_max * 0.10, 1)
  q_value <- protein_summary$BH_q_value_vehicle_vs_IAA
  label <- if (is.na(q_value)) {
    "n/a"
  } else if (q_value < 0.001) {
    "***"
  } else if (q_value < 0.01) {
    "**"
  } else if (q_value < 0.05) {
    "*"
  } else {
    "ns"
  }
  data.frame(
    protein = protein_name,
    x = 1,
    xend = 2,
    y = y_max + y_pad * 0.45,
    yend = y_max + y_pad * 0.45,
    label_y = y_max + y_pad * 0.78,
    label = label,
    stringsAsFactors = FALSE
  )
}))
stat_labels$protein <- factor(stat_labels$protein, levels = c("ARO", "MIC2"))

condition_colors <- c("vehicle" = "#2C7FB8", "IAA" = "#D73027")

paired_plot <- ggplot(plot_df, aes(x = condition, y = intensity)) +
  geom_line(aes(group = replicate), color = "#B8B8B8", linewidth = ICAT_LINE_MM * 0.8, alpha = 0.75) +
  geom_errorbar(
    data = condition_summary,
    aes(x = condition, ymin = mean_intensity - sd_intensity, ymax = mean_intensity + sd_intensity),
    inherit.aes = FALSE,
    width = 0.12,
    linewidth = ICAT_LINE_MM,
    color = "black",
    na.rm = TRUE
  ) +
  geom_point(
    data = condition_summary,
    aes(x = condition, y = mean_intensity),
    inherit.aes = FALSE,
    shape = 21,
    size = 1.45,
    stroke = ICAT_LINE_MM * 1.2,
    fill = "white",
    color = "black"
  ) +
  geom_point(
    aes(fill = condition),
    position = position_jitter(width = 0.045, height = 0, seed = 20260826),
    shape = 21,
    size = 1.25,
    stroke = ICAT_LINE_MM,
    color = "black",
    show.legend = FALSE
  ) +
  geom_segment(
    data = stat_labels,
    aes(x = x, xend = xend, y = y, yend = yend),
    inherit.aes = FALSE,
    linewidth = ICAT_LINE_MM,
    color = "black"
  ) +
  geom_text(
    data = stat_labels,
    aes(x = 1.5, y = label_y, label = label),
    inherit.aes = FALSE,
    size = 1.95,
    color = "black"
  ) +
  facet_wrap(~ protein, nrow = 1, scales = "free_y") +
  scale_fill_manual(values = condition_colors) +
  scale_y_continuous(limits = c(0, NA), expand = expansion(mult = c(0, 0.22))) +
  icat_theme_classic(base_family = "Arial") +
  theme(
    axis.title.x = element_blank(),
    axis.text.x = element_text(size = 5.2, color = "black"),
    axis.text.y = element_text(size = 5.2, color = "black"),
    axis.title.y = element_text(size = 5.8, color = "black"),
    strip.background = element_blank(),
    strip.text = element_text(size = 6.0, face = "bold", color = "black"),
    plot.title = element_blank(),
    panel.spacing = unit(1.4, "mm"),
    plot.margin = margin(0.8, 1.2, 0.7, 0.7)
  ) +
  labs(y = "Raw intensity")

save_figure <- function(plot, stem, width_cm = 4.5, height_cm = 2.8, dpi = 600) {
  ggsave(
    file.path(figure_dir, "PNG", paste0(stem, ".png")),
    plot = plot,
    width = width_cm / 2.54,
    height = height_cm / 2.54,
    units = "in",
    dpi = dpi,
    device = ragg::agg_png,
    bg = "transparent"
  )
  ggsave(
    file.path(figure_dir, "PDF", paste0(stem, ".pdf")),
    plot = plot,
    width = width_cm / 2.54,
    height = height_cm / 2.54,
    units = "in",
    device = grDevices::cairo_pdf,
    family = "Arial"
  )
  ggsave(
    file.path(figure_dir, "SVG", paste0(stem, ".svg")),
    plot = plot,
    width = width_cm / 2.54,
    height = height_cm / 2.54,
    units = "in",
    device = grDevices::svg,
    bg = "transparent"
  )
}

save_figure(paired_plot, "ARO_MIC2_total_abundance_vehicle_IAA_paired", width_cm = 4.5, height_cm = 2.8)

format_number <- function(x, digits = 3) {
  ifelse(is.na(x), "NA", formatC(x, format = "f", digits = digits))
}

report_lines <- c(
  "# ARO/MIC2 total protein abundance",
  "",
  "Raw band intensity is plotted for vehicle and IAA in each biological repeat.",
  "",
  "Aldolase is intentionally not used for normalization in this analysis.",
  "",
  "`IAA / vehicle` is retained as a replicate-level ratio and summary statistic.",
  "",
  "| protein | n | vehicle mean | IAA mean | mean IAA/vehicle | s.d. ratio | paired t-test P | BH q |",
  "|---|---:|---:|---:|---:|---:|---:|---:|",
  apply(summary_table, 1, function(row) {
    paste0(
      "| ", row[["protein"]],
      " | ", row[["n_replicates"]],
      " | ", format_number(as.numeric(row[["mean_vehicle_intensity"]])),
      " | ", format_number(as.numeric(row[["mean_IAA_intensity"]])),
      " | ", format_number(as.numeric(row[["mean_IAA_vehicle_ratio"]])),
      " | ", format_number(as.numeric(row[["sd_IAA_vehicle_ratio"]])),
      " | ", format_number(as.numeric(row[["paired_t_p_value_vehicle_vs_IAA"]])),
      " | ", format_number(as.numeric(row[["BH_q_value_vehicle_vs_IAA"]])),
      " |"
    )
  }),
  "",
  "Plot size: 4.5 x 2.8 cm.",
  "Colored points are biological replicates; grey lines connect paired vehicle and IAA values; open circles and error bars show mean +/- s.d.",
  "Statistics are paired two-sided t-tests comparing vehicle and IAA raw intensities within each protein, with Benjamini-Hochberg correction across ARO and MIC2."
)

writeLines(report_lines, file.path(report_dir, "ARO_MIC2_total_abundance_ratio_report.md"))

message("Wrote ARO/MIC2 total abundance ratio outputs to: ", figure_dir)
