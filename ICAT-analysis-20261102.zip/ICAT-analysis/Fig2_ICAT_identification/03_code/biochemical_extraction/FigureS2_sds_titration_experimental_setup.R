#!/usr/bin/env Rscript

# SDS titration co-fractionation experimental setup schematic.
#
# Figure contract:
#   This schematic explains how SDS titration fractionation links ICAT
#   biochemical extraction behaviour to conoid/cytoskeletal association.

args <- commandArgs(trailingOnly = FALSE)
file_arg <- grep("^--file=", args, value = TRUE)
script_path <- if (length(file_arg)) {
  normalizePath(sub("^--file=", "", file_arg[1]), mustWork = TRUE)
} else {
  normalizePath("FigureS2_sds_titration_experimental_setup.R", mustWork = TRUE)
}

fig_dir <- normalizePath(file.path(dirname(script_path), "..", ".."), mustWork = TRUE)
project_root <- normalizePath(file.path(fig_dir, ".."), mustWork = TRUE)
source(file.path(project_root, "shared", "R", "project_library.R"))
icat_activate_project_library(project_root)
source(file.path(project_root, "shared", "R", "plot_style.R"))

suppressPackageStartupMessages({
  library(grid)
})

out_dir <- file.path(fig_dir, "04_results", "figures", "biochemical_extraction")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

base_name <- file.path(out_dir, "FigureS2_SDS_titration_experimental_setup")

col_black <- "#1F1F1F"
col_grey <- "#6F6F6F"
col_light <- "#F4F4F4"
col_line <- "#7A7A7A"
col_sds <- "#86BCE8"
col_sds_dark <- "#3E8BC3"
col_icat <- "#C026D3"
col_conoid <- "#46B978"
col_pellet <- "#D9A441"

txt <- function(label, x, y, size = 7, fontface = "plain", colour = col_black,
                just = "centre", lineheight = 0.9, rot = 0) {
  grid.text(
    label, x = unit(x, "npc"), y = unit(y, "npc"), just = just, rot = rot,
    gp = gpar(fontfamily = "Helvetica", fontsize = size, fontface = fontface,
              col = colour, lineheight = lineheight)
  )
}

box <- function(x, y, w, h, label, fill = "white", stroke = col_line,
                size = 7, fontface = "plain", radius = unit(1.5, "mm")) {
  grid.roundrect(
    x = unit(x, "npc"), y = unit(y, "npc"),
    width = unit(w, "npc"), height = unit(h, "npc"),
    r = radius,
    gp = gpar(fill = fill, col = stroke, lwd = 0.55)
  )
  txt(label, x, y, size = size, fontface = fontface, lineheight = 0.88)
}

arrow <- function(x0, y0, x1, y1, col = col_line) {
  grid.segments(
    x0 = unit(x0, "npc"), y0 = unit(y0, "npc"),
    x1 = unit(x1, "npc"), y1 = unit(y1, "npc"),
    gp = gpar(col = col, lwd = 0.6),
    arrow = grid::arrow(type = "closed", length = unit(1.8, "mm"))
  )
}

tube <- function(x, y, w = 0.035, h = 0.24, fill_frac = 0.35,
                 liquid = col_sds, outline = col_line) {
  # tube body
  grid.roundrect(
    x = unit(x, "npc"), y = unit(y, "npc"),
    width = unit(w, "npc"), height = unit(h, "npc"),
    r = unit(1.2, "mm"),
    gp = gpar(fill = "white", col = outline, lwd = 0.45)
  )
  # tube liquid
  grid.roundrect(
    x = unit(x, "npc"),
    y = unit(y - h / 2 + (h * fill_frac) / 2 + 0.012, "npc"),
    width = unit(w * 0.80, "npc"),
    height = unit(h * fill_frac, "npc"),
    r = unit(0.8, "mm"),
    gp = gpar(fill = liquid, col = NA)
  )
  # cap
  grid.rect(
    x = unit(x, "npc"), y = unit(y + h / 2 + 0.012, "npc"),
    width = unit(w * 1.12, "npc"), height = unit(0.018, "npc"),
    gp = gpar(fill = col_light, col = outline, lwd = 0.45)
  )
}

draw_sds_series <- function() {
  xs <- seq(0.33, 0.59, length.out = 7)
  labels <- c("0", "0.1", "0.2", "0.3", "0.4", "0.5", "1%")
  fills <- seq(0.18, 0.72, length.out = 7)
  cols <- colorRampPalette(c("#DCEFFA", col_sds_dark))(7)
  for (i in seq_along(xs)) {
    tube(xs[i], 0.55, fill_frac = fills[i], liquid = cols[i])
    txt(labels[i], xs[i], 0.36, size = 5.8)
  }
  txt("SDS titration", 0.46, 0.82, size = 8, fontface = "bold")
  txt("0.1–0.5% resolves ICAT solubility;\n>0.4% releases ICAT into supernatant",
      0.46, 0.25, size = 5.8, colour = col_grey, lineheight = 0.9)
  grid.segments(
    unit(0.51, "npc"), unit(0.69, "npc"),
    unit(0.51, "npc"), unit(0.42, "npc"),
    gp = gpar(col = col_icat, lwd = 0.75, lty = 2)
  )
  txt("0.4%", 0.522, 0.72, size = 6, colour = col_icat, fontface = "bold", just = "left")
}

draw_centrifuge <- function(x = 0.70, y = 0.55) {
  grid.circle(
    x = unit(x, "npc"), y = unit(y, "npc"), r = unit(0.045, "npc"),
    gp = gpar(fill = "#F7F7F7", col = col_line, lwd = 0.55)
  )
  for (ang in c(90, 210, 330)) {
    dx <- 0.026 * cos(ang * pi / 180)
    dy <- 0.026 * sin(ang * pi / 180)
    grid.segments(
      unit(x, "npc"), unit(y, "npc"),
      unit(x + dx, "npc"), unit(y + dy, "npc"),
      gp = gpar(col = col_line, lwd = 0.65)
    )
    grid.circle(
      x = unit(x + dx, "npc"), y = unit(y + dy, "npc"),
      r = unit(0.007, "npc"),
      gp = gpar(fill = col_sds_dark, col = NA)
    )
  }
  txt("spin", x, y - 0.10, size = 6.2, fontface = "bold")
}

draw_fraction_tubes <- function() {
  tube(0.84, 0.62, w = 0.043, h = 0.24, fill_frac = 0.55, liquid = "#BFE3F6")
  tube(0.91, 0.62, w = 0.043, h = 0.24, fill_frac = 0.20, liquid = col_pellet)
  grid.circle(
    x = unit(0.91, "npc"), y = unit(0.51, "npc"), r = unit(0.010, "npc"),
    gp = gpar(fill = col_pellet, col = NA)
  )
  txt("S", 0.84, 0.79, size = 7, fontface = "bold", colour = col_sds_dark)
  txt("P", 0.91, 0.79, size = 7, fontface = "bold", colour = col_pellet)
  txt("supernatant", 0.84, 0.33, size = 5.8, colour = col_grey)
  txt("pellet", 0.91, 0.33, size = 5.8, colour = col_grey)
}

draw_western <- function() {
  x0 <- 0.79
  y0 <- 0.16
  w <- 0.17
  h <- 0.09
  grid.roundrect(
    unit(x0 + w / 2, "npc"), unit(y0, "npc"),
    width = unit(w, "npc"), height = unit(h, "npc"),
    r = unit(1.2, "mm"),
    gp = gpar(fill = "white", col = col_line, lwd = 0.5)
  )
  lanes <- seq(x0 + 0.025, x0 + w - 0.025, length.out = 4)
  for (lx in lanes) {
    grid.rect(unit(lx, "npc"), unit(y0 + 0.018, "npc"),
              width = unit(0.025, "npc"), height = unit(0.008, "npc"),
              gp = gpar(fill = col_icat, col = NA))
    grid.rect(unit(lx, "npc"), unit(y0 - 0.010, "npc"),
              width = unit(0.025, "npc"), height = unit(0.006, "npc"),
              gp = gpar(fill = col_conoid, col = NA))
  }
  txt("WB + S/(S+P)", x0 + w / 2, y0 - 0.075, size = 6.2, fontface = "bold")
}

draw_panel <- function() {
  grid.newpage()
  grid.rect(gp = gpar(fill = "white", col = NA))

  txt("SDS titration co-fractionation", 0.03, 0.92, size = 9, fontface = "bold", just = "left")
  txt("Test whether ICAT low-SDS resistance tracks with conoid/cytoskeletal association",
      0.03, 0.86, size = 6.4, colour = col_grey, just = "left")

  box(0.11, 0.55, 0.16, 0.25, "Parasite\nlysate", fill = "#F7FAF8", size = 7.2, fontface = "bold")
  txt("ICAT + markers", 0.11, 0.35, size = 5.8, colour = col_grey)

  arrow(0.20, 0.55, 0.285, 0.55)
  draw_sds_series()
  arrow(0.62, 0.55, 0.665, 0.55)
  draw_centrifuge(0.70, 0.55)
  arrow(0.735, 0.55, 0.795, 0.55)
  draw_fraction_tubes()
  arrow(0.875, 0.39, 0.875, 0.235)
  draw_western()

  # Marker legend
  grid.rect(unit(0.055, "npc"), unit(0.125, "npc"),
            width = unit(0.035, "npc"), height = unit(0.010, "npc"),
            gp = gpar(fill = col_icat, col = NA))
  txt("ICAT", 0.080, 0.125, size = 5.8, just = "left")
  grid.rect(unit(0.145, "npc"), unit(0.125, "npc"),
            width = unit(0.035, "npc"), height = unit(0.010, "npc"),
            gp = gpar(fill = col_conoid, col = NA))
  txt("conoid/cytoskeletal marker", 0.170, 0.125, size = 5.8, just = "left")

  txt("Readout: ICAT release threshold compared with conoid/cytoskeletal and soluble controls",
      0.03, 0.055, size = 6, colour = col_grey, just = "left")
}

save_pdf <- function(path, width_mm = 170, height_mm = 55) {
  cairo_pdf(path, width = width_mm / 25.4, height = height_mm / 25.4,
            family = "Helvetica")
  draw_panel()
  dev.off()
}

save_png <- function(path, width_mm = 170, height_mm = 55, dpi = 600) {
  ragg::agg_png(path, width = width_mm / 25.4, height = height_mm / 25.4,
                units = "in", res = dpi, background = "white")
  draw_panel()
  dev.off()
}

save_svg <- function(path, width_mm = 170, height_mm = 55) {
  svglite::svglite(path, width = width_mm / 25.4, height = height_mm / 25.4,
                   bg = "white")
  draw_panel()
  dev.off()
}

save_pdf(paste0(base_name, ".pdf"))
save_png(paste0(base_name, ".png"))
save_svg(paste0(base_name, ".svg"))

message("Wrote: ", paste0(base_name, ".pdf"))
message("Wrote: ", paste0(base_name, ".png"))
message("Wrote: ", paste0(base_name, ".svg"))
