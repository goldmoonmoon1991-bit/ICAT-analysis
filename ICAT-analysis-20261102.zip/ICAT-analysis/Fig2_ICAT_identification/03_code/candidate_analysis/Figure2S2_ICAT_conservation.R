#!/usr/bin/env Rscript

# Figure 2 supplementary conservation analysis: ICAT/OG7_0102099 presence.
#
# Figure contract:
#   The panel tests whether ICAT is broadly conserved or restricted to a
#   coccidian apicomplexan clade. It intentionally shows binary presence/absence
#   rather than copy number.

args <- commandArgs(trailingOnly = FALSE)
file_arg <- grep("^--file=", args, value = TRUE)
script_path <- if (length(file_arg)) {
  normalizePath(sub("^--file=", "", file_arg[1]), mustWork = TRUE)
} else {
  normalizePath("Figure2S2_ICAT_conservation.R", mustWork = TRUE)
}

fig_dir <- normalizePath(file.path(dirname(script_path), "..", ".."), mustWork = TRUE)
project_root <- normalizePath(file.path(fig_dir, ".."), mustWork = TRUE)
source(file.path(project_root, "shared", "R", "project_library.R"))
icat_activate_project_library(project_root)
source(file.path(project_root, "shared", "R", "plot_style.R"))

suppressPackageStartupMessages({
  library(dplyr)
  library(ggplot2)
  library(patchwork)
})

output_dir <- file.path(fig_dir, "04_results")
table_dir <- file.path(output_dir, "tables")
figure_pdf_dir <- file.path(output_dir, "figures", "pdf")
figure_png_dir <- file.path(output_dir, "figures", "png")
legend_dir <- file.path(output_dir, "legends")
report_dir <- file.path(output_dir, "reports")
for (path in c(table_dir, figure_pdf_dir, figure_png_dir, legend_dir, report_dir)) {
  dir.create(path, recursive = TRUE, showWarnings = FALSE)
}

orthomcl_url <- "https://orthomcl.org/orthomcl/app/record/group/OG7_0102099#TaxonCounts"
access_date <- format(Sys.Date(), "%Y-%m-%d")

presence_data <- data.frame(
  major_clade = rep("Eukaryota", 16),
  subclade = c(rep("Alveolata", 13), "Opisthokonta", "Archaeplastida", "Opisthokonta"),
  order_or_group = c(
    rep("Coccidia", 6),
    "Cryptosporidia",
    "Haemosporida",
    "Piroplasmida",
    "Piroplasmida",
    "Chromerida",
    "Dinoflagellata",
    "Ciliophora",
    "Fungi",
    "Viridiplantae",
    "Metazoa"
  ),
  species = c(
    "Toxoplasma gondii",
    "Hammondia hammondi",
    "Neospora caninum",
    "Besnoitia besnoiti",
    "Sarcocystis neurona",
    "Cystoisospora suis",
    "Cryptosporidium parvum",
    "Plasmodium falciparum",
    "Babesia bovis",
    "Theileria annulata",
    "Vitrella brassicaformis",
    "Symbiodinium microadriaticum",
    "Tetrahymena thermophila",
    "Saccharomyces cerevisiae",
    "Arabidopsis thaliana",
    "Homo sapiens"
  ),
  reference_strain = c(
    "ME49",
    "H.H.34",
    "Liverpool",
    "Bb-Ger1",
    "SN3",
    "Wien I",
    "Iowa II",
    "3D7",
    "T2Bo",
    "Ankara",
    "CCMP3155",
    "",
    "SB210",
    "S288C",
    "Col-0",
    "GRCh38"
  ),
  orthomcl_taxon_code = c(
    "tgon",
    "hhhh",
    "ncan",
    "bbes",
    "sneu",
    "csui",
    rep(NA_character_, 10)
  ),
  og7_0102099_count = c(1, 2, 1, 1, 1, 1, rep(0, 10)),
  stringsAsFactors = FALSE
) %>%
  mutate(
    ICAT_presence = ifelse(og7_0102099_count > 0, "present", "absent"),
    source = ifelse(
      og7_0102099_count > 0,
      paste0("OrthoMCL OG7_0102099 TaxonCounts non-zero entry; accessed ", access_date, "; ", orthomcl_url),
      paste0("Reference taxon not listed in non-zero OrthoMCL OG7_0102099 TaxonCounts view; encoded as absent; accessed ", access_date, "; ", orthomcl_url)
    )
  )

write.csv(
  presence_data,
  file.path(table_dir, "Figure2S2_ICAT_conservation_source_data.csv"),
  row.names = FALSE, na = ""
)

plot_order <- c(
  "Toxoplasma gondii",
  "Hammondia hammondi",
  "Neospora caninum",
  "Besnoitia besnoiti",
  "Sarcocystis neurona",
  "Cystoisospora suis",
  "Cryptosporidium parvum",
  "Plasmodium falciparum",
  "Babesia bovis",
  "Theileria annulata",
  "Vitrella brassicaformis",
  "Symbiodinium microadriaticum",
  "Tetrahymena thermophila",
  "Saccharomyces cerevisiae",
  "Arabidopsis thaliana",
  "Homo sapiens"
)

plot_data <- presence_data %>%
  mutate(
    x = seq_along(plot_order)[match(species, plot_order)],
    plot_label = c(
      "T.g",
      "H.h",
      "N.c",
      "B.b",
      "S.n",
      "C.s",
      "C.p",
      "P.f",
      "B.b",
      "T.a",
      "V.b",
      "S.m",
      "T.t",
      "S.c",
      "A.t",
      "H.s"
    ),
    ICAT_presence = factor(ICAT_presence, levels = c("present", "absent"))
  )

clade_range <- plot_data %>%
  group_by(order_or_group) %>%
  summarise(xmin = min(x), xmax = max(x), xmid = mean(range(x)), .groups = "drop")

group_y <- 2.38
leaf_y <- 1.95
apic_y <- 2.73
alve_y <- 3.05
euk_y <- 3.36

range_mid <- function(groups) {
  rng <- range(plot_data$x[plot_data$order_or_group %in% groups])
  mean(rng)
}

node_x <- c(
  Coccidia = clade_range$xmid[clade_range$order_or_group == "Coccidia"],
  Cryptosporidia = clade_range$xmid[clade_range$order_or_group == "Cryptosporidia"],
  Haemosporida = clade_range$xmid[clade_range$order_or_group == "Haemosporida"],
  Piroplasmida = clade_range$xmid[clade_range$order_or_group == "Piroplasmida"],
  Chromerida = clade_range$xmid[clade_range$order_or_group == "Chromerida"],
  Dinoflagellata = clade_range$xmid[clade_range$order_or_group == "Dinoflagellata"],
  Ciliophora = clade_range$xmid[clade_range$order_or_group == "Ciliophora"],
  Fungi = clade_range$xmid[clade_range$order_or_group == "Fungi"],
  Viridiplantae = clade_range$xmid[clade_range$order_or_group == "Viridiplantae"],
  Metazoa = clade_range$xmid[clade_range$order_or_group == "Metazoa"],
  Apicomplexa = range_mid(c("Coccidia", "Cryptosporidia", "Haemosporida", "Piroplasmida")),
  Alveolata = range_mid(c("Coccidia", "Cryptosporidia", "Haemosporida", "Piroplasmida", "Chromerida", "Dinoflagellata", "Ciliophora")),
  Eukaryota = mean(range(plot_data$x))
)

group_segments <- clade_range %>%
  transmute(x = xmin, xend = xmax, y = group_y, yend = group_y)
leaf_segments <- plot_data %>%
  transmute(
    x = x, xend = x,
    y = leaf_y,
    yend = case_when(
      order_or_group == "Coccidia" ~ group_y,
      order_or_group == "Piroplasmida" ~ group_y,
      TRUE ~ group_y
    )
  )
apic_groups <- c("Coccidia", "Cryptosporidia", "Haemosporida", "Piroplasmida")
alve_groups <- c(apic_groups, "Chromerida", "Dinoflagellata", "Ciliophora")
euk_groups <- c("Alveolata", "Fungi", "Viridiplantae", "Metazoa")

apic_children <- data.frame(child = apic_groups, x = node_x[apic_groups])
alve_children <- data.frame(child = c("Apicomplexa", "Chromerida", "Dinoflagellata", "Ciliophora"), x = c(node_x["Apicomplexa"], node_x[c("Chromerida", "Dinoflagellata", "Ciliophora")]))
euk_children <- data.frame(child = euk_groups, x = c(node_x["Alveolata"], node_x[c("Fungi", "Viridiplantae", "Metazoa")]))

tree_segments <- bind_rows(
  group_segments,
  leaf_segments,
  data.frame(x = min(apic_children$x), xend = max(apic_children$x), y = apic_y, yend = apic_y),
  data.frame(x = apic_children$x, xend = apic_children$x, y = group_y, yend = apic_y),
  data.frame(x = min(alve_children$x), xend = max(alve_children$x), y = alve_y, yend = alve_y),
  data.frame(x = alve_children$x, xend = alve_children$x, y = ifelse(alve_children$child == "Apicomplexa", apic_y, group_y), yend = alve_y),
  data.frame(x = min(euk_children$x), xend = max(euk_children$x), y = euk_y, yend = euk_y),
  data.frame(x = euk_children$x, xend = euk_children$x, y = ifelse(euk_children$child == "Alveolata", alve_y, group_y), yend = euk_y)
)

tree_labels <- data.frame(
  label = c("Eukaryota", "Alveolata", "Apicomplexa", "Coccidia"),
  x = c(node_x["Eukaryota"], node_x["Alveolata"], node_x["Apicomplexa"], node_x["Coccidia"]),
  y = c(euk_y + 0.20, alve_y + 0.20, apic_y + 0.18, group_y + 0.16),
  stringsAsFactors = FALSE
)

group_labels <- data.frame(
  label = c("Cry.", "Hae.", "Pir.", "Chr.", "Din.", "Cil.", "Fun.", "Plt.", "Met."),
  x = node_x[c("Cryptosporidia", "Haemosporida", "Piroplasmida", "Chromerida", "Dinoflagellata", "Ciliophora", "Fungi", "Viridiplantae", "Metazoa")],
  y = rep(group_y + 0.16, 9),
  stringsAsFactors = FALSE
)

present_colour <- "#46B978"
absent_colour <- "#E6E6E6"
tree_colour <- "#4D4D4D"

figure_plot <- ggplot() +
  geom_segment(
    data = tree_segments,
    aes(x = x, xend = xend, y = y, yend = yend),
    linewidth = ICAT_LINE_MM * 0.75, lineend = "round", colour = tree_colour
  ) +
  geom_label(
    data = tree_labels,
    aes(x = x, y = y, label = label),
    family = "Helvetica", fontface = "bold", size = 6 / ICAT_GGPLOT_PT_PER_MM,
    hjust = 0.5, colour = tree_colour, fill = "white",
    linewidth = 0, label.padding = unit(0.05, "mm")
  ) +
  geom_label(
    data = group_labels,
    aes(x = x, y = y, label = label),
    family = "Helvetica", size = 6 / ICAT_GGPLOT_PT_PER_MM,
    hjust = 0.5, colour = "#777777", fill = "white",
    linewidth = 0, label.padding = unit(0.03, "mm")
  ) +
  annotate(
    "text", x = 0.35, y = 3.54, label = "ICAT / OG7_0102099",
    family = "Helvetica", fontface = "bold", size = 6 / ICAT_GGPLOT_PT_PER_MM,
    hjust = 0, vjust = 0.5, lineheight = 0.85, colour = "black"
  ) +
  geom_point(
    data = plot_data,
    aes(x = x, y = 1.27, fill = ICAT_presence),
    shape = 21, size = 1.65, stroke = 0.14, colour = "#777777"
  ) +
  geom_text(
    data = plot_data,
    aes(x = x, y = 0.74, label = plot_label),
    family = "Helvetica", size = 6 / ICAT_GGPLOT_PT_PER_MM,
    angle = 0, hjust = 0.5, vjust = 0.5, colour = "#222222"
  ) +
  scale_fill_manual(
    values = c(present = present_colour, absent = absent_colour),
    breaks = c("present", "absent"),
    labels = c("present", "absent"),
    name = NULL
  ) +
  annotate("point", x = 12.9, y = 0.24, shape = 21, size = 1.25, stroke = 0.12, fill = present_colour, colour = "#777777") +
  annotate("text", x = 13.15, y = 0.24, label = "present", family = "Helvetica", size = 6 / ICAT_GGPLOT_PT_PER_MM, hjust = 0, vjust = 0.5) +
  annotate("point", x = 14.55, y = 0.24, shape = 21, size = 1.25, stroke = 0.12, fill = absent_colour, colour = "#777777") +
  annotate("text", x = 14.80, y = 0.24, label = "absent", family = "Helvetica", size = 6 / ICAT_GGPLOT_PT_PER_MM, hjust = 0, vjust = 0.5) +
  coord_cartesian(xlim = c(0.25, length(plot_order) + 0.65), ylim = c(0.05, 3.70), clip = "off") +
  scale_x_continuous(expand = expansion(mult = c(0, 0))) +
  scale_y_continuous(expand = expansion(mult = c(0, 0))) +
  theme_void(base_family = "Helvetica") +
  theme(
    legend.position = "none",
    plot.margin = margin(0.5, 1.0, 0.2, 1.0, unit = "mm")
  )

pdf_path <- file.path(figure_pdf_dir, "Figure2S2_ICAT_conservation.pdf")
png_path <- file.path(figure_png_dir, "Figure2S2_ICAT_conservation.png")

figure_width_in <- 92 / 25.4
figure_height_in <- 22 / 25.4

grDevices::cairo_pdf(pdf_path, width = figure_width_in, height = figure_height_in, family = "Helvetica")
print(figure_plot)
grDevices::dev.off()

grDevices::png(
  png_path, width = figure_width_in, height = figure_height_in,
  units = "in", res = 600, type = "cairo", bg = "white"
)
print(figure_plot)
grDevices::dev.off()

present_species <- presence_data %>% filter(ICAT_presence == "present")
absent_species <- presence_data %>% filter(ICAT_presence == "absent")
format_reference <- function(df, include_count = FALSE) {
  label <- paste(df$species, df$reference_strain)
  label <- trimws(gsub("  +", " ", label))
  code_text <- ifelse(is.na(df$orthomcl_taxon_code) | df$orthomcl_taxon_code == "", "", paste0("; ", df$orthomcl_taxon_code))
  count_text <- if (include_count) paste0("; count=", df$og7_0102099_count) else ""
  paste0("  - ", label, " (OG7_0102099", code_text, count_text, ")")
}

summary_lines <- c(
  "Figure 2S2 ICAT protein conservation analysis",
  "",
  "Group: OrthoMCL OG7_0102099.",
  paste0("Source page: ", orthomcl_url),
  paste0("Access date recorded by script: ", access_date),
  "Presence rule: OG7_0102099 count > 0 is encoded as present; count = 0 is encoded as absent.",
  "Display rule: one reference strain per species; copy number is retained in source data but not displayed in the figure.",
  "Species label rule: genus initial in uppercase and species initial in lowercase, separated by a dot.",
  "",
  sprintf("Present references: %d", nrow(present_species)),
  format_reference(present_species, include_count = TRUE),
  "",
  sprintf("Absent reference/outgroup taxa: %d", nrow(absent_species)),
  format_reference(absent_species, include_count = FALSE),
  "",
  "Interpretation: ICAT/OG7_0102099 is detected in selected coccidian apicomplexan references and absent from selected non-coccidian apicomplexan, alveolate and distant eukaryotic outgroup references."
)
writeLines(summary_lines, file.path(report_dir, "Figure2S2_ICAT_conservation_summary.txt"))

figure_legend <- paste(
  "Figure 2S2. Conservation of ICAT across selected alveolate reference species.",
  "A simplified taxonomic backbone is paired with a binary presence/absence circle matrix for OrthoMCL group OG7_0102099.",
  "Each species is represented by one reference strain.",
  "Species names are abbreviated as genus initial and species initial separated by a dot.",
  "Green circles indicate presence of at least one OG7_0102099 member, whereas grey circles indicate absence from the non-zero OrthoMCL TaxonCounts view.",
  "Copy number is not shown in the figure and is provided in the source data.",
  "The distribution supports conservation of ICAT within coccidian apicomplexans and absence from the selected non-coccidian apicomplexan, alveolate and distant eukaryotic outgroups."
)
writeLines(
  figure_legend,
  file.path(legend_dir, "Figure2S2_ICAT_conservation_figure_legend.txt")
)

message("Wrote: ", pdf_path)
message("Wrote: ", png_path)
