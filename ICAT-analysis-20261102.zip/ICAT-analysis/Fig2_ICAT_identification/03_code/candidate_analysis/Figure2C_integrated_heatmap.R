#!/usr/bin/env Rscript

# Figure 2 compact ComplexHeatmap candidate-selection analysis
#
# Run from any directory:
#   Rscript Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R
#
# All outputs are written beside this script. Original input files are not modified.

suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(tidyr)
  library(readxl)
  library(scales)
})

args <- commandArgs(trailingOnly = FALSE)
file_arg <- grep("^--file=", args, value = TRUE)
script_path <- if (length(file_arg)) {
  normalizePath(sub("^--file=", "", file_arg[1]), mustWork = TRUE)
} else {
  normalizePath("Figure2_transposed_integrated_heatmap.R", mustWork = TRUE)
}

fig_dir <- normalizePath(file.path(dirname(script_path), "..", ".."), mustWork = TRUE)
project_root <- normalizePath(file.path(fig_dir, ".."), mustWork = TRUE)
source(file.path(project_root, "shared", "R", "plot_style.R"))
input_dir <- file.path(fig_dir, "01_raw_data", "identification")
output_dir <- file.path(fig_dir, "04_results")
table_dir <- file.path(output_dir, "tables")
figure_pdf_dir <- file.path(output_dir, "figures", "pdf")
figure_png_dir <- file.path(output_dir, "figures", "png")
legend_dir <- file.path(output_dir, "legends")
report_dir <- file.path(output_dir, "reports")
for (path in c(table_dir, figure_pdf_dir, figure_png_dir, legend_dir, report_dir)) {
  dir.create(path, recursive = TRUE, showWarnings = FALSE)
}

suppressPackageStartupMessages({
  library(ComplexHeatmap)
  library(circlize)
})

canonical_gene_id <- function(x) {
  x <- trimws(as.character(x))
  x <- sub("^TGGT1_", "TGME49_", x)
  x <- sub(" \\[.*$", "", x)
  sub("(?<=[0-9])[AB]$", "", x, perl = TRUE)
}

numeric_matrix <- function(frame) {
  as.matrix(data.frame(lapply(frame, function(x) {
    suppressWarnings(as.numeric(gsub(",", "", as.character(x))))
  })))
}

safe_welch <- function(a, b) {
  if (any(!is.finite(c(a, b))) || length(unique(c(a, b))) < 2) return(1)
  tryCatch(t.test(a, b, var.equal = FALSE)$p.value, error = function(e) 1)
}

safe_min <- function(x) {
  x <- x[is.finite(x)]
  if (!length(x)) return(NA_real_)
  min(x)
}

safe_mean <- function(x) {
  x <- x[is.finite(x)]
  if (!length(x)) return(NA_real_)
  mean(x)
}

read_hyperlopit <- function(path) {
  lines <- readLines(path, warn = FALSE, encoding = "UTF-8")
  header <- strsplit(lines[1], ",", fixed = TRUE)[[1]]
  header[1] <- "GeneID"
  expected <- length(header)

  parse_line <- function(line) {
    fields <- strsplit(line, ",", fixed = TRUE)[[1]]
    if (length(fields) > expected) {
      extra <- length(fields) - expected
      fields <- c(
        fields[1:32],
        paste(fields[33:(33 + extra)], collapse = ","),
        fields[(34 + extra):length(fields)]
      )
    }
    if (length(fields) < expected) {
      fields <- c(fields, rep("", expected - length(fields)))
    }
    if (length(fields) != expected) {
      stop("Unable to repair a HyperLOPIT row with ", length(fields), " fields")
    }
    fields
  }

  parsed <- lapply(lines[-1], parse_line)
  frame <- as.data.frame(do.call(rbind, parsed), stringsAsFactors = FALSE)
  names(frame) <- header
  frame$GeneID <- canonical_gene_id(frame$GeneID)

  keep <- c(
    "GeneID", "Description", "tagm.mcmc.allocation",
    "tagm.mcmc.probability", "tagm.mcmc.joint.apical.1",
    "tagm.mcmc.joint.apical.2", "tagm.mcmc.joint.micronemes",
    "tagm.mcmc.joint.tubulin.cytoskeleton"
  )
  frame <- frame[, keep]
  numeric_columns <- setdiff(keep, c("GeneID", "Description", "tagm.mcmc.allocation"))
  frame[numeric_columns] <- lapply(frame[numeric_columns], function(x) {
    suppressWarnings(as.numeric(x))
  })
  frame %>% distinct(GeneID, .keep_all = TRUE)
}

# -----------------------------------------------------------------------------
# 1. CF5 proximity dataset
# -----------------------------------------------------------------------------

cf5 <- read.csv(
  file.path(input_dir, "CF5_Normalized spec count.csv"),
  check.names = FALSE, stringsAsFactors = FALSE
)
names(cf5)[1:2] <- c("TGGT1_ID", "GeneID")
cf5$GeneID <- canonical_gene_id(cf5$GeneID)
cf5 <- cf5[grepl("^TGME49_[0-9]+$", cf5$GeneID), ]

cf5_values <- numeric_matrix(cf5[, 3:8])
valid <- apply(cf5_values, 1, function(x) all(is.finite(x) & x > 0))
cf5 <- cf5[valid, ]
cf5_values <- cf5_values[valid, , drop = FALSE]

cf5_bait_log <- log2(cf5_values[, 1:3, drop = FALSE])
cf5_control_log <- log2(cf5_values[, 4:6, drop = FALSE])
cf5$CF5_log2FC <- rowMeans(cf5_bait_log) - rowMeans(cf5_control_log)
cf5$CF5_p_value <- vapply(seq_len(nrow(cf5)), function(i) {
  safe_welch(cf5_bait_log[i, ], cf5_control_log[i, ])
}, numeric(1))
cf5$CF5_mean_normalized_spectral_count <- rowMeans(cf5_values[, 1:3, drop = FALSE])
cf5$Cyto_mean_normalized_spectral_count <- rowMeans(cf5_values[, 4:6, drop = FALSE])

cf5 <- cf5 %>%
  arrange(desc(CF5_log2FC)) %>%
  distinct(GeneID, .keep_all = TRUE)
cf5$CF5_FDR <- p.adjust(cf5$CF5_p_value, method = "BH")
cf5$CF5_fold_rank <- rank(-cf5$CF5_log2FC, ties.method = "min")

cf5_peptides <- read.csv(
  file.path(input_dir, "CF5_Total unique peptide.csv"),
  check.names = FALSE, stringsAsFactors = FALSE
)
names(cf5_peptides)[1] <- "GeneID"
cf5_peptides$GeneID <- canonical_gene_id(cf5_peptides$GeneID)
cf5_peptides <- cf5_peptides[grepl("^TGME49_[0-9]+$", cf5_peptides$GeneID), ]
cf5_peptide_values <- numeric_matrix(cf5_peptides[, 2:7])
cf5_peptides$CF5_mean_unique_peptides <- rowMeans(
  cf5_peptide_values[, 1:3, drop = FALSE], na.rm = TRUE
)
cf5_peptides$Cyto_mean_unique_peptides <- rowMeans(
  cf5_peptide_values[, 4:6, drop = FALSE], na.rm = TRUE
)
cf5_peptides <- cf5_peptides %>%
  group_by(GeneID) %>%
  summarise(
    CF5_mean_unique_peptides = max(CF5_mean_unique_peptides, na.rm = TRUE),
    Cyto_mean_unique_peptides = max(Cyto_mean_unique_peptides, na.rm = TRUE),
    .groups = "drop"
  )
cf5 <- left_join(cf5, cf5_peptides, by = "GeneID")

# -----------------------------------------------------------------------------
# 2. Long CPH1/MyoH proximity datasets
# -----------------------------------------------------------------------------

long <- read.csv(
  file.path(input_dir, "Long_Datasets_Combined_intensity.csv"),
  check.names = FALSE, stringsAsFactors = FALSE
)
long$GeneID <- canonical_gene_id(long$`Accession Number`)
long_values <- numeric_matrix(long[, 11:18])
long$MyoH_log2FC <- rowMeans(log2(long_values[, 1:2, drop = FALSE] + 1)) -
  rowMeans(log2(long_values[, 5:8, drop = FALSE] + 1))
long$CPH1_log2FC <- rowMeans(log2(long_values[, 3:4, drop = FALSE] + 1)) -
  rowMeans(log2(long_values[, 5:8, drop = FALSE] + 1))
long$MyoH_mean_intensity <- rowMeans(long_values[, 1:2, drop = FALSE])
long$CPH1_mean_intensity <- rowMeans(long_values[, 3:4, drop = FALSE])
long$RH_mean_intensity <- rowMeans(long_values[, 5:8, drop = FALSE])

long <- long %>%
  filter(grepl("^TGME49_[0-9]+$", GeneID)) %>%
  select(
    GeneID, MyoH_log2FC, CPH1_log2FC,
    MyoH_mean_intensity, CPH1_mean_intensity, RH_mean_intensity
  ) %>%
  group_by(GeneID) %>%
  summarise(across(where(is.numeric), ~ max(.x, na.rm = TRUE)), .groups = "drop")

long_peptides <- read.csv(
  file.path(input_dir, "Long_Datasets_Combined_peptide#.csv"),
  check.names = FALSE, stringsAsFactors = FALSE
)
long_peptides$GeneID <- canonical_gene_id(long_peptides$`Accession Number`)
long_peptide_values <- numeric_matrix(long_peptides[, 11:18])
long_peptides$MyoH_mean_peptides <- rowMeans(
  long_peptide_values[, 1:2, drop = FALSE], na.rm = TRUE
)
long_peptides$CPH1_mean_peptides <- rowMeans(
  long_peptide_values[, 3:4, drop = FALSE], na.rm = TRUE
)
long_peptides$RH_mean_peptides <- rowMeans(
  long_peptide_values[, 5:8, drop = FALSE], na.rm = TRUE
)
long_peptides <- long_peptides %>%
  filter(grepl("^TGME49_[0-9]+$", GeneID)) %>%
  select(GeneID, MyoH_mean_peptides, CPH1_mean_peptides, RH_mean_peptides) %>%
  group_by(GeneID) %>%
  summarise(across(where(is.numeric), ~ max(.x, na.rm = TRUE)), .groups = "drop")
long <- left_join(long, long_peptides, by = "GeneID")

# -----------------------------------------------------------------------------
# 3. External spatial and fitness annotations
# -----------------------------------------------------------------------------

hyper <- read_hyperlopit(file.path(input_dir, "HyperLp.csv"))

crispr <- suppressWarnings(read_excel(
  file.path(input_dir, "CRISPR rank-ordered genes.xlsx"),
  sheet = "Sheet1"
)) %>%
  rename(
    InputID = ID,
    CRISPR_description = `Protein desprition`,
    CRISPR_short_name = `Protein short name`,
    CRISPR_rank = `Rank numbers`,
    CRISPR_phenotype = `mean phenotype`
  )
crispr$GeneID <- canonical_gene_id(crispr$InputID)
crispr <- crispr %>%
  mutate(
    CRISPR_rank = as.numeric(CRISPR_rank),
    CRISPR_phenotype = as.numeric(CRISPR_phenotype)
  ) %>%
  group_by(GeneID) %>%
  summarise(
    CRISPR_input_ids = paste(InputID, collapse = ";"),
    CRISPR_best_rank = safe_min(CRISPR_rank),
    CRISPR_most_negative_phenotype = safe_min(CRISPR_phenotype),
    CRISPR_mean_phenotype = safe_mean(CRISPR_phenotype),
    .groups = "drop"
  )

kehu <- read.csv(
  file.path(input_dir, "Conoid_265_ke_hu.csv"),
  stringsAsFactors = FALSE
)
kehu$GeneID <- canonical_gene_id(kehu$Gene.ID)
kehu <- kehu %>%
  transmute(GeneID, KeHu_conoid_detected = TRUE) %>%
  distinct(GeneID, .keep_all = TRUE)

# -----------------------------------------------------------------------------
# 4. Candidate selection and common reference centring
# -----------------------------------------------------------------------------

master <- cf5 %>%
  left_join(long, by = "GeneID") %>%
  left_join(hyper, by = "GeneID") %>%
  left_join(crispr, by = "GeneID") %>%
  left_join(kehu, by = "GeneID")
master$KeHu_conoid_detected[is.na(master$KeHu_conoid_detected)] <- FALSE
master$HyperLOPIT_apical_probability <- pmax(
  master$tagm.mcmc.joint.apical.1,
  master$tagm.mcmc.joint.apical.2,
  na.rm = TRUE
)
master$HyperLOPIT_apical_probability[
  !is.finite(master$HyperLOPIT_apical_probability)
] <- NA_real_

top12 <- master %>%
  filter(CF5_FDR < 0.05) %>%
  arrange(CF5_fold_rank) %>%
  slice_head(n = 12) %>%
  mutate(Display = ifelse(GeneID == "TGME49_252880", "ICAT", GeneID))

reference <- data.frame(
  Display = c(
    "DCX", "CPH1", "CF6", "MyoH",
    "SAS6L", "CF5", "CIP3", "CF1",
    "CF2", "CF3", "CF4", "PRP"
  ),
  GeneID = c(
    "TGME49_256030", "TGME49_266630", "TGME49_245640", "TGME49_243250",
    "TGME49_301420", "TGME49_297180", "TGME49_225020", "TGME49_222350",
    "TGME49_258090", "TGME49_255895", "TGME49_246720", "TGME49_291880"
  ),
  Spatial_class = c(
    rep("outer reference", 4), rep("bridge", 4), rep("inner", 4)
  ),
  stringsAsFactors = FALSE
)

reference_data <- reference %>%
  left_join(master, by = "GeneID")

outer_median <- reference_data %>%
  filter(Spatial_class == "outer reference") %>%
  summarise(
    CPH1 = median(CPH1_log2FC, na.rm = TRUE),
    MyoH = median(MyoH_log2FC, na.rm = TRUE),
    CF5 = median(CF5_log2FC, na.rm = TRUE)
  )

# CF1 is both a bridge landmark and one of the 12 significant CF5 hits.
# Retain it in the bridge block; the candidate block displays its GeneID, so
# the two roles remain visually distinct.

candidate_data <- top12 %>%
  mutate(Spatial_class = "CF5 hits (FDR < 0.05)")

selected <- bind_rows(reference_data, candidate_data) %>%
  mutate(
    CPH1_relative = CPH1_log2FC - outer_median$CPH1,
    MyoH_relative = MyoH_log2FC - outer_median$MyoH,
    CF5_relative = CF5_log2FC - outer_median$CF5,
    HyperLOPIT_location = case_when(
      tagm.mcmc.allocation == "apical 1" ~ "apical 1",
      tagm.mcmc.allocation == "apical 2" ~ "apical 2",
      is.na(tagm.mcmc.allocation) | tagm.mcmc.allocation == "" ~ "not available",
      TRUE ~ "other"
    ),
    HyperLOPIT_label = recode(
      HyperLOPIT_location,
      `apical 1` = "A1", `apical 2` = "A2",
      other = "other", `not available` = "ND"
    ),
    CRISPR_label = ifelse(
      is.na(CRISPR_most_negative_phenotype), "ND",
      sprintf("%.1f", CRISPR_most_negative_phenotype)
    ),
    Apical_probability_label = ifelse(
      is.na(HyperLOPIT_apical_probability), "ND",
      sprintf("%.2f", HyperLOPIT_apical_probability)
    )
  )

display_order <- c(reference_data$Display, candidate_data$Display)
class_order <- c(
  "outer reference", "bridge", "inner", "CF5 hits (FDR < 0.05)"
)
selected$Display <- factor(selected$Display, levels = display_order)
selected$Spatial_class <- factor(selected$Spatial_class, levels = class_order)

# -----------------------------------------------------------------------------
# 5. Export auditable source tables
# -----------------------------------------------------------------------------

write.csv(
  master %>% arrange(CF5_fold_rank),
  file.path(table_dir, "CF5_all_protein_statistics_and_annotations.csv"),
  row.names = FALSE, na = ""
)
write.csv(
  top12,
  file.path(table_dir, "CF5_top12_FDR_significant_hits.csv"),
  row.names = FALSE, na = ""
)
write.csv(
  selected,
  file.path(table_dir, "Figure2C_integrated_source_data.csv"),
  row.names = FALSE, na = ""
)
write.csv(
  crispr,
  file.path(table_dir, "CRISPR_collapsed_gene_annotations.csv"),
  row.names = FALSE, na = ""
)
write.csv(
  hyper,
  file.path(table_dir, "HyperLOPIT_repaired_annotations.csv"),
  row.names = FALSE, na = ""
)

# -----------------------------------------------------------------------------
# 6. Build a compact portrait ComplexHeatmap panel
# -----------------------------------------------------------------------------

# Put the statistically selected CF5 candidates first. ICAT is the leading
# candidate and therefore occupies the first row of the candidate block.
portrait_class_order <- c(
  "CF5 hits (FDR < 0.05)", "outer reference", "bridge", "inner"
)
selected_plot <- selected %>%
  mutate(
    .class_rank = match(as.character(Spatial_class), portrait_class_order),
    .within_rank = ifelse(
      as.character(Spatial_class) == "CF5 hits (FDR < 0.05)",
      CF5_fold_rank,
      match(as.character(Display), display_order)
    )
  ) %>%
  arrange(.class_rank, .within_rank)

write.csv(
  selected_plot %>% select(-.class_rank, -.within_rank),
  file.path(table_dir, "Figure2C_compact_ComplexHeatmap_source_data.csv"),
  row.names = FALSE, na = ""
)

display_names <- as.character(selected_plot$Display)
enrichment_matrix <- as.matrix(
  selected_plot[, c("CPH1_relative", "MyoH_relative", "CF5_relative")]
)
rownames(enrichment_matrix) <- display_names
colnames(enrichment_matrix) <- c("CPH1", "MyoH", "CF5")

location_matrix <- matrix(
  dplyr::case_when(
    selected_plot$HyperLOPIT_location %in% c("apical 1", "apical 2") ~ "apical",
    TRUE ~ "non-apical / ND"
  ),
  ncol = 1, dimnames = list(display_names, "LOPIT")
)
crispr_matrix <- matrix(
  selected_plot$CRISPR_most_negative_phenotype,
  ncol = 1, dimnames = list(display_names, "CRISPR")
)

row_groups <- factor(
  as.character(selected_plot$Spatial_class),
  levels = portrait_class_order,
  labels = c("CF5 candidates", "outer", "bridge", "inner")
)

icat_colour <- "#C51ACB"
na_colour <- "#E7E7E7"
cell_border <- function(mat) {
  function(j, i, x, y, width, height, fill) {
    if (rownames(mat)[i] == "ICAT") {
      grid::grid.rect(
        x, y, width, height,
        gp = grid::gpar(fill = NA, col = icat_colour, lwd = 1.4)
      )
    }
  }
}

enrichment_colours <- circlize::colorRamp2(
  c(-4.5, 0, 4.5), c("#4A90C2", "#F7F7F7", "#D95F5F")
)
crispr_colours <- circlize::colorRamp2(
  c(-5, 0, 2), c("#B2182B", "#F7F7F7", "#2166AC")
)
location_colours <- c(
  "apical" = "#BECFAA",
  "non-apical / ND" = "#D9D9D9"
)

compact_legend <- list(
  direction = "horizontal",
  legend_width = grid::unit(15, "mm"),
  title_position = "topcenter",
  title_gp = grid::gpar(fontfamily = "Helvetica", fontsize = ICAT_FONT_SMALL_PT),
  labels_gp = grid::gpar(fontfamily = "Helvetica", fontsize = ICAT_FONT_SMALL_PT)
)

draw_group_bracket <- function(index, nm, rotate_label = FALSE) {
  grid::grid.lines(
    x = grid::unit(c(0.95, 0.75, 0.75, 0.95), "npc"),
    y = grid::unit(c(1, 1, 0, 0), "npc"),
    gp = grid::gpar(col = "#444444", lwd = 0.7)
  )
  grid::grid.text(
    nm,
    x = grid::unit(if (rotate_label) 0.22 else 0.35, "npc"),
    y = grid::unit(0.5, "npc"),
    rot = if (rotate_label) 90 else 0,
    gp = grid::gpar(
      fontfamily = "Helvetica", fontsize = ICAT_FONT_SMALL_PT,
      fontface = if (rotate_label) "bold" else "plain",
      col = "#333333"
    )
  )
}

build_heatmap_list <- function() {
left_group_annotation <- ComplexHeatmap::rowAnnotation(
  section = ComplexHeatmap::anno_empty(
    which = "row", border = FALSE, width = grid::unit(6, "mm")
  ),
  subgroup = ComplexHeatmap::anno_block(
    align_to = list(
      outer = 13:16,
      bridge = 17:20,
      inner = 21:24
    ),
    panel_fun = function(index, nm) {
      draw_group_bracket(index, nm, rotate_label = FALSE)
    },
    width = grid::unit(8, "mm")
  ),
  protein = ComplexHeatmap::anno_text(
    display_names,
    which = "row",
    location = grid::unit(1, "npc"),
    just = "right",
    gp = grid::gpar(
      fontfamily = "Helvetica", fontsize = ICAT_FONT_SMALL_PT,
      fontface = ifelse(display_names == "ICAT", "bold", "plain"),
      col = ifelse(display_names == "ICAT", icat_colour, "#222222")
    ),
    width = grid::unit(24, "mm")
  ),
  gap = grid::unit(0.5, "mm"),
  show_annotation_name = FALSE
)

ht_enrichment <- ComplexHeatmap::Heatmap(
  enrichment_matrix,
  name = "Relative log2 enrichment",
  col = enrichment_colours,
  na_col = na_colour,
  cluster_rows = FALSE,
  cluster_columns = FALSE,
  row_split = row_groups,
  row_gap = grid::unit(1.1, "mm"),
  row_title = NULL,
  left_annotation = left_group_annotation,
  show_row_names = FALSE,
  column_title = "bait",
  column_title_gp = grid::gpar(fontfamily = "Helvetica", fontsize = ICAT_FONT_BODY_PT, fontface = "bold"),
  column_names_gp = grid::gpar(fontfamily = "Helvetica", fontsize = ICAT_FONT_SMALL_PT),
  column_names_side = "top",
  rect_gp = grid::gpar(col = "white", lwd = 0.6),
  width = grid::unit(15, "mm"),
  show_heatmap_legend = FALSE,
  heatmap_legend_param = c(
    compact_legend,
    list(at = c(-4, 0, 4), labels = c("-4", "0", "4"))
  ),
  cell_fun = cell_border(enrichment_matrix)
)

ht_location <- ComplexHeatmap::Heatmap(
  location_matrix,
  name = "HyperLOPIT",
  col = location_colours,
  na_col = na_colour,
  cluster_rows = FALSE,
  cluster_columns = FALSE,
  show_row_names = FALSE,
  column_names_gp = grid::gpar(fontfamily = "Helvetica", fontsize = ICAT_FONT_SMALL_PT),
  column_names_side = "top",
  rect_gp = grid::gpar(col = "white", lwd = 0.6),
  width = grid::unit(5, "mm"),
  show_heatmap_legend = FALSE,
  heatmap_legend_param = list(
    title = "HyperLOPIT",
    at = names(location_colours),
    labels = c("apical", "non-apical / ND"),
    nrow = 1,
    by_row = TRUE,
    title_gp = grid::gpar(fontfamily = "Helvetica", fontsize = ICAT_FONT_SMALL_PT),
    labels_gp = grid::gpar(fontfamily = "Helvetica", fontsize = ICAT_FONT_SMALL_PT),
    grid_width = grid::unit(2.2, "mm"),
    grid_height = grid::unit(2.2, "mm")
  ),
  cell_fun = cell_border(location_matrix)
)

ht_crispr <- ComplexHeatmap::Heatmap(
  crispr_matrix,
  name = "CRISPR phenotype",
  col = crispr_colours,
  na_col = na_colour,
  cluster_rows = FALSE,
  cluster_columns = FALSE,
  show_row_names = FALSE,
  column_names_gp = grid::gpar(fontfamily = "Helvetica", fontsize = ICAT_FONT_SMALL_PT),
  column_names_side = "top",
  rect_gp = grid::gpar(col = "white", lwd = 0.6),
  width = grid::unit(5, "mm"),
  show_heatmap_legend = FALSE,
  heatmap_legend_param = c(
    compact_legend,
    list(at = c(-5, 0, 2), labels = c("-5", "0", "2"))
  ),
  cell_fun = cell_border(crispr_matrix)
)

ht_enrichment + ht_location + ht_crispr
}

build_bottom_legends <- function() {
  enrichment_legend <- ComplexHeatmap::Legend(
    at = c(-4, 0, 4),
    labels = c("-4", "0", "4"),
    col_fun = enrichment_colours,
    title = "Relative log2 enrichment",
    direction = "horizontal",
    legend_width = grid::unit(22, "mm"),
    grid_height = grid::unit(3, "mm"),
    title_position = "topcenter",
    title_gp = grid::gpar(fontfamily = "Helvetica", fontsize = ICAT_FONT_SMALL_PT),
    labels_gp = grid::gpar(fontfamily = "Helvetica", fontsize = ICAT_FONT_SMALL_PT)
  )

  lopit_legend <- ComplexHeatmap::Legend(
    at = names(location_colours),
    labels = c("apical", "non-apical / ND"),
    title = "HyperLOPIT",
    type = "grid",
    ncol = 1,
    grid_width = grid::unit(2.6, "mm"),
    grid_height = grid::unit(2.6, "mm"),
    row_gap = grid::unit(0.7, "mm"),
    legend_gp = grid::gpar(fill = unname(location_colours), col = NA),
    title_position = "topcenter",
    title_gp = grid::gpar(fontfamily = "Helvetica", fontsize = ICAT_FONT_SMALL_PT),
    labels_gp = grid::gpar(fontfamily = "Helvetica", fontsize = ICAT_FONT_SMALL_PT)
  )

  crispr_legend <- ComplexHeatmap::Legend(
    at = c(-5, 0, 2),
    labels = c("-5", "0", "2"),
    col_fun = crispr_colours,
    title = "CRISPR phenotype",
    direction = "horizontal",
    legend_width = grid::unit(18, "mm"),
    grid_height = grid::unit(3, "mm"),
    title_position = "topcenter",
    title_gp = grid::gpar(fontfamily = "Helvetica", fontsize = ICAT_FONT_SMALL_PT),
    labels_gp = grid::gpar(fontfamily = "Helvetica", fontsize = ICAT_FONT_SMALL_PT)
  )

  ComplexHeatmap::packLegend(
    enrichment_legend, lopit_legend, crispr_legend,
    direction = "horizontal", gap = grid::unit(1, "mm")
  )
}

draw_page_section_bracket <- function(label, y_top, y_bottom) {
  grid::grid.lines(
    x = grid::unit(c(0.145, 0.130, 0.130, 0.145), "npc"),
    y = grid::unit(c(y_top, y_top, y_bottom, y_bottom), "npc"),
    gp = grid::gpar(col = "#444444", lwd = 0.7)
  )
  grid::grid.text(
    label,
    x = grid::unit(0.090, "npc"),
    y = grid::unit((y_top + y_bottom) / 2, "npc"),
    rot = 90,
    gp = grid::gpar(
      fontfamily = "Helvetica", fontsize = ICAT_FONT_SMALL_PT,
      fontface = "bold", col = "#333333"
    )
  )
}

draw_integrated <- function() {
  heatmap_list <- build_heatmap_list()
  bottom_legends <- build_bottom_legends()
  ComplexHeatmap::draw(
    heatmap_list,
    ht_gap = grid::unit(1.1, "mm"),
    padding = grid::unit(c(19, 2, 2, 2), "mm")
  )
  grid::popViewport(0)
  ComplexHeatmap::draw(
    bottom_legends,
    x = grid::unit(0.5, "npc"),
    y = grid::unit(2.5, "mm"),
    just = c("center", "bottom")
  )
  grid::popViewport(0)
  draw_page_section_bracket("top 12 candidates", 0.862, 0.515)
  draw_page_section_bracket("landmarks", 0.505, 0.139)
  grid::grid.text(
    "c",
    x = grid::unit(1.5, "mm"),
    y = grid::unit(1, "npc") - grid::unit(1.5, "mm"),
    just = c("left", "top"),
    gp = grid::gpar(fontfamily = "Helvetica", fontface = "bold", fontsize = ICAT_FONT_TITLE_PT)
  )
  grid::grid.text(
    "ICAT",
    x = grid::unit(1, "npc") - grid::unit(2, "mm"),
    y = grid::unit(1, "npc") - grid::unit(2, "mm"),
    just = c("right", "top"),
    gp = grid::gpar(fontfamily = "Helvetica", fontface = "bold", fontsize = ICAT_FONT_TITLE_PT, col = icat_colour)
  )
}

pdf_path <- file.path(figure_pdf_dir, "Figure2C_compact_ComplexHeatmap.pdf")
png_path <- file.path(figure_png_dir, "Figure2C_compact_ComplexHeatmap.png")

# Final requested journal-panel size: 7.2 cm wide by 11.5 cm high.
grDevices::cairo_pdf(pdf_path, width = 7.2 / 2.54, height = 11.5 / 2.54)
draw_integrated()
grDevices::dev.off()

grDevices::png(
  png_path, width = 7.2 / 2.54, height = 11.5 / 2.54,
  units = "in", res = 600, type = "cairo", bg = "white"
)
draw_integrated()
grDevices::dev.off()

icat <- selected %>% filter(as.character(Display) == "ICAT")
summary_lines <- c(
  "Figure 2 compact ComplexHeatmap analysis",
  "",
  "Selection: first 12 CF5 hits passing Benjamini-Hochberg FDR < 0.05, ordered by CF5 fold enrichment.",
  "Cross-bait values: log2 enrichment minus the median enrichment of DCX, CPH1, CF6 and MyoH within each bait dataset.",
  "ND: not detected/not available; ND is not treated as zero.",
  "HyperLOPIT: binary track; apical 1/2 allocations are apical, while non-apical and missing allocations share the grey category.",
  "CRISPR: most negative phenotype after collapsing A/B gene annotations to the common TGME49 gene ID.",
  "Panel dimensions: 7.2 cm wide x 11.5 cm high.",
  "",
  sprintf("ICAT CF5 rank: %d of %d", icat$CF5_fold_rank, nrow(master)),
  sprintf("ICAT CF5 log2FC / FDR: %.3f / %.5f", icat$CF5_log2FC, icat$CF5_FDR),
  sprintf("ICAT outer-centred CPH1 / MyoH / CF5: %.3f / %.3f / %.3f",
          icat$CPH1_relative, icat$MyoH_relative, icat$CF5_relative),
  sprintf("ICAT HyperLOPIT allocation: %s", icat$tagm.mcmc.allocation),
  sprintf("ICAT CRISPR most-negative phenotype / best rank: %.3f / %.0f",
          icat$CRISPR_most_negative_phenotype, icat$CRISPR_best_rank)
)
writeLines(summary_lines, file.path(report_dir, "Figure2_analysis_summary.txt"))

figure_legend <- paste(
  "Figure 2C. Integrated spatial enrichment and functional annotation of CF5 proximity-labeling candidates.",
  "Rows show the first 12 CF5-enriched proteins passing Benjamini-Hochberg FDR < 0.05, followed by established outer, bridge and inner conoid landmarks; CF1 is retained in the bridge landmark block and is also represented by its GeneID in the candidate block.",
  "Bait-enrichment colors represent log2 enrichment relative to the median of the outer-conoid reference set for CPH1, MyoH and CF5 proximity-labeling datasets (blue, lower; white, unchanged; red, higher).",
  "HyperLOPIT allocation is shown as a binary track (#BECFAA, apical; grey, non-apical or not detected); CRISPR phenotype scores are shown from red (more negative) to blue (more positive).",
  "ICAT is placed at the top of the candidate block and highlighted by a magenta label and cell borders.",
  sep = " "
)
writeLines(
  figure_legend,
  file.path(legend_dir, "Figure2C_compact_figure_legend.txt")
)

cat(paste(summary_lines, collapse = "\n"), "\n")
cat("\nOutputs written to:", output_dir, "\n")
