#!/usr/bin/env Rscript

# Figure 2B: compact CF5 proximity-labeling volcano plot
# Final panel size: 7.0 cm wide x 4.5 cm high.

args <- commandArgs(trailingOnly = FALSE)
file_arg <- grep("^--file=", args, value = TRUE)
script_path <- if (length(file_arg)) {
  normalizePath(sub("^--file=", "", file_arg[1]), mustWork = TRUE)
} else {
  normalizePath("Figure2B_volcano_plot.R", mustWork = TRUE)
}

fig_dir <- normalizePath(file.path(dirname(script_path), "..", ".."), mustWork = TRUE)
project_root <- normalizePath(file.path(fig_dir, ".."), mustWork = TRUE)
source(file.path(project_root, "shared", "R", "plot_style.R"))
identification_dir <- fig_dir
output_dir <- file.path(fig_dir, "04_results")
table_dir <- file.path(output_dir, "tables")
figure_pdf_dir <- file.path(output_dir, "figures", "pdf")
figure_png_dir <- file.path(output_dir, "figures", "png")
legend_dir <- file.path(output_dir, "legends")
for (path in c(table_dir, figure_pdf_dir, figure_png_dir, legend_dir)) {
  dir.create(path, recursive = TRUE, showWarnings = FALSE)
}
suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(ggrepel)
  library(readxl)
})

input_file <- file.path(
  table_dir, "CF5_all_protein_statistics_and_annotations.csv"
)
if (!file.exists(input_file)) {
  stop("Run Figure2C_integrated_heatmap.R first to create: ", input_file)
}

volcano <- read.csv(
  input_file, check.names = FALSE, stringsAsFactors = FALSE
) %>%
  filter(
    is.finite(CF5_log2FC),
    is.finite(CF5_p_value),
    CF5_p_value > 0,
    is.finite(CF5_FDR)
  ) %>%
  mutate(
    minus_log10_p = -log10(CF5_p_value),
    CF5_enriched = CF5_log2FC >= 1 & CF5_FDR < 0.05
  )

# Protein names are read directly from the Cryo-EM sheet requested for Fig. 2B.
apical_table_file <- file.path(
  identification_dir, "01_raw_data", "identification", "Apical Tables.xlsx"
)
if (!file.exists(apical_table_file)) {
  stop("Missing protein-name source: ", apical_table_file)
}
cryo_em_raw <- readxl::read_excel(
  apical_table_file, sheet = "Cryo-EM", skip = 1,
  .name_repair = "minimal"
)
cryo_em_names <- data.frame(
  GeneID = trimws(as.character(cryo_em_raw[[1]])),
  CryoEM_name = trimws(as.character(cryo_em_raw[[2]])),
  stringsAsFactors = FALSE
) %>%
  filter(
    grepl("^TGME49_[0-9]+$", GeneID),
    !is.na(CryoEM_name), CryoEM_name != ""
  ) %>%
  distinct(GeneID, .keep_all = TRUE)

# Structure-supported proteins used throughout Figure 2.
landmark_key <- data.frame(
  Fallback_label = c(
    "DCX", "CPH1", "CF6", "MyoH",
    "SAS6L", "CF5", "CIP3", "CF1",
    "CF2", "CF3", "CF4", "PRP", "ICAT"
  ),
  GeneID = c(
    "TGME49_256030", "TGME49_266630", "TGME49_245640", "TGME49_243250",
    "TGME49_301420", "TGME49_297180", "TGME49_225020", "TGME49_222350",
    "TGME49_258090", "TGME49_255895", "TGME49_246720", "TGME49_291880",
    "TGME49_252880"
  ),
  Spatial_class = c(
    rep("outer", 4), rep("bridge", 4), rep("inner", 4), "candidate"
  ),
  stringsAsFactors = FALSE
)

landmarks <- landmark_key %>%
  left_join(cryo_em_names, by = "GeneID") %>%
  mutate(
    Label = case_when(
      GeneID == "TGME49_252880" ~ "ICAT",
      !is.na(CryoEM_name) ~ CryoEM_name,
      TRUE ~ Fallback_label
    ),
    Label_source = case_when(
      GeneID == "TGME49_252880" ~ "study name",
      !is.na(CryoEM_name) ~ "Apical Tables.xlsx: Cryo-EM",
      TRUE ~ "Figure 2 reference name"
    )
  ) %>%
  left_join(
    volcano %>% select(
      GeneID, CF5_log2FC, minus_log10_p, CF5_p_value, CF5_FDR
    ),
    by = "GeneID"
  )

write.csv(
  volcano %>% select(
    GeneID, CF5_log2FC, CF5_p_value, CF5_FDR,
    minus_log10_p, CF5_enriched
  ),
  file.path(table_dir, "Figure2B_volcano_source_data.csv"),
  row.names = FALSE
)
write.csv(
  landmarks,
  file.path(table_dir, "Figure2B_landmark_coordinates.csv"),
  row.names = FALSE
)
write.csv(
  landmarks %>% select(
    GeneID, Label, CryoEM_name, Fallback_label, Label_source, Spatial_class
  ),
  file.path(table_dir, "Figure2B_protein_name_mapping.csv"),
  row.names = FALSE, na = ""
)

layer_colours <- c(
  outer = "#46B978",
  bridge = "#DCA23A",
  inner = "#66AEDD"
)
icat_colour <- "#C51ACB"

background <- volcano %>% filter(!CF5_enriched)
enriched <- volcano %>% filter(CF5_enriched)
known_landmarks <- landmarks %>% filter(Spatial_class != "candidate")
label_positions <- data.frame(
  Label = c(
    "DCX", "CPH1", "CF6", "MyoH",
    "SAS6L", "CF5", "CIP3", "CF1",
    "CF2", "CF3", "CF4", "PRP", "ICAT"
  ),
  label_x = c(
    0.72, 3.18, 1.48, 2.75,
    1.62, 1.55, 2.66, 3.55,
    0.92, 3.18, 1.15, 3.35, 5.12
  ),
  label_y = c(
    4.00, 4.72, 2.18, 3.82,
    1.78, 3.45, 2.88, 3.42,
    2.78, 2.30, 4.76, 1.55, 3.43
  ),
  line_x = c(
    0.95, 3.00, 1.62, 2.56,
    1.72, 1.74, 2.55, 3.42,
    1.06, 3.05, 1.29, 3.24, 5.40
  ),
  line_y = c(
    4.10, 4.60, 2.32, 3.70,
    1.92, 3.42, 2.99, 3.36,
    2.71, 2.22, 4.82, 1.46, 3.30
  ),
  stringsAsFactors = FALSE
)
label_landmarks <- known_landmarks %>%
  inner_join(label_positions, by = "Label")
icat <- landmarks %>%
  filter(Spatial_class == "candidate") %>%
  inner_join(label_positions, by = "Label")

set.seed(252880)
volcano_plot <- ggplot() +
  geom_hline(
    yintercept = -log10(0.05),
    colour = "#A9A9A9", linewidth = 0.30, linetype = "22"
  ) +
  geom_vline(
    xintercept = c(-1, 1),
    colour = "#A9A9A9", linewidth = 0.30, linetype = "22"
  ) +
  geom_point(
    data = background,
    aes(CF5_log2FC, minus_log10_p),
    shape = 16, size = 0.75, colour = "#C9C9C9", alpha = 0.38
  ) +
  geom_point(
    data = enriched,
    aes(CF5_log2FC, minus_log10_p),
    shape = 16, size = 1.0, colour = "#D98282", alpha = 0.72
  ) +
  geom_point(
    data = known_landmarks,
    aes(CF5_log2FC, minus_log10_p, fill = Spatial_class),
    shape = 21, size = 1.75, colour = "#555555", stroke = 0.28
  ) +
  ggrepel::geom_text_repel(
    data = label_landmarks,
    aes(CF5_log2FC, minus_log10_p, label = Label),
    nudge_x = label_landmarks$label_x - label_landmarks$CF5_log2FC,
    nudge_y = label_landmarks$label_y - label_landmarks$minus_log10_p,
    family = "Helvetica", size = ICAT_TEXT_SMALL_MM, colour = "#414141",
    box.padding = 0.10, point.padding = 0.14,
    min.segment.length = 0, segment.size = 0.14,
    segment.alpha = 1, segment.color = "#555555",
    max.overlaps = Inf, max.time = 3, seed = 252880,
    force = 0.8, force_pull = 0.8
  ) +
  geom_point(
    data = icat,
    aes(CF5_log2FC, minus_log10_p),
    shape = 21, size = 2.55, fill = "white",
    colour = icat_colour, stroke = 0.70
  ) +
  ggrepel::geom_text_repel(
    data = icat,
    aes(CF5_log2FC, minus_log10_p, label = Label),
    nudge_x = icat$label_x - icat$CF5_log2FC,
    nudge_y = icat$label_y - icat$minus_log10_p,
    family = "Helvetica", fontface = "bold", size = ICAT_TEXT_BODY_MM,
    colour = icat_colour,
    box.padding = 0.14, point.padding = 0.18,
    min.segment.length = 0, segment.size = 0.17,
    segment.color = icat_colour, max.overlaps = Inf,
    max.time = 3, seed = 252880,
    force = 1.0, force_pull = 0.8
  ) +
  scale_fill_manual(
    values = layer_colours,
    breaks = c("outer", "bridge", "inner"),
    guide = guide_legend(
      title = NULL, nrow = 1, byrow = TRUE,
      override.aes = list(size = 1.8, colour = "#555555")
    )
  ) +
  scale_x_continuous(
    limits = c(-6, 6), breaks = c(-6, -3, 0, 3, 6),
    expand = expansion(mult = 0)
  ) +
  scale_y_continuous(
    limits = c(0, 5.15), breaks = 0:5,
    expand = expansion(mult = c(0, 0.02))
  ) +
  labs(
    tag = "B",
    x = "log2 fold change (CF5/cytosol)",
    y = "-log10 P"
  ) +
  coord_cartesian(clip = "off") +
  icat_theme_classic(base_family = "Helvetica") +
  theme(
    axis.title = element_text(size = ICAT_FONT_BODY_PT, colour = "black"),
    axis.text = element_text(size = ICAT_FONT_SMALL_PT, colour = "black"),
    axis.ticks = element_line(linewidth = ICAT_LINE_MM, colour = "black"),
    axis.ticks.length = grid::unit(1.2, "mm"),
    axis.line = element_line(linewidth = ICAT_LINE_MM, colour = "black"),
    legend.position = "top",
    legend.justification = "left",
    legend.direction = "horizontal",
    legend.text = element_text(size = ICAT_FONT_SMALL_PT, colour = "#333333"),
    legend.key.width = grid::unit(3.1, "mm"),
    legend.key.height = grid::unit(2.5, "mm"),
    legend.spacing.x = grid::unit(0.6, "mm"),
    legend.margin = margin(0, 0, -1.2, 0, unit = "mm"),
    plot.tag = element_text(face = "bold", size = ICAT_FONT_TITLE_PT),
    plot.tag.position = c(0.01, 0.99),
    plot.margin = margin(1.2, 1.8, 1.0, 1.4, unit = "mm")
  )

pdf_path <- file.path(figure_pdf_dir, "Figure2B_CF5_volcano_optimized.pdf")
png_path <- file.path(figure_png_dir, "Figure2B_CF5_volcano_optimized.png")

ggsave(
  pdf_path, volcano_plot,
  width = 7.0, height = 4.5, units = "cm", device = cairo_pdf
)
ggsave(
  png_path, volcano_plot,
  width = 7.0, height = 4.5, units = "cm", dpi = 600, bg = "white"
)

figure_legend <- paste(
  "Figure 2B. CF5 proximity-labeling enrichment relative to the cytosolic control.",
  "The x axis shows log2 fold change and the y axis shows -log10 of the two-sided Welch-test P value.",
  "Muted red points satisfy log2 fold change >= 1 and Benjamini-Hochberg FDR < 0.05; dashed lines indicate absolute log2 fold change = 1 and nominal P = 0.05.",
  "Established conoid landmarks are colored according to the Figure 2A spatial scheme (outer, green; bridge, gold; inner, blue).",
  "Landmark labels are connected to their corresponding points by leader lines; protein names are read from the Cryo-EM sheet of Apical Tables.xlsx where available, and ICAT is highlighted in magenta."
)
writeLines(
  figure_legend,
  file.path(legend_dir, "Figure2B_volcano_figure_legend.txt")
)

message("Wrote: ", pdf_path)
message("Wrote: ", png_path)
