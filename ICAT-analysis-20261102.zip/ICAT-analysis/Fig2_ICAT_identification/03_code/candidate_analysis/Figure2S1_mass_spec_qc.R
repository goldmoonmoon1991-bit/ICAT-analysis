#!/usr/bin/env Rscript

# Figure 2 supplementary QC: CF5 mass-spectrometry replicate quality control.
#
# Panels:
#   a. Pearson correlation heatmap with hierarchical clustering.
#   b. PCA of replicate-level protein abundance profiles.
#   c. Sample-level intensity distributions and peptide detection support.
#   d. PC1 score plot emphasizing the dominant bait-control separation.

args <- commandArgs(trailingOnly = FALSE)
file_arg <- grep("^--file=", args, value = TRUE)
script_path <- if (length(file_arg)) {
  normalizePath(sub("^--file=", "", file_arg[1]), mustWork = TRUE)
} else {
  normalizePath("Figure2S1_mass_spec_qc.R", mustWork = TRUE)
}

fig_dir <- normalizePath(file.path(dirname(script_path), "..", ".."), mustWork = TRUE)
project_root <- normalizePath(file.path(fig_dir, ".."), mustWork = TRUE)
source(file.path(project_root, "shared", "R", "project_library.R"))
icat_activate_project_library(project_root)
source(file.path(project_root, "shared", "R", "plot_style.R"))

suppressPackageStartupMessages({
  library(ComplexHeatmap)
  library(circlize)
  library(dendextend)
  library(dplyr)
  library(ggplot2)
  library(ggrepel)
  library(gridExtra)
  library(patchwork)
  library(scales)
})

input_dir <- file.path(fig_dir, "01_raw_data", "identification")
output_dir <- file.path(fig_dir, "04_results")
table_dir <- file.path(output_dir, "tables")
figure_pdf_dir <- file.path(output_dir, "figures", "pdf")
figure_png_dir <- file.path(output_dir, "figures", "png")
legend_dir <- file.path(output_dir, "legends")
report_dir <- file.path(output_dir, "reports")
for (path in c(table_dir, figure_pdf_dir, figure_png_dir, legend_dir, report_dir)) {
  dir.create(path, recursive = TRUE, showWarnings = FALSE)
}

cf5_file <- file.path(input_dir, "CF5_Normalized spec count.csv")
peptide_file <- file.path(input_dir, "CF5_Total unique peptide.csv")
if (!file.exists(cf5_file)) stop("Missing source file: ", cf5_file)
if (!file.exists(peptide_file)) stop("Missing source file: ", peptide_file)

sample_display <- c("CF5-1", "CF5-2", "CF5-3", "Cyto-1", "Cyto-2", "Cyto-3")
sample_group <- c(rep("CF5 bait", 3), rep("cytosol", 3))
sample_colours <- c("CF5 bait" = "#46B978", cytosol = "#C9C9C9")

numeric_matrix <- function(frame) {
  mat <- as.matrix(data.frame(lapply(frame, function(x) {
    suppressWarnings(as.numeric(gsub(",", "", as.character(x))))
  })))
  storage.mode(mat) <- "numeric"
  mat
}

sample_key <- data.frame(
  raw_name = rep(NA_character_, length(sample_display)),
  display_name = sample_display,
  group = sample_group,
  stringsAsFactors = FALSE
)

cf5_raw <- read.csv(cf5_file, check.names = FALSE, stringsAsFactors = FALSE)
sample_key$raw_name <- names(cf5_raw)[3:8]

counts <- numeric_matrix(cf5_raw[, 3:8])
colnames(counts) <- sample_display
keep_rows <- rowSums(is.finite(counts)) > 0
counts <- counts[keep_rows, , drop = FALSE]

log_counts <- log2(counts + 1)
keep_var <- apply(log_counts, 1, function(x) stats::sd(x, na.rm = TRUE) > 0)
log_counts <- log_counts[keep_var, , drop = FALSE]

# -----------------------------------------------------------------------------
# Panel a: replicate correlation heatmap
# -----------------------------------------------------------------------------

cor_mat <- cor(log_counts, method = "pearson", use = "pairwise.complete.obs")
hc <- hclust(as.dist(1 - cor_mat), method = "average")
dend <- as.dendrogram(hc)
dend <- dendextend::rotate(dend, order = sample_display)
ordered_display <- labels(dend)

sample_key <- sample_key[match(ordered_display, sample_key$display_name), , drop = FALSE]

cor_df <- as.data.frame(as.table(cor_mat), stringsAsFactors = FALSE)
names(cor_df) <- c("sample_x", "sample_y", "pearson_r")
cor_df$sample_x <- factor(cor_df$sample_x, levels = ordered_display)
cor_df$sample_y <- factor(cor_df$sample_y, levels = ordered_display)
cor_df <- cor_df %>%
  arrange(sample_x, sample_y) %>%
  mutate(
    sample_x = as.character(sample_x),
    sample_y = as.character(sample_y)
  )

write.csv(
  sample_key,
  file.path(table_dir, "Figure2S1_mass_spec_qc_sample_map.csv"),
  row.names = FALSE, na = ""
)
write.csv(
  cor_df,
  file.path(table_dir, "Figure2S1_mass_spec_qc_correlation_matrix.csv"),
  row.names = FALSE, na = ""
)

within_bait <- cor_mat[sample_group == "CF5 bait", sample_group == "CF5 bait"]
within_cyto <- cor_mat[sample_group == "cytosol", sample_group == "cytosol"]
between_groups <- cor_mat[sample_group == "CF5 bait", sample_group == "cytosol"]
corr_floor <- max(0.75, floor(min(cor_mat[lower.tri(cor_mat)]) * 100) / 100)

sample_annotation <- ComplexHeatmap::HeatmapAnnotation(
  sample = factor(sample_group, levels = names(sample_colours)),
  col = list(sample = sample_colours),
  annotation_name_gp = grid::gpar(fontfamily = "Helvetica", fontsize = ICAT_FONT_SMALL_PT),
  height = grid::unit(2.2, "mm"),
  show_legend = FALSE,
  show_annotation_name = FALSE
)

cor_colours <- circlize::colorRamp2(
  c(corr_floor, round((corr_floor + 1) / 2, 2), 1),
  c("#F6FBFF", "#9EC9E2", "#2166AC")
)

heatmap_panel <- ComplexHeatmap::Heatmap(
  cor_mat,
  name = "Pearson r",
  col = cor_colours,
  cluster_rows = dend,
  cluster_columns = dend,
  top_annotation = sample_annotation,
  column_title = NULL,
  row_names_side = "left",
  column_names_side = "bottom",
  column_names_rot = 45,
  row_names_gp = grid::gpar(fontfamily = "Helvetica", fontsize = ICAT_FONT_SMALL_PT),
  column_names_gp = grid::gpar(fontfamily = "Helvetica", fontsize = ICAT_FONT_SMALL_PT),
  row_dend_width = grid::unit(3.5, "mm"),
  column_dend_height = grid::unit(3.5, "mm"),
  width = grid::unit(25, "mm"),
  height = grid::unit(25, "mm"),
  rect_gp = grid::gpar(col = "white", lwd = 0.6),
  border = TRUE,
  heatmap_legend_param = list(
    title = "Pearson r",
    at = c(corr_floor, round((corr_floor + 1) / 2, 2), 1),
    labels = sprintf("%.2f", c(corr_floor, round((corr_floor + 1) / 2, 2), 1)),
    legend_height = grid::unit(20, "mm"),
    title_gp = grid::gpar(fontfamily = "Helvetica", fontsize = ICAT_FONT_SMALL_PT),
    labels_gp = grid::gpar(fontfamily = "Helvetica", fontsize = ICAT_FONT_SMALL_PT)
  )
)

heatmap_grob <- grid::grid.grabExpr(
  ComplexHeatmap::draw(
    heatmap_panel,
    heatmap_legend_side = "right",
    annotation_legend_side = "right",
    padding = grid::unit(c(2, 2, 2, 2), "mm")
  )
)
panel_a_grob <- grid::grobTree(
  heatmap_grob,
  grid::textGrob(
    "a",
    x = grid::unit(0, "npc"),
    y = grid::unit(1, "npc"),
    just = c("left", "top"),
    gp = grid::gpar(fontfamily = "Helvetica", fontsize = ICAT_FONT_TITLE_PT, fontface = "bold")
  )
)

# -----------------------------------------------------------------------------
# Panel b: PCA sample separation
# -----------------------------------------------------------------------------

pca <- prcomp(t(log_counts), center = TRUE, scale. = FALSE)
pca_var <- 100 * (pca$sdev^2 / sum(pca$sdev^2))
pca_scores <- data.frame(
  sample = rownames(pca$x),
  group = sample_group[match(rownames(pca$x), sample_display)],
  PC1 = pca$x[, 1],
  PC2 = pca$x[, 2],
  stringsAsFactors = FALSE
)

write.csv(
  pca_scores,
  file.path(table_dir, "Figure2S1_mass_spec_qc_pca_scores.csv"),
  row.names = FALSE, na = ""
)

qc_theme <- function(base_size = ICAT_FONT_SMALL_PT) {
  theme_classic(base_size = base_size, base_family = "Helvetica") +
    theme(
      axis.line = element_line(linewidth = ICAT_LINE_MM, colour = "black"),
      axis.ticks = element_line(linewidth = ICAT_LINE_MM, colour = "black"),
      axis.title = element_text(size = ICAT_FONT_SMALL_PT),
      axis.text = element_text(size = ICAT_FONT_SMALL_PT, colour = "black"),
      legend.position = "none",
      plot.title = element_text(size = ICAT_FONT_BODY_PT, face = "bold"),
      plot.tag = element_text(size = ICAT_FONT_TITLE_PT, face = "bold"),
      plot.margin = margin(1, 1, 1, 1, unit = "mm")
    )
}

p_pca <- ggplot(pca_scores, aes(PC1, PC2, fill = group)) +
  geom_hline(yintercept = 0, linewidth = ICAT_LINE_MM, colour = "#D8D8D8") +
  geom_vline(xintercept = 0, linewidth = ICAT_LINE_MM, colour = "#D8D8D8") +
  geom_point(shape = 21, size = 2.2, stroke = 0.35, colour = "#333333") +
  ggrepel::geom_text_repel(
    aes(label = sample),
    family = "Helvetica", size = ICAT_TEXT_SMALL_MM,
    colour = "#222222", min.segment.length = 0,
    segment.size = 0.12, segment.color = "#777777",
    box.padding = 0.15, point.padding = 0.18,
    force = 4, force_pull = 0.35,
    max.time = 3, max.overlaps = Inf, seed = 252880
  ) +
  scale_fill_manual(values = sample_colours) +
  scale_x_continuous(expand = expansion(mult = 0.16)) +
  scale_y_continuous(expand = expansion(mult = 0.18)) +
  labs(
    tag = "b",
    title = "PCA",
    x = sprintf("PC1 (%.1f%%)", pca_var[1]),
    y = sprintf("PC2 (%.1f%%)", pca_var[2])
  ) +
  qc_theme()

# -----------------------------------------------------------------------------
# Panel d: dominant PC1 separation
# -----------------------------------------------------------------------------

pca_scores <- pca_scores %>%
  mutate(group_plot = factor(group, levels = c("CF5 bait", "cytosol"))) %>%
  group_by(group_plot) %>%
  arrange(sample, .by_group = TRUE) %>%
  mutate(pc1_y = as.numeric(group_plot) + c(-0.08, 0, 0.08)[row_number()]) %>%
  ungroup()

p_pc1 <- ggplot(pca_scores, aes(PC1, pc1_y, fill = group)) +
  geom_vline(xintercept = 0, linewidth = ICAT_LINE_MM, colour = "#D8D8D8") +
  geom_point(shape = 21, size = 1.95, stroke = 0.35, colour = "#333333") +
  scale_fill_manual(values = sample_colours) +
  scale_y_continuous(
    breaks = c(1, 2),
    labels = c("CF5", "Cyto"),
    limits = c(0.65, 2.35),
    expand = expansion(mult = c(0, 0))
  ) +
  scale_x_continuous(expand = expansion(mult = 0.18)) +
  labs(
    tag = "d",
    title = "PC1 score",
    x = sprintf("PC1 (%.1f%%)", pca_var[1]),
    y = NULL
  ) +
  qc_theme() +
  theme(
    axis.text.y = element_text(size = ICAT_FONT_SMALL_PT, colour = "black"),
    axis.ticks.y = element_blank()
  )

# -----------------------------------------------------------------------------
# Panel c: abundance distributions and peptide support
# -----------------------------------------------------------------------------

distribution_df <- as.data.frame(as.table(log_counts), stringsAsFactors = FALSE)
names(distribution_df) <- c("protein_index", "sample", "log2_normalized_spectral_count")
distribution_df$sample <- factor(distribution_df$sample, levels = sample_display)
distribution_df$group <- sample_group[match(as.character(distribution_df$sample), sample_display)]

write.csv(
  distribution_df,
  file.path(table_dir, "Figure2S1_mass_spec_qc_sample_distribution.csv"),
  row.names = FALSE, na = ""
)

peptides_raw <- read.csv(peptide_file, check.names = FALSE, stringsAsFactors = FALSE)
peptide_values <- numeric_matrix(peptides_raw[, 2:7])
colnames(peptide_values) <- sample_display
detection_summary <- data.frame(
  sample = sample_display,
  group = sample_group,
  detected_proteins_with_unique_peptides = colSums(peptide_values > 0, na.rm = TRUE),
  total_unique_peptides = colSums(peptide_values, na.rm = TRUE),
  stringsAsFactors = FALSE
)

write.csv(
  detection_summary,
  file.path(table_dir, "Figure2S1_mass_spec_qc_detection_summary.csv"),
  row.names = FALSE, na = ""
)

p_distribution <- ggplot(distribution_df, aes(sample, log2_normalized_spectral_count, fill = group)) +
  geom_violin(width = 0.86, colour = "#555555", linewidth = 0.18, scale = "width", trim = TRUE) +
  geom_boxplot(width = 0.14, outlier.shape = NA, colour = "#222222", linewidth = 0.18, fill = "white") +
  scale_fill_manual(values = sample_colours) +
  labs(
    tag = "c",
    title = "Sample distribution",
    x = NULL,
    y = "log2 NSC + 1"
  ) +
  qc_theme() +
  theme(
    axis.text.x = element_blank(),
    axis.ticks.x = element_blank()
  )

p_detection <- ggplot(
  detection_summary,
  aes(factor(sample, levels = sample_display), detected_proteins_with_unique_peptides, fill = group)
) +
  geom_col(width = 0.72, colour = "#555555", linewidth = 0.18) +
  geom_text(
    aes(label = paste0(round(total_unique_peptides / 1000, 1), "k")),
    family = "Helvetica", size = ICAT_TEXT_SMALL_MM * 0.82,
    vjust = -0.35, colour = "#222222"
  ) +
  scale_fill_manual(values = sample_colours) +
  scale_y_continuous(
    labels = scales::comma,
    expand = expansion(mult = c(0, 0.16))
  ) +
  labs(
    x = NULL,
    y = "proteins"
  ) +
  qc_theme() +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1, vjust = 1)
  )

p_qc_summary <- p_distribution / p_detection +
  patchwork::plot_layout(heights = c(1.1, 0.85))

figure_grob <- gridExtra::arrangeGrob(
  grobs = list(panel_a_grob, ggplotGrob(p_pca), patchwork::patchworkGrob(p_qc_summary), ggplotGrob(p_pc1)),
  ncol = 4,
  widths = c(1.18, 1.00, 1.26, 0.70)
)

pdf_path <- file.path(figure_pdf_dir, "Figure2S1_CF5_mass_spec_QC.pdf")
png_path <- file.path(figure_png_dir, "Figure2S1_CF5_mass_spec_QC.png")

grDevices::cairo_pdf(pdf_path, width = 18.6 / 2.54, height = 6.2 / 2.54, family = "Helvetica")
grid::grid.newpage()
grid::grid.draw(figure_grob)
grDevices::dev.off()

grDevices::png(
  png_path, width = 18.6 / 2.54, height = 6.2 / 2.54,
  units = "in", res = 600, type = "cairo", bg = "white"
)
grid::grid.newpage()
grid::grid.draw(figure_grob)
grDevices::dev.off()

summary_lines <- c(
  "Figure 2 supplementary mass spectrometry QC",
  "",
  "Input matrix: CF5_Normalized spec count.csv.",
  "Transformation: log2(normalized spectral count + 1).",
  "Clustering: average-linkage hierarchical clustering on 1 - Pearson r.",
  "PCA: centered log2-normalized spectral counts without unit-variance scaling.",
  sprintf("Proteins retained for correlation/PCA QC: %d", nrow(log_counts)),
  sprintf("Bait replicate mean Pearson r: %.3f", mean(within_bait[upper.tri(within_bait)], na.rm = TRUE)),
  sprintf("Cytosol replicate mean Pearson r: %.3f", mean(within_cyto[upper.tri(within_cyto)], na.rm = TRUE)),
  sprintf("Between-group mean Pearson r: %.3f", mean(between_groups, na.rm = TRUE)),
  sprintf("PCA PC1 variance explained: %.2f%%", pca_var[1]),
  sprintf("PCA PC2 variance explained: %.2f%%", pca_var[2]),
  "",
  "Unique peptide support per sample:",
  paste0(
    detection_summary$sample, ": ",
    detection_summary$detected_proteins_with_unique_peptides, " proteins, ",
    detection_summary$total_unique_peptides, " total unique peptides"
  )
)
writeLines(summary_lines, file.path(report_dir, "Figure2S1_mass_spec_qc_summary.txt"))

figure_legend <- paste(
  "Figure 2S1. Mass spectrometry sample quality control for the CF5 proximity-labeling dataset.",
  "(a) Pearson correlation heatmap of log2-normalized spectral counts across detected proteins, with average-linkage hierarchical clustering on 1 - Pearson r; the dendrogram is rotated to display replicate numbers in ascending order where compatible with the clustering topology.",
  "(b) Principal-component analysis of centered log2-normalized protein abundance profiles.",
  "(c) Distributions of log2-normalized spectral counts for each replicate, with lower bars indicating the number of proteins supported by at least one unique peptide; text above bars shows total unique peptide counts.",
  "(d) One-dimensional PC1 score plot highlighting the dominant bait-control separation.",
  "Green denotes CF5 bait triplicates and grey denotes cytosolic-control triplicates.",
  "Together, the panels support high within-group reproducibility and separation of bait and control MS profiles."
)
writeLines(
  figure_legend,
  file.path(legend_dir, "Figure2S1_CF5_mass_spec_QC_figure_legend.txt")
)

message("Wrote: ", pdf_path)
message("Wrote: ", png_path)
