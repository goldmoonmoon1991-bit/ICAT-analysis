#!/usr/bin/env Rscript

# Surface-aware distance analysis for ICMTs, rhoptries, and micronemes.
# B1 and B2 are normalized to 0 and 1. FWHM-facing edges are used to estimate
# surface-to-surface gaps, while peak-center distances are retained for audit.

runtime_cache <- file.path(tempdir(), "symmetry-distance-cache")
dir.create(runtime_cache, recursive = TRUE, showWarnings = FALSE)
Sys.setenv(XDG_CACHE_HOME = runtime_cache)

suppressPackageStartupMessages({
  library(ggplot2)
})

script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
script_path <- if (length(script_arg)) {
  normalizePath(sub("^--file=", "", script_arg[[1]]), mustWork = TRUE)
} else {
  normalizePath("symmetry_distance.R", mustWork = TRUE)
}

code_dir <- dirname(script_path)
fig_dir <- normalizePath(file.path(code_dir, "..", ".."), mustWork = TRUE)
project_root <- normalizePath(file.path(fig_dir, ".."), mustWork = TRUE)
source(file.path(project_root, "shared", "R", "plot_style.R"))
results_root <- file.path(fig_dir, "04_results", "tables", "peak_profiles")
figure_root <- file.path(fig_dir, "04_results", "figures", "peak_profiles")
report_root <- file.path(fig_dir, "04_results", "reports", "peak_profiles")
corrected_root <- file.path(fig_dir, "02_processed_data", "peak_profiles")

args <- commandArgs(trailingOnly = TRUE)
focused_group_arg <- grep("^--purple-b2-group=", args, value = TRUE)
if (length(focused_group_arg) > 1L) {
  stop("Provide at most one --purple-b2-group argument.")
}
focused_purple_b2 <- length(focused_group_arg) == 1L
focused_group <- if (focused_purple_b2) {
  sub("^--purple-b2-group=", "", focused_group_arg[[1]])
} else {
  NA_character_
}
if (focused_purple_b2 &&
    (!nzchar(focused_group) || basename(focused_group) != focused_group)) {
  stop("Invalid group folder name: ", focused_group)
}
expansion_arg <- grep("^--expansion-factor=", args, value = TRUE)
if (length(expansion_arg) > 1L) {
  stop("Provide at most one --expansion-factor argument.")
}
focused_expansion_factor <- if (length(expansion_arg)) {
  as.numeric(sub("^--expansion-factor=", "", expansion_arg[[1]]))
} else {
  4.5
}
if (!is.finite(focused_expansion_factor) || focused_expansion_factor <= 0) {
  stop("--expansion-factor must be a positive number.")
}
height_fraction_arg <- grep("^--height-fraction=", args, value = TRUE)
if (length(height_fraction_arg) > 1L) {
  stop("Provide at most one --height-fraction argument.")
}
focused_height_fraction <- if (length(height_fraction_arg)) {
  as.numeric(sub("^--height-fraction=", "", height_fraction_arg[[1]]))
} else {
  0.5
}
if (!is.finite(focused_height_fraction) ||
    focused_height_fraction <= 0 || focused_height_fraction >= 1) {
  stop("--height-fraction must be between 0 and 1.")
}
height_fraction_tag <- if (abs(focused_height_fraction - 2 / 3) < 1e-6) {
  "height_2over3"
} else {
  paste0("height_", gsub("\\.", "p", format(focused_height_fraction, trim = TRUE)))
}

output_key <- if (focused_purple_b2) {
  focused_root <- file.path(focused_group, "symmetry_distance")
  if (abs(focused_height_fraction - 0.5) < 1e-8) {
    focused_root
  } else {
    file.path(focused_root, height_fraction_tag)
  }
} else {
  "symmetry_distance"
}
figure_dir <- file.path(figure_root, output_key)
table_dir <- file.path(results_root, output_key)
output_dir <- file.path(report_root, output_key)
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

primary_groups <- if (focused_purple_b2) character() else c("ARO", "WT-MIC2")
microneme_groups <- if (focused_purple_b2) {
  focused_group
} else {
  c("WT-MIC2", "ICMAP1-MIC2", "ICMAP2-MIC2", "ARO-MIC2")
}
required_groups <- unique(c(primary_groups, microneme_groups))

group_labels <- c(
  "ARO" = "ARO (rhoptry)",
  "WT-MIC2" = "WT",
  "ICMAP1-MIC2" = "ICMAP1 KO",
  "ICMAP2-MIC2" = "ICMAP2 KO",
  "ARO-MIC2" = "ARO KO"
)
if (focused_purple_b2) {
  group_labels <- setNames("ICAT B2 asymmetry", focused_group)
}

group_colors <- c(
  "ARO" = "#D64B3B",
  "WT-MIC2" = "#33373D",
  "ICMAP1-MIC2" = "#178A5B",
  "ICMAP2-MIC2" = "#2878B5",
  "ARO-MIC2" = "#D07A27"
)
if (focused_purple_b2) {
  group_colors <- setNames("#B21BB5", focused_group)
}

structure_colors <- c(
  "ICMTs" = "#00874A",
  "Rhoptry" = "#D64B3B",
  "Microneme" = "#C000C8"
)

display_group_colors <- c(
  "ICMTs (WT)" = "#00876C",
  "ICMTs (ARO)" = "#65A30D",
  "Rhoptry (ARO)" = "#D1495B",
  "Microneme (WT)" = "#B000B5",
  "Microneme (ICMAP1 KO)" = "#0072B2",
  "Microneme (ICMAP2 KO)" = "#E69F00",
  "Microneme (ARO KO)" = "#7B61A8"
)

required_measurement_columns <- c(
  "group", "cell_id", "conoid_boundary_1_nm", "icmt_peak_nm",
  "conoid_boundary_2_nm", "purple_peak_nm", "conoid_width_nm",
  "icmt_position_normalized", "purple_position_normalized",
  "icmt_imputed", "orientation_reversed", "included_in_average", "qc_flag"
)
required_profile_columns <- c(
  "group", "cell_id", "position_normalized", "channel", "intensity"
)

read_group_inputs <- function(group_name) {
  measurement_path <- file.path(
    results_root, group_name, "peak_measurements_per_cell.csv"
  )
  profile_path <- file.path(
    corrected_root, group_name, "aligned_profiles_normalized.csv"
  )
  if (!file.exists(measurement_path)) stop("Missing measurement table: ", measurement_path)
  if (!file.exists(profile_path)) stop("Missing normalized profiles: ", profile_path)

  measurements <- read.csv(
    measurement_path, check.names = FALSE, stringsAsFactors = FALSE
  )
  profiles <- read.csv(profile_path, check.names = FALSE, stringsAsFactors = FALSE)

  missing_measurements <- setdiff(required_measurement_columns, names(measurements))
  missing_profiles <- setdiff(required_profile_columns, names(profiles))
  if (length(missing_measurements)) {
    stop(group_name, " measurement table is missing: ",
         paste(missing_measurements, collapse = ", "))
  }
  if (length(missing_profiles)) {
    stop(group_name, " profile table is missing: ",
         paste(missing_profiles, collapse = ", "))
  }
  if (any(measurements$orientation_reversed %in% TRUE, na.rm = TRUE)) {
    stop(group_name, " contains orientation-reversed measurements.")
  }

  measurements <- measurements[
    measurements$included_in_average %in% TRUE &
      is.finite(measurements$conoid_width_nm) &
      measurements$conoid_width_nm > 0,
    ,
    drop = FALSE
  ]
  profiles <- profiles[
    profiles$cell_id %in% measurements$cell_id &
      profiles$channel %in% c("Green", "Purple"),
    ,
    drop = FALSE
  ]
  if (!nrow(measurements) || !nrow(profiles)) {
    stop("No eligible measurements or profiles for ", group_name)
  }
  list(measurements = measurements, profiles = profiles)
}

inputs <- setNames(lapply(required_groups, read_group_inputs), required_groups)

linear_crossing <- function(x1, y1, x2, y2, level) {
  if (!all(is.finite(c(x1, y1, x2, y2, level))) || y2 == y1) {
    return(mean(c(x1, x2)))
  }
  x1 + (level - y1) * (x2 - x1) / (y2 - y1)
}

empty_fwhm <- function(expected_center, status, height_fraction = 0.5) {
  list(
    expected_center = expected_center,
    height_fraction = height_fraction,
    peak_center = NA_real_,
    peak_height = NA_real_,
    local_baseline = NA_real_,
    half_height = NA_real_,
    left = NA_real_,
    right = NA_real_,
    width = NA_real_,
    left_found = FALSE,
    right_found = FALSE,
    left_method = "unresolved",
    right_method = "unresolved",
    status = status
  )
}

local_fwhm <- function(curve, expected_center, domain_left, domain_right,
                       search_radius = 0.08,
                       mirror_missing_edge = FALSE,
                       height_fraction = 0.5) {
  if (!is.finite(height_fraction) || height_fraction <= 0 || height_fraction >= 1) {
    stop("height_fraction must be between 0 and 1.")
  }
  curve <- curve[
    is.finite(curve$position_normalized) & is.finite(curve$intensity),
    c("position_normalized", "intensity"),
    drop = FALSE
  ]
  curve <- curve[order(curve$position_normalized), , drop = FALSE]
  curve <- curve[
    curve$position_normalized >= domain_left &
      curve$position_normalized <= domain_right,
    ,
    drop = FALSE
  ]
  if (nrow(curve) < 5L || !is.finite(expected_center)) {
    return(empty_fwhm(expected_center, "INSUFFICIENT_PROFILE", height_fraction))
  }

  search <- which(
    curve$position_normalized >= expected_center - search_radius &
      curve$position_normalized <= expected_center + search_radius
  )
  if (!length(search)) {
    return(empty_fwhm(expected_center, "PEAK_SEARCH_EMPTY", height_fraction))
  }
  peak_index <- search[which.max(curve$intensity[search])]
  peak_height <- curve$intensity[peak_index]
  if (!is.finite(peak_height) || peak_height <= 0) {
    return(empty_fwhm(expected_center, "INVALID_PEAK_HEIGHT", height_fraction))
  }

  # Use the local prominence baseline so partially overlapping peaks retain
  # interpretable half-height crossings. This is equivalent to a local,
  # background-corrected FWHM rather than an absolute 0.5 intensity cutoff.
  left_baseline <- min(curve$intensity[seq_len(peak_index)], na.rm = TRUE)
  right_baseline <- min(
    curve$intensity[seq.int(peak_index, nrow(curve))], na.rm = TRUE
  )
  local_baseline <- max(left_baseline, right_baseline)
  if (!is.finite(local_baseline) || peak_height <= local_baseline) {
    return(empty_fwhm(expected_center, "INVALID_LOCAL_PROMINENCE", height_fraction))
  }
  half_height <- local_baseline + height_fraction * (peak_height - local_baseline)

  left <- NA_real_
  if (peak_index > 1L) {
    for (j in seq.int(peak_index - 1L, 1L)) {
      if (curve$intensity[j] <= half_height &&
          curve$intensity[j + 1L] > half_height) {
        left <- linear_crossing(
          curve$position_normalized[j], curve$intensity[j],
          curve$position_normalized[j + 1L], curve$intensity[j + 1L],
          half_height
        )
        break
      }
    }
  }

  right <- NA_real_
  if (peak_index < nrow(curve)) {
    for (j in seq.int(peak_index, nrow(curve) - 1L)) {
      if (curve$intensity[j] > half_height &&
          curve$intensity[j + 1L] <= half_height) {
        right <- linear_crossing(
          curve$position_normalized[j], curve$intensity[j],
          curve$position_normalized[j + 1L], curve$intensity[j + 1L],
          half_height
        )
        break
      }
    }
  }

  left_method <- if (is.finite(left)) "observed" else "unresolved"
  right_method <- if (is.finite(right)) "observed" else "unresolved"

  # Adjacent green peaks often merge above half maximum. In that case the
  # inward-facing crossing is optically hidden, while the outward half-width
  # remains measurable. Mirror that observed half-width around the local peak
  # center and retain the method in the QC columns.
  peak_center <- curve$position_normalized[peak_index]
  curve_left <- min(curve$position_normalized)
  curve_right <- max(curve$position_normalized)
  if (mirror_missing_edge && !is.finite(left) && is.finite(right)) {
    candidate <- peak_center - (right - peak_center)
    if (is.finite(candidate) && candidate >= curve_left && candidate < peak_center) {
      left <- candidate
      left_method <- "mirrored_from_right"
    }
  }
  if (mirror_missing_edge && is.finite(left) && !is.finite(right)) {
    candidate <- peak_center + (peak_center - left)
    if (is.finite(candidate) && candidate <= curve_right && candidate > peak_center) {
      right <- candidate
      right_method <- "mirrored_from_left"
    }
  }

  left_found <- is.finite(left)
  right_found <- is.finite(right)
  status <- if (left_found && right_found &&
                left_method == "observed" && right_method == "observed") {
    "PASS"
  } else if (left_found && right_found) {
    "PASS_ONE_EDGE_MIRRORED"
  } else if (!left_found && !right_found) {
    "BOTH_HALFMAX_EDGES_UNRESOLVED"
  } else if (!left_found) {
    "LEFT_HALFMAX_EDGE_UNRESOLVED"
  } else {
    "RIGHT_HALFMAX_EDGE_UNRESOLVED"
  }

  list(
    expected_center = expected_center,
    height_fraction = height_fraction,
    peak_center = peak_center,
    peak_height = peak_height,
    local_baseline = local_baseline,
    half_height = half_height,
    left = left,
    right = right,
    width = if (left_found && right_found) right - left else NA_real_,
    left_found = left_found,
    right_found = right_found,
    left_method = left_method,
    right_method = right_method,
    status = status
  )
}

surface_gap <- function(left_fwhm, right_fwhm) {
  if (is.finite(left_fwhm$right) && is.finite(right_fwhm$left)) {
    raw_gap <- right_fwhm$left - left_fwhm$right
    return(list(
      gap = max(0, raw_gap),
      raw_gap = raw_gap,
      overlap = raw_gap <= 0,
      overlap_zero_assigned = FALSE,
      status = if (raw_gap <= 0) "FWHM_INTERVALS_OVERLAP" else "PASS"
    ))
  }
  list(
    gap = NA_real_, raw_gap = NA_real_, overlap = NA,
    overlap_zero_assigned = FALSE, status = "FWHM_FACING_EDGE_UNRESOLVED"
  )
}

fwhm_columns <- function(prefix, fwhm) {
  out <- data.frame(
    expected_center = fwhm$expected_center,
    height_fraction = fwhm$height_fraction,
    peak_center = fwhm$peak_center,
    peak_height = fwhm$peak_height,
    local_baseline = fwhm$local_baseline,
    half_height = fwhm$half_height,
    fwhm_left = fwhm$left,
    fwhm_right = fwhm$right,
    fwhm_width = fwhm$width,
    fwhm_left_method = fwhm$left_method,
    fwhm_right_method = fwhm$right_method,
    fwhm_status = fwhm$status,
    stringsAsFactors = FALSE
  )
  names(out) <- paste0(prefix, "_", names(out))
  out
}

make_relation_row <- function(group_name, measurement, relation,
                              structure, boundary, boundary_center,
                              structure_center, boundary_fwhm,
                              structure_fwhm, left_structure) {
  if (left_structure == "boundary") {
    gap <- surface_gap(boundary_fwhm, structure_fwhm)
    center_distance <- structure_center - boundary_center
    boundary_surface <- boundary_fwhm$right
    structure_surface <- structure_fwhm$left
  } else {
    gap <- surface_gap(structure_fwhm, boundary_fwhm)
    center_distance <- boundary_center - structure_center
    boundary_surface <- boundary_fwhm$left
    structure_surface <- structure_fwhm$right
  }

  width_nm <- measurement$conoid_width_nm
  ordering_valid <- is.finite(center_distance) && center_distance >= 0
  included_surface <- ordering_valid && is.finite(gap$gap)

  cbind(
    data.frame(
      group = group_name,
      group_label = unname(group_labels[group_name]),
      cell_id = measurement$cell_id,
      relation = relation,
      structure = structure,
      boundary = boundary,
      conoid_width_nm = width_nm,
      center_distance_normalized = center_distance,
      center_distance_nm = center_distance * width_nm,
      boundary_facing_surface_normalized = boundary_surface,
      structure_facing_surface_normalized = structure_surface,
      surface_gap_normalized = gap$gap,
      surface_gap_nm = gap$gap * width_nm,
      boundary_fwhm_width_nm = boundary_fwhm$width * width_nm,
      structure_fwhm_width_nm = structure_fwhm$width * width_nm,
      raw_surface_gap_normalized = gap$raw_gap,
      fwhm_intervals_overlap = gap$overlap,
      overlap_zero_assigned = gap$overlap_zero_assigned,
      surface_gap_status = gap$status,
      center_ordering_valid = ordering_valid,
      included_surface_analysis = included_surface,
      icmt_imputed = measurement$icmt_imputed %in% TRUE,
      source_qc_flag = measurement$qc_flag,
      stringsAsFactors = FALSE
    ),
    fwhm_columns("boundary", boundary_fwhm),
    fwhm_columns("structure", structure_fwhm)
  )
}

relation_rows <- list()

for (group_name in required_groups) {
  measurements <- inputs[[group_name]]$measurements
  profiles <- inputs[[group_name]]$profiles
  profile_split <- split(profiles, profiles$cell_id)

  for (i in seq_len(nrow(measurements))) {
    measurement <- measurements[i, , drop = FALSE]
    cell_id <- measurement$cell_id
    cell_profile <- profile_split[[cell_id]]
    if (is.null(cell_profile) || !nrow(cell_profile)) next

    green <- cell_profile[cell_profile$channel == "Green", , drop = FALSE]
    purple <- cell_profile[cell_profile$channel == "Purple", , drop = FALSE]
    icmt_center <- measurement$icmt_position_normalized
    purple_center <- measurement$purple_position_normalized
    if (!is.finite(icmt_center) || !is.finite(purple_center)) next

    green_min <- min(green$position_normalized, na.rm = TRUE)
    green_max <- max(green$position_normalized, na.rm = TRUE)
    purple_min <- min(purple$position_normalized, na.rm = TRUE)
    purple_max <- max(purple$position_normalized, na.rm = TRUE)
    midpoint_b1_icmt <- 0.5 * icmt_center
    midpoint_icmt_b2 <- 0.5 * (icmt_center + 1)
    green_radius <- max(0.025, min(0.08, 0.35 * min(
      abs(icmt_center), abs(1 - icmt_center)
    )))

    b1_fwhm <- local_fwhm(
      green, 0, green_min, midpoint_b1_icmt,
      search_radius = green_radius,
      mirror_missing_edge = TRUE
    )
    icmt_fwhm <- local_fwhm(
      green, icmt_center, midpoint_b1_icmt, midpoint_icmt_b2,
      search_radius = green_radius,
      mirror_missing_edge = TRUE
    )
    b2_fwhm <- local_fwhm(
      green, 1, midpoint_icmt_b2, green_max,
      search_radius = green_radius,
      mirror_missing_edge = TRUE,
      height_fraction = if (focused_purple_b2) focused_height_fraction else 0.5
    )
    purple_fwhm <- local_fwhm(
      purple, purple_center,
      max(purple_min, purple_center - 0.45),
      min(purple_max, purple_center + 0.45),
      search_radius = 0.10,
      height_fraction = if (focused_purple_b2) focused_height_fraction else 0.5
    )

    if (group_name %in% primary_groups && !(measurement$icmt_imputed %in% TRUE)) {
      relation_rows[[length(relation_rows) + 1L]] <- make_relation_row(
        group_name, measurement,
        relation = "ICMTs to B1", structure = "ICMTs", boundary = "B1",
        boundary_center = 0, structure_center = icmt_center,
        boundary_fwhm = b1_fwhm, structure_fwhm = icmt_fwhm,
        left_structure = "boundary"
      )
    }

    if (group_name == "ARO") {
      relation_rows[[length(relation_rows) + 1L]] <- make_relation_row(
        group_name, measurement,
        relation = "Rhoptry to B1", structure = "Rhoptry", boundary = "B1",
        boundary_center = 0, structure_center = purple_center,
        boundary_fwhm = b1_fwhm, structure_fwhm = purple_fwhm,
        left_structure = "boundary"
      )
    }

    if (group_name %in% microneme_groups) {
      relation_rows[[length(relation_rows) + 1L]] <- make_relation_row(
        group_name, measurement,
        relation = if (focused_purple_b2) "Purple signal to B2" else "Microneme to B2",
        structure = if (focused_purple_b2) "Purple signal" else "Microneme",
        boundary = "B2",
        boundary_center = 1, structure_center = purple_center,
        boundary_fwhm = b2_fwhm, structure_fwhm = purple_fwhm,
        left_structure = "structure"
      )
    }
  }
}

distance_data <- do.call(rbind, relation_rows)
rownames(distance_data) <- NULL
if (!nrow(distance_data)) stop("No distance rows were generated.")

distance_data$relation <- factor(
  distance_data$relation,
  levels = c(
    "ICMTs to B1", "Rhoptry to B1", "Microneme to B2",
    "Purple signal to B2"
  )
)

summarize_values <- function(values) {
  values <- values[is.finite(values)]
  n <- length(values)
  se <- if (n > 1L) sd(values) / sqrt(n) else NA_real_
  critical <- if (n > 1L) qt(0.975, n - 1L) else NA_real_
  data.frame(
    n = n,
    mean = if (n) mean(values) else NA_real_,
    median = if (n) median(values) else NA_real_,
    sd = if (n > 1L) sd(values) else NA_real_,
    sem = se,
    q1 = if (n) unname(quantile(values, 0.25)) else NA_real_,
    q3 = if (n) unname(quantile(values, 0.75)) else NA_real_,
    ci95_low = if (n > 1L) mean(values) - critical * se else NA_real_,
    ci95_high = if (n > 1L) mean(values) + critical * se else NA_real_
  )
}

if (focused_purple_b2) {
  distance_data$expansion_factor <- focused_expansion_factor
  distance_data$height_fraction <- focused_height_fraction
  distance_data$center_distance_biological_nm <-
    distance_data$center_distance_nm / focused_expansion_factor
  distance_data$surface_gap_biological_nm <-
    distance_data$surface_gap_nm / focused_expansion_factor

  focused_metrics <- c(
    "center_distance_normalized", "center_distance_nm",
    "center_distance_biological_nm", "surface_gap_normalized",
    "surface_gap_nm", "surface_gap_biological_nm"
  )
  focused_summary <- do.call(rbind, lapply(focused_metrics, function(metric) {
    cbind(
      data.frame(
        group = focused_group,
        relation = "Purple signal to B2",
        metric = metric,
        expansion_factor = focused_expansion_factor,
        height_fraction = focused_height_fraction,
        stringsAsFactors = FALSE
      ),
      summarize_values(distance_data[[metric]])
    )
  }))
  rownames(focused_summary) <- NULL

  focused_qc <- data.frame(
    group = focused_group,
    n_total = nrow(distance_data),
    n_center_order_valid = sum(distance_data$center_ordering_valid),
    n_surface_gap_available = sum(distance_data$included_surface_analysis),
    n_fwhm_overlap = sum(distance_data$fwhm_intervals_overlap %in% TRUE, na.rm = TRUE),
    n_surface_unresolved = sum(!is.finite(distance_data$surface_gap_normalized)),
    surface_success_rate = mean(distance_data$included_surface_analysis),
    expansion_factor = focused_expansion_factor,
    height_fraction = focused_height_fraction,
    stringsAsFactors = FALSE
  )

  plot_data <- rbind(
    data.frame(
      cell_id = distance_data$cell_id,
      method = "Peak center to B2",
      distance_nm = distance_data$center_distance_biological_nm
    ),
    data.frame(
      cell_id = distance_data$cell_id,
      method = "Threshold surface gap",
      distance_nm = distance_data$surface_gap_biological_nm
    )
  )
  plot_data <- plot_data[is.finite(plot_data$distance_nm), , drop = FALSE]
  plot_data$method <- factor(
    plot_data$method,
    levels = c("Peak center to B2", "Threshold surface gap")
  )

  p_focused <- ggplot(
    plot_data,
    aes(x = method, y = distance_nm, group = cell_id)
  ) +
    geom_line(color = "#CAB6CC", linewidth = 0.35, alpha = 0.65) +
    geom_point(
      aes(fill = method), shape = 21, size = 2.0,
      color = "#5C265E", stroke = 0.35, alpha = 0.9
    ) +
    stat_summary(
      aes(group = method), fun = mean, geom = "point",
      shape = 23, size = 3.0, fill = "#F29AF3", color = "black",
      stroke = 0.45
    ) +
    scale_fill_manual(values = c(
      "Peak center to B2" = "#D992DC",
      "Threshold surface gap" = "#8E2A91"
    )) +
    scale_x_discrete(labels = c(
      "Peak center to B2" = "Peak center",
      "Threshold surface gap" = if (
        abs(focused_height_fraction - 2 / 3) < 1e-6
      ) "2/3-max gap" else paste0(
        format(round(focused_height_fraction, 3), trim = TRUE), "-max gap"
      )
    )) +
    labs(
      title = "Purple signal–B2 distance",
      subtitle = paste0(
        "Threshold: ",
        if (abs(focused_height_fraction - 2 / 3) < 1e-6) "2/3" else
          format(round(focused_height_fraction, 3), trim = TRUE),
        " max\n", focused_expansion_factor, "× de-expanded; diamonds = means"
      ),
      x = NULL,
      y = "Distance to B2 (nm)"
    ) +
    icat_theme_classic() +
    theme(
      legend.position = "none",
      plot.title = element_text(face = "bold", size = ICAT_FONT_TITLE_PT),
      plot.subtitle = element_text(size = ICAT_FONT_SMALL_PT, color = "#555555"),
      axis.title.y = element_text(size = ICAT_FONT_BODY_PT),
      axis.text.x = element_text(face = "bold", size = ICAT_FONT_SMALL_PT),
      plot.margin = margin(4, 5, 4, 5)
    )

  # Compact panel-ready violin using the Fig. 1F visual language: muted
  # source-colored observations with a high-contrast black group estimate.
  violin_all_data <- distance_data[
    is.finite(distance_data$surface_gap_biological_nm),
    c("cell_id", "surface_gap_biological_nm"),
    drop = FALSE
  ]
  names(violin_all_data)[2] <- "distance_nm"
  violin_all_data$comparison <- "Purple-B2"
  violin_all_data$x <- 1
  violin_all_data$is_max_outlier <- FALSE
  max_outlier_index <- which.max(violin_all_data$distance_nm)
  violin_all_data$is_max_outlier[max_outlier_index] <- TRUE
  violin_data <- violin_all_data[!violin_all_data$is_max_outlier, , drop = FALSE]
  violin_outlier_data <- violin_all_data[violin_all_data$is_max_outlier, , drop = FALSE]
  violin_data$comparison <- "Purple-B2"
  violin_data$x <- 1
  violin_n <- nrow(violin_data)
  violin_total_n <- nrow(violin_all_data)
  violin_outlier_n <- nrow(violin_outlier_data)
  violin_mean <- mean(violin_data$distance_nm)
  violin_quartiles <- quantile(
    violin_data$distance_nm,
    probs = c(0.25, 0.50, 0.75),
    names = FALSE
  )
  violin_summary <- data.frame(
    comparison = "Purple-B2",
    n_included = violin_n,
    n_total = violin_total_n,
    n_max_outlier_excluded = violin_outlier_n,
    max_outlier_distance_nm = violin_outlier_data$distance_nm[[1]],
    mean = violin_mean,
    q1 = violin_quartiles[[1]],
    median = violin_quartiles[[2]],
    q3 = violin_quartiles[[3]]
  )
  violin_quartile_lines <- data.frame(
    comparison = "Purple-B2",
    statistic = c("Q1", "Q2", "Q3"),
    x = c(0.82, 0.78, 0.82),
    xend = c(1.18, 1.22, 1.18),
    distance_nm = violin_quartiles,
    line_width = c(0.34, 0.52, 0.34)
  )
  violin_upper <- max(30, ceiling(max(violin_data$distance_nm) / 10) * 10)

  set.seed(2701)
  p_violin <- ggplot(violin_data, aes(x = x, y = distance_nm)) +
    geom_violin(
      aes(group = comparison),
      width = 0.58, trim = TRUE, scale = "width", adjust = 1.05,
      fill = "white", color = "#8A8E91", linewidth = 0.36
    ) +
    geom_jitter(
      width = 0.075, height = 0, shape = 21, size = 1.05,
      fill = "#B8BBBD", color = "#777B7E", stroke = 0.25, alpha = 0.72
    ) +
    geom_segment(
      data = violin_quartile_lines,
      aes(
        x = x, xend = xend,
        y = distance_nm, yend = distance_nm,
        linewidth = line_width
      ),
      inherit.aes = FALSE, color = "black",
      lineend = "round"
    ) +
    geom_point(
      data = violin_summary,
      aes(x = 1, y = mean),
      inherit.aes = FALSE, shape = 23, size = 1.9,
      fill = "#D12CE0", color = "#D12CE0", stroke = 0.25
    ) +
    annotate(
      "text", x = 1.18, y = violin_mean + 1.7,
      label = paste0("\u03bc=", sprintf("%.1f", violin_mean), " nm"), hjust = 0,
      family = "Arial", size = ICAT_TEXT_SMALL_MM * 0.85, color = "#7F858A"
    ) +
    annotate(
      "text", x = 0.68, y = violin_upper * 0.94,
      label = paste0("n=", violin_n), hjust = 0,
      family = "Arial", size = ICAT_TEXT_SMALL_MM * 0.80, color = "#333333"
    ) +
    scale_x_continuous(
      limits = c(0.62, 1.38),
      breaks = NULL
    ) +
    scale_linewidth_identity() +
    scale_y_continuous(
      limits = c(-1.5, violin_upper),
      breaks = seq(0, violin_upper, by = 10),
      expand = expansion(mult = c(0, 0.025))
    ) +
    labs(x = "Estimated distance between\nICAT and Conoid", y = "Distance (nm)") +
    icat_theme_classic(base_family = "Arial") +
    theme(
      axis.title.y = element_text(size = ICAT_FONT_BODY_PT, margin = margin(r = 2)),
      axis.title.x = element_text(size = ICAT_FONT_SMALL_PT, margin = margin(t = 2)),
      axis.text = element_text(size = ICAT_FONT_SMALL_PT, color = "black"),
      axis.text.x = element_blank(),
      axis.line = element_line(linewidth = ICAT_LINE_MM, color = "black"),
      axis.ticks = element_line(linewidth = ICAT_LINE_MM, color = "black"),
      axis.ticks.x = element_blank(),
      axis.ticks.length = unit(1.2, "mm"),
      plot.margin = margin(2.5, 4, 2, 2.5)
    )

  ggsave(
    file.path(figure_dir, "purple_signal_to_B2_distance.pdf"),
    p_focused, width = 7 / 2.54, height = 4.8 / 2.54,
    device = cairo_pdf, bg = "white"
  )
  ggsave(
    file.path(figure_dir, "purple_signal_to_B2_distance.png"),
    p_focused, width = 7 / 2.54, height = 4.8 / 2.54,
    dpi = 600, bg = "white"
  )
  ggsave(
    file.path(figure_dir, "purple_signal_to_B2_violin.pdf"),
    p_violin, width = 5 / 2.54, height = 2.7 / 2.54,
    device = cairo_pdf, bg = "white"
  )
  ggsave(
    file.path(figure_dir, "purple_signal_to_B2_violin.png"),
    p_violin, width = 5 / 2.54, height = 2.7 / 2.54,
    dpi = 600, bg = "white"
  )
  write.csv(
    distance_data,
    file.path(table_dir, "purple_signal_to_B2_distance_per_cell.csv"),
    row.names = FALSE
  )
  write.csv(
    focused_summary,
    file.path(table_dir, "purple_signal_to_B2_distance_summary.csv"),
    row.names = FALSE
  )
  write.csv(
    violin_summary,
    file.path(table_dir, "purple_signal_to_B2_violin_summary.csv"),
    row.names = FALSE
  )
  write.csv(
    focused_qc,
    file.path(table_dir, "purple_signal_to_B2_FWHM_QC.csv"),
    row.names = FALSE
  )

  cat("Focused Purple-to-B2 distance analysis complete.\n")
  cat("Group:", focused_group, "\n")
  cat("Height fraction:", focused_height_fraction, "\n")
  cat("Profiles:", nrow(distance_data), "\n")
  cat("Threshold surface gaps available:", focused_qc$n_surface_gap_available, "\n")
  print(focused_summary)
  quit(save = "no", status = 0)
}

# uExM-aware width-threshold sensitivity analysis for micronemes. The selected
# level is chosen only from WT-MIC2 by proximity of the median de-expanded
# width to the midpoint of the independently supplied 50-80 nm range.
uexm_expansion_factor <- 4.5
microneme_width_target_nm <- c(50, 80)
microneme_width_target_midpoint_nm <- mean(microneme_width_target_nm)
b2_width_target_nm <- c(20, 30)
b2_width_target_midpoint_nm <- mean(b2_width_target_nm)
candidate_height_fractions <- c(0.25, 0.50, 2 / 3, 0.75)
candidate_height_fraction_labels <- c("1/4", "1/2", "2/3", "3/4")
height_fraction_label <- function(value) {
  candidate_height_fraction_labels[
    which.min(abs(candidate_height_fractions - value))
  ]
}
threshold_rows <- list()

for (group_name in microneme_groups) {
  measurements <- inputs[[group_name]]$measurements
  profiles <- inputs[[group_name]]$profiles
  profile_split <- split(profiles, profiles$cell_id)

  for (i in seq_len(nrow(measurements))) {
    measurement <- measurements[i, , drop = FALSE]
    cell_profile <- profile_split[[measurement$cell_id]]
    if (is.null(cell_profile) || !nrow(cell_profile)) next

    green <- cell_profile[cell_profile$channel == "Green", , drop = FALSE]
    purple <- cell_profile[cell_profile$channel == "Purple", , drop = FALSE]
    icmt_center <- measurement$icmt_position_normalized
    purple_center <- measurement$purple_position_normalized
    if (!is.finite(icmt_center) || !is.finite(purple_center)) next

    green_max <- max(green$position_normalized, na.rm = TRUE)
    purple_min <- min(purple$position_normalized, na.rm = TRUE)
    purple_max <- max(purple$position_normalized, na.rm = TRUE)
    midpoint_icmt_b2 <- 0.5 * (icmt_center + 1)
    green_radius <- max(0.025, min(0.08, 0.35 * min(
      abs(icmt_center), abs(1 - icmt_center)
    )))

    for (height_fraction in candidate_height_fractions) {
      b2_width <- local_fwhm(
        green, 1, midpoint_icmt_b2, green_max,
        search_radius = green_radius,
        mirror_missing_edge = TRUE,
        height_fraction = height_fraction
      )
      microneme_width <- local_fwhm(
        purple, purple_center,
        max(purple_min, purple_center - 0.45),
        min(purple_max, purple_center + 0.45),
        search_radius = 0.10,
        height_fraction = height_fraction
      )
      gap <- surface_gap(microneme_width, b2_width)
      width_nm <- measurement$conoid_width_nm
      center_distance_normalized <- 1 - purple_center

      threshold_rows[[length(threshold_rows) + 1L]] <- data.frame(
        group = group_name,
        group_label = unname(group_labels[group_name]),
        cell_id = measurement$cell_id,
        height_fraction = height_fraction,
        height_fraction_label = height_fraction_label(height_fraction),
        uexm_expansion_factor = uexm_expansion_factor,
        conoid_width_expanded_nm = width_nm,
        center_distance_normalized = center_distance_normalized,
        center_distance_expanded_nm = center_distance_normalized * width_nm,
        center_distance_biological_nm = center_distance_normalized * width_nm /
          uexm_expansion_factor,
        microneme_width_normalized = microneme_width$width,
        microneme_width_expanded_nm = microneme_width$width * width_nm,
        microneme_width_biological_nm = microneme_width$width * width_nm /
          uexm_expansion_factor,
        microneme_left_normalized = microneme_width$left,
        microneme_right_normalized = microneme_width$right,
        microneme_width_status = microneme_width$status,
        b2_width_normalized = b2_width$width,
        b2_width_expanded_nm = b2_width$width * width_nm,
        b2_width_biological_nm = b2_width$width * width_nm /
          uexm_expansion_factor,
        b2_left_normalized = b2_width$left,
        b2_right_normalized = b2_width$right,
        b2_width_status = b2_width$status,
        raw_surface_gap_normalized = gap$raw_gap,
        surface_gap_normalized = gap$gap,
        surface_gap_expanded_nm = gap$gap * width_nm,
        surface_gap_biological_nm = gap$gap * width_nm /
          uexm_expansion_factor,
        intervals_overlap = gap$overlap,
        surface_gap_status = gap$status,
        included_surface_analysis = is.finite(center_distance_normalized) &&
          center_distance_normalized >= 0 && is.finite(gap$gap),
        stringsAsFactors = FALSE
      )
    }
  }
}

microneme_threshold_data <- do.call(rbind, threshold_rows)
rownames(microneme_threshold_data) <- NULL

threshold_comparison <- do.call(rbind, lapply(
  candidate_height_fractions,
  function(height_fraction) {
    z <- microneme_threshold_data[
      microneme_threshold_data$group == "WT-MIC2" &
        abs(microneme_threshold_data$height_fraction - height_fraction) < 1e-8,
      , drop = FALSE
    ]
    stats <- summarize_values(z$microneme_width_biological_nm)
    b2_stats <- summarize_values(z$b2_width_biological_nm)
    microneme_midpoint_error_scaled <- abs(
      stats$median - microneme_width_target_midpoint_nm
    ) / diff(microneme_width_target_nm) * 2
    b2_midpoint_error_scaled <- abs(
      b2_stats$median - b2_width_target_midpoint_nm
    ) / diff(b2_width_target_nm) * 2
    data.frame(
      height_fraction = height_fraction,
      height_fraction_label = height_fraction_label(height_fraction),
      n = stats$n,
      mean_width_expanded_nm = mean(z$microneme_width_expanded_nm, na.rm = TRUE),
      median_width_expanded_nm = median(z$microneme_width_expanded_nm, na.rm = TRUE),
      mean_width_biological_nm = stats$mean,
      median_width_biological_nm = stats$median,
      sd_width_biological_nm = stats$sd,
      q1_width_biological_nm = stats$q1,
      q3_width_biological_nm = stats$q3,
      percent_cells_in_50_80_nm = 100 * mean(
        z$microneme_width_biological_nm >= microneme_width_target_nm[1] &
          z$microneme_width_biological_nm <= microneme_width_target_nm[2],
        na.rm = TRUE
      ),
      mean_b2_width_biological_nm = b2_stats$mean,
      median_b2_width_biological_nm = b2_stats$median,
      percent_b2_in_20_30_nm = 100 * mean(
        z$b2_width_biological_nm >= b2_width_target_nm[1] &
          z$b2_width_biological_nm <= b2_width_target_nm[2],
        na.rm = TRUE
      ),
      microneme_midpoint_error_scaled = microneme_midpoint_error_scaled,
      b2_midpoint_error_scaled = b2_midpoint_error_scaled,
      joint_selection_score = microneme_midpoint_error_scaled +
        b2_midpoint_error_scaled,
      stringsAsFactors = FALSE
    )
  }
))
selected_height_fraction <- threshold_comparison$height_fraction[
  which.min(threshold_comparison$joint_selection_score)
]
threshold_comparison$selected <- abs(
  threshold_comparison$height_fraction - selected_height_fraction
) < 1e-8

height_fraction_file_tag <- function(value) {
  label <- height_fraction_label(value)
  if (label == "2/3") return("2over3")
  if (label == "3/4") return("3over4")
  gsub("[^0-9A-Za-z]+", "_", label)
}
threshold_result_fractions <- c(2 / 3, 0.75)

microneme_distance_data_for_fraction <- function(height_fraction) {
  z <- microneme_threshold_data[
    abs(microneme_threshold_data$height_fraction - height_fraction) < 1e-8,
    , drop = FALSE
  ]
  z$group_label <- factor(
    z$group_label,
    levels = unname(group_labels[microneme_groups])
  )
  z
}

summarize_microneme_distance_data <- function(dat, fraction_column_name) {
  out <- do.call(rbind, lapply(split(
    dat,
    paste(dat$height_fraction_label, dat$group, sep = "___")
  ), function(z) {
    width_stats <- summarize_values(z$microneme_width_biological_nm)
    gap_stats <- summarize_values(z$surface_gap_biological_nm)
    finite_gaps <- is.finite(z$surface_gap_biological_nm)
    data.frame(
      group = z$group[1],
      group_label = as.character(z$group_label[1]),
      height_fraction = z$height_fraction[1],
      height_fraction_label = z$height_fraction_label[1],
      n_width = width_stats$n,
      mean_microneme_width_biological_nm = width_stats$mean,
      median_microneme_width_biological_nm = width_stats$median,
      n_surface_gap = gap_stats$n,
      mean_surface_gap_biological_nm = gap_stats$mean,
      median_surface_gap_biological_nm = gap_stats$median,
      q1_surface_gap_biological_nm = gap_stats$q1,
      q3_surface_gap_biological_nm = gap_stats$q3,
      n_surface_gap_zero = sum(finite_gaps & z$surface_gap_biological_nm == 0),
      percent_surface_gap_zero = 100 * mean(
        z$surface_gap_biological_nm[finite_gaps] == 0
      ),
      stringsAsFactors = FALSE
    )
  }))
  names(out)[names(out) == "height_fraction"] <- fraction_column_name
  rownames(out) <- NULL
  out
}

microneme_selected_distance_data <- microneme_distance_data_for_fraction(
  selected_height_fraction
)
microneme_selected_distance_summary <- summarize_microneme_distance_data(
  microneme_selected_distance_data,
  "selected_height_fraction"
)
rownames(microneme_selected_distance_summary) <- NULL

microneme_threshold_result_data <- do.call(rbind, lapply(
  threshold_result_fractions,
  microneme_distance_data_for_fraction
))
rownames(microneme_threshold_result_data) <- NULL
microneme_threshold_result_summary <- summarize_microneme_distance_data(
  microneme_threshold_result_data,
  "height_fraction"
)

summary_rows <- list()
summary_metrics <- c(
  "center_distance_normalized", "center_distance_nm",
  "surface_gap_normalized", "surface_gap_nm",
  "structure_fwhm_width", "boundary_fwhm_width",
  "structure_fwhm_width_nm", "boundary_fwhm_width_nm"
)
for (relation_name in levels(distance_data$relation)) {
  for (group_name in unique(as.character(
    distance_data$group[distance_data$relation == relation_name]
  ))) {
    z <- distance_data[
      distance_data$relation == relation_name & distance_data$group == group_name,
      ,
      drop = FALSE
    ]
    for (metric in summary_metrics) {
      stats <- summarize_values(z[[metric]])
      summary_rows[[length(summary_rows) + 1L]] <- cbind(
        data.frame(
          relation = relation_name, group = group_name,
          group_label = unname(group_labels[group_name]), metric = metric,
          stringsAsFactors = FALSE
        ),
        stats
      )
    }
  }
}
distance_summary <- do.call(rbind, summary_rows)
rownames(distance_summary) <- NULL

microneme_width_summary <- do.call(rbind, lapply(split(
  distance_data[distance_data$relation == "Microneme to B2", , drop = FALSE],
  distance_data$group[distance_data$relation == "Microneme to B2"]
), function(z) {
  width_stats <- summarize_values(z$structure_fwhm_width_nm)
  finite_gaps <- is.finite(z$surface_gap_nm)
  zero_gaps <- finite_gaps & z$surface_gap_nm == 0
  data.frame(
    group = z$group[1],
    group_label = z$group_label[1],
    n_fwhm_width = width_stats$n,
    mean_fwhm_width_nm = width_stats$mean,
    median_fwhm_width_nm = width_stats$median,
    sd_fwhm_width_nm = width_stats$sd,
    q1_fwhm_width_nm = width_stats$q1,
    q3_fwhm_width_nm = width_stats$q3,
    ci95_low_fwhm_width_nm = width_stats$ci95_low,
    ci95_high_fwhm_width_nm = width_stats$ci95_high,
    mean_fwhm_width_normalized = mean(z$structure_fwhm_width, na.rm = TRUE),
    n_surface_gap_available = sum(finite_gaps),
    n_surface_gap_zero = sum(zero_gaps),
    percent_surface_gap_zero = if (any(finite_gaps)) {
      100 * sum(zero_gaps) / sum(finite_gaps)
    } else {
      NA_real_
    },
    stringsAsFactors = FALSE
  )
}))
rownames(microneme_width_summary) <- NULL

qc_summary <- do.call(rbind, lapply(split(
  distance_data,
  interaction(distance_data$relation, distance_data$group, drop = TRUE)
), function(z) {
  data.frame(
    relation = as.character(z$relation[1]),
    group = z$group[1],
    n_total = nrow(z),
    n_center_order_valid = sum(z$center_ordering_valid),
    n_surface_gap_available = sum(z$included_surface_analysis),
    n_fwhm_overlap = sum(z$fwhm_intervals_overlap %in% TRUE, na.rm = TRUE),
    n_overlap_zero_assigned = sum(z$overlap_zero_assigned),
    n_surface_unresolved = sum(!is.finite(z$surface_gap_normalized)),
    surface_success_rate = mean(z$included_surface_analysis),
    stringsAsFactors = FALSE
  )
}))
rownames(qc_summary) <- NULL

primary_data <- rbind(
  distance_data[
    distance_data$relation == "ICMTs to B1" &
      distance_data$group %in% primary_groups,
    ,
    drop = FALSE
  ],
  distance_data[
    distance_data$relation == "Rhoptry to B1" & distance_data$group == "ARO",
    ,
    drop = FALSE
  ],
  distance_data[
    distance_data$relation == "Microneme to B2" &
      distance_data$group == "WT-MIC2",
    ,
    drop = FALSE
  ]
)

primary_data$display_relation <- ifelse(
  primary_data$relation == "ICMTs to B1",
  "ICMTs - B1\n(ARO + WT)",
  ifelse(
    primary_data$relation == "Rhoptry to B1",
    "Rhoptry - B1\n(ARO)",
    "Microneme - B2\n(WT)"
  )
)
primary_relation_levels <- c(
  "ICMTs - B1\n(ARO + WT)",
  "Rhoptry - B1\n(ARO)",
  "Microneme - B2\n(WT)"
)
primary_data$display_relation <- factor(
  primary_data$display_relation, levels = primary_relation_levels
)

asymmetry_test <- function(values, alternative, structure, source) {
  values <- values[is.finite(values)]
  tt <- t.test(values, mu = 0.5, alternative = alternative)
  wt <- suppressWarnings(wilcox.test(
    values, mu = 0.5, alternative = alternative, exact = FALSE
  ))
  data.frame(
    structure = structure,
    source = source,
    n = length(values),
    mean_peak_position = mean(values),
    expected_boundary = if (alternative == "less") "B1" else "B2",
    alternative = if (alternative == "less") "position < 0.5" else "position > 0.5",
    t_statistic = unname(tt$statistic),
    t_df = unname(tt$parameter),
    t_p_value_one_sided = tt$p.value,
    wilcoxon_statistic = unname(wt$statistic),
    wilcoxon_p_value_one_sided = wt$p.value,
    stringsAsFactors = FALSE
  )
}

asymmetry_tests <- rbind(
  asymmetry_test(
    primary_data$structure_expected_center[primary_data$structure == "ICMTs"],
    "less", "ICMTs", "ARO + WT-MIC2"
  ),
  asymmetry_test(
    primary_data$structure_expected_center[primary_data$structure == "Rhoptry"],
    "less", "Rhoptry", "ARO"
  ),
  asymmetry_test(
    primary_data$structure_expected_center[primary_data$structure == "Microneme"],
    "greater", "Microneme", "WT-MIC2"
  )
)

zone_separation_test <- function(left_values, right_values, comparison) {
  left_values <- left_values[is.finite(left_values)]
  right_values <- right_values[is.finite(right_values)]
  tt <- t.test(right_values, left_values, alternative = "two.sided")
  wt <- suppressWarnings(wilcox.test(
    right_values, left_values, alternative = "two.sided", exact = FALSE
  ))
  data.frame(
    comparison = comparison,
    n_left = length(left_values),
    n_right = length(right_values),
    mean_left_position = mean(left_values),
    mean_right_position = mean(right_values),
    mean_separation_normalized = mean(right_values) - mean(left_values),
    separation_ci95_low = unname(tt$conf.int[1]),
    separation_ci95_high = unname(tt$conf.int[2]),
    welch_t_statistic = unname(tt$statistic),
    welch_df = unname(tt$parameter),
    welch_p_value = tt$p.value,
    wilcoxon_statistic = unname(wt$statistic),
    wilcoxon_p_value = wt$p.value,
    stringsAsFactors = FALSE
  )
}

primary_microneme_positions <- primary_data$structure_expected_center[
  primary_data$structure == "Microneme"
]
zone_separation_tests <- rbind(
  zone_separation_test(
    primary_data$structure_expected_center[primary_data$structure == "Rhoptry"],
    primary_microneme_positions,
    "Rhoptry (ARO) vs Microneme (WT)"
  ),
  zone_separation_test(
    primary_data$structure_expected_center[primary_data$structure == "ICMTs"],
    primary_microneme_positions,
    "ICMTs (ARO + WT) vs Microneme (WT)"
  )
)

map_data <- distance_data[
  (distance_data$relation == "ICMTs to B1" &
     distance_data$group %in% primary_groups) |
    distance_data$relation == "Rhoptry to B1" |
    distance_data$relation == "Microneme to B2",
  ,
  drop = FALSE
]
map_data$display_row <- ifelse(
  map_data$structure == "ICMTs", "ICMTs (ARO + WT)",
  ifelse(
    map_data$structure == "Rhoptry", "Rhoptry (ARO)",
    paste0("Microneme (", unname(group_labels[map_data$group]), ")")
  )
)
map_levels <- c(
  "ICMTs (ARO + WT)", "Rhoptry (ARO)", "Microneme (WT)",
  "Microneme (ICMAP1 KO)", "Microneme (ICMAP2 KO)", "Microneme (ARO KO)"
)
map_data$display_row <- factor(map_data$display_row, levels = rev(map_levels))
map_data$row_number <- as.numeric(map_data$display_row)
set.seed(2701)
map_data$row_jitter <- map_data$row_number + runif(nrow(map_data), -0.13, 0.13)

map_summary <- do.call(rbind, lapply(split(map_data, map_data$display_row), function(z) {
  stats <- summarize_values(z$structure_expected_center)
  data.frame(
    display_row = z$display_row[1],
    row_number = z$row_number[1],
    structure = z$structure[1],
    mean_center = stats$mean,
    ci95_low = stats$ci95_low,
    ci95_high = stats$ci95_high,
    mean_left = mean(z$structure_fwhm_left, na.rm = TRUE),
    mean_right = mean(z$structure_fwhm_right, na.rm = TRUE),
    n = stats$n,
    stringsAsFactors = FALSE
  )
}))
rownames(map_summary) <- NULL

theme_distance <- icat_theme_classic() +
  theme(
    plot.title = element_text(face = "bold", size = ICAT_FONT_TITLE_PT),
    plot.subtitle = element_text(color = "#444444"),
    axis.text.y = element_text(face = "bold"),
    legend.position = "top",
    plot.margin = margin(10, 16, 10, 10)
  )

p_map <- ggplot() +
  geom_vline(xintercept = c(0, 1), color = "#222222", linewidth = 0.65) +
  geom_vline(xintercept = 0.5, color = "#777777", linetype = "dashed", linewidth = 0.45) +
  geom_segment(
    data = map_data[
      is.finite(map_data$structure_fwhm_left) &
        is.finite(map_data$structure_fwhm_right),
      ,
      drop = FALSE
    ],
    aes(
      x = structure_fwhm_left, xend = structure_fwhm_right,
      y = row_jitter, yend = row_jitter, color = structure
    ),
    alpha = 0.22, linewidth = 0.75
  ) +
  geom_point(
    data = map_data,
    aes(x = structure_expected_center, y = row_jitter, color = structure),
    alpha = 0.30, size = 1.6
  ) +
  geom_segment(
    data = map_summary,
    aes(
      x = mean_left, xend = mean_right,
      y = row_number, yend = row_number, color = structure
    ),
    linewidth = 2.3
  ) +
  geom_errorbar(
    data = map_summary,
    aes(
      x = mean_center, ymin = row_number - 0.13, ymax = row_number + 0.13,
      color = structure
    ),
    width = 0, linewidth = ICAT_LINE_MM
  ) +
  geom_point(
    data = map_summary,
    aes(x = mean_center, y = row_number, color = structure),
    shape = 18, size = 4
  ) +
  annotate("text", x = 0, y = length(map_levels) + 0.45, label = "B1",
           fontface = "bold", size = ICAT_TEXT_TITLE_MM) +
  annotate("text", x = 1, y = length(map_levels) + 0.45, label = "B2",
           fontface = "bold", size = ICAT_TEXT_TITLE_MM) +
  scale_color_manual(values = structure_colors) +
  scale_x_continuous(
    breaks = seq(0, 1, 0.25), labels = sprintf("%.2f", seq(0, 1, 0.25)),
    expand = expansion(mult = 0)
  ) +
  scale_y_continuous(
    breaks = seq_along(levels(map_data$display_row)),
    labels = levels(map_data$display_row)
  ) +
  coord_cartesian(xlim = c(0, 1), ylim = c(0.55, length(map_levels) + 0.55), clip = "off") +
  labs(
    title = "Rhoptry and microneme occupy opposite sides of the conoid",
    subtitle = "Light segments are cell FWHM intervals; diamonds and thick segments are mean peak and mean FWHM",
    x = "Normalized position across B1-B2",
    y = NULL,
    color = NULL
  ) +
  theme_distance

p_gap <- ggplot(
  primary_data[primary_data$included_surface_analysis, , drop = FALSE],
  aes(x = surface_gap_nm, y = display_relation, color = structure, fill = structure)
) +
  geom_violin(scale = "width", trim = FALSE, alpha = 0.12, color = NA) +
  geom_boxplot(width = 0.18, outlier.shape = NA, alpha = 0.32, linewidth = 0.55) +
  geom_jitter(height = 0.08, width = 0, alpha = 0.42, size = 1.6) +
  stat_summary(fun = mean, geom = "point", shape = 18, size = 4, color = "black") +
  scale_color_manual(values = structure_colors) +
  scale_fill_manual(values = structure_colors) +
  scale_x_continuous(expand = expansion(mult = c(0.02, 0.08))) +
  labs(
    title = "FWHM surface-to-surface distances",
    subtitle = "Zero indicates overlapping local-FWHM intervals; black diamonds show means",
    x = "Surface gap (nm)",
    y = NULL,
    color = NULL,
    fill = NULL
  ) +
  theme_distance +
  theme(legend.position = "none")

paired_method <- rbind(
  data.frame(
    primary_data[c("group", "cell_id", "display_relation", "structure")],
    method = "Peak centers",
    distance_nm = primary_data$center_distance_nm,
    stringsAsFactors = FALSE
  ),
  data.frame(
    primary_data[c("group", "cell_id", "display_relation", "structure")],
    method = "FWHM surfaces",
    distance_nm = primary_data$surface_gap_nm,
    stringsAsFactors = FALSE
  )
)
paired_method <- paired_method[is.finite(paired_method$distance_nm), , drop = FALSE]
paired_method$method <- factor(
  paired_method$method, levels = c("Peak centers", "FWHM surfaces")
)

p_method <- ggplot(
  paired_method,
  aes(x = method, y = distance_nm, group = interaction(group, cell_id))
) +
  geom_line(color = "#A5A5A5", alpha = 0.28, linewidth = 0.45) +
  geom_point(aes(color = structure), alpha = 0.38, size = 1.5) +
  stat_summary(
    aes(group = 1), fun = mean, geom = "line",
    color = "black", linewidth = 1.0
  ) +
  stat_summary(
    aes(group = 1), fun = mean, geom = "point",
    color = "black", shape = 18, size = 3.8
  ) +
  facet_wrap(~display_relation, scales = "free_y", nrow = 1) +
  scale_color_manual(values = structure_colors) +
  labs(
    title = "FWHM correction avoids overestimating structural separation",
    subtitle = "Gray lines connect the peak-center and surface-gap estimates for each cell",
    x = NULL,
    y = "Distance (nm)",
    color = NULL
  ) +
  icat_theme_classic() +
  theme(
    legend.position = "none",
    plot.title = element_text(face = "bold", size = ICAT_FONT_TITLE_PT),
    strip.text = element_text(face = "bold"),
    axis.text.x = element_text(angle = 20, hjust = 1)
  )

microneme_data <- distance_data[
  distance_data$relation == "Microneme to B2" &
    distance_data$included_surface_analysis,
  ,
  drop = FALSE
]
microneme_data$group_label <- factor(
  microneme_data$group_label,
  levels = unname(group_labels[microneme_groups])
)

p_mutants <- ggplot(
  microneme_data,
  aes(x = surface_gap_normalized, y = group_label, color = group, fill = group)
) +
  geom_violin(scale = "width", trim = FALSE, alpha = 0.12, color = NA) +
  geom_boxplot(width = 0.18, outlier.shape = NA, alpha = 0.30, linewidth = 0.55) +
  geom_jitter(height = 0.08, width = 0, alpha = 0.42, size = 1.6) +
  stat_summary(fun = mean, geom = "point", shape = 18, size = 4, color = "black") +
  scale_color_manual(values = group_colors) +
  scale_fill_manual(values = group_colors) +
  labs(
    title = "Microneme-to-B2 surface gaps in WT and mutants",
    subtitle = "Mutants are supplementary; WT-MIC2 is the primary microneme dataset",
    x = "FWHM surface gap to B2 (normalized B1-B2 units)",
    y = NULL,
    color = NULL,
    fill = NULL
  ) +
  theme_distance +
  theme(legend.position = "none")

threshold_plot_source <- microneme_threshold_data[
  microneme_threshold_data$group == "WT-MIC2",
  , drop = FALSE
]
threshold_plot_data <- rbind(
  data.frame(
    cell_id = threshold_plot_source$cell_id,
    height_fraction = threshold_plot_source$height_fraction,
    height_fraction_label = threshold_plot_source$height_fraction_label,
    structure = "Microneme",
    width_biological_nm = threshold_plot_source$microneme_width_biological_nm
  ),
  data.frame(
    cell_id = threshold_plot_source$cell_id,
    height_fraction = threshold_plot_source$height_fraction,
    height_fraction_label = threshold_plot_source$height_fraction_label,
    structure = "B2",
    width_biological_nm = threshold_plot_source$b2_width_biological_nm
  )
)
threshold_plot_data$fraction_index <- match(
  threshold_plot_data$height_fraction_label,
  candidate_height_fraction_labels
)
threshold_plot_data$structure <- factor(
  threshold_plot_data$structure, levels = c("Microneme", "B2")
)
target_bands <- data.frame(
  structure = factor(c("Microneme", "B2"), levels = c("Microneme", "B2")),
  ymin = c(microneme_width_target_nm[1], b2_width_target_nm[1]),
  ymax = c(microneme_width_target_nm[2], b2_width_target_nm[2])
)
selected_fraction_index <- which.min(
  abs(candidate_height_fractions - selected_height_fraction)
)

p_threshold_selection <- ggplot(
  threshold_plot_data,
  aes(x = fraction_index, y = width_biological_nm)
) +
  geom_rect(
    data = target_bands,
    aes(xmin = 0.5, xmax = 4.5, ymin = ymin, ymax = ymax),
    inherit.aes = FALSE, fill = "#DDEFE3", alpha = 0.75
  ) +
  annotate(
    "rect",
    xmin = selected_fraction_index - 0.18,
    xmax = selected_fraction_index + 0.18,
    ymin = -Inf, ymax = Inf,
    fill = "#F1C75B", alpha = 0.16
  ) +
  geom_jitter(width = 0.08, height = 0, alpha = 0.24, size = 1.2, color = "#4A4A4A") +
  stat_summary(fun = median, geom = "line", aes(group = 1), linewidth = 0.75,
               color = "#222222") +
  stat_summary(fun = median, geom = "point", shape = 18, size = 3.5,
               color = "#222222") +
  facet_wrap(~structure, scales = "free_y", nrow = 1) +
  scale_x_continuous(
    breaks = seq_along(candidate_height_fraction_labels),
    labels = candidate_height_fraction_labels,
    limits = c(0.5, 4.5)
  ) +
  labs(
    title = "Peak-height threshold selection using known uExM widths",
    subtitle = paste0(
      "Green bands: microneme 50-80 nm and B2 20-30 nm; selected level = ",
      height_fraction_label(selected_height_fraction)
    ),
    x = "Fraction of local peak height",
    y = "Estimated biological width (nm; expanded measurement / 4.5)"
  ) +
  icat_theme_classic() +
  theme(
    plot.title = element_text(face = "bold", size = ICAT_FONT_TITLE_PT),
    strip.text = element_text(face = "bold"),
    axis.title = element_text(face = "bold")
  )

make_microneme_threshold_gap_plot <- function(plot_data, height_fraction, subtitle_suffix) {
  quartile_data <- do.call(rbind, lapply(split(
    plot_data[plot_data$included_surface_analysis, , drop = FALSE],
    plot_data$group[plot_data$included_surface_analysis]
  ), function(z) {
    qs <- quantile(z$surface_gap_biological_nm, probs = c(0.25, 0.75), na.rm = TRUE)
    data.frame(
      group = z$group[1],
      group_label = z$group_label[1],
      quartile = c("Q1", "Q3"),
      surface_gap_biological_nm = as.numeric(qs),
      stringsAsFactors = FALSE
    )
  }))
  ggplot(
    plot_data[
      plot_data$included_surface_analysis,
      , drop = FALSE
    ],
    aes(
      x = surface_gap_biological_nm,
      y = group_label,
      color = group,
      fill = group
    )
  ) +
    geom_violin(scale = "width", trim = TRUE, alpha = 0.12, color = NA) +
    geom_boxplot(width = 0.18, outlier.shape = NA, alpha = 0.30, linewidth = 0.55) +
    geom_point(
      data = quartile_data,
      aes(x = surface_gap_biological_nm, y = group_label),
      inherit.aes = FALSE,
      shape = "|", size = 6.2, stroke = 1.0, color = "#202020"
    ) +
    geom_jitter(height = 0.08, width = 0, alpha = 0.45, size = 1.6) +
    stat_summary(fun = mean, geom = "point", shape = 18, size = 4, color = "black") +
    scale_color_manual(values = group_colors) +
    scale_fill_manual(values = group_colors) +
    scale_x_continuous(limits = c(0, NA), expand = expansion(mult = c(0, 0.06))) +
    labs(
      title = "Microneme-to-B2 surface distance after width calibration",
      subtitle = paste0(
        "Local ", height_fraction_label(height_fraction),
        "-maximum boundaries ", subtitle_suffix
      ),
      x = "Estimated biological surface gap (nm; expanded measurement / 4.5)",
      y = NULL,
      color = NULL,
      fill = NULL
    ) +
    theme_distance +
    theme(legend.position = "none")
}

p_selected_gap <- make_microneme_threshold_gap_plot(
  microneme_selected_distance_data,
  selected_height_fraction,
  "selected from WT width targets"
)

threshold_result_gap_plots <- setNames(lapply(threshold_result_fractions, function(x) {
  make_microneme_threshold_gap_plot(
    microneme_distance_data_for_fraction(x),
    x,
    "shown for threshold sensitivity"
  )
}), vapply(threshold_result_fractions, height_fraction_file_tag, character(1)))

threshold_comparison_plot_data <- microneme_threshold_result_data[
  microneme_threshold_result_data$included_surface_analysis,
  , drop = FALSE
]
threshold_comparison_plot_data$height_fraction_label <- factor(
  threshold_comparison_plot_data$height_fraction_label,
  levels = c("2/3", "3/4")
)
threshold_comparison_quartile_data <- do.call(rbind, lapply(split(
  threshold_comparison_plot_data,
  paste(
    threshold_comparison_plot_data$height_fraction_label,
    threshold_comparison_plot_data$group,
    sep = "___"
  )
), function(z) {
  qs <- quantile(z$surface_gap_biological_nm, probs = c(0.25, 0.75), na.rm = TRUE)
  data.frame(
    group = z$group[1],
    group_label = z$group_label[1],
    height_fraction_label = z$height_fraction_label[1],
    quartile = c("Q1", "Q3"),
    surface_gap_biological_nm = as.numeric(qs),
    stringsAsFactors = FALSE
  )
}))
threshold_comparison_quartile_data$height_fraction_label <- factor(
  threshold_comparison_quartile_data$height_fraction_label,
  levels = c("2/3", "3/4")
)
p_threshold_gap_comparison <- ggplot(
  threshold_comparison_plot_data,
  aes(
    x = surface_gap_biological_nm,
    y = group_label,
    color = group,
    fill = group
  )
) +
  geom_violin(scale = "width", trim = TRUE, alpha = 0.12, color = NA) +
  geom_boxplot(width = 0.18, outlier.shape = NA, alpha = 0.30, linewidth = 0.55) +
  geom_point(
    data = threshold_comparison_quartile_data,
    aes(x = surface_gap_biological_nm, y = group_label),
    inherit.aes = FALSE,
    shape = "|", size = 5.6, stroke = 0.95, color = "#202020"
  ) +
  geom_jitter(height = 0.08, width = 0, alpha = 0.42, size = 1.3) +
  stat_summary(fun = mean, geom = "point", shape = 18, size = 3.4, color = "black") +
  facet_wrap(~height_fraction_label, nrow = 1) +
  scale_color_manual(values = group_colors) +
  scale_fill_manual(values = group_colors) +
  scale_x_continuous(limits = c(0, NA), expand = expansion(mult = c(0, 0.06))) +
  labs(
    title = "Threshold sensitivity of microneme-to-B2 surface distance",
    subtitle = "Same line profiles quantified at local 2/3- and 3/4-maximum boundaries",
    x = "Estimated biological surface gap (nm; expanded measurement / 4.5)",
    y = NULL,
    color = NULL,
    fill = NULL
  ) +
  theme_distance +
  theme(legend.position = "none")

# Compact source-resolved distance display.
compact_data <- distance_data[
  distance_data$included_surface_analysis,
  ,
  drop = FALSE
]
compact_data$display_group <- ifelse(
  compact_data$structure == "ICMTs",
  paste0("ICMTs (", ifelse(compact_data$group == "WT-MIC2", "WT", "ARO"), ")"),
  ifelse(
    compact_data$structure == "Rhoptry",
    "Rhoptry (ARO)",
    paste0("Microneme (", unname(group_labels[compact_data$group]), ")")
  )
)
compact_levels <- names(display_group_colors)
compact_data$display_group <- factor(
  compact_data$display_group, levels = rev(compact_levels)
)
compact_data$boundary_side <- factor(
  ifelse(compact_data$boundary == "B1", "B1-facing structures", "B2-facing structures"),
  levels = c("B1-facing structures", "B2-facing structures")
)

p_compact <- ggplot(
  compact_data,
  aes(x = surface_gap_nm, y = display_group, color = display_group)
) +
  geom_boxplot(
    width = 0.20, outlier.shape = NA, fill = "white",
    alpha = 0.75, linewidth = 0.55
  ) +
  geom_jitter(height = 0.10, width = 0, alpha = 0.58, size = 1.8) +
  stat_summary(fun = mean, geom = "point", shape = 18, size = 3.8, color = "black") +
  facet_grid(boundary_side ~ ., scales = "free_y", space = "free_y") +
  scale_color_manual(values = display_group_colors, drop = FALSE) +
  scale_x_continuous(expand = expansion(mult = c(0.02, 0.08))) +
  labs(
    title = "Structure-to-boundary surface distances",
    subtitle = "Points are cells; black diamonds are group means",
    x = "Local-FWHM surface gap (nm)",
    y = NULL,
    color = NULL
  ) +
  theme_distance +
  theme(
    legend.position = "none",
    strip.background = element_rect(fill = "#F2F2F2", color = NA),
    strip.text = element_text(face = "bold")
  )

# Circular cross-section schematic. Horizontal position is measured; point
# jitter and half-violin height are display encodings rather than spatial axes.
circle_data <- distance_data
circle_data$display_group <- ifelse(
  circle_data$structure == "ICMTs",
  paste0("ICMTs (", ifelse(circle_data$group == "WT-MIC2", "WT", "ARO"), ")"),
  ifelse(
    circle_data$structure == "Rhoptry",
    "Rhoptry (ARO)",
    paste0("Microneme (", unname(group_labels[circle_data$group]), ")")
  )
)
circle_data$display_group <- factor(circle_data$display_group, levels = compact_levels)
circle_data$x_position <- 2 * (circle_data$structure_expected_center - 0.5)
set.seed(2702)
circle_data$y_display <- 0.16 + runif(nrow(circle_data), -0.045, 0.045)

density_base <- 0.29
density_height <- 0.25
density_rows <- lapply(split(circle_data, circle_data$display_group), function(z) {
  values <- z$x_position[is.finite(z$x_position)]
  if (length(values) < 2L) return(NULL)
  spread <- max(diff(range(values)), 0.06)
  den <- density(
    values,
    from = max(-1, min(values) - 0.20 * spread),
    to = min(1, max(values) + 0.20 * spread),
    n = 220
  )
  data.frame(
    display_group = z$display_group[1],
    x = den$x,
    y_top = density_base + density_height * den$y / max(den$y),
    stringsAsFactors = FALSE
  )
})
density_data <- do.call(rbind, density_rows)
density_data$display_group <- factor(density_data$display_group, levels = compact_levels)

axis_ticks <- data.frame(
  x = seq(-1, 1, 0.5),
  label = sprintf("%.2f", seq(0, 1, 0.25))
)

left_theta <- seq(pi / 2, 3 * pi / 2, length.out = 240)
right_theta <- seq(-pi / 2, pi / 2, length.out = 240)
left_half <- data.frame(
  x = c(0, cos(left_theta), 0),
  y = c(0, sin(left_theta), 0)
)
right_half <- data.frame(
  x = c(0, cos(right_theta), 0),
  y = c(0, sin(right_theta), 0)
)
circle_outline <- data.frame(
  x = cos(seq(0, 2 * pi, length.out = 361)),
  y = sin(seq(0, 2 * pi, length.out = 361))
)

p_circle <- ggplot() +
  geom_polygon(data = left_half, aes(x = x, y = y), fill = "#FCE9E6", color = NA) +
  geom_polygon(data = right_half, aes(x = x, y = y), fill = "#F7E6FA", color = NA) +
  geom_path(data = circle_outline, aes(x = x, y = y), color = "#222222", linewidth = 0.9) +
  geom_segment(
    aes(x = 0, xend = 0, y = -0.98, yend = 0.98),
    color = "#777777", linewidth = 0.45, linetype = "dashed"
  ) +
  geom_segment(
    aes(x = -1, xend = 1, y = 0, yend = 0),
    color = "#222222", linewidth = 0.75
  ) +
  geom_segment(
    data = axis_ticks,
    aes(x = x, xend = x, y = -0.025, yend = 0.025),
    color = "#222222", linewidth = 0.55
  ) +
  geom_text(
    data = axis_ticks,
    aes(x = x, y = -0.075, label = label),
    size = ICAT_TEXT_BODY_MM, color = "#222222"
  ) +
  geom_ribbon(
    data = density_data,
    aes(
      x = x, ymin = density_base, ymax = y_top,
      fill = display_group, group = display_group
    ),
    alpha = 0.10, color = NA
  ) +
  geom_line(
    data = density_data,
    aes(x = x, y = y_top, color = display_group, group = display_group),
    linewidth = 0.75, alpha = 0.90
  ) +
  geom_point(
    data = circle_data,
    aes(x = x_position, y = y_display, color = display_group, shape = structure),
    size = 2.1, alpha = 0.68
  ) +
  annotate("text", x = -0.56, y = 0.72, label = "B1-facing\nrhoptry zone",
           color = "#9E2F3F", fontface = "bold", size = ICAT_TEXT_TITLE_MM) +
  annotate("text", x = 0.56, y = 0.72, label = "B2-facing\nmicroneme zone",
           color = "#8A128F", fontface = "bold", size = ICAT_TEXT_TITLE_MM) +
  annotate("text", x = -0.94, y = 0.075, label = "B1", fontface = "bold", size = ICAT_TEXT_TITLE_MM) +
  annotate("text", x = 0.94, y = 0.075, label = "B2", fontface = "bold", size = ICAT_TEXT_TITLE_MM) +
  annotate("text", x = 0, y = -0.19, label = "Normalized position along B1-B2",
           fontface = "bold", size = ICAT_TEXT_BODY_MM) +
  scale_color_manual(values = display_group_colors, drop = FALSE) +
  scale_fill_manual(values = display_group_colors, drop = FALSE) +
  scale_shape_manual(values = c("ICMTs" = 16, "Rhoptry" = 17, "Microneme" = 15)) +
  coord_equal(xlim = c(-1.20, 1.20), ylim = c(-1.14, 1.14), clip = "off") +
  labs(
    title = "Spatially separated secretion zones within the conoid",
    subtitle = "Points show cells; upper half-violins show source-specific position densities",
    x = NULL,
    y = NULL,
    color = NULL,
    shape = NULL,
    caption = "Point jitter is display-only; half-violin height represents relative density."
  ) +
  theme_void(base_size = ICAT_FONT_BODY_PT) +
  theme(
    plot.title = element_text(face = "bold", size = ICAT_FONT_TITLE_PT),
    plot.subtitle = element_text(color = "#444444", size = ICAT_FONT_SMALL_PT),
    plot.caption = element_text(color = "#555555", hjust = 0, size = ICAT_FONT_SMALL_PT),
    legend.position = "bottom",
    legend.box = "vertical",
    legend.text = element_text(size = 9),
    plot.margin = margin(12, 20, 10, 20)
  ) +
  guides(
    color = guide_legend(ncol = 3, order = 1, override.aes = list(shape = 16)),
    shape = guide_legend(nrow = 1, order = 2),
    fill = "none"
  )

# Data-driven transition figure for the following regulatory-factor panel.
regulatory_data <- rbind(
  transform(
    distance_data[
      distance_data$structure == "Rhoptry" & distance_data$group == "ARO",
      , drop = FALSE
    ],
    regulatory_group = "Rhoptry (ARO)", panel_side = "above"
  ),
  transform(
    distance_data[
      distance_data$structure == "Microneme" & distance_data$group == "WT-MIC2",
      , drop = FALSE
    ],
    regulatory_group = "Microneme (WT)", panel_side = "above"
  ),
  transform(
    distance_data[distance_data$structure == "ICMTs", , drop = FALSE],
    regulatory_group = "ICMTs (ARO + WT)", panel_side = "below"
  ),
  transform(
    distance_data[
      distance_data$structure == "Microneme" &
        distance_data$group %in% c("ICMAP1-MIC2", "ICMAP2-MIC2", "ARO-MIC2"),
      , drop = FALSE
    ],
    regulatory_group = paste0(
      "Microneme (", unname(group_labels[group]), ")"
    ),
    panel_side = "below"
  )
)
regulatory_levels <- c(
  "Rhoptry (ARO)", "Microneme (WT)", "ICMTs (ARO + WT)",
  "Microneme (ICMAP1 KO)", "Microneme (ICMAP2 KO)", "Microneme (ARO KO)"
)
regulatory_colors <- c(
  "Rhoptry (ARO)" = display_group_colors[["Rhoptry (ARO)"]],
  "Microneme (WT)" = display_group_colors[["Microneme (WT)"]],
  "ICMTs (ARO + WT)" = structure_colors[["ICMTs"]],
  "Microneme (ICMAP1 KO)" = display_group_colors[["Microneme (ICMAP1 KO)"]],
  "Microneme (ICMAP2 KO)" = display_group_colors[["Microneme (ICMAP2 KO)"]],
  "Microneme (ARO KO)" = display_group_colors[["Microneme (ARO KO)"]]
)
regulatory_data$regulatory_group <- factor(
  regulatory_data$regulatory_group, levels = regulatory_levels
)
regulatory_data$x_position <- regulatory_data$structure_expected_center
set.seed(2703)
regulatory_data$y_display <- ifelse(
  regulatory_data$panel_side == "above", 0.22, -0.22
) + runif(nrow(regulatory_data), -0.035, 0.035)

make_directional_density <- function(z) {
  values <- z$x_position[is.finite(z$x_position)]
  if (length(values) < 2L) return(NULL)
  spread <- max(diff(range(values)), 0.03)
  den <- density(
    values,
    from = max(0, min(values) - 0.20 * spread),
    to = min(1, max(values) + 0.20 * spread),
    n = 220
  )
  above <- z$panel_side[1] == "above"
  baseline <- if (above) 0.31 else -0.31
  extent <- 0.18 * den$y / max(den$y)
  data.frame(
    regulatory_group = z$regulatory_group[1],
    x = den$x,
    y_base = baseline,
    y_edge = baseline + if (above) extent else -extent,
    stringsAsFactors = FALSE
  )
}
regulatory_density <- do.call(
  rbind,
  lapply(split(regulatory_data, regulatory_data$regulatory_group), make_directional_density)
)
regulatory_density$regulatory_group <- factor(
  regulatory_density$regulatory_group, levels = regulatory_levels
)
regulatory_ticks <- data.frame(
  x = seq(0, 1, 0.25),
  label = sprintf("%.2f", seq(0, 1, 0.25))
)

p_regulatory <- ggplot() +
  annotate("rect", xmin = 0, xmax = 0.5, ymin = -0.72, ymax = 0.72,
           fill = "#FCE9E6", alpha = 0.55) +
  annotate("rect", xmin = 0.5, xmax = 1, ymin = -0.72, ymax = 0.72,
           fill = "#F7E6FA", alpha = 0.55) +
  geom_segment(
    aes(x = 0, xend = 1, y = 0, yend = 0),
    color = "#222222", linewidth = 0.8
  ) +
  geom_segment(
    aes(x = 0.5, xend = 0.5, y = -0.70, yend = 0.70),
    color = "#777777", linetype = "dashed", linewidth = 0.5
  ) +
  geom_segment(
    data = regulatory_ticks,
    aes(x = x, xend = x, y = -0.018, yend = 0.018),
    color = "#222222", linewidth = 0.55
  ) +
  geom_text(
    data = regulatory_ticks,
    aes(x = x, y = -0.055, label = label),
    size = ICAT_TEXT_BODY_MM, color = "#222222", vjust = 1
  ) +
  geom_ribbon(
    data = regulatory_density,
    aes(
      x = x, ymin = pmin(y_base, y_edge), ymax = pmax(y_base, y_edge),
      fill = regulatory_group, group = regulatory_group
    ),
    alpha = 0.10, color = NA
  ) +
  geom_line(
    data = regulatory_density,
    aes(x = x, y = y_edge, color = regulatory_group, group = regulatory_group),
    linewidth = 0.8
  ) +
  geom_point(
    data = regulatory_data,
    aes(x = x_position, y = y_display, color = regulatory_group, shape = structure),
    size = 2.0, alpha = 0.64
  ) +
  annotate(
    "segment", x = 0.31, xend = 0.35, y = -0.17, yend = 0.17,
    color = "#356859", linewidth = 0.8,
    arrow = grid::arrow(length = grid::unit(0.16, "cm"))
  ) +
  annotate(
    "text", x = 0.16, y = 0.095,
    label = "Known ICMT-dependent\nrhoptry positioning",
    color = "#356859", fontface = "bold", size = ICAT_TEXT_BODY_MM
  ) +
  annotate(
    "segment", x = 0.72, xend = 0.69, y = -0.17, yend = 0.17,
    color = "#8A128F", linewidth = 0.8, linetype = "dashed",
    arrow = grid::arrow(length = grid::unit(0.16, "cm"))
  ) +
  annotate(
    "text", x = 0.86, y = 0.095,
    label = "Additional conoid\nregulator(s)?",
    color = "#8A128F", fontface = "bold", size = ICAT_TEXT_BODY_MM
  ) +
  annotate("text", x = 0.02, y = 0.66, label = "SECRETORY ORGANELLES",
           hjust = 0, fontface = "bold", color = "#333333", size = ICAT_TEXT_TITLE_MM) +
  annotate("text", x = 0.02, y = -0.66,
           label = "POSITIONING SYSTEM / TESTED PERTURBATIONS",
           hjust = 0, fontface = "bold", color = "#333333", size = ICAT_TEXT_TITLE_MM) +
  annotate("text", x = 0.30, y = 0.56, label = "Rhoptry",
           color = unname(regulatory_colors["Rhoptry (ARO)"]), fontface = "bold",
           size = ICAT_TEXT_BODY_MM) +
  annotate("text", x = 0.72, y = 0.56, label = "Microneme",
           color = unname(regulatory_colors["Microneme (WT)"]), fontface = "bold",
           size = ICAT_TEXT_BODY_MM) +
  annotate("text", x = 0.30, y = -0.56, label = "ICMTs",
           color = unname(regulatory_colors["ICMTs (ARO + WT)"]), fontface = "bold",
           size = ICAT_TEXT_BODY_MM) +
  annotate("text", x = 0.73, y = -0.56,
           label = "MIC2 remains B2-biased in 3 mutants",
           color = "#6F2375", fontface = "bold", size = ICAT_TEXT_TITLE_MM) +
  scale_color_manual(values = regulatory_colors, drop = FALSE) +
  scale_fill_manual(values = regulatory_colors, drop = FALSE) +
  scale_shape_manual(values = c("ICMTs" = 16, "Rhoptry" = 17, "Microneme" = 15)) +
  coord_cartesian(xlim = c(-0.02, 1.02), ylim = c(-0.73, 0.73), clip = "off") +
  labs(
    title = "Distinct positioning logic for rhoptry and microneme secretion",
    subtitle = "Known ICMT control explains the B1-facing rhoptry site; tested mutants retain B2-biased MIC2 asymmetry",
    x = "Normalized position along B1-B2",
    y = NULL,
    color = NULL,
    shape = NULL,
    caption = paste0(
      "Retention of asymmetry does not mean identical distributions: ",
      "ICMAP1 KO shows a positional shift within the predefined +/-0.15 equivalence margin."
    )
  ) +
  theme_void(base_size = ICAT_FONT_BODY_PT) +
  theme(
    plot.title = element_text(face = "bold", size = ICAT_FONT_TITLE_PT),
    plot.subtitle = element_text(color = "#444444", size = ICAT_FONT_SMALL_PT),
    axis.title.x = element_text(face = "bold", margin = margin(t = 6)),
    plot.caption = element_text(color = "#555555", hjust = 0, size = 8.5),
    legend.position = "bottom",
    legend.box = "vertical",
    legend.text = element_text(size = 8.8),
    plot.margin = margin(12, 20, 10, 20)
  ) +
  guides(
    color = guide_legend(ncol = 3, order = 1, override.aes = list(shape = 16)),
    shape = guide_legend(nrow = 1, order = 2),
    fill = "none"
  )

save_plot <- function(plot, stem, width, height) {
  ggsave(
    file.path(figure_dir, paste0(stem, ".png")), plot,
    width = width, height = height, dpi = 300, bg = "white"
  )
  ggsave(
    file.path(figure_dir, paste0(stem, ".pdf")), plot,
    width = width, height = height, device = cairo_pdf, bg = "white"
  )
}

save_plot(p_map, "01_conoid_surface_position_map", 9.2, 6.2)
save_plot(p_gap, "02_primary_surface_gap_distributions", 8.2, 4.8)
save_plot(p_method, "03_peak_center_vs_FWHM_surface_distance", 10.2, 4.8)
save_plot(p_mutants, "04_microneme_B2_WT_and_mutants", 8.2, 4.8)
save_plot(p_compact, "05_compact_distances_by_source", 8.4, 6.2)
save_plot(p_circle, "06_conoid_cross_section_zones", 8.8, 8.2)
save_plot(p_regulatory, "07_regulatory_transition_map", 10.2, 7.2)
save_plot(p_threshold_selection, "08_microneme_B2_width_threshold_selection", 9.4, 4.8)
save_plot(p_selected_gap, "09_microneme_B2_selected_surface_distance", 8.4, 5.0)
for (height_fraction in threshold_result_fractions) {
  height_tag <- height_fraction_file_tag(height_fraction)
  save_plot(
    threshold_result_gap_plots[[height_tag]],
    paste0("09_microneme_B2_surface_distance_threshold_", height_tag),
    8.4,
    5.0
  )
}
save_plot(
  p_threshold_gap_comparison,
  "09_microneme_B2_surface_distance_threshold_2over3_vs_3over4",
  10.2,
  5.0
)

write.csv(
  distance_data,
  file.path(table_dir, "surface_distances_per_cell.csv"),
  row.names = FALSE
)
write.csv(
  distance_summary,
  file.path(table_dir, "surface_distance_summary.csv"),
  row.names = FALSE
)
write.csv(
  microneme_width_summary,
  file.path(table_dir, "microneme_FWHM_width_summary.csv"),
  row.names = FALSE
)
write.csv(
  microneme_threshold_data,
  file.path(table_dir, "microneme_width_thresholds_per_cell.csv"),
  row.names = FALSE
)
write.csv(
  threshold_comparison,
  file.path(table_dir, "microneme_B2_width_threshold_comparison.csv"),
  row.names = FALSE
)
write.csv(
  microneme_selected_distance_data,
  file.path(table_dir, "microneme_B2_selected_surface_distances_per_cell.csv"),
  row.names = FALSE
)
write.csv(
  microneme_selected_distance_summary,
  file.path(table_dir, "microneme_B2_selected_surface_distance_summary.csv"),
  row.names = FALSE
)
for (height_fraction in threshold_result_fractions) {
  height_tag <- height_fraction_file_tag(height_fraction)
  threshold_data <- microneme_distance_data_for_fraction(height_fraction)
  threshold_summary <- summarize_microneme_distance_data(
    threshold_data,
    "height_fraction"
  )
  write.csv(
    threshold_data,
    file.path(
      table_dir,
      paste0("microneme_B2_surface_distances_threshold_", height_tag, "_per_cell.csv")
    ),
    row.names = FALSE
  )
  write.csv(
    threshold_summary,
    file.path(
      table_dir,
      paste0("microneme_B2_surface_distance_threshold_", height_tag, "_summary.csv")
    ),
    row.names = FALSE
  )
}
write.csv(
  microneme_threshold_result_summary,
  file.path(table_dir, "microneme_B2_surface_distance_threshold_2over3_vs_3over4_summary.csv"),
  row.names = FALSE
)
write.csv(
  qc_summary,
  file.path(table_dir, "FWHM_QC_summary.csv"),
  row.names = FALSE
)
write.csv(
  asymmetry_tests,
  file.path(table_dir, "asymmetry_tests.csv"),
  row.names = FALSE
)
write.csv(
  zone_separation_tests,
  file.path(table_dir, "zone_separation_tests.csv"),
  row.names = FALSE
)
write.csv(
  circle_data[c(
    "group", "cell_id", "structure", "display_group",
    "structure_expected_center", "x_position", "y_display"
  )],
  file.path(table_dir, "conoid_cross_section_plot_data.csv"),
  row.names = FALSE
)
write.csv(
  regulatory_data[c(
    "group", "cell_id", "structure", "regulatory_group", "panel_side",
    "structure_expected_center", "x_position", "y_display"
  )],
  file.path(table_dir, "regulatory_transition_plot_data.csv"),
  row.names = FALSE
)
write.csv(
  data.frame(
    parameter = c(
      "B1_normalized_position", "B2_normalized_position",
      "local_FWHM_fraction_above_baseline", "profile_source",
      "orientation_rule", "ICMT_source_groups", "rhoptry_source_group",
      "primary_microneme_group", "supplementary_microneme_groups",
      "hidden_green_halfmax_edge_rule", "uexm_expansion_factor",
      "microneme_biological_width_target_nm", "B2_biological_width_target_nm",
      "candidate_local_peak_height_fractions", "selected_height_fraction",
      "reported_threshold_sensitivity_fractions",
      "threshold_selection_rule"
    ),
    value = c(
      0, 1, 0.5, "aligned_profiles_normalized.csv",
      "preserve original ZEN direction; no flipping",
      "ARO; WT-MIC2 (direct ICMT peaks only)", "ARO", "WT-MIC2",
      "ICMAP1-MIC2; ICMAP2-MIC2; ARO-MIC2",
      "mirror the observed outward half-width around the green peak center; unresolved if neither edge is observed",
      uexm_expansion_factor, "50-80", "20-30", "1/4; 1/2; 2/3; 3/4",
      selected_height_fraction,
      "2/3; 3/4",
      "minimize sum of midpoint errors scaled by each target range half-width, using WT medians"
    ),
    stringsAsFactors = FALSE
  ),
  file.path(table_dir, "analysis_parameters.csv"),
  row.names = FALSE
)

readme_lines <- c(
  "# Symmetry distance analysis",
  "",
  "## Run",
  "",
  "```bash",
  "Rscript Fig1_intro_spatial/03_code/peak_profiles/symmetry_distance.R",
  "```",
  "",
  "Run `run_all_peak_groups.R` first whenever raw CSV files change.",
  "",
  "## Distance definitions",
  "",
  "- B1 and B2 are normalized to 0 and 1; original ZEN direction is preserved.",
  "- Peak-center distances are retained as a conventional reference.",
  "- Each structure surface is estimated from local-background FWHM crossings",
  "  of its smoothed, normalized single-cell profile. Half height is halfway",
  "  between the local prominence baseline and the peak maximum.",
  "- If an inward green half-height crossing is hidden by an adjacent peak,",
  "  the observed outward half-width is mirrored around that peak center.",
  "  Per-cell edge-method columns identify observed and mirrored boundaries.",
  "- ICMTs-B1 and rhoptry-B1 use the two FWHM edges facing each other.",
  "- Microneme-B2 uses the microneme right edge and B2 left edge.",
  "- Overlapping FWHM intervals have a surface gap of zero, not a negative gap.",
  "- Microneme FWHM widths in normalized and nm units are written per cell, and",
  "  summarized in `tables/microneme_FWHM_width_summary.csv` together with the",
  "  number and percentage of zero surface gaps.",
  "- A uExM sensitivity analysis compares local 1/4, 1/2, 2/3, and 3/4 peak-height",
  "  widths after dividing expanded measurements by 4.5. The selected fraction",
  "  minimizes the joint standardized WT median-width error against independent",
  "  microneme (50-80 nm) and B2 (20-30 nm) biological target ranges.",
  paste0("- The currently selected fraction is `", height_fraction_label(selected_height_fraction),
         "`; its microneme-B2 estimates are separate from the original FWHM audit."),
  "- Additional threshold-sensitivity outputs are written for local `2/3` and",
  "  `3/4` peak-height boundaries, including per-cell tables, summaries and a",
  "  side-by-side comparison plot.",
  "- Directly detected ICMT peaks are used; imputed ICMT peaks are excluded.",
  "",
  "## Biological sources",
  "",
  "- ICMTs: ARO and WT-MIC2.",
  "- Rhoptry: purple channel in ARO.",
  "- Primary microneme: purple channel in WT-MIC2.",
  "- ICMAP1-MIC2, ICMAP2-MIC2, and ARO-MIC2 are supplementary microneme groups.",
  "",
  "## Compact visualizations",
  "",
  "- `05_compact_distances_by_source` separates ICMTs and rhoptry measurements",
  "  at B1 and shows WT and mutant microneme measurements at B2 by color.",
  "- `06_conoid_cross_section_zones` projects the measured one-dimensional peak",
  "  positions onto the horizontal diameter of a conoid cross-section schematic.",
  "  Colored points identify sample-source groups; overlaid upper half-violins",
  "  show their relative position densities. Point jitter is display-only.",
  "- The left/right separation supports spatial organization and compartmentalization",
  "  of rhoptry- and microneme-associated secretion zones. These localization data",
  "  alone do not establish a causal mechanism of secretion regulation.",
  "- `tables/zone_separation_tests.csv` directly tests the normalized-position",
  "  separation between the primary B1-facing and B2-facing distributions.",
  "- `07_regulatory_transition_map` places rhoptry and WT microneme above the",
  "  B1-B2 axis, with ICMTs and three mutant microneme datasets below it. It is",
  "  designed as a transition to candidate conoid regulators of microneme polarity.",
  "  All three mutants retain B2-biased MIC2 asymmetry, but ICMAP1 KO is shifted",
  "  relative to WT; retained polarity must not be described as identical profiles.",
  "",
  "FWHM surface distances reduce the optical-width bias of peak-center distances,",
  "but they are still optical estimates rather than molecular membrane distances.",
  "Inspect FWHM_QC_summary.csv before interpreting the group summaries."
)
writeLines(readme_lines, file.path(output_dir, "README.md"))

cat("Symmetry distance analysis complete.\n")
cat("Rows by relation and group:\n")
print(with(distance_data, table(relation, group)))
cat("\nFWHM surface QC:\n")
print(qc_summary, row.names = FALSE)
cat("\nAsymmetry tests:\n")
print(asymmetry_tests, row.names = FALSE)
