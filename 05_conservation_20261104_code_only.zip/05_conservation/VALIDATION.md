# Validation

Validation date: 2026-11-04. Performed locally using R 4.5.0 and the recorded package versions.

This module completed 3 positive task/configuration runs from an external working directory. It has 5 retained numerical comparison/consistency checks.

| Check | Result | Rows or matched cells |
|---|---|---:|
|module conservation scores|matched|33|
|conservation correlation statistics|matched|3|
|conservation correlation source|matched|11|
|current source-data conservation correlations|matched|3|
|current source-data conservation source|matched|11|

Comparisons use the same external inputs as the original numerical exports. Shared numerical fields are compared with relative tolerance 1e-9 and absolute tolerance 1e-12; missing patterns, keys and categorical fields are checked separately. PCoA geometry is checked independently of axis signs/rotation. Input snapshots, expected result tables, negative-test fixtures and generated results are not included in this package.

All five package entry points, missing-file handling, unknown-task handling and refusal to write inside the code package were checked. Domain checks cover missing fields and duplicate identifiers for every module, plus nonbinary class/presence values and the full-length-to-N-terminal handoff. All checks passed.

349 original external input files retained their pre-run SHA-256 hashes. Package syntax and runtime dependencies were checked. A fresh network/environment installation was not performed; validation reused the installed matching R environment. These tests do not establish availability or redistribution rights for the external datasets.

The original long-format presence route and the current Fig. 5f source workbook both reproduced the strict correlation results. Optional model-score overrides are kept separate from strict scores. Dual module membership was preserved.
