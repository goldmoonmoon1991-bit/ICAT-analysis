#!/usr/bin/env Rscript
script_arg <- grep("^--file=",commandArgs(FALSE),value=TRUE)
module_dir <- dirname(normalizePath(sub("^--file=","",script_arg[[1]]),mustWork=TRUE))
source(file.path(module_dir,"R","runtime.R"))
opts <- cli(commandArgs(TRUE));need_package("jsonlite")
config_file <- normalizePath(opts[["--config"]],mustWork=TRUE);config_dir <- dirname(config_file)
cfg <- jsonlite::fromJSON(config_file,simplifyVector=TRUE)
task <- cfg$task
tasks <- c(conservation="conservation.R", orthogroup_presence="orthogroup_presence.R")
if(is.null(task)||!task %in% names(tasks)) stop("Unknown task. Choose: ",paste(names(tasks),collapse=", "),call.=FALSE)
canonical_future <- function(p) {
 if(file.exists(p)) return(normalizePath(p,mustWork=TRUE))
 parent <- dirname(p)
 if(identical(parent,p)) stop("Cannot resolve output path.")
 file.path(canonical_future(parent),basename(p))
}
out_arg <- opts[["--out-dir"]]
if(!grepl("^/",out_arg)) out_arg <- file.path(getwd(),out_arg)
out_dir <- canonical_future(out_arg)
is_within <- function(path,parent) identical(path,parent)||startsWith(path,paste0(parent,"/"))
if(is_within(out_dir,module_dir)) stop("Output must be outside the code package.",call.=FALSE)
# Resolve every declared input before any computation; never create or amend inputs.
if(length(cfg$inputs)) for(n in names(cfg$inputs)) {
 p <- input_path(n,directory=dir.exists(if(grepl("^/",cfg$inputs[[n]])) cfg$inputs[[n]] else file.path(config_dir,cfg$inputs[[n]])))
 if(identical(out_dir,p)||is_within(out_dir,if(dir.exists(p)) p else dirname(p))) stop("Output must be outside all external input locations.",call.=FALSE)
}
dir.create(out_dir,recursive=TRUE,showWarnings=FALSE)
sys.source(file.path(module_dir,"R",tasks[[task]]),envir=environment())
writeLines(capture.output(sessionInfo()),file.path(out_dir,"sessionInfo.txt"))
message("Completed ",task,". Numerical results: ",out_dir)
