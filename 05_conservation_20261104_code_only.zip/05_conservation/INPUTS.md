# External presence, morphology and curation inputs

## conservation

The long `protein_presence` table requires module, gene_id, species, orthogroup_present (0/1/missing) and include_in_score. Module + gene_id + species is unique. Module labels are Conoid scaffold, ICMT/ICMAP system and ICAT structure. **The same gene may belong to more than one module**; those curated memberships are preserved and exported for review, rather than deduplicated across modules.

`morphology` requires unique species, clade, model and conoid score. The original morphology gate is conoid score / 2; missing morphology scores retain the original zero-coalescing rule. A configuration may explicitly scale the supplied score representation. Module presence fractions use the original included-reference denominators. The conoid index is scaffold presence fraction times the morphology gate. The derived-module score is the mean of strict ICMT and ICAT fractions. Spearman uses exact = FALSE, Pearson is two-sided, and the linear model includes an intercept.

Optional `model_overrides` is external curation with species, module, model_score_override and optional evidence_class/evidence_note. These affect the separate module_model_score, **not** strict_conservation_fraction or the correlation's strict ICAT score. No low-confidence species-specific observation is hardcoded. Optional `context_taxa` documents excluded evolutionary context; when the original representative table is supplied, its Ciliates, Perkinsids and Chromerids rows are counted as excluded context. Without that table, no count of unseen context records is invented.

`config/source_data_workbook.example.json` reads the current Figure_5f_Source_Data.xlsx directly: Y3:AL33 for the protein-presence matrix and A2:Q13 for species/morphology metadata on Fig_5f. The configuration maps module/species labels and multiplies the supplied 0-1 Morphology weight by 2 before the original /2 gate. It contains labels and schema metadata only, not the observed matrix. Adjust ranges explicitly if the separately distributed workbook changes.

Outputs are per-module species scores, strict correlation inputs/statistics, protein summaries and cross-module gene membership checks. Existing SPM1 dual membership is preserved. Tree/sector construction, point offsets, colours and barcode rendering are excluded.

## orthogroup_presence

`orthogroup_scan` requires unique gene_id and member_genera. `target_genera` is named species-to-genus metadata. The original case-insensitive genus-presence rule is applied to the supplied member strings; unavailable/blank member strings remain missing, not absent. This is an offline annotation step, not a new sequence-homology search or automatic OrthoMCL download. Reference lists, member results, species matrices, morphology and overrides must remain separately distributed data.
