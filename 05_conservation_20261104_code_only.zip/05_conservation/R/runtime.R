# Shared input/CLI handling. Analysis formulas are in R/.
need_package <- function(p) {
  if (!requireNamespace(p, quietly=TRUE)) stop("Missing R package: ",p,". Restore the supplied environment before running.",call.=FALSE)
}
assert_columns <- function(x, cols, label="input") {
  missing <- setdiff(cols,names(x))
  if(length(missing)) stop(label," is missing required fields: ",paste(missing,collapse=", "),call.=FALSE)
}
assert_unique <- function(x, cols, label="input") {
  assert_columns(x,cols,label)
  if(anyDuplicated(x[,cols,drop=FALSE])) stop("Duplicate ",paste(cols,collapse="/")," identifiers in ",label,".",call.=FALSE)
}
input_path <- function(name, directory=FALSE) {
  value <- cfg$inputs[[name]]
  if(is.null(value)||length(value)!=1L||is.na(value)||!nzchar(value)||grepl("^<",value)) stop("Configure external input: ",name,call.=FALSE)
  if(!grepl("^(/|[A-Za-z]:[/\\\\])",value)) value <- file.path(config_dir,value)
  if(!file.exists(value)) stop("Missing external input ",name,": ",value,call.=FALSE)
  if(directory && !dir.exists(value)) stop("Expected a directory for ",name,call.=FALSE)
  if(!directory && dir.exists(value)) stop("Expected a file for ",name,call.=FALSE)
  normalizePath(value,mustWork=TRUE)
}
read_input_table <- function(name, fields=NULL, unique_by=NULL) {
  p <- input_path(name)
  if(grepl("\\.xlsx?$",p,ignore.case=TRUE)) {
    need_package("readxl")
    spec <- cfg$tables[[name]]
    sheet <- if(is.null(spec$sheet)) 1 else spec$sheet
    skip <- if(is.null(spec$skip)) 0 else as.integer(spec$skip)
    if(!is.null(spec$range)) x <- as.data.frame(readxl::read_excel(p,sheet=sheet,range=spec$range,na=c("","NA")),check.names=FALSE)
    else x <- as.data.frame(readxl::read_excel(p,sheet=sheet,skip=skip,na=c("","NA")),check.names=FALSE)
  } else {
    x <- read.csv(p,check.names=FALSE,stringsAsFactors=FALSE,na.strings=c("","NA"))
  }
  mapping <- cfg$columns[[name]]
  if(length(mapping)) for(target in names(mapping)) {
    source <- mapping[[target]]
    if(!source %in% names(x)) stop(name," is missing mapped field: ",source,call.=FALSE)
    names(x)[match(source,names(x))] <- target
  }
  if(length(fields)) assert_columns(x,fields,name)
  if(length(unique_by)) assert_unique(x,unique_by,name)
  x
}
write_table <- function(x,name,row.names=FALSE) {
  if(is.data.frame(x)) for(n in names(x)) if(is.list(x[[n]])) x[[n]] <- vapply(x[[n]],paste,character(1),collapse="; ")
  write.csv(x,file.path(out_dir,name),row.names=row.names,na="")
}
cli <- function(args) {
  if(!length(args)||"--help" %in% args) {
    cat("Usage: Rscript run_analysis.R --config /path/config.json --out-dir /path/results\n")
    quit(status=0)
  }
  allowed <- c("--config","--out-dir"); parsed <- list();i<-1L
  while(i<=length(args)) {
    a<-args[[i]]
    if(!a %in% allowed||i==length(args)||a %in% names(parsed)) stop("Use each of --config and --out-dir exactly once.",call.=FALSE)
    parsed[[a]]<-args[[i+1L]];i<-i+2L
  }
  if(!all(allowed %in% names(parsed))) stop("Both --config and --out-dir are required.",call.=FALSE)
  parsed
}
