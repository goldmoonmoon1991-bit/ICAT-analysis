suppressPackageStartupMessages({library(dplyr);library(tidyr)})
if(identical(cfg$presence_format,"wide_source_data")) {
 protein_wide <- read_input_table("protein_presence",c("module","gene_id"))
 sm <- unlist(cfg$species_map);mm <- unlist(cfg$module_map)
 if(!length(sm)||!length(mm)) stop("Wide source data require species_map and module_map metadata.")
 assert_columns(protein_wide,names(sm),"wide protein presence")
 protein_long <- protein_wide %>% pivot_longer(cols=all_of(names(sm)),names_to="species",values_to="orthogroup_present")
 protein_long$species <- unname(sm[protein_long$species]);protein_long$module <- unname(mm[protein_long$module]);protein_long$include_in_score <- 1L
 if(anyNA(protein_long$species)||anyNA(protein_long$module)) stop("Incomplete species or module mapping.")
 assert_unique(protein_long,c("module","gene_id","species"),"expanded protein presence")
} else protein_long <- read_input_table("protein_presence",c("module","gene_id","species","orthogroup_present","include_in_score"),c("module","gene_id","species"))
protein_long$orthogroup_present <- as.numeric(protein_long$orthogroup_present)
if(any(!is.na(protein_long$orthogroup_present)&!protein_long$orthogroup_present %in% c(0L,1L))) stop("orthogroup_present must be 0, 1 or missing.")
protein_long$orthogroup_present <- as.integer(protein_long$orthogroup_present)
module_species_scores <- protein_long %>% filter(include_in_score==1L,!is.na(orthogroup_present)) %>% group_by(module,species) %>% summarise(n_reference_proteins=n(),n_present=sum(orthogroup_present==1L),module_conservation_fraction=n_present/n_reference_proteins,.groups="drop") %>% mutate(strict_conservation_fraction=module_conservation_fraction,module_model_score=module_conservation_fraction)
if(!is.null(cfg$inputs$model_overrides)) {
 overrides <- read_input_table("model_overrides",c("species","module","model_score_override"),c("species","module"))
 module_species_scores <- module_species_scores %>% left_join(overrides %>% select(species,module,model_score_override,any_of(c("evidence_class","evidence_note"))),by=c("species","module")) %>% mutate(module_model_score=coalesce(model_score_override,module_conservation_fraction))
}
if(!"evidence_class" %in% names(module_species_scores)) module_species_scores$evidence_class <- NA_character_
if(!"evidence_note" %in% names(module_species_scores)) module_species_scores$evidence_note <- NA_character_
module_species_scores <- module_species_scores %>% mutate(evidence_class=coalesce(evidence_class,"strict orthogroup conservation"),evidence_note=coalesce(evidence_note,"No model override applied."))
# A gene may occur in more than one curated module. Preserve those memberships.
duplicate_module_gene_ids <- protein_long %>% distinct(module,gene_id) %>% group_by(gene_id) %>% summarise(n_modules=n_distinct(module),modules=paste(unique(module),collapse="; "),.groups="drop") %>% filter(n_modules>1)
structure_matrix_raw <- read_input_table("morphology",c("species","clade","model","conoid score"),"species")
if(!is.null(cfg$morphology_score_scale)) structure_matrix_raw$`conoid score` <- structure_matrix_raw$`conoid score` * cfg$morphology_score_scale
species_long_raw <- module_species_scores
species_wide_core <- species_long_raw %>% mutate(module_id=case_when(module=="Conoid scaffold" ~ "conoid_scaffold_ortholog_fraction",module=="ICMT/ICMAP system" ~ "icmt_score",module=="ICAT structure" ~ "icat_score",TRUE ~ module),strict_score=strict_conservation_fraction) %>% select(species,module_id,strict_score) %>% pivot_wider(names_from=module_id,values_from=strict_score) %>% left_join(structure_matrix_raw %>% transmute(species,source_clade=clade,morphology_state=model,morphology_score=`conoid score`,morphology_gate=morphology_score/2),by="species") %>% mutate(morphology_score=coalesce(morphology_score,0),morphology_gate=coalesce(morphology_gate,0),conoid_scaffold_score=conoid_scaffold_ortholog_fraction*morphology_gate,data_class="protein conservation")
assert_columns(species_wide_core,c("conoid_scaffold_score","icmt_score","icat_score"),"three module scores")
correlation_source <- species_wide_core %>% mutate(derived_score=rowMeans(cbind(icmt_score,icat_score),na.rm=TRUE),morphology_gated_conoid_scaffold_index=conoid_scaffold_score)
if(any(!is.finite(correlation_source$conoid_scaffold_score)|!is.finite(correlation_source$derived_score))) stop("All correlation taxa need finite x and y scores.")
if(nrow(correlation_source)<3L||length(unique(correlation_source$conoid_scaffold_score))<2L||length(unique(correlation_source$derived_score))<2L) stop("Correlation needs at least three taxa and two nonconstant scores.")
correlation_context <- data.frame()
if(!is.null(cfg$inputs$context_taxa)) {
 correlation_context <- read_input_table("context_taxa")
 if("representative_label" %in% names(correlation_context)) correlation_context <- correlation_context %>% filter(representative_label %in% c("Ciliates","Perkinsids","Chromerids"))
}
spearman_scaffold_derived <- suppressWarnings(cor.test(correlation_source$conoid_scaffold_score,correlation_source$derived_score,method="spearman",exact=FALSE))
pearson_scaffold_derived <- suppressWarnings(cor.test(correlation_source$conoid_scaffold_score,correlation_source$derived_score,method="pearson"))
lm_scaffold_derived <- lm(derived_score ~ conoid_scaffold_score,data=correlation_source);lm_summary<-summary(lm_scaffold_derived)
correlation_stats <- data.frame(method=c("Spearman rank correlation","Pearson correlation","Linear model"),estimate=c(unname(spearman_scaffold_derived$estimate),unname(pearson_scaffold_derived$estimate),unname(coef(lm_scaffold_derived)[["conoid_scaffold_score"]])),p_value=c(spearman_scaffold_derived$p.value,pearson_scaffold_derived$p.value,lm_summary$coefficients["conoid_scaffold_score","Pr(>|t|)"]),r_squared=c(NA_real_,NA_real_,lm_summary$r.squared),n_species=nrow(correlation_source),outgroups_excluded_from_stats=nrow(correlation_context))
write_table(module_species_scores,"module_species_scores.csv")
write_table(correlation_source,"conservation_correlation_source.csv")
write_table(correlation_stats,"conservation_correlation_statistics.csv")
write_table(duplicate_module_gene_ids,"cross_module_gene_memberships.csv")
write_table(protein_long %>% filter(include_in_score==1L) %>% group_by(module,gene_id) %>% summarise(n_species=n(),n_present=sum(orthogroup_present==1L,na.rm=TRUE),presence_fraction=mean(orthogroup_present==1L,na.rm=TRUE),.groups="drop"),"protein_conservation_summary.csv")
