suppressPackageStartupMessages({library(dplyr);library(tidyr)})

# Adapted from Fig5_secretion_mechanism/03_code/conoid_evolution/analyze_toxoplasma_reference_module_conservation.R, lines 391-396.
genus_present <- function(genera_string, genus_pattern) {
  if (is.na(genera_string) || !nzchar(genera_string)) {
    return(NA_integer_)
  }
  as.integer(grepl(genus_pattern, genera_string, ignore.case = TRUE))
}

members <- read_input_table("orthogroup_scan",c("gene_id","member_genera"),"gene_id")
targets <- cfg$target_genera
if(is.null(targets)||!length(targets)||any(!grepl("^[A-Za-z]+$",unlist(targets)))) stop("Configure target_genera as named species-to-genus metadata.")
presence <- members
for(species in names(targets)) presence[[species]] <- vapply(members$member_genera,genus_present,integer(1),genus_pattern=targets[[species]])
write_table(presence,"genus_level_orthogroup_presence.csv")
