# Localization perturbation and Gower PCoA

Local deposit candidate, prepared 2026-11-04. Supports Fig. 3b; Extended Data Fig. 3b.

## Contents and use

This package contains calculation code, configuration examples, environment metadata and documentation only. Experimental data, reference annotations, processed input tables and result snapshots are distributed separately. No input data are downloaded automatically.

Tasks: localization_pcoa. Copy the relevant configuration example outside this package, replace every external path, and run from any working directory:

```sh
Rscript /path/to/03_localization_pcoa/run_analysis.R --config /path/to/config.json --out-dir /path/to/results
```

Paths in a configuration are absolute or relative to that configuration. Input tables may be mapped through `columns` (canonical field to source field); supported workbook inputs use `tables` with `sheet`, `skip` and `range`. Outputs must be outside this package and outside input locations. Inputs are never edited. Missing inputs or required fields cause an error; no replacement observations are generated.

## Scope

The numerical calculation blocks were extracted from the original project scripts; see SOURCE_PROVENANCE.json. Plotting, colour/layout code, figure exporters and routine phenotype plotting are excluded. Calculation thresholds, missing-value rules and random seeds are retained unless the documented configuration explicitly changes a parameter. See INPUTS.md for exact input requirements and VALIDATION.md for observed test coverage.

## Interpretation and release status

This is a candidate for author selection, not a claim that every final paper panel has been regenerated. External source-data tables may begin downstream of the raw inputs required by some tasks; consult INPUTS.md rather than treating every panel workbook as a complete raw-input bundle. Version decisions and missing external inputs are reported explicitly. No GitHub repository or manuscript statement was changed.

The original all-rights-reserved copyright statement is preserved. No new software licence or third-party redistribution permission is asserted.
