# Validation

Validation date: 2026-11-04. Performed locally using R 4.5.0 and the recorded package versions.

This module completed 2 positive task/configuration runs from an external working directory. It has 8 retained numerical comparison/consistency checks.

| Check | Result | Rows or matched cells |
|---|---|---:|
|Gower PCoA: IFA_processed_replicates.csv|matched|27|
|Gower PCoA: IFA_genotype_summary.csv|matched|9|
|Gower PCoA: IFA_PCoA_feature_contributions.csv|matched|8|
|Gower PCoA: IFA_Gower_distance_matrix.csv|matched|9|
|Gower PCoA: eigenvalues from original distance matrix|matched|9|
|PCoA coordinate geometry (rotation/sign invariant)|matched|9|
|current source-data PCoA: IFA_genotype_summary.csv|matched|9|
|current source-data PCoA: IFA_Gower_distance_matrix.csv|matched|9|

Comparisons use the same external inputs as the original numerical exports. Shared numerical fields are compared with relative tolerance 1e-9 and absolute tolerance 1e-12; missing patterns, keys and categorical fields are checked separately. PCoA geometry is checked independently of axis signs/rotation. Input snapshots, expected result tables, negative-test fixtures and generated results are not included in this package.

All five package entry points, missing-file handling, unknown-task handling and refusal to write inside the code package were checked. Domain checks cover missing fields and duplicate identifiers for every module, plus nonbinary class/presence values and the full-length-to-N-terminal handoff. All checks passed.

349 original external input files retained their pre-run SHA-256 hashes. Package syntax and runtime dependencies were checked. A fresh network/environment installation was not performed; validation reused the installed matching R environment. These tests do not establish availability or redistribution rights for the external datasets.

Environment note: cluster 2.1.8.1 was used and is pinned here; the earlier full-project lockfile recorded 2.1.8.2. Saved original distances and PCoA geometry matched, and eigenvalues matched a separate additive-corrected PCoA calculation from the original distance matrix.
