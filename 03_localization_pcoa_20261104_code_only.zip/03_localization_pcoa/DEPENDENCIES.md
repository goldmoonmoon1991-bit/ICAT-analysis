# Runtime environment

R 4.5.0. Direct packages: jsonlite, cluster, readxl.

The lockfile records the tested runtime dependency closure, without plotting packages. The tested cluster version is 2.1.8.1; the earlier full-project lockfile recorded 2.1.8.2. Numerical validation used 2.1.8.1 and reproduced the original saved Gower distances, PCoA geometry and eigenvalues reconstructed from the original distance matrix. Restore with `renv::restore(lockfile="renv.lock", prompt=FALSE)` after installing renv. The original copyright notice is preserved in LICENSE.
