suppressPackageStartupMessages(library(cluster))
input_path_value <- input_path("localization_input")
table_dir <- out_dir

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 51-57.
required <- c(
  "biological_replicate", "genotype", "primary_perturbation_target", "target_module",
  "total_cells", "intact_n", "altered_n", "lost_n", "unscorable_n",
  "expected_icat_effect", "conoid_body_status", "apical_ring_status",
  "icmt_status", "bridge_status", "rhoptry_status", "icat_total_signal_status",
  "wb_abundance_ratio"
)

raw <- read_input_table("localization_input")
assert_unique(raw[!is.na(raw$total_cells),,drop=FALSE],c("genotype","biological_replicate"),"completed localization records")

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 70-76.
apical_col <- if ("apical_polar_ring_status" %in% names(raw)) {
  "apical_polar_ring_status"
} else if ("apical_ring_status" %in% names(raw)) {
  "apical_ring_status"
} else {
  NA_character_
}

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 77-77.
missing_columns <- setdiff(required, names(raw))

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 78-78.
missing_columns <- setdiff(missing_columns, c("apical_ring_status", "apical_polar_ring_status"))

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 79-81.
if (length(missing_columns)) {
  stop("Input is missing required columns: ", paste(missing_columns, collapse = ", "))
}

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 82-82.
if (is.na(apical_col)) stop("Input is missing required column: apical_polar_ring_status")

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 83-83.
rhoptry_col <- if ("rhoptry_status" %in% names(raw)) "rhoptry_status" else NA_character_

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 84-84.
abundance_col <- if ("wb_abundance_ratio" %in% names(raw)) "wb_abundance_ratio" else NA_character_

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 85-85.
if (is.na(rhoptry_col)) stop("Input is missing required column: rhoptry_status")

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 86-86.
if (is.na(abundance_col)) stop("Input is missing required column: wb_abundance_ratio")

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 88-88.
completed <- !is.na(raw$total_cells) & nzchar(trimws(as.character(raw$total_cells)))

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 89-89.
dat <- raw[completed, , drop = FALSE]

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 90-95.
if (!nrow(dat)) {
  stop(
    "No completed rows were found. Fill total_cells, intact_n, altered_n, lost_n ",
    "and unscorable_n before running the analysis."
  )
}

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 97-97.
count_columns <- c("total_cells", "intact_n", "altered_n", "lost_n", "unscorable_n")

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 98-98.
for (column in count_columns) dat[[column]] <- as.numeric(dat[[column]])

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 99-101.
if (any(!is.finite(as.matrix(dat[count_columns])))) {
  stop("All count columns must be numeric for completed rows.")
}

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 102-105.
if (any(as.matrix(dat[count_columns]) < 0) ||
    any(abs(as.matrix(dat[count_columns]) - round(as.matrix(dat[count_columns]))) > 1e-8)) {
  stop("Cell counts must be non-negative integers.")
}

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 107-107.
count_sum <- dat$intact_n + dat$altered_n + dat$lost_n + dat$unscorable_n

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 108-108.
bad_sum <- which(dat$total_cells != count_sum)

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 109-115.
if (length(bad_sum)) {
  warning(
    "Count mismatch in rows: ",
    paste(which(completed)[bad_sum] + 1L, collapse = ", "),
    ". Proceeding with the provided counts."
  )
}

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 117-117.
dat$scored_cells <- dat$intact_n + dat$altered_n + dat$lost_n

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 118-118.
if (any(dat$scored_cells <= 0)) stop("Each completed row must contain at least one scorable cell.")

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 119-119.
dat$intact_prop <- dat$intact_n / dat$scored_cells

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 120-120.
dat$altered_prop <- dat$altered_n / dat$scored_cells

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 121-121.
dat$lost_prop <- dat$lost_n / dat$scored_cells

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 122-122.
dat$unscorable_prop <- dat$unscorable_n / dat$total_cells

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 124-134.
status_score <- function(x, type = "structure") {
  x <- tolower(trimws(as.character(x)))
  if (type == "abundance") {
    map <- c(normal = 0, reduced = 1, lost = 2, nd = NA_real_)
  } else {
    map <- c(intact = 0, altered = 1, lost = 2, nd = NA_real_)
  }
  out <- unname(map[x])
  out[x == ""] <- NA_real_
  out
}

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 136-136.
dat$conoid_body_score <- status_score(dat$conoid_body_status)

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 137-137.
dat$apical_ring_score <- status_score(dat[[apical_col]])

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 138-138.
dat$icmt_score <- status_score(dat$icmt_status)

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 139-139.
dat$bridge_score <- status_score(dat$bridge_status)

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 140-140.
dat$rhoptry_score <- status_score(dat$rhoptry_status)

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 141-141.
dat$icat_abundance_score <- status_score(dat$icat_total_signal_status, "abundance")

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 142-142.
dat$wb_abundance_ratio <- suppressWarnings(as.numeric(dat$wb_abundance_ratio))

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 144-144.
mean_or_na <- function(x) if (all(is.na(x))) NA_real_ else mean(x, na.rm = TRUE)

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 145-148.
first_nonblank <- function(x) {
  x <- x[!is.na(x) & nzchar(trimws(as.character(x)))]
  if (length(x)) as.character(x[[1]]) else NA_character_
}

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 149-159.
normalize_perturbation_structures <- function(primary, module) {
  terms <- tolower(c(primary, module))
  out <- character()
  add_if <- function(flag, label) {
    if (any(flag, na.rm = TRUE)) out <<- unique(c(out, label))
  }
  add_if(grepl("conoid", terms) | grepl("bridge", terms), "Conoid")
  add_if(grepl("icmt", terms), "ICMTs")
  add_if(grepl("rhoptry", terms), "Rhoptry")
  out
}

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 160-168.
normalize_primary_target <- function(primary) {
  term <- tolower(trimws(as.character(primary)))
  if (is.na(term) || !nzchar(term) || term == "none") return(character())
  out <- character()
  if (grepl("conoid|bridge", term)) out <- c(out, "Conoid")
  if (grepl("icmt", term)) out <- c(out, "ICMTs")
  if (grepl("rhoptry", term)) out <- c(out, "Rhoptry")
  unique(out)
}

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 169-175.
display_genotype <- function(x) {
  x <- gsub("CIP3KO/CF1KD", "CIP3/CF1", x, fixed = TRUE)
  x <- gsub("_KO_CF1_KD$", "/CF1", x)
  x <- gsub("_(KO|KD)$", "", x)
  x <- gsub("(KO|KD)$", "", x)
  gsub("_", " ", x)
}

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 189-192.
fig3b_order <- c(
  "WT", "CF5KO", "AROKD", "ICMAP1KD", "ICMAP2KD",
  "CIP3KO", "RNG2KD", "AC9KD", "CIP3KO/CF1KD"
)

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 945-945.
pieces <- split(dat, dat$genotype)

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 946-981.
summary_rows <- lapply(pieces, function(z) {
  data.frame(
    genotype = z$genotype[[1]],
    primary_perturbation_target = first_nonblank(z$primary_perturbation_target),
    target_module = first_nonblank(z$target_module),
    expected_icat_effect = first_nonblank(z$expected_icat_effect),
    conoid_body_status = first_nonblank(z$conoid_body_status),
    apical_ring_status = first_nonblank(z[[apical_col]]),
    icmt_status = first_nonblank(z$icmt_status),
    bridge_status = first_nonblank(z$bridge_status),
    rhoptry_status = first_nonblank(z[[rhoptry_col]]),
    n_biological_replicates = length(unique(z$biological_replicate)),
    total_scored_cells = sum(z$scored_cells),
    intact_prop = mean(z$intact_prop),
    altered_prop = mean(z$altered_prop),
    lost_prop = mean(z$lost_prop),
    unscorable_prop = mean(z$unscorable_prop),
    conoid_body_score = mean_or_na(z$conoid_body_score),
    conoid_assembly_score = mean_or_na(z$conoid_assembly_score),
    conoid_position_score = mean_or_na(z$conoid_position_score),
    apical_ring_score = mean_or_na(z$apical_ring_score),
    icmt_score = mean_or_na(z$icmt_score),
    bridge_score = mean_or_na(z$bridge_score),
    rhoptry_score = mean_or_na(z$rhoptry_score),
    icat_abundance_score = mean_or_na(z$icat_abundance_score),
    wb_abundance_ratio = mean_or_na(z[[abundance_col]]),
    perturb_structures = I(list(normalize_perturbation_structures(
      first_nonblank(z$primary_perturbation_target),
      first_nonblank(z$target_module)
    ))),
    primary_targets = I(list(normalize_primary_target(
      first_nonblank(z$primary_perturbation_target)
    ))),
    stringsAsFactors = FALSE
  )
})

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 982-982.
summary <- do.call(rbind, summary_rows)

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 983-983.
rownames(summary) <- NULL

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 984-984.
summary <- summary[match(fig3b_order, summary$genotype), , drop = FALSE]

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 985-987.
if (anyNA(summary$genotype)) {
  stop("Some genotypes from fig3b_order are missing in the Excel input.")
}

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 988-990.
if (!identical(summary$genotype, fig3b_order)) {
  stop("Summary rows are not in the requested dendrogram order.")
}

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 991-991.
summary$genotype <- as.character(summary$genotype)

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 992-1002.
if (!any(is.finite(summary$wb_abundance_ratio))) {
  summary$expression_fraction <- rep(NA_real_, nrow(summary))
} else {
  wt_baseline <- mean(summary$wb_abundance_ratio[summary$genotype == "WT"], na.rm = TRUE)
  if (!is.finite(wt_baseline) || wt_baseline <= 0) {
    wt_baseline <- max(summary$wb_abundance_ratio, na.rm = TRUE)
  }
  summary$expression_fraction <- summary$wb_abundance_ratio / wt_baseline
  summary$expression_fraction[!is.finite(summary$expression_fraction)] <- NA_real_
  summary$expression_fraction <- pmin(pmax(summary$expression_fraction, 0), 1)
}

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 1004-1004.
dominant_labels <- c("intact", "altered", "lost")

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 1005-1012.
summary$dominant_icat_outcome <- apply(
  summary[, c("intact_prop", "altered_prop", "lost_prop")],
  1,
  function(x) {
    hits <- which(abs(x - max(x)) < 1e-10)
    if (length(hits) == 1L) dominant_labels[hits] else "mixed"
  }
)

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 1016-1016.
pseudocount <- 0.005

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 1017-1017.
composition <- as.matrix(summary[, c("intact_prop", "altered_prop", "lost_prop")]) + pseudocount

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 1018-1018.
composition <- composition / rowSums(composition)

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 1019-1021.
summary$ilr_intact_vs_nonintact <- sqrt(2 / 3) * log(
  composition[, 1] / sqrt(composition[, 2] * composition[, 3])
)

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 1022-1022.
summary$ilr_altered_vs_lost <- sqrt(1 / 2) * log(composition[, 2] / composition[, 3])

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 1024-1028.
feature_names <- c(
  "ilr_intact_vs_nonintact", "ilr_altered_vs_lost",
  "conoid_body_score", "apical_ring_score", "icmt_score", "bridge_score",
  "icat_abundance_score", "wb_abundance_ratio"
)

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 1029-1029.
features <- summary[, feature_names, drop = FALSE]

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 1030-1033.
informative <- vapply(features, function(x) {
  finite <- x[is.finite(x)]
  length(finite) >= 2L && length(unique(finite)) > 1L
}, logical(1))

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 1034-1034.
features <- features[, informative, drop = FALSE]

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 1035-1037.
if (ncol(features) < 2L) {
  stop("At least two non-constant phenotype features are required for clustering.")
}

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 1038-1040.
if (nrow(features) < 4L) {
  stop("At least four genotypes with completed measurements are required for clustering.")
}

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 1042-1042.
rownames(features) <- summary$genotype

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 1043-1043.
gower <- daisy(features, metric = "gower")

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 1044-1044.
hc <- hclust(as.dist(gower), method = "average")

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 1045-1045.
pcoa <- cmdscale(as.dist(gower), k = 2, eig = TRUE, add = TRUE)

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 1046-1053.
pcoa_data <- data.frame(
  genotype = summary$genotype,
  PCoA1 = pcoa$points[, 1],
  PCoA2 = pcoa$points[, 2],
  target_module = summary$target_module,
  dominant_icat_outcome = summary$dominant_icat_outcome,
  stringsAsFactors = FALSE
)

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 1054-1054.
pcoa_data$display_genotype <- display_genotype(pcoa_data$genotype)

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 1057-1057.
variance <- pmax(pcoa$eig, 0)

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 1058-1058.
variance_percent <- 100 * variance / sum(variance)

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 1082-1091.
feature_sources <- c(
  ilr_intact_vs_nonintact = "Excel counts: intact_n, altered_n, lost_n",
  ilr_altered_vs_lost = "Excel counts: intact_n, altered_n, lost_n",
  conoid_body_score = "conoid_body_status",
  apical_ring_score = "apical_polar_ring_status/apical_ring_status",
  icmt_score = "icmt_status",
  bridge_score = "bridge_status",
  icat_abundance_score = "icat_total_signal_status",
  wb_abundance_ratio = "wb_abundance_ratio"
)

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 1092-1101.
feature_descriptions <- c(
  ilr_intact_vs_nonintact = "ICAT apical retention versus altered/lost localization",
  ilr_altered_vs_lost = "Altered versus lost ICAT localization among non-intact cells",
  conoid_body_score = "Conoid body structural severity",
  apical_ring_score = "Conoid/apical position structural severity",
  icmt_score = "ICMT structural severity",
  bridge_score = "Fibrous material/bridge structural severity",
  icat_abundance_score = "IF-based ICAT abundance severity",
  wb_abundance_ratio = "Western blot ICAT abundance relative to WT"
)

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 1102-1102.
coords <- pcoa$points[, 1:2, drop = FALSE]

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 1103-1103.
colnames(coords) <- c("PCoA1", "PCoA2")

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 1104-1119.
pcoa_feature_contribution <- do.call(rbind, lapply(names(features), function(feature_name) {
  values <- features[[feature_name]]
  ok <- is.finite(values)
  r1 <- suppressWarnings(cor(values[ok], coords[ok, "PCoA1"], method = "spearman"))
  r2 <- suppressWarnings(cor(values[ok], coords[ok, "PCoA2"], method = "spearman"))
  data.frame(
    feature = feature_name,
    excel_source = unname(feature_sources[feature_name]),
    interpretation = unname(feature_descriptions[feature_name]),
    spearman_r_PCoA1 = r1,
    spearman_r_PCoA2 = r2,
    abs_r_PCoA1 = abs(r1),
    abs_r_PCoA2 = abs(r2),
    stringsAsFactors = FALSE
  )
}))

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 1120-1121.
pcoa_feature_contribution$PCoA1_percent <- 100 *
  pcoa_feature_contribution$abs_r_PCoA1 / sum(pcoa_feature_contribution$abs_r_PCoA1)

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 1122-1123.
pcoa_feature_contribution$PCoA2_percent <- 100 *
  pcoa_feature_contribution$abs_r_PCoA2 / sum(pcoa_feature_contribution$abs_r_PCoA2)

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 1124-1127.
pcoa_feature_contribution$combined_strength <- sqrt(
  pcoa_feature_contribution$abs_r_PCoA1^2 +
    pcoa_feature_contribution$abs_r_PCoA2^2
)

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 1128-1129.
pcoa_feature_contribution$combined_percent <- 100 *
  pcoa_feature_contribution$combined_strength / sum(pcoa_feature_contribution$combined_strength)

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 1130-1137.
pcoa_feature_contribution <- pcoa_feature_contribution[
  order(-pcoa_feature_contribution$combined_percent),
  c(
    "feature", "excel_source", "interpretation",
    "spearman_r_PCoA1", "spearman_r_PCoA2",
    "PCoA1_percent", "PCoA2_percent", "combined_percent"
  )
]

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 1235-1251.
ratio_rows <- lapply(split(dat, dat$genotype), function(z) {
  values <- z$intact_prop
  n_rep <- length(values)
  mean_value <- mean(values)
  if (n_rep >= 2L) {
    half_width <- qt(0.975, df = n_rep - 1L) * sd(values) / sqrt(n_rep)
  } else {
    half_width <- NA_real_
  }
  data.frame(
    genotype = z$genotype[[1]], n_biological_replicates = n_rep,
    intact_ratio_mean = mean_value,
    ci_low = ifelse(is.na(half_width), NA_real_, max(0, mean_value - half_width)),
    ci_high = ifelse(is.na(half_width), NA_real_, min(1, mean_value + half_width)),
    stringsAsFactors = FALSE
  )
})

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 1252-1252.
ratio_summary <- do.call(rbind, ratio_rows)

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 1253-1253.
rownames(ratio_summary) <- NULL

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 1393-1393.
write.csv(dat, file.path(table_dir, "IFA_processed_replicates.csv"), row.names = FALSE)

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 1394-1394.
write_table(summary,"IFA_genotype_summary.csv")

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 1395-1395.
write.csv(ratio_summary, file.path(table_dir, "IFA_intact_ratio_95CI.csv"), row.names = FALSE)

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 1396-1396.
write.csv(pcoa_data, file.path(table_dir, "IFA_Gower_PCoA_coordinates.csv"), row.names = FALSE)

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 1397-1401.
write.csv(
  pcoa_feature_contribution,
  file.path(table_dir, "IFA_PCoA_feature_contributions.csv"),
  row.names = FALSE
)

# Adapted from Fig3_ICAT_neighboring/03_code/localization_perturbation/ICAT_localization_pertubation_analysis.R, lines 1402-1402.
write.csv(as.matrix(gower), file.path(table_dir, "IFA_Gower_distance_matrix.csv"))

write_table(data.frame(axis=seq_along(pcoa$eig),eigenvalue=pcoa$eig,positive_variance_percent=variance_percent),"IFA_PCoA_eigenvalues.csv")
write_table(data.frame(genotype=hc$labels[hc$order],cluster_order=seq_along(hc$order)),"IFA_clustering_order.csv")
