# External localization input

`localization_input` is a CSV or workbook. Workbook sheet/skip/range can be set in `tables.localization_input`; the original workbook used sheet Data. A current main source-data workbook can instead use sheet Fig_3b. `columns.localization_input` can map canonical names to supplied headers.

Required fields: biological_replicate, genotype, primary_perturbation_target, target_module, total_cells, intact_n, altered_n, lost_n, unscorable_n, expected_icat_effect, conoid_body_status, icmt_status, bridge_status, rhoptry_status, icat_total_signal_status, wb_abundance_ratio; the apical-ring field is apical_polar_ring_status or apical_ring_status. Blank trailing template rows are excluded using the original completed-record rule. Genotype + biological_replicate must identify a completed record uniquely.

Original count checks, status coding and missing-status handling are retained. In particular, statuses unknown to the original dictionary remain missing rather than being assigned new scores. Counts use scored cells as their original denominator. The original 0.005 compositional pseudocount, ILR transformation, nonconstant-feature selection, Gower distance, average-linkage clustering and additive-corrected two-axis PCoA are preserved. The predefined nine-genotype cohort/order is retained; absent expected genotypes cause the original explicit error.

Outputs are processed replicate records, genotype summaries, intact-ratio confidence intervals, Gower distances, PCoA coordinates/eigenvalues, feature contributions and clustering order. List-valued descriptive annotations are serialized with semicolons so CSV remains parseable; this does not affect numerical analysis. Icons, enclosures, dendrogram drawings and all plots are excluded.
