suppressPackageStartupMessages({library(dplyr);library(tidyr);library(readr);library(readxl);library(stringr)})
input_dir <- input_path("identification_directory",directory=TRUE)

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 45-50.
canonical_gene_id <- function(x) {
  x <- trimws(as.character(x))
  x <- sub("^TGGT1_", "TGME49_", x)
  x <- sub(" \\[.*$", "", x)
  sub("(?<=[0-9])[AB]$", "", x, perl = TRUE)
}

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 52-56.
numeric_matrix <- function(frame) {
  as.matrix(data.frame(lapply(frame, function(x) {
    suppressWarnings(as.numeric(gsub(",", "", as.character(x))))
  })))
}

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 58-61.
safe_welch <- function(a, b) {
  if (any(!is.finite(c(a, b))) || length(unique(c(a, b))) < 2) return(1)
  tryCatch(t.test(a, b, var.equal = FALSE)$p.value, error = function(e) 1)
}

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 63-67.
safe_min <- function(x) {
  x <- x[is.finite(x)]
  if (!length(x)) return(NA_real_)
  min(x)
}

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 69-73.
safe_mean <- function(x) {
  x <- x[is.finite(x)]
  if (!length(x)) return(NA_real_)
  mean(x)
}

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 75-117.
read_hyperlopit <- function(path) {
  lines <- readLines(path, warn = FALSE, encoding = "UTF-8")
  header <- strsplit(lines[1], ",", fixed = TRUE)[[1]]
  header[1] <- "GeneID"
  expected <- length(header)

  parse_line <- function(line) {
    fields <- strsplit(line, ",", fixed = TRUE)[[1]]
    if (length(fields) > expected) {
      extra <- length(fields) - expected
      fields <- c(
        fields[1:32],
        paste(fields[33:(33 + extra)], collapse = ","),
        fields[(34 + extra):length(fields)]
      )
    }
    if (length(fields) < expected) {
      fields <- c(fields, rep("", expected - length(fields)))
    }
    if (length(fields) != expected) {
      stop("Unable to repair a HyperLOPIT row with ", length(fields), " fields")
    }
    fields
  }

  parsed <- lapply(lines[-1], parse_line)
  frame <- as.data.frame(do.call(rbind, parsed), stringsAsFactors = FALSE)
  names(frame) <- header
  frame$GeneID <- canonical_gene_id(frame$GeneID)

  keep <- c(
    "GeneID", "Description", "tagm.mcmc.allocation",
    "tagm.mcmc.probability", "tagm.mcmc.joint.apical.1",
    "tagm.mcmc.joint.apical.2", "tagm.mcmc.joint.micronemes",
    "tagm.mcmc.joint.tubulin.cytoskeleton"
  )
  frame <- frame[, keep]
  numeric_columns <- setdiff(keep, c("GeneID", "Description", "tagm.mcmc.allocation"))
  frame[numeric_columns] <- lapply(frame[numeric_columns], function(x) {
    suppressWarnings(as.numeric(x))
  })
  frame %>% distinct(GeneID, .keep_all = TRUE)
}

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 123-126.
cf5 <- read.csv(
  file.path(input_dir, "CF5_Normalized spec count.csv"),
  check.names = FALSE, stringsAsFactors = FALSE
)

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 127-127.
if(ncol(cf5)<8L) stop("CF5 spectral-count input needs two ID columns and six sample columns.")
names(cf5)[1:2] <- c("TGGT1_ID", "GeneID")

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 128-128.
cf5$GeneID <- canonical_gene_id(cf5$GeneID)
if(anyDuplicated(cf5$GeneID)) message("Duplicate canonical gene IDs are collapsed by the original descending-enrichment rule.")

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 129-129.
cf5 <- cf5[grepl("^TGME49_[0-9]+$", cf5$GeneID), ]

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 131-131.
cf5_values <- numeric_matrix(cf5[, 3:8])

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 132-132.
valid <- apply(cf5_values, 1, function(x) all(is.finite(x) & x > 0))

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 133-133.
cf5 <- cf5[valid, ]

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 134-134.
cf5_values <- cf5_values[valid, , drop = FALSE]

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 136-136.
cf5_bait_log <- log2(cf5_values[, 1:3, drop = FALSE])

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 137-137.
cf5_control_log <- log2(cf5_values[, 4:6, drop = FALSE])

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 138-138.
cf5$CF5_log2FC <- rowMeans(cf5_bait_log) - rowMeans(cf5_control_log)

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 139-141.
cf5$CF5_p_value <- vapply(seq_len(nrow(cf5)), function(i) {
  safe_welch(cf5_bait_log[i, ], cf5_control_log[i, ])
}, numeric(1))

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 142-142.
cf5$CF5_mean_normalized_spectral_count <- rowMeans(cf5_values[, 1:3, drop = FALSE])

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 143-143.
cf5$Cyto_mean_normalized_spectral_count <- rowMeans(cf5_values[, 4:6, drop = FALSE])

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 145-147.
cf5 <- cf5 %>%
  arrange(desc(CF5_log2FC)) %>%
  distinct(GeneID, .keep_all = TRUE)

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 148-148.
cf5$CF5_FDR <- p.adjust(cf5$CF5_p_value, method = "BH")

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 149-149.
cf5$CF5_fold_rank <- rank(-cf5$CF5_log2FC, ties.method = "min")

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 151-154.
cf5_peptides <- read.csv(
  file.path(input_dir, "CF5_Total unique peptide.csv"),
  check.names = FALSE, stringsAsFactors = FALSE
)

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 155-155.
if(ncol(cf5_peptides)<7L) stop("CF5 peptide input needs a gene ID and six sample columns.")
names(cf5_peptides)[1] <- "GeneID"

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 156-156.
cf5_peptides$GeneID <- canonical_gene_id(cf5_peptides$GeneID)

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 157-157.
cf5_peptides <- cf5_peptides[grepl("^TGME49_[0-9]+$", cf5_peptides$GeneID), ]

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 158-158.
cf5_peptide_values <- numeric_matrix(cf5_peptides[, 2:7])

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 159-161.
cf5_peptides$CF5_mean_unique_peptides <- rowMeans(
  cf5_peptide_values[, 1:3, drop = FALSE], na.rm = TRUE
)

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 162-164.
cf5_peptides$Cyto_mean_unique_peptides <- rowMeans(
  cf5_peptide_values[, 4:6, drop = FALSE], na.rm = TRUE
)

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 165-171.
cf5_peptides <- cf5_peptides %>%
  group_by(GeneID) %>%
  summarise(
    CF5_mean_unique_peptides = max(CF5_mean_unique_peptides, na.rm = TRUE),
    Cyto_mean_unique_peptides = max(Cyto_mean_unique_peptides, na.rm = TRUE),
    .groups = "drop"
  )

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 172-172.
cf5 <- left_join(cf5, cf5_peptides, by = "GeneID")

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 178-181.
long <- read.csv(
  file.path(input_dir, "Long_Datasets_Combined_intensity.csv"),
  check.names = FALSE, stringsAsFactors = FALSE
)

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 182-182.
long$GeneID <- canonical_gene_id(long$`Accession Number`)

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 183-183.
long_values <- numeric_matrix(long[, 11:18])

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 184-185.
long$MyoH_log2FC <- rowMeans(log2(long_values[, 1:2, drop = FALSE] + 1)) -
  rowMeans(log2(long_values[, 5:8, drop = FALSE] + 1))

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 186-187.
long$CPH1_log2FC <- rowMeans(log2(long_values[, 3:4, drop = FALSE] + 1)) -
  rowMeans(log2(long_values[, 5:8, drop = FALSE] + 1))

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 188-188.
long$MyoH_mean_intensity <- rowMeans(long_values[, 1:2, drop = FALSE])

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 189-189.
long$CPH1_mean_intensity <- rowMeans(long_values[, 3:4, drop = FALSE])

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 190-190.
long$RH_mean_intensity <- rowMeans(long_values[, 5:8, drop = FALSE])

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 192-199.
long <- long %>%
  filter(grepl("^TGME49_[0-9]+$", GeneID)) %>%
  select(
    GeneID, MyoH_log2FC, CPH1_log2FC,
    MyoH_mean_intensity, CPH1_mean_intensity, RH_mean_intensity
  ) %>%
  group_by(GeneID) %>%
  summarise(across(where(is.numeric), ~ max(.x, na.rm = TRUE)), .groups = "drop")

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 201-204.
long_peptides <- read.csv(
  file.path(input_dir, "Long_Datasets_Combined_peptide#.csv"),
  check.names = FALSE, stringsAsFactors = FALSE
)

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 205-205.
long_peptides$GeneID <- canonical_gene_id(long_peptides$`Accession Number`)

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 206-206.
long_peptide_values <- numeric_matrix(long_peptides[, 11:18])

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 207-209.
long_peptides$MyoH_mean_peptides <- rowMeans(
  long_peptide_values[, 1:2, drop = FALSE], na.rm = TRUE
)

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 210-212.
long_peptides$CPH1_mean_peptides <- rowMeans(
  long_peptide_values[, 3:4, drop = FALSE], na.rm = TRUE
)

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 213-215.
long_peptides$RH_mean_peptides <- rowMeans(
  long_peptide_values[, 5:8, drop = FALSE], na.rm = TRUE
)

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 216-220.
long_peptides <- long_peptides %>%
  filter(grepl("^TGME49_[0-9]+$", GeneID)) %>%
  select(GeneID, MyoH_mean_peptides, CPH1_mean_peptides, RH_mean_peptides) %>%
  group_by(GeneID) %>%
  summarise(across(where(is.numeric), ~ max(.x, na.rm = TRUE)), .groups = "drop")

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 221-221.
long <- left_join(long, long_peptides, by = "GeneID")

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 227-227.
hyper <- read_hyperlopit(file.path(input_dir, "HyperLp.csv"))

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 229-239.
crispr <- suppressWarnings(read_excel(
  file.path(input_dir, "CRISPR rank-ordered genes.xlsx"),
  sheet = "Sheet1"
)) %>%
  rename(
    InputID = ID,
    CRISPR_description = `Protein desprition`,
    CRISPR_short_name = `Protein short name`,
    CRISPR_rank = `Rank numbers`,
    CRISPR_phenotype = `mean phenotype`
  )

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 240-240.
crispr$GeneID <- canonical_gene_id(crispr$InputID)

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 241-253.
crispr <- crispr %>%
  mutate(
    CRISPR_rank = as.numeric(CRISPR_rank),
    CRISPR_phenotype = as.numeric(CRISPR_phenotype)
  ) %>%
  group_by(GeneID) %>%
  summarise(
    CRISPR_input_ids = paste(InputID, collapse = ";"),
    CRISPR_best_rank = safe_min(CRISPR_rank),
    CRISPR_most_negative_phenotype = safe_min(CRISPR_phenotype),
    CRISPR_mean_phenotype = safe_mean(CRISPR_phenotype),
    .groups = "drop"
  )

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 255-258.
kehu <- read.csv(
  file.path(input_dir, "Conoid_265_ke_hu.csv"),
  stringsAsFactors = FALSE
)

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 259-259.
kehu$GeneID <- canonical_gene_id(kehu$Gene.ID)

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 260-262.
kehu <- kehu %>%
  transmute(GeneID, KeHu_conoid_detected = TRUE) %>%
  distinct(GeneID, .keep_all = TRUE)

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 268-272.
master <- cf5 %>%
  left_join(long, by = "GeneID") %>%
  left_join(hyper, by = "GeneID") %>%
  left_join(crispr, by = "GeneID") %>%
  left_join(kehu, by = "GeneID")

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 273-273.
master$KeHu_conoid_detected[is.na(master$KeHu_conoid_detected)] <- FALSE

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 274-278.
master$HyperLOPIT_apical_probability <- pmax(
  master$tagm.mcmc.joint.apical.1,
  master$tagm.mcmc.joint.apical.2,
  na.rm = TRUE
)

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 279-281.
master$HyperLOPIT_apical_probability[
  !is.finite(master$HyperLOPIT_apical_probability)
] <- NA_real_

# Adapted from Fig2_ICAT_identification/03_code/candidate_analysis/Figure2C_integrated_heatmap.R, lines 283-287.
top12 <- master %>%
  filter(CF5_FDR < 0.05) %>%
  arrange(CF5_fold_rank) %>%
  slice_head(n = 12) %>%
  mutate(Display = ifelse(GeneID == "TGME49_252880", "ICAT", GeneID))

write_table(master %>% arrange(CF5_fold_rank),"CF5_all_protein_statistics_and_annotations.csv")
write_table(top12,"CF5_top12_FDR_significant_hits.csv")
