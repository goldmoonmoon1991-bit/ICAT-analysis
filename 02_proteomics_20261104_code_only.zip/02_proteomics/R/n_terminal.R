suppressPackageStartupMessages({library(dplyr);library(tidyr);library(readr);library(readxl);library(stringr)})
loose_file <- input_path("loose_n_terminal_report")
strict_file <- input_path("strict_n_terminal_report")
full_length_file <- input_path("full_length_annotations")
surface_file <- input_path("microneme_surface_annotations")
internal_file <- input_path("microneme_internal_annotations")

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_ICAT_N_term_TurboID_analysis.R, lines 59-64.
clean_gene_id <- function(x) {
  x %>%
    as.character() %>%
    str_replace("^\ufeff", "") %>%
    str_squish()
}

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_ICAT_N_term_TurboID_analysis.R, lines 66-71.
as_flag <- function(x) {
  if (is.logical(x)) {
    return(coalesce(x, FALSE))
  }
  tolower(as.character(x)) %in% c("true", "t", "1", "yes", "y")
}

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_ICAT_N_term_TurboID_analysis.R, lines 73-78.
flag_col <- function(data, col) {
  if (!col %in% names(data)) {
    return(rep(FALSE, nrow(data)))
  }
  as_flag(data[[col]])
}

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_ICAT_N_term_TurboID_analysis.R, lines 80-82.
format_p <- function(x) {
  ifelse(is.na(x), "NA", format.pval(x, digits = 2, eps = 1e-4))
}

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_ICAT_N_term_TurboID_analysis.R, lines 84-94.
auc_from_values <- function(group_values, rest_values) {
  n_group <- length(group_values)
  n_rest <- length(rest_values)
  if (n_group < 1 || n_rest < 1) {
    return(NA_real_)
  }
  values <- c(group_values, rest_values)
  ranks <- rank(values, ties.method = "average")
  w <- sum(ranks[seq_len(n_group)]) - n_group * (n_group + 1) / 2
  w / (n_group * n_rest)
}

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_ICAT_N_term_TurboID_analysis.R, lines 96-101.
safe_wilcox_greater <- function(group_values, rest_values) {
  if (length(group_values) < 2 || length(rest_values) < 2) {
    return(NA_real_)
  }
  suppressWarnings(wilcox.test(group_values, rest_values, alternative = "greater", exact = FALSE)$p.value)
}

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_ICAT_N_term_TurboID_analysis.R, lines 103-113.
read_microneme_list <- function(path, class_label) {
  readr::read_csv(path, show_col_types = FALSE) %>%
    mutate(gene = clean_gene_id(Gene_ID)) %>%
    transmute(
      gene,
      display_name = str_squish(Gene_Name),
      microneme_class = class_label
    ) %>%
    filter(!is.na(gene), gene != "") %>%
    distinct(gene, .keep_all = TRUE)
}

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_ICAT_N_term_TurboID_analysis.R, lines 115-159.
read_proteome_discoverer_text <- function(path, threshold_label) {
  raw <- suppressWarnings(
    readr::read_tsv(
      path,
      skip = 3,
      show_col_types = FALSE,
      name_repair = "unique"
    )
  )
  protein_col <- names(raw)[str_detect(names(raw), "^Identified Proteins")]
  if (!length(protein_col)) {
    stop("Could not find Identified Proteins column in ", path)
  }
  protein_col <- protein_col[[1]]

  parse_number_safe <- function(x) readr::parse_number(as.character(x), locale = readr::locale(grouping_mark = ","))

  raw %>%
    transmute(
      source_threshold = threshold_label,
      row_id = suppressWarnings(as.integer(.data[["#"]])),
      protein_description = as.character(.data[[protein_col]]),
      accession_number = as.character(.data[["Accession Number"]]),
      molecular_weight = as.character(.data[["Molecular Weight"]]),
      gene = clean_gene_id(str_extract(protein_description, "TGME49_[0-9]+")),
      gene_product = str_squish(str_match(protein_description, "gene_product=([^|]+)")[, 2]),
      PG1 = parse_number_safe(.data[["PG1"]]),
      PG2 = parse_number_safe(.data[["PG2"]]),
      PG3 = parse_number_safe(.data[["PG3"]]),
      PG4 = parse_number_safe(.data[["PG4"]])
    ) %>%
    filter(!is.na(gene), gene != "") %>%
    group_by(gene) %>%
    summarise(
      source_threshold = first(source_threshold),
      accession_number = first(na.omit(accession_number)),
      gene_product = first(na.omit(gene_product)),
      molecular_weight = first(na.omit(molecular_weight)),
      PG1 = sum(PG1, na.rm = TRUE),
      PG2 = sum(PG2, na.rm = TRUE),
      PG3 = sum(PG3, na.rm = TRUE),
      PG4 = sum(PG4, na.rm = TRUE),
      .groups = "drop"
    )
}

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_ICAT_N_term_TurboID_analysis.R, lines 161-161.
surface_reference <- read_microneme_list(surface_file, "Surface")

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_ICAT_N_term_TurboID_analysis.R, lines 162-162.
internal_reference <- read_microneme_list(internal_file, "Internal")

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_ICAT_N_term_TurboID_analysis.R, lines 163-164.
microneme_reference <- bind_rows(surface_reference, internal_reference) %>%
  distinct(gene, .keep_all = TRUE)

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_ICAT_N_term_TurboID_analysis.R, lines 166-178.
full_annotation <- readr::read_csv(full_length_file, show_col_types = FALSE) %>%
  mutate(
    gene = clean_gene_id(gene),
    hyperlp_allocation = as.character(hyperlp_allocation),
    gene_product_full = as.character(gene_product),
    hyperlp_description = as.character(hyperlp_description),
    apical_flag = flag_col(., "apical_flag"),
    microneme_flag = flag_col(., "microneme_flag"),
    rhoptry_flag = flag_col(., "rhoptry_flag"),
    dense_granule_flag = flag_col(., "dense_granule_flag"),
    imc_or_cytoskeleton_flag = flag_col(., "imc_or_cytoskeleton_flag")
  ) %>%
  distinct(gene, .keep_all = TRUE)

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_ICAT_N_term_TurboID_analysis.R, lines 180-180.
loose_n <- read_proteome_discoverer_text(loose_file, "F1-1_loose")

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_ICAT_N_term_TurboID_analysis.R, lines 181-182.
strict_n <- read_proteome_discoverer_text(strict_file, "F1-2_strict") %>%
  select(gene, strict_detected = source_threshold)

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_ICAT_N_term_TurboID_analysis.R, lines 184-186.
nonzero_values <- loose_n %>%
  select(PG1, PG2, PG3, PG4) %>%
  unlist(use.names = FALSE)

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_ICAT_N_term_TurboID_analysis.R, lines 187-187.
nonzero_values <- nonzero_values[is.finite(nonzero_values) & nonzero_values > 0]

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_ICAT_N_term_TurboID_analysis.R, lines 188-188.
pseudocount <- min(nonzero_values, na.rm = TRUE) / 2

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_ICAT_N_term_TurboID_analysis.R, lines 190-236.
icat_n_quant <- loose_n %>%
  left_join(strict_n %>% mutate(strict_detected = TRUE), by = "gene") %>%
  mutate(strict_detected = coalesce(strict_detected, FALSE)) %>%
  left_join(
    full_annotation %>%
      select(
        gene,
        hyperlp_allocation,
        hyperlp_description,
        gene_product_full,
        apical_flag,
        microneme_flag,
        rhoptry_flag,
        dense_granule_flag,
        imc_or_cytoskeleton_flag
      ),
    by = "gene"
  ) %>%
  mutate(
    gene_product = coalesce(gene_product, gene_product_full),
    exp1_log2_N_vs_cyto = log2((PG2 + pseudocount) / (PG1 + pseudocount)),
    exp2_log2_N_vs_cyto = log2((PG4 + pseudocount) / (PG3 + pseudocount)),
    mean_log2_N_vs_cyto = (exp1_log2_N_vs_cyto + exp2_log2_N_vs_cyto) / 2,
    min_log2_N_vs_cyto = pmin(exp1_log2_N_vs_cyto, exp2_log2_N_vs_cyto),
    experiments_N_enriched = (exp1_log2_N_vs_cyto > 0) + (exp2_log2_N_vs_cyto > 0),
    samples_detected = (PG1 > 0) + (PG2 > 0) + (PG3 > 0) + (PG4 > 0),
    text_for_annotation = str_to_lower(paste(
      coalesce(gene_product, ""),
      coalesce(hyperlp_description, ""),
      coalesce(hyperlp_allocation, ""),
      sep = " | "
    )),
    conoid_core_keyword = str_detect(
      text_for_annotation,
      "conoid|intraconoidal|preconoidal|icmap|pcr[0-9]|tlap|morn|centrin|sas6|doublecortin|dcx|mapm|spmt|apical polar"
    ),
    conoid_broad = conoid_core_keyword | apical_flag | imc_or_cytoskeleton_flag,
    microneme_surface_curated = gene %in% surface_reference$gene,
    microneme_internal_curated = gene %in% internal_reference$gene,
    microneme_curated = gene %in% microneme_reference$gene,
    microneme_any = microneme_curated | microneme_flag | str_detect(text_for_annotation, "microneme|micronemal|\\bmic[0-9]|ama1|plp1"),
    apical_secretory_or_cytoskeleton = conoid_broad | microneme_any | rhoptry_flag | dense_granule_flag,
    rank_N_desc = rank(-mean_log2_N_vs_cyto, ties.method = "first"),
    rank_fraction_N = rank_N_desc / n(),
    enrichment_percentile_N = 1 - (rank_N_desc - 0.5) / n()
  ) %>%
  arrange(rank_N_desc)

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_ICAT_N_term_TurboID_analysis.R, lines 238-261.
full_length_quant <- full_annotation %>%
  filter(as_flag(science_peptide_filter), is.finite(mean_log2_rapa_vs_control)) %>%
  mutate(
    text_for_annotation = str_to_lower(paste(
      coalesce(gene_product_full, ""),
      coalesce(hyperlp_description, ""),
      coalesce(hyperlp_allocation, ""),
      sep = " | "
    )),
    conoid_core_keyword = str_detect(
      text_for_annotation,
      "conoid|intraconoidal|preconoidal|icmap|pcr[0-9]|tlap|morn|centrin|sas6|doublecortin|dcx|mapm|spmt|apical polar"
    ),
    conoid_broad = conoid_core_keyword | apical_flag | imc_or_cytoskeleton_flag,
    microneme_surface_curated = gene %in% surface_reference$gene,
    microneme_internal_curated = gene %in% internal_reference$gene,
    microneme_curated = gene %in% microneme_reference$gene,
    microneme_any = microneme_curated | microneme_flag | str_detect(text_for_annotation, "microneme|micronemal|\\bmic[0-9]|ama1|plp1"),
    apical_secretory_or_cytoskeleton = conoid_broad | microneme_any | rhoptry_flag | dense_granule_flag,
    rank_FL_desc = rank(-mean_log2_rapa_vs_control, ties.method = "first"),
    rank_fraction_FL = rank_FL_desc / n(),
    enrichment_percentile_FL = 1 - (rank_FL_desc - 0.5) / n()
  ) %>%
  arrange(rank_FL_desc)

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_ICAT_N_term_TurboID_analysis.R, lines 271-280.
category_definitions <- tibble::tribble(
  ~category_id, ~category_label, ~category_short_label,
  "conoid_core_keyword", "Conoid core keyword", "Conoid core",
  "conoid_broad", "Conoid / apical cytoskeleton", "Conoid broad",
  "microneme_surface_curated", "Microneme surface curated", "Surface MIC",
  "microneme_any", "Microneme all", "All microneme",
  "microneme_internal_curated", "Microneme internal curated", "Internal MIC",
  "rhoptry_flag", "Rhoptry", "Rhoptry",
  "dense_granule_flag", "Dense granule", "Dense granule"
)

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_ICAT_N_term_TurboID_analysis.R, lines 282-306.
make_dataset_long <- function(data, dataset_id, dataset_label, score_col, rank_col, pct_col) {
  bind_rows(lapply(seq_len(nrow(category_definitions)), function(i) {
    category <- category_definitions[i, ]
    if (!category$category_id %in% names(data)) {
      return(tibble::tibble())
    }
    data %>%
      transmute(
        dataset_id,
        dataset_label,
        gene,
        accession_number = if ("accession_number" %in% names(data)) accession_number else NA_character_,
        gene_product = if ("gene_product" %in% names(data)) gene_product else gene_product_full,
        hyperlp_allocation,
        score = .data[[score_col]],
        rank_fraction = .data[[rank_col]],
        enrichment_percentile = .data[[pct_col]],
        category_id = category$category_id,
        category_label = category$category_label,
        category_short_label = category$category_short_label,
        in_category = .data[[category$category_id]]
      ) %>%
      filter(in_category, is.finite(score))
  }))
}

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_ICAT_N_term_TurboID_analysis.R, lines 308-311.
dataset_members <- bind_rows(
  make_dataset_long(icat_n_quant, "ICAT_N", "ICAT N-term", "mean_log2_N_vs_cyto", "rank_fraction_N", "enrichment_percentile_N"),
  make_dataset_long(full_length_quant, "ICAT_FL", "Full-length ICAT", "mean_log2_rapa_vs_control", "rank_fraction_FL", "enrichment_percentile_FL")
)

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_ICAT_N_term_TurboID_analysis.R, lines 313-318.
all_dataset_scores <- bind_rows(
  icat_n_quant %>%
    transmute(dataset_id = "ICAT_N", dataset_label = "ICAT N-term", gene, score = mean_log2_N_vs_cyto),
  full_length_quant %>%
    transmute(dataset_id = "ICAT_FL", dataset_label = "Full-length ICAT", gene, score = mean_log2_rapa_vs_control)
)

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_ICAT_N_term_TurboID_analysis.R, lines 320-348.
category_tests <- bind_rows(lapply(unique(all_dataset_scores$dataset_id), function(dataset) {
  data <- if (dataset == "ICAT_N") icat_n_quant else full_length_quant
  score_col <- if (dataset == "ICAT_N") "mean_log2_N_vs_cyto" else "mean_log2_rapa_vs_control"
  dataset_label <- if (dataset == "ICAT_N") "ICAT N-term" else "Full-length ICAT"
  bind_rows(lapply(seq_len(nrow(category_definitions)), function(i) {
    category <- category_definitions[i, ]
    if (!category$category_id %in% names(data)) {
      return(tibble::tibble())
    }
    feature <- data[[category$category_id]] %in% TRUE
    group_values <- data[[score_col]][feature & is.finite(data[[score_col]])]
    rest_values <- data[[score_col]][!feature & is.finite(data[[score_col]])]
    tibble::tibble(
      dataset_id = dataset,
      dataset_label = dataset_label,
      category_id = category$category_id,
      category_label = category$category_label,
      category_short_label = category$category_short_label,
      n = length(group_values),
      background_n = length(rest_values),
      median_score = median(group_values, na.rm = TRUE),
      background_median_score = median(rest_values, na.rm = TRUE),
      median_shift = median_score - background_median_score,
      AUC = auc_from_values(group_values, rest_values),
      wilcox_p = safe_wilcox_greater(group_values, rest_values)
    )
  })) %>%
    mutate(wilcox_fdr_bh = p.adjust(wilcox_p, method = "BH"))
}))

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_ICAT_N_term_TurboID_analysis.R, lines 350-379.
top_rank_recovery <- bind_rows(lapply(c(0.05, 0.10, 0.20, 0.30), function(frac) {
  bind_rows(
    category_definitions %>%
      rowwise() %>%
      mutate(
        dataset_id = "ICAT_N",
        dataset_label = "ICAT N-term",
        top_fraction = frac,
        top_n = ceiling(nrow(icat_n_quant) * frac),
        category_n = sum(icat_n_quant[[category_id]] %in% TRUE, na.rm = TRUE),
        recovered_n = sum(icat_n_quant[[category_id]] %in% TRUE & icat_n_quant$rank_N_desc <= top_n, na.rm = TRUE),
        recovered_fraction = if_else(category_n > 0, recovered_n / category_n, NA_real_),
        recovery_over_random = recovered_fraction / top_fraction
      ) %>%
      ungroup(),
    category_definitions %>%
      rowwise() %>%
      mutate(
        dataset_id = "ICAT_FL",
        dataset_label = "Full-length ICAT",
        top_fraction = frac,
        top_n = ceiling(nrow(full_length_quant) * frac),
        category_n = sum(full_length_quant[[category_id]] %in% TRUE, na.rm = TRUE),
        recovered_n = sum(full_length_quant[[category_id]] %in% TRUE & full_length_quant$rank_FL_desc <= top_n, na.rm = TRUE),
        recovered_fraction = if_else(category_n > 0, recovered_n / category_n, NA_real_),
        recovery_over_random = recovered_fraction / top_fraction
      ) %>%
      ungroup()
  )
}))

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_ICAT_N_term_TurboID_analysis.R, lines 381-414.
top_candidates <- icat_n_quant %>%
  filter(conoid_broad | microneme_any | rank_N_desc <= 100) %>%
  mutate(
    hit_focus = case_when(
      conoid_core_keyword ~ "conoid_core",
      conoid_broad ~ "conoid_broad",
      microneme_surface_curated ~ "microneme_surface",
      microneme_any ~ "microneme",
      TRUE ~ "top100_other"
    )
  ) %>%
  arrange(rank_N_desc) %>%
  select(
    rank_N_desc,
    gene,
    accession_number,
    gene_product,
    hyperlp_allocation,
    PG1,
    PG2,
    PG3,
    PG4,
    exp1_log2_N_vs_cyto,
    exp2_log2_N_vs_cyto,
    mean_log2_N_vs_cyto,
    min_log2_N_vs_cyto,
    strict_detected,
    conoid_core_keyword,
    conoid_broad,
    microneme_surface_curated,
    microneme_internal_curated,
    microneme_any,
    hit_focus
  )

write_table(icat_n_quant,"Figure6_ICAT_N_term_quantified_proteins_annotated.csv")
write_table(category_tests,"Figure6_ICAT_N_term_category_tests.csv")
write_table(top_rank_recovery,"Figure6_ICAT_N_term_top_rank_recovery.csv")
write_table(dataset_members,"Figure6_ICAT_N_term_dataset_members.csv")
write_table(top_candidates,"Figure6_ICAT_N_term_top_candidates.csv")
