suppressPackageStartupMessages({library(dplyr);library(tidyr);library(readr);library(readxl);library(stringr)})

cf5_raw <- read_input_table("spectral_counts")
peptides <- read_input_table("unique_peptides")
if(ncol(cf5_raw)<8||ncol(peptides)<7) stop("QC requires the original six-sample column layout.")
numeric_matrix <- function(frame) {mat <- as.matrix(data.frame(lapply(frame,function(x)suppressWarnings(as.numeric(gsub(",","",as.character(x)))))));storage.mode(mat)<-"numeric";mat}
sample_display <- c("CF5-1","CF5-2","CF5-3","Cyto-1","Cyto-2","Cyto-3")
sample_group <- c(rep("CF5 bait",3),rep("cytosol",3))
counts <- numeric_matrix(cf5_raw[,3:8]);colnames(counts)<-sample_display
counts <- counts[rowSums(is.finite(counts))>0,,drop=FALSE]
log_counts <- log2(counts+1)
log_counts <- log_counts[apply(log_counts,1,function(x)stats::sd(x,na.rm=TRUE)>0),,drop=FALSE]
cor_mat <- cor(log_counts,method="pearson",use="pairwise.complete.obs")
hc <- hclust(as.dist(1-cor_mat),method="average")
cor_df <- as.data.frame(as.table(cor_mat),stringsAsFactors=FALSE);names(cor_df)<-c("sample_x","sample_y","pearson_r")
pca_input <- t(log_counts)
if(any(!is.finite(pca_input))) stop("PCA requires finite log-transformed counts.")
pca <- prcomp(pca_input,center=TRUE,scale.=FALSE)
scores <- data.frame(sample=rownames(pca$x),group=sample_group,PC1=pca$x[,1],PC2=pca$x[,2])
write_table(cor_df,"Figure2S1_mass_spec_qc_correlation_matrix.csv")
write_table(scores,"Figure2S1_mass_spec_qc_pca_scores.csv")
peptide_values <- numeric_matrix(peptides[,2:7]);colnames(peptide_values)<-sample_display
write_table(data.frame(sample=sample_display,group=sample_group,detected_proteins_with_unique_peptides=colSums(peptide_values>0,na.rm=TRUE),total_unique_peptides=colSums(peptide_values,na.rm=TRUE)),"Figure2S1_mass_spec_qc_detection_summary.csv")
write_table(data.frame(component=seq_along(pca$sdev),variance_percent=100*pca$sdev^2/sum(pca$sdev^2)),"pca_variance_percent.csv")
write_table(data.frame(sample=sample_display,total_spectra=colSums(counts,na.rm=TRUE)),"sample_totals.csv")
