suppressPackageStartupMessages({library(dplyr);library(tidyr);library(readr);library(readxl);library(stringr)})
# Candidate interpretation, retained as exploratory. Curation is an external input.
n_term_file <- input_path("n_terminal_annotations")
full_length_file <- input_path("full_length_annotations")
internal_diagnostic_file <- input_path("internal_diagnostics")
target_list <- read_input_table("target_annotations",c("gene","protein_label","category","broad_class","list_source"),"gene") %>% select(gene,protein_label,category,broad_class,list_source)

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_ICAT_construct_heatmap_topology_filtered_exploratory.R, lines 78-83.
clean_gene_id <- function(x) {
  x %>%
    as.character() %>%
    str_replace("^\ufeff", "") %>%
    str_squish()
}

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_ICAT_construct_heatmap_topology_filtered_exploratory.R, lines 85-90.
as_flag <- function(x) {
  if (is.logical(x)) {
    return(coalesce(x, FALSE))
  }
  tolower(as.character(x)) %in% c("true", "t", "1", "yes", "y")
}

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_ICAT_construct_heatmap_topology_filtered_exploratory.R, lines 163-170.
n_term <- readr::read_csv(n_term_file, show_col_types = FALSE) %>%
  mutate(gene = clean_gene_id(gene)) %>%
  transmute(
    gene,
    icat_n_log2 = mean_log2_N_vs_cyto,
    icat_n_percentile = enrichment_percentile_N,
    icat_n_quantified = is.finite(mean_log2_N_vs_cyto)
  )

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_ICAT_construct_heatmap_topology_filtered_exploratory.R, lines 172-187.
full_length <- readr::read_csv(full_length_file, show_col_types = FALSE) %>%
  mutate(
    gene = clean_gene_id(gene),
    science_peptide_filter = as_flag(science_peptide_filter)
  ) %>%
  filter(science_peptide_filter, is.finite(mean_log2_rapa_vs_control)) %>%
  mutate(
    rank_FL_desc = rank(-mean_log2_rapa_vs_control, ties.method = "first"),
    enrichment_percentile_FL = 1 - (rank_FL_desc - 0.5) / n()
  ) %>%
  transmute(
    gene,
    full_length_log2 = mean_log2_rapa_vs_control,
    full_length_percentile = enrichment_percentile_FL,
    full_length_quantified = is.finite(mean_log2_rapa_vs_control)
  )

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_ICAT_construct_heatmap_topology_filtered_exploratory.R, lines 189-201.
internal_diagnostic <- readr::read_csv(internal_diagnostic_file, show_col_types = FALSE) %>%
  mutate(gene = clean_gene_id(gene)) %>%
  transmute(
    gene,
    internal_p4_assessment = possibility4_assessment,
    internal_evidence_class = evidence_class,
    internal_negative_preferred_raw = as_flag(negative_preferred_raw_flag),
    internal_single_bait_only = as_flag(single_bait_only_flag),
    internal_low_preferred_signal = as_flag(low_preferred_signal_flag),
    internal_one_rep_detection = as_flag(one_rep_preferred_detection_flag),
    internal_one_rep_positive = as_flag(one_rep_positive_flag),
    internal_pseudocount_sensitive = as_flag(pseudocount_sensitive_flag)
  )

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_ICAT_construct_heatmap_topology_filtered_exploratory.R, lines 203-219.
heatmap_source <- target_list %>%
  left_join(n_term, by = "gene") %>%
  left_join(full_length, by = "gene") %>%
  left_join(internal_diagnostic, by = "gene") %>%
  mutate(
    icat_n_quantified = coalesce(icat_n_quantified, FALSE),
    full_length_quantified = coalesce(full_length_quantified, FALSE),
    quantified_any = icat_n_quantified | full_length_quantified,
    quantified_both = icat_n_quantified & full_length_quantified,
    preference_delta_FL_minus_N = full_length_percentile - icat_n_percentile,
    preference_label = case_when(
      !quantified_both ~ "single bait only",
      preference_delta_FL_minus_N > 0.20 ~ "Full-length-high",
      preference_delta_FL_minus_N < -0.20 ~ "ICAT N-high",
      TRUE ~ "balanced"
    )
  )

# Preserve the original percentile-difference and low-signal interpretation rules.
interpreted <- heatmap_source %>% filter(quantified_any) %>% mutate(
 bias_score=case_when(quantified_both ~ preference_delta_FL_minus_N,full_length_quantified & !icat_n_quantified ~ 0.65,icat_n_quantified & !full_length_quantified ~ -0.65,TRUE ~ NA_real_),
 preferred_raw_log2=case_when(is.finite(bias_score)&bias_score>0 ~ full_length_log2,is.finite(bias_score)&bias_score<0 ~ icat_n_log2,TRUE ~ NA_real_),
 bias_negative_raw_preferred=is.finite(bias_score)&bias_score!=0&is.finite(preferred_raw_log2)&preferred_raw_log2<0,
 internal_p4_uninterpretable=broad_class=="Microneme internal" & is.finite(bias_score)&bias_score!=0 & (coalesce(internal_p4_assessment=="consistent_with_possibility_4",FALSE)|coalesce(internal_negative_preferred_raw,FALSE)|coalesce(internal_single_bait_only,FALSE)|coalesce(internal_low_preferred_signal,FALSE)|coalesce(internal_one_rep_detection,FALSE)|coalesce(internal_pseudocount_sensitive,FALSE)),
 bias_uninterpretable=bias_negative_raw_preferred|internal_p4_uninterpretable,
 interpreted_preference=case_when(bias_uninterpretable ~ "not_interpreted",!is.finite(bias_score) ~ "not_interpreted",bias_score>0.20 ~ "FL_high",bias_score< -0.20 ~ "N_high",TRUE ~ "balanced"))
write_table(heatmap_source,"construct_preference_source.csv")
write_table(interpreted,"construct_preference_interpretation_exploratory.csv")
write_table(interpreted %>% count(broad_class,interpreted_preference,name="n_proteins"),"construct_preference_summary_exploratory.csv")
