suppressPackageStartupMessages({library(dplyr);library(tidyr);library(readr);library(readxl);library(stringr)})

spectra_file <- input_path("spectra_report")
peptide_file <- input_path("peptide_report")
sample_map_file <- input_path("sample_map")
hyperlp_file <- input_path("hyperlopit_annotations")
crispr_file <- input_path("crispr_annotations")

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_interactome_analysis.R, lines 45-48.
preflight_map <- read_input_table("sample_map",c("sample_id","experiment","condition","sample_label"),"sample_id")
assert_unique(preflight_map,"sample_label","sample map")
extract_field <- function(x, key) {
  value <- str_match(x, paste0("\\b", key, "=([^|]+)"))[, 2]
  str_squish(value)
}

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_interactome_analysis.R, lines 50-109.
clean_report <- function(path, value_name) {
  table_lines <- readLines(path, warn = FALSE)
  table_lines <- table_lines[-seq_len(3)]
  table_lines <- sub("\\t+$", "", table_lines)
  table_lines <- table_lines[!str_detect(table_lines, "^END OF FILE\\s*$")]

  raw <- readr::read_tsv(
    I(paste(table_lines, collapse = "\n")),
    col_types = cols(.default = col_character()),
    name_repair = "minimal",
    show_col_types = FALSE,
    progress = FALSE
  )

  stopifnot(ncol(raw) >= 15)

  names(raw)[seq_len(11)] <- c(
    "row_id",
    "visible",
    "starred",
    "protein_description",
    "accession_number",
    "alternate_id",
    "molecular_weight",
    "protein_grouping_ambiguity",
    "quantitative_variance_1",
    "quantitative_variance_2",
    "taxonomy"
  )

  sample_count <- ncol(raw) - 11
  names(raw)[12:ncol(raw)] <- paste0("sample_", seq_len(sample_count))

  raw %>%
    mutate(
      row_id = as.integer(row_id),
      visible = visible == "true",
      protein_grouping_ambiguity = protein_grouping_ambiguity == "true",
      molecular_weight_kda = parse_number(molecular_weight),
      quantitative_variance_1_percent = parse_number(quantitative_variance_1),
      quantitative_variance_2_percent = parse_number(quantitative_variance_2),
      transcript = extract_field(protein_description, "transcript"),
      gene = extract_field(protein_description, "gene"),
      organism = extract_field(protein_description, "organism"),
      gene_product = extract_field(protein_description, "gene_product"),
      transcript_product = extract_field(protein_description, "transcript_product"),
      location = extract_field(protein_description, "location"),
      protein_length_aa = as.integer(extract_field(protein_description, "protein_length")),
      sequence_SO = extract_field(protein_description, "sequence_SO"),
      SO = extract_field(protein_description, "SO"),
      is_pseudo = extract_field(protein_description, "is_pseudo") == "true"
    ) %>%
    mutate(across(starts_with("sample_"), readr::parse_number)) %>%
    pivot_longer(
      cols = starts_with("sample_"),
      names_to = "sample_id",
      values_to = value_name
    ) %>%
    mutate(sample_id = str_remove(sample_id, "^sample_"))
}

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_interactome_analysis.R, lines 111-111.
spectra_long <- clean_report(spectra_file, "normalized_total_spectra")

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_interactome_analysis.R, lines 112-112.
peptide_long <- clean_report(peptide_file, "unique_peptide_count")

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_interactome_analysis.R, lines 114-122.
sample_map <- readr::read_csv(
  sample_map_file,
  col_types = cols(.default = col_character()),
  show_col_types = FALSE
) %>%
  mutate(
    condition = factor(condition, levels = c("control", "rapa")),
    sample_label = factor(sample_label, levels = sample_label)
  )

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_interactome_analysis.R, lines 124-148.
assert_unique(sample_map,"sample_id","sample map")
annotation_cols <- c(
  "row_id",
  "visible",
  "starred",
  "protein_description",
  "accession_number",
  "alternate_id",
  "molecular_weight",
  "protein_grouping_ambiguity",
  "taxonomy",
  "molecular_weight_kda",
  "quantitative_variance_1_percent",
  "quantitative_variance_2_percent",
  "transcript",
  "gene",
  "organism",
  "gene_product",
  "transcript_product",
  "location",
  "protein_length_aa",
  "sequence_SO",
  "SO",
  "is_pseudo",
  "sample_id"
)

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_interactome_analysis.R, lines 150-162.
merged_long <- spectra_long %>%
  select(any_of(annotation_cols), normalized_total_spectra) %>%
  full_join(
    peptide_long %>%
      select(row_id, accession_number, sample_id, unique_peptide_count),
    by = c("row_id", "accession_number", "sample_id")
  ) %>%
  mutate(
    normalized_total_spectra = replace_na(normalized_total_spectra, 0),
    unique_peptide_count = replace_na(unique_peptide_count, 0)
  ) %>%
  left_join(sample_map, by = "sample_id") %>%
  relocate(experiment, condition, sample_label, .after = sample_id)

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_interactome_analysis.R, lines 164-164.
sample_count <- n_distinct(merged_long$sample_id)

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_interactome_analysis.R, lines 165-165.
experiment_count <- n_distinct(sample_map$experiment)

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_interactome_analysis.R, lines 166-166.
spectra_pseudocount <- min(merged_long$normalized_total_spectra[merged_long$normalized_total_spectra > 0], na.rm = TRUE) / 2

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_interactome_analysis.R, lines 168-187.
wide_source <- merged_long %>%
  select(
    row_id,
    accession_number,
    gene,
    transcript,
    gene_product,
    molecular_weight_kda,
    taxonomy,
    protein_grouping_ambiguity,
    sample_label,
    normalized_total_spectra,
    unique_peptide_count
  ) %>%
  pivot_wider(
    names_from = sample_label,
    values_from = c(normalized_total_spectra, unique_peptide_count),
    names_glue = "{.value}_{sample_label}"
  ) %>%
  arrange(row_id)

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_interactome_analysis.R, lines 189-216.
paired_enrichment <- merged_long %>%
  select(
    row_id,
    accession_number,
    gene,
    transcript,
    gene_product,
    molecular_weight_kda,
    taxonomy,
    protein_grouping_ambiguity,
    experiment,
    condition,
    normalized_total_spectra,
    unique_peptide_count
  ) %>%
  pivot_wider(
    names_from = condition,
    values_from = c(normalized_total_spectra, unique_peptide_count),
    values_fill = 0
  ) %>%
  mutate(
    normalized_log2_ratio_rapa_control = log2((normalized_total_spectra_rapa + spectra_pseudocount) / (normalized_total_spectra_control + spectra_pseudocount)),
    significance_b_abundance_proxy = log10(((normalized_total_spectra_rapa + normalized_total_spectra_control) / 2) + spectra_pseudocount),
    rapa_minus_control_spectra = normalized_total_spectra_rapa - normalized_total_spectra_control,
    rapa_peptide_supported = unique_peptide_count_rapa >= 2,
    control_peptide_supported = unique_peptide_count_control >= 2,
    science_peptide_filter_experiment = pmax(unique_peptide_count_rapa, unique_peptide_count_control, na.rm = TRUE) >= 2
  )

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_interactome_analysis.R, lines 218-269.
add_significance_b <- function(data, window_fraction = 0.15, min_window = 101) {
  data <- data %>%
    arrange(significance_b_abundance_proxy)
  n <- nrow(data)
  if (!n) return(data)

  window_size <- min(n, max(min_window, ceiling(n * window_fraction)))
  if (window_size %% 2 == 0 && window_size < n) window_size <- window_size + 1
  half_window <- floor(window_size / 2)
  ratios <- data$normalized_log2_ratio_rapa_control

  global_center <- median(ratios, na.rm = TRUE)
  global_scale <- mad(ratios, center = global_center, constant = 1.4826, na.rm = TRUE)
  if (!is.finite(global_scale) || global_scale <= 0) {
    global_scale <- sd(ratios, na.rm = TRUE)
  }
  if (!is.finite(global_scale) || global_scale <= 0) {
    global_scale <- 1
  }

  local_center <- numeric(n)
  local_scale <- numeric(n)

  for (i in seq_len(n)) {
    lo <- max(1L, i - half_window)
    hi <- min(n, i + half_window)
    if ((hi - lo + 1L) < window_size) {
      if (lo == 1L) hi <- min(n, window_size)
      if (hi == n) lo <- max(1L, n - window_size + 1L)
    }

    local_ratios <- ratios[lo:hi]
    center <- median(local_ratios, na.rm = TRUE)
    scale <- mad(local_ratios, center = center, constant = 1.4826, na.rm = TRUE)
    if (!is.finite(scale) || scale <= 0) scale <- global_scale

    local_center[[i]] <- center
    local_scale[[i]] <- scale
  }

  z <- (ratios - local_center) / local_scale
  p_two_sided <- 2 * pnorm(abs(z), lower.tail = FALSE)

  data %>%
    mutate(
      significance_b_local_center = local_center,
      significance_b_local_scale = local_scale,
      significance_b_z = z,
      significance_b_pvalue = p_two_sided,
      significance_b_fdr_bh = p.adjust(significance_b_pvalue, method = "BH")
    )
}

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_interactome_analysis.R, lines 271-287.
significance_b_results <- paired_enrichment %>%
  filter(science_peptide_filter_experiment) %>%
  group_by(experiment) %>%
  group_split() %>%
  lapply(add_significance_b) %>%
  bind_rows() %>%
  select(
    row_id,
    accession_number,
    experiment,
    significance_b_abundance_proxy,
    significance_b_local_center,
    significance_b_local_scale,
    significance_b_z,
    significance_b_pvalue,
    significance_b_fdr_bh
  )

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_interactome_analysis.R, lines 289-293.
paired_enrichment <- paired_enrichment %>%
  left_join(
    significance_b_results,
    by = c("row_id", "accession_number", "experiment", "significance_b_abundance_proxy")
  )

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_interactome_analysis.R, lines 295-327.
paired_wide <- paired_enrichment %>%
  select(
    row_id,
    accession_number,
    experiment,
    normalized_log2_ratio_rapa_control,
    normalized_total_spectra_control,
    normalized_total_spectra_rapa,
    unique_peptide_count_control,
    unique_peptide_count_rapa,
    rapa_peptide_supported,
    science_peptide_filter_experiment,
    significance_b_abundance_proxy,
    significance_b_z,
    significance_b_pvalue,
    significance_b_fdr_bh
  ) %>%
  pivot_wider(
    names_from = experiment,
    values_from = c(
      normalized_log2_ratio_rapa_control,
      normalized_total_spectra_control,
      normalized_total_spectra_rapa,
      unique_peptide_count_control,
      unique_peptide_count_rapa,
      rapa_peptide_supported,
      science_peptide_filter_experiment,
      significance_b_abundance_proxy,
      significance_b_z,
      significance_b_pvalue,
      significance_b_fdr_bh
    )
  )

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_interactome_analysis.R, lines 329-426.
candidate_summary <- merged_long %>%
  group_by(
    row_id,
    accession_number,
    gene,
    transcript,
    gene_product,
    molecular_weight_kda,
    protein_length_aa,
    taxonomy,
    protein_grouping_ambiguity
  ) %>%
  summarise(
    mean_normalized_total_spectra = mean(normalized_total_spectra, na.rm = TRUE),
    median_normalized_total_spectra = median(normalized_total_spectra, na.rm = TRUE),
    max_normalized_total_spectra = max(normalized_total_spectra, na.rm = TRUE),
    sd_normalized_total_spectra = sd(normalized_total_spectra, na.rm = TRUE),
    cv_percent = if_else(
      mean_normalized_total_spectra > 0,
      100 * sd_normalized_total_spectra / mean_normalized_total_spectra,
      NA_real_
    ),
    mean_unique_peptide_count = mean(unique_peptide_count, na.rm = TRUE),
    min_unique_peptide_count = min(unique_peptide_count, na.rm = TRUE),
    max_unique_peptide_count = max(unique_peptide_count, na.rm = TRUE),
    samples_with_spectra = sum(normalized_total_spectra > 0, na.rm = TRUE),
    samples_with_unique_peptides = sum(unique_peptide_count > 0, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  left_join(paired_wide, by = c("row_id", "accession_number")) %>%
  mutate(
    mean_control_spectra = rowMeans(pick(starts_with("normalized_total_spectra_control_")), na.rm = TRUE),
    mean_rapa_spectra = rowMeans(pick(starts_with("normalized_total_spectra_rapa_")), na.rm = TRUE),
    mean_control_unique_peptides = rowMeans(pick(starts_with("unique_peptide_count_control_")), na.rm = TRUE),
    mean_rapa_unique_peptides = rowMeans(pick(starts_with("unique_peptide_count_rapa_")), na.rm = TRUE),
    exp1_log2_rapa_vs_control = normalized_log2_ratio_rapa_control_exp1,
    exp2_log2_rapa_vs_control = normalized_log2_ratio_rapa_control_exp2,
    mean_log2_rapa_vs_control = rowMeans(pick(exp1_log2_rapa_vs_control, exp2_log2_rapa_vs_control), na.rm = TRUE),
    min_log2_rapa_vs_control = pmin(exp1_log2_rapa_vs_control, exp2_log2_rapa_vs_control, na.rm = TRUE),
    experiments_rapa_enriched = (exp1_log2_rapa_vs_control > 0) + (exp2_log2_rapa_vs_control > 0),
    experiments_with_rapa_peptide_support = rapa_peptide_supported_exp1 + rapa_peptide_supported_exp2,
    experiments_passing_science_peptide_filter = science_peptide_filter_experiment_exp1 + science_peptide_filter_experiment_exp2,
    significance_b_fdr_exp1 = significance_b_fdr_bh_exp1,
    significance_b_fdr_exp2 = significance_b_fdr_bh_exp2,
    significance_b_pvalue_exp1 = significance_b_pvalue_exp1,
    significance_b_pvalue_exp2 = significance_b_pvalue_exp2,
    max_significance_b_fdr = pmax(significance_b_fdr_exp1, significance_b_fdr_exp2, na.rm = TRUE),
    min_significance_b_fdr = pmin(significance_b_fdr_exp1, significance_b_fdr_exp2, na.rm = TRUE),
    fdr_display_bin = case_when(
      max_significance_b_fdr < 1e-10 ~ "<1e-10",
      max_significance_b_fdr < 1e-9 ~ "<1e-9",
      max_significance_b_fdr < 1e-7 ~ "<1e-7",
      max_significance_b_fdr < 1e-6 ~ "<1e-6",
      max_significance_b_fdr < 1e-5 ~ "<1e-5",
      max_significance_b_fdr < 1e-4 ~ "<1e-4",
      max_significance_b_fdr < 1e-3 ~ "<1e-3",
      max_significance_b_fdr < 1e-2 ~ "<1e-2",
      TRUE ~ ">=1e-2"
    ),
    fdr_display_bin = factor(
      fdr_display_bin,
      levels = c("<1e-2", "<1e-3", "<1e-4", "<1e-5", "<1e-6", "<1e-7", "<1e-9", "<1e-10", ">=1e-2")
    ),
    high_confidence_observed = samples_with_spectra == sample_count &
      min_unique_peptide_count >= 2,
    science_peptide_filter = experiments_passing_science_peptide_filter == experiment_count,
    significance_b_fdr_0_01_both_experiments = significance_b_fdr_exp1 < 0.01 &
      significance_b_fdr_exp2 < 0.01,
    reproducible_rapa_enriched = experiments_rapa_enriched == experiment_count,
    rapa_enrichment_candidate = science_peptide_filter &
      reproducible_rapa_enriched &
      significance_b_fdr_0_01_both_experiments,
    exclusion_reason = case_when(
      rapa_enrichment_candidate ~ "FDR < 0.01 in both experiments",
      !science_peptide_filter ~ "Excluded by peptide filter",
      !reproducible_rapa_enriched ~ "Not rapa-enriched in both experiments",
      is.na(significance_b_fdr_exp1) & is.na(significance_b_fdr_exp2) ~ "No Significance B FDR in either experiment",
      is.na(significance_b_fdr_exp1) ~ "No Significance B FDR in exp1",
      is.na(significance_b_fdr_exp2) ~ "No Significance B FDR in exp2",
      significance_b_fdr_exp1 >= 0.01 & significance_b_fdr_exp2 >= 0.01 ~ "FDR >= 0.01 in both experiments",
      significance_b_fdr_exp1 >= 0.01 ~ "FDR >= 0.01 in exp1",
      significance_b_fdr_exp2 >= 0.01 ~ "FDR >= 0.01 in exp2",
      TRUE ~ "Excluded by candidate screen"
    ),
    icat_keyword = str_detect(
      str_to_lower(paste(gene, gene_product, accession_number)),
      "icat|imap|icmt|conoid"
    )
  ) %>%
  arrange(
    desc(rapa_enrichment_candidate),
    max_significance_b_fdr,
    desc(mean_log2_rapa_vs_control),
    desc(mean_rapa_spectra),
    accession_number
  ) %>%
  mutate(candidate_rank = row_number()) %>%
  relocate(candidate_rank)

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_interactome_analysis.R, lines 428-438.
sample_qc <- merged_long %>%
  group_by(sample_id, experiment, condition, sample_label) %>%
  summarise(
    total_normalized_spectra = sum(normalized_total_spectra, na.rm = TRUE),
    proteins_with_spectra = sum(normalized_total_spectra > 0, na.rm = TRUE),
    total_unique_peptide_counts = sum(unique_peptide_count, na.rm = TRUE),
    proteins_with_unique_peptides = sum(unique_peptide_count > 0, na.rm = TRUE),
    median_spectra_detected_proteins = median(normalized_total_spectra[normalized_total_spectra > 0], na.rm = TRUE),
    .groups = "drop"
  ) %>%
  arrange(as.integer(sample_id))

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_interactome_analysis.R, lines 562-562.
hyperlp <- read.csv(hyperlp_file, check.names = FALSE)

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_interactome_analysis.R, lines 563-563.
names(hyperlp)[1] <- "hyperlp_gene_id"

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_interactome_analysis.R, lines 564-592.
known_hyperlp_locations <- c(
  "19S proteasome",
  "20S proteasome",
  "40S ribosome",
  "60S ribosome",
  "apical 1",
  "apical 2",
  "apicoplast",
  "cytosol",
  "dense granules",
  "endomembrane vesicles",
  "ER 1",
  "ER 2",
  "Golgi",
  "IMC",
  "micronemes",
  "mitochondrion - membranes",
  "mitochondrion - soluble",
  "nucleolus",
  "nucleus - chromatin",
  "nucleus - non-chromatin",
  "PM - integral",
  "PM - peripheral 1",
  "PM - peripheral 2",
  "rhoptries 1",
  "rhoptries 2",
  "tubulin cytoskeleton",
  "unknown"
)

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_interactome_analysis.R, lines 594-596.
as_numeric_safe <- function(x) {
  suppressWarnings(readr::parse_number(as.character(x)))
}

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_interactome_analysis.R, lines 598-661.
hyperlp_annotation <- hyperlp %>%
  mutate(
    tagm_mcmc_probability_numeric = as_numeric_safe(tagm.mcmc.probability),
    tagm_mcmc_allocation_pred_numeric = as_numeric_safe(tagm.mcmc.allocation.pred),
    hyperlp_allocation_resolved = case_when(
      tagm.mcmc.allocation %in% known_hyperlp_locations ~ tagm.mcmc.allocation,
      tagm.mcmc.probability %in% known_hyperlp_locations ~ tagm.mcmc.probability,
      tagm.mcmc.probability.lowerquantile %in% known_hyperlp_locations ~ tagm.mcmc.probability.lowerquantile,
      tagm.mcmc.allocation.pred %in% known_hyperlp_locations ~ tagm.mcmc.allocation.pred,
      tagm.map.allocation %in% known_hyperlp_locations ~ tagm.map.allocation,
      tagm.map.probability %in% known_hyperlp_locations ~ tagm.map.probability,
      tagm.map.outlier %in% known_hyperlp_locations ~ tagm.map.outlier,
      TRUE ~ NA_character_
    )
  ) %>%
  transmute(
    gene = hyperlp_gene_id,
    hyperlp_accession = Accession,
    hyperlp_description = Description,
    hyperlp_allocation = hyperlp_allocation_resolved,
    hyperlp_allocation_probability = coalesce(tagm_mcmc_probability_numeric, tagm_mcmc_allocation_pred_numeric),
    hyperlp_loc_probability = as_numeric_safe(tagm.mcmc.loc.prob),
    hyperlp_apical_probability = coalesce(as_numeric_safe(`tagm.mcmc.joint.apical.1`), 0) +
      coalesce(as_numeric_safe(`tagm.mcmc.joint.apical.2`), 0),
    hyperlp_microneme_probability = coalesce(as_numeric_safe(`tagm.mcmc.joint.micronemes`), 0),
    hyperlp_rhoptry_probability = coalesce(as_numeric_safe(`tagm.mcmc.joint.rhoptries.1`), 0) +
      coalesce(as_numeric_safe(`tagm.mcmc.joint.rhoptries.2`), 0),
    hyperlp_dense_granule_probability = coalesce(as_numeric_safe(`tagm.mcmc.joint.dense.granules`), 0),
    hyperlp_pm_probability = coalesce(as_numeric_safe(`tagm.mcmc.joint.PM.integral`), 0) +
      coalesce(as_numeric_safe(`tagm.mcmc.joint.PM.peripheral.1`), 0) +
      coalesce(as_numeric_safe(`tagm.mcmc.joint.PM.peripheral.2`), 0),
    hyperlp_tubulin_cytoskeleton_probability = coalesce(as_numeric_safe(`tagm.mcmc.joint.tubulin.cytoskeleton`), 0),
    hyperlp_imc_probability = coalesce(as_numeric_safe(`tagm.mcmc.joint.IMC`), 0),
    num_tmds_tmhmm = as_numeric_safe(Num.TMDs.TMHMM),
    signalp5 = str_to_upper(str_squish(as.character(SignalP5.0))),
    num_tmds_sp_corrected = as_numeric_safe(Num.TMDs.SP.corrected),
    hyperlp_crispr_score = as_numeric_safe(CRISPR.Score),
    hyperlp_conservation_score = as_numeric_safe(Conservation.score),
    hyperlp_conservation_profile = na_if(str_squish(as.character(Assigned.conservation.profile)), ""),
    apical_flag = str_detect(hyperlp_allocation, "^apical") | hyperlp_apical_probability >= 0.5,
    microneme_flag = hyperlp_allocation == "micronemes" | hyperlp_microneme_probability >= 0.5,
    rhoptry_flag = str_detect(hyperlp_allocation, "^rhoptries") | hyperlp_rhoptry_probability >= 0.5,
    dense_granule_flag = hyperlp_allocation == "dense granules" | hyperlp_dense_granule_probability >= 0.5,
    secretory_organelle_flag = microneme_flag | rhoptry_flag | dense_granule_flag,
    imc_or_cytoskeleton_flag = hyperlp_allocation %in% c("IMC", "tubulin cytoskeleton") |
      hyperlp_imc_probability >= 0.5 |
      hyperlp_tubulin_cytoskeleton_probability >= 0.5,
    apical_secretory_cytoskeleton_flag = apical_flag |
      secretory_organelle_flag |
      imc_or_cytoskeleton_flag,
    pm_surface_flag = str_detect(hyperlp_allocation, "^PM") | hyperlp_pm_probability >= 0.5,
    signalp_flag = signalp5 %in% c("SP", "TRUE"),
    has_tmd_flag = coalesce(num_tmds_tmhmm, 0) > 0 |
      coalesce(num_tmds_sp_corrected, 0) > 0,
    multi_tmd_flag = pmax(coalesce(num_tmds_tmhmm, 0), coalesce(num_tmds_sp_corrected, 0)) >= 2,
    secretory_or_membrane_feature = signalp_flag | has_tmd_flag,
    coccidia_or_toxo_restricted_flag = str_detect(
      hyperlp_conservation_profile,
      "Toxoplasma/Hammondia|Coccidia"
    ) & !str_detect(hyperlp_conservation_profile, "Plasmodium|Piroplasms"),
    broadly_conserved_flag = str_detect(hyperlp_conservation_profile, "SAR|Other eukaryotes") |
      hyperlp_conservation_score >= 0.9,
    microneme_surface_like_proxy = microneme_flag & secretory_or_membrane_feature
  )

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_interactome_analysis.R, lines 663-672.
crispr_rank <- suppressWarnings(readxl::read_excel(crispr_file, sheet = "Sheet1")) %>%
  transmute(
    crispr_gt1_id = ID,
    crispr_description = `Protein desprition`,
    crispr_rank = `Rank numbers`,
    crispr_mean_phenotype = `mean phenotype`,
    crispr_rank_percentile = crispr_rank / max(crispr_rank, na.rm = TRUE),
    crispr_top20pct = crispr_rank_percentile <= 0.2,
    crispr_top10pct = crispr_rank_percentile <= 0.1
  )

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_interactome_analysis.R, lines 674-685.
annotated_candidates <- candidate_summary %>%
  mutate(
    gene_numeric_id = str_match(gene, "^TGME49_(\\d+)")[, 2],
    crispr_gt1_id = if_else(!is.na(gene_numeric_id), paste0("TGGT1_", gene_numeric_id), NA_character_)
  ) %>%
  left_join(hyperlp_annotation, by = "gene") %>%
  left_join(crispr_rank, by = "crispr_gt1_id") %>%
  mutate(
    has_hyperlp_annotation = !is.na(hyperlp_allocation),
    has_crispr_rank = !is.na(crispr_rank),
    candidate_class = if_else(rapa_enrichment_candidate, "FDR candidate", "background")
  )

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_interactome_analysis.R, lines 687-688.
enrichment_universe <- annotated_candidates %>%
  filter(science_peptide_filter, has_hyperlp_annotation)

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_interactome_analysis.R, lines 690-723.
fisher_for_flag <- function(
  data,
  flag_col,
  feature_label = flag_col,
  feature_family = "Localization/feature",
  universe_label = "HyperLp-annotated peptide-filtered proteins"
) {
  flag <- data[[flag_col]]
  hit <- data$rapa_enrichment_candidate
  complete <- !is.na(flag) & !is.na(hit)
  tab <- table(hit = hit[complete], flag = flag[complete])
  for (rn in c("FALSE", "TRUE")) {
    if (!rn %in% rownames(tab)) tab <- rbind(tab, setNames(c(0, 0), colnames(tab)))
  }
  for (cn in c("FALSE", "TRUE")) {
    if (!cn %in% colnames(tab)) tab <- cbind(tab, setNames(c(0, 0), cn))
  }
  tab <- tab[c("FALSE", "TRUE"), c("FALSE", "TRUE")]
  ft <- fisher.test(tab, alternative = "greater")
  tibble::tibble(
    feature = flag_col,
    feature_label = feature_label,
    feature_family = feature_family,
    universe = universe_label,
    candidates_with_feature = unname(tab["TRUE", "TRUE"]),
    candidates_total = sum(tab["TRUE", ]),
    background_with_feature = unname(tab["FALSE", "TRUE"]),
    background_total = sum(tab["FALSE", ]),
    candidate_fraction = if_else(candidates_total > 0, candidates_with_feature / candidates_total, NA_real_),
    background_fraction = if_else(background_total > 0, background_with_feature / background_total, NA_real_),
    odds_ratio = unname(ft$estimate),
    p_value = ft$p.value
  )
}

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_interactome_analysis.R, lines 725-726.
crispr_enrichment_universe <- annotated_candidates %>%
  filter(science_peptide_filter, has_crispr_rank)

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_interactome_analysis.R, lines 728-745.
feature_tests <- tibble::tribble(
  ~feature, ~feature_label, ~feature_family, ~universe_label,
  "apical_flag", "Apical", "Localization", "HyperLp-annotated peptide-filtered proteins",
  "microneme_flag", "Microneme", "Localization", "HyperLp-annotated peptide-filtered proteins",
  "microneme_surface_like_proxy", "Microneme + SignalP/TMD", "Localization + structure", "HyperLp-annotated peptide-filtered proteins",
  "rhoptry_flag", "Rhoptry", "Localization", "HyperLp-annotated peptide-filtered proteins",
  "dense_granule_flag", "Dense granule", "Localization", "HyperLp-annotated peptide-filtered proteins",
  "secretory_organelle_flag", "Secretory organelle", "Localization", "HyperLp-annotated peptide-filtered proteins",
  "apical_secretory_cytoskeleton_flag", "Apical/secretory/cytoskeleton", "Localization", "HyperLp-annotated peptide-filtered proteins",
  "imc_or_cytoskeleton_flag", "IMC/cytoskeleton", "Localization", "HyperLp-annotated peptide-filtered proteins",
  "pm_surface_flag", "PM surface-like", "Localization", "HyperLp-annotated peptide-filtered proteins",
  "signalp_flag", "Signal peptide", "Structure", "HyperLp-annotated peptide-filtered proteins",
  "has_tmd_flag", "Any TMD", "Structure", "HyperLp-annotated peptide-filtered proteins",
  "multi_tmd_flag", ">=2 TMDs", "Structure", "HyperLp-annotated peptide-filtered proteins",
  "secretory_or_membrane_feature", "SignalP/TMD", "Structure", "HyperLp-annotated peptide-filtered proteins",
  "coccidia_or_toxo_restricted_flag", "Coccidia/Toxo-biased", "Conservation", "HyperLp-annotated peptide-filtered proteins",
  "broadly_conserved_flag", "Broadly conserved", "Conservation", "HyperLp-annotated peptide-filtered proteins"
)

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_interactome_analysis.R, lines 747-776.
feature_enrichment <- bind_rows(
  lapply(seq_len(nrow(feature_tests)), function(i) {
    fisher_for_flag(
      enrichment_universe,
      feature_tests$feature[[i]],
      feature_tests$feature_label[[i]],
      feature_tests$feature_family[[i]],
      feature_tests$universe_label[[i]]
    )
  }),
  fisher_for_flag(
    crispr_enrichment_universe,
    "crispr_top20pct",
    "CRISPR top 20%",
    "Essentiality",
    "CRISPR-mapped peptide-filtered proteins"
  ),
  fisher_for_flag(
    crispr_enrichment_universe,
    "crispr_top10pct",
    "CRISPR top 10%",
    "Essentiality",
    "CRISPR-mapped peptide-filtered proteins"
  )
) %>%
  mutate(
    fdr_bh = p.adjust(p_value, method = "BH")
  )

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_interactome_analysis.R, lines 778-783.
safe_wilcox_p <- function(x, y, alternative = "less") {
  x <- x[is.finite(x)]
  y <- y[is.finite(y)]
  if (length(x) < 1 || length(y) < 1) return(NA_real_)
  wilcox.test(x, y, alternative = alternative)$p.value
}

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_interactome_analysis.R, lines 785-817.
crispr_compare <- annotated_candidates %>%
  filter(science_peptide_filter) %>%
  summarise(
    candidate_n = sum(rapa_enrichment_candidate),
    background_n = sum(!rapa_enrichment_candidate),
    candidate_with_gt1_rank_n = sum(rapa_enrichment_candidate & has_crispr_rank),
    background_with_gt1_rank_n = sum(!rapa_enrichment_candidate & has_crispr_rank),
    candidate_median_rank = median(crispr_rank[rapa_enrichment_candidate], na.rm = TRUE),
    background_median_rank = median(crispr_rank[!rapa_enrichment_candidate], na.rm = TRUE),
    candidate_median_percentile = median(crispr_rank_percentile[rapa_enrichment_candidate], na.rm = TRUE),
    background_median_percentile = median(crispr_rank_percentile[!rapa_enrichment_candidate], na.rm = TRUE),
    candidate_median_mean_phenotype = median(crispr_mean_phenotype[rapa_enrichment_candidate], na.rm = TRUE),
    background_median_mean_phenotype = median(crispr_mean_phenotype[!rapa_enrichment_candidate], na.rm = TRUE),
    wilcox_rank_p_lower = safe_wilcox_p(
      crispr_rank[rapa_enrichment_candidate],
      crispr_rank[!rapa_enrichment_candidate],
      alternative = "less"
    ),
    wilcox_phenotype_p_lower = safe_wilcox_p(
      crispr_mean_phenotype[rapa_enrichment_candidate],
      crispr_mean_phenotype[!rapa_enrichment_candidate],
      alternative = "less"
    ),
    candidate_with_hyperlp_crispr_n = sum(rapa_enrichment_candidate & is.finite(hyperlp_crispr_score)),
    background_with_hyperlp_crispr_n = sum(!rapa_enrichment_candidate & is.finite(hyperlp_crispr_score)),
    candidate_median_hyperlp_crispr_score = median(hyperlp_crispr_score[rapa_enrichment_candidate], na.rm = TRUE),
    background_median_hyperlp_crispr_score = median(hyperlp_crispr_score[!rapa_enrichment_candidate], na.rm = TRUE),
    wilcox_hyperlp_crispr_p_lower = safe_wilcox_p(
      hyperlp_crispr_score[rapa_enrichment_candidate],
      hyperlp_crispr_score[!rapa_enrichment_candidate],
      alternative = "less"
    )
  )

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_interactome_analysis.R, lines 819-853.
compare_continuous_feature <- function(
  data,
  value_col,
  feature_label,
  feature_family,
  alternative = "two.sided",
  direction_note = "two-sided"
) {
  value <- data[[value_col]]
  hit <- data$rapa_enrichment_candidate
  x <- value[hit]
  y <- value[!hit]
  x <- x[is.finite(x)]
  y <- y[is.finite(y)]
  p <- if (length(x) >= 1 && length(y) >= 1) {
    wilcox.test(x, y, alternative = alternative)$p.value
  } else {
    NA_real_
  }

  tibble::tibble(
    feature = value_col,
    feature_label = feature_label,
    feature_family = feature_family,
    test = "Wilcoxon rank-sum",
    alternative = direction_note,
    candidate_n = length(x),
    background_n = length(y),
    candidate_median = median(x, na.rm = TRUE),
    background_median = median(y, na.rm = TRUE),
    candidate_mean = mean(x, na.rm = TRUE),
    background_mean = mean(y, na.rm = TRUE),
    p_value = p
  )
}

# Adapted from Fig6_ICAT_interactome/03_code/interactome/Figure6_interactome_analysis.R, lines 855-905.
continuous_feature_compare <- bind_rows(
  compare_continuous_feature(
    annotated_candidates %>% filter(science_peptide_filter),
    "molecular_weight_kda",
    "Molecular weight",
    "Protein properties"
  ),
  compare_continuous_feature(
    annotated_candidates %>% filter(science_peptide_filter),
    "protein_length_aa",
    "Protein length",
    "Protein properties"
  ),
  compare_continuous_feature(
    annotated_candidates %>% filter(science_peptide_filter, has_hyperlp_annotation),
    "num_tmds_sp_corrected",
    "SP-corrected TMD count",
    "Structure"
  ),
  compare_continuous_feature(
    annotated_candidates %>% filter(science_peptide_filter, has_hyperlp_annotation),
    "hyperlp_conservation_score",
    "Conservation score",
    "Conservation"
  ),
  compare_continuous_feature(
    annotated_candidates %>% filter(science_peptide_filter, has_crispr_rank),
    "crispr_rank_percentile",
    "CRISPR rank percentile",
    "Essentiality",
    alternative = "less",
    direction_note = "candidate lower than background"
  ),
  compare_continuous_feature(
    annotated_candidates %>% filter(science_peptide_filter, has_crispr_rank),
    "crispr_mean_phenotype",
    "CRISPR mean phenotype",
    "Essentiality",
    alternative = "less",
    direction_note = "candidate lower than background"
  ),
  compare_continuous_feature(
    annotated_candidates %>% filter(science_peptide_filter, has_hyperlp_annotation),
    "hyperlp_crispr_score",
    "HyperLp CRISPR score",
    "Essentiality",
    alternative = "less",
    direction_note = "candidate lower than background"
  )
) %>%
  mutate(fdr_bh = p.adjust(p_value, method = "BH"))

write_table(candidate_summary,"Figure6_interactome_candidate_summary.csv")
write_table(annotated_candidates,"Figure6_interactome_candidate_summary_with_database_annotations.csv")
write_table(sample_qc,"Figure6_interactome_sample_qc.csv")
write_table(paired_enrichment,"Figure6_interactome_paired_enrichment.csv")
write_table(feature_enrichment,"Figure6_interactome_feature_enrichment.csv")
write_table(continuous_feature_compare,"Figure6_interactome_continuous_feature_compare.csv")
