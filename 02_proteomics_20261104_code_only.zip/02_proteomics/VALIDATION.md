# Validation

Validation date: 2026-11-04. Performed locally using R 4.5.0 and the recorded package versions.

This module completed 5 positive task/configuration runs from an external working directory. It has 13 retained numerical comparison/consistency checks.

| Check | Result | Rows or matched cells |
|---|---|---:|
|CF5: CF5_all_protein_statistics_and_annotations.csv|matched|2074|
|CF5: CF5_top12_FDR_significant_hits.csv|matched|12|
|CF5 QC correlation|matched|36|
|CF5 QC PCA|matched|6|
|CF5 QC peptide detection|matched|6|
|full length: Figure6_interactome_candidate_summary.csv|matched|2536|
|full length: Figure6_interactome_candidate_summary_with_database_annotations.csv|matched|2536|
|full length: Figure6_interactome_sample_qc.csv|matched|4|
|N terminal: Figure6_ICAT_N_term_quantified_proteins_annotated.csv|matched|3491|
|N terminal: Figure6_ICAT_N_term_category_tests.csv|matched|14|
|N terminal: Figure6_ICAT_N_term_top_rank_recovery.csv|matched|56|
|construct comparison numeric source|matched|42|
|construct preference interpretation|matched|26|

Comparisons use the same external inputs as the original numerical exports. Shared numerical fields are compared with relative tolerance 1e-9 and absolute tolerance 1e-12; missing patterns, keys and categorical fields are checked separately. PCoA geometry is checked independently of axis signs/rotation. Input snapshots, expected result tables, negative-test fixtures and generated results are not included in this package.

All five package entry points, missing-file handling, unknown-task handling and refusal to write inside the code package were checked. Domain checks cover missing fields and duplicate identifiers for every module, plus nonbinary class/presence values and the full-length-to-N-terminal handoff. All checks passed.

349 original external input files retained their pre-run SHA-256 hashes. Package syntax and runtime dependencies were checked. A fresh network/environment installation was not performed; validation reused the installed matching R environment. These tests do not establish availability or redistribution rights for the external datasets.

The construct-preference branch is retained as exploratory and needs author selection before being described as the final Fig. 3e release. The candidate/annotation calculations are verified, while graphic assembly is intentionally excluded.
